const Rollback = artifacts.require( "./Rollback.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Rollback" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6dE20D9d444354Ff9B271A6Ea6f9274F2467df35", "0xD850942eF8811f2A866692A623011bDE52a462C1", "0x5cd9f1c602CA78444142568958151027b1334d36", "0x49e0D69ADA66A1daa235315d9E2c822183119e3c", "0xc1c828dE7733D6025200042783285A61B9895eB2", "0xC5cc4644c3B9cCca30c3e9a2D21651B795a96a89", "0x0DF1f2b5ddaA7946CB78Dd1Fa7109Cb6a05e42f3", "0xD0E543ca83ad0b81A85eC5881114B71bb48860Ce", "0x6A67f70686D9E3C8f475CFA792D35245e3bF07a7", "0x65eFAA289fd2B85Bab5b8C0DF33148b05C27F96a", "0x134695A70a231F06961caF5627c55b9Fdc0f6A02", "0x5C3E219d680A054Cd1ed68ae44e043839fb0e382", "0x0776257B04000a0B85F294575D37134aE043F667", "0x07D6aE1bf42Ef612A862eAdAC1149bC06b34571a", "0x87F4ec71Df913b67B3d3fe6973D3c54065fc6488", "0x67C95fBcAE618e33b68AD0A345528B1C5913E5af", "0xa89191001AD92d8744B0523C1915DCbdd0148e68", "0xB273d19B969048FE293aE19C81522A64dFF217b5", "0x3c1dC86E40B7673dF95bB39496146CE3C3973625", "0x8325e604cFb88f2813fA4d84c1C85223F92dDFFF", "0x14C94F79d4ab175984Ea0d605ac744e17C999e76", "0x233D2a3D6B4c2302845190DeE9E82fE66E964e15", "0x6bA8F4C5fA2c5F39Cb706dE32a8c3fab68d364c3", "0x1f53Cd8160FC0e18D091caBc4d2eD6837e4daed4", "0x001E9f07AcAa1C952b7E440a0ba0419dd67B28fF", "0xD3705D24d96D19f2f9230426d0503716f66D74e5", "0xC72C2AaE3Fb9B076eD4cCe2147d033a1aD880138", "0x3E1748fe842A7421eAAD23854831d5c17B40F1Ca", "0x473623E9980195179495662a297E9f3B0459a36d", "0xdD5aE2a233Fa7AD24EC431a443D97a32971601Fa", "0xBE37AB5c88B56172BaE3348AB9D095ad740425b2", "0x3FaB3bA4724fAC00baC3Fe256C223bf8dC0D2584", "0x840C59F8f0547f2eed4539B69a408914A78E3a9E", "0x00593f8Bd480C885486b893362551B601C9e5aD2", "0x09EEEF68e335BA48b6cd56090F8d22184B20a4b3", "0x0952e83e5f2e73674D771C32E7E64F63e328Aa9e", "0x02e9B363C0117D142b2B5dCd495fBc40179b6201", "0x7ec82728f50ac4aCeB98caf5f386FE25fDBF0C8B", "0xdbEA615bf6C26E595517645DEc43Ada12E01f7D1", "0xE8fA669978eE39C3D57f693C47ad3296736C6A86", "0xc562B9310436D9fA01ED015E481458894d4cC9A1", "0x5C0c7D6a401e8c5C75f9089c7391547B4446080F", "0x8C3269824e0aeE47bB238bAc87b2f92DE7a7B786", "0x43d88E3C6AbD13F4c32757b900b25c2117D4e21C", "0x00Af7Cd420B5fa9DdC81c01A734cD04988540c8a", "0xFc10CaE24414b1206accd748Bcc89020695881EC", "0xE9f754708FC7FF60BF18e675119a5C0A3e30dd50", "0x00ec0f22f8267C107550F323B29493688f41d2b7", "0x6DcAbD1308Fb517d2A862bAc24560B46da5963Ed", "0x58c3d7d551D4BD0fE926f1C5cbD6C2787711c119"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalSetCredit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_account", type: "address"}], name: "getCredit", outputs: [{name: "total", type: "uint256"}, {name: "used", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalReturnedCredit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "who", type: "address"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "ethAmount", type: "uint256"}], name: "onReturned", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onSetCredit(address,uint256)", "onReturned(address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcc9fd9d90de7a2135149a968c984dafeac1083f781875a525248b63d9a4f574d", "0x9a84792b61ff7122b8808b79ec079ef0da4de94236873c973605e4c98a27f1e2"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4247323 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4247928 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Rollback", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalSetCredit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSetCredit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getCredit", outputs: [{name: "total", type: "uint256"}, {name: "used", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCredit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalReturnedCredit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalReturnedCredit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Rollback", function( accounts ) {

	it( "TEST: Rollback(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4247323", timeStamp: "1504769637", hash: "0xa1eed49ba79f0c353c166d5da0f85017ba5e83950497ee5d7a01a9875dd6837f", nonce: "13", blockHash: "0x0e5a199973da7d37b2ab2d6f972934608b4008be335e09678825ed1fa6c03dc1", transactionIndex: "55", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: 0, value: "0", gas: "795443", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xe7058e15", contractAddress: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", cumulativeGasUsed: "4041551", gasUsed: "662869", confirmations: "3457223"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Rollback", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Rollback.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1504769637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Rollback.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[5], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4247531", timeStamp: "1504774870", hash: "0x255fe79fd9db75f841b47ebec50888fd0fc266c689b123b7bf5341bd49b56fa1", nonce: "14", blockHash: "0x62406029b55a7b6f10283737d76a3e183435b34fd28dd75dabccc21019ea71ec", transactionIndex: "130", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "32000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000049e0d69ada66a1daa235315d9e2c822183119e3c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4460755", gasUsed: "71107", confirmations: "3457015"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[5]}, {type: "uint256", name: "_amount", value: "1"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[5], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1504774870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x49e0d69ada66a1daa235315d9e2c822183119e3c"}, {name: "amount", type: "uint256", value: "1"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[5], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4247568", timeStamp: "1504775776", hash: "0x23ae2578ac3115e858113cf1909db6fb59c453eff8ca6949240c5e8158adbd3e", nonce: "15", blockHash: "0xa15ff1bb6823fc1fef2df431a9c39d5a05ac3f4a12fafdbe144ca8ba1c052c36", transactionIndex: "64", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "32000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000049e0d69ada66a1daa235315d9e2c822183119e3c0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2173690", gasUsed: "41427", confirmations: "3456978"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[5]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[5], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1504775776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x49e0d69ada66a1daa235315d9e2c822183119e3c"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4247573", timeStamp: "1504775923", hash: "0x2ecbb9574d8c5676416b6ae1c7c53c7e046b2e0ed1640518233971889b8c44f4", nonce: "16", blockHash: "0xfdbfd4d13778dcbe637e136566851b6895377215ed5b82328020822146369d0b", transactionIndex: "19", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "10000000000000000", gas: "90000", gasPrice: "48584539050", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1294774", gasUsed: "21051", confirmations: "3456973"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1504775923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[6], \"1207500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247700", timeStamp: "1504779206", hash: "0x699df74a250c2521793d02a6c9e2000628d737d9ac123d4542b79fa044f40e99", nonce: "17", blockHash: "0x93c1ab6f62fc803cec837e821e7bbdd917a3bbae7ece75f7bb7fc7f86d01dd06", transactionIndex: "142", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000c1c828de7733d6025200042783285a61b9895eb2000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "3931964", gasUsed: "56491", confirmations: "3456846"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[6]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[6], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1504779206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xc1c828de7733d6025200042783285a61b9895eb2"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[7], \"1207500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247707", timeStamp: "1504779357", hash: "0x7079cd25ef755cd98ff7883489877381a545153df0ca47f58574bab65230f0fb", nonce: "18", blockHash: "0x8ff29eb0cb04569b9ad216db0603e9c08d92a5ecf10a44aab3dbe663697d498e", transactionIndex: "0", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000c5cc4644c3b9ccca30c3e9a2d21651b795a96a89000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "56555", gasUsed: "56555", confirmations: "3456839"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[7]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[7], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1504779357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xc5cc4644c3b9ccca30c3e9a2d21651b795a96a89"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[8], \"3823750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247710", timeStamp: "1504779410", hash: "0x320631c5ab43fe3b88d118f12d2bece486eb15df9e79483705d0412a24c97926", nonce: "19", blockHash: "0x4fd0b7580278dc5e997886db692b819d54b6e180b7d8bd7f2a14e08f6cac6f64", transactionIndex: "77", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000000df1f2b5ddaa7946cb78dd1fa7109cb6a05e42f3000000000000000000000000000000000000000000000818dbe94b0ad7060000", contractAddress: "", cumulativeGasUsed: "4119774", gasUsed: "56555", confirmations: "3456836"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[8]}, {type: "uint256", name: "_amount", value: "38237500000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[8], "38237500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1504779410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x0df1f2b5ddaa7946cb78dd1fa7109cb6a05e42f3"}, {name: "amount", type: "uint256", value: "38237500000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[9], \"1207500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247711", timeStamp: "1504779420", hash: "0x810f236d541d9856d0c15d674609a8c8353401823e6337b2907fb902d1a7bbf9", nonce: "20", blockHash: "0x6d347b6464a77a373caa83e223e6caaab61fce401fb7ca6275879965889c7bec", transactionIndex: "56", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000d0e543ca83ad0b81a85ec5881114b71bb48860ce000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "3405187", gasUsed: "56555", confirmations: "3456835"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[9]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[9], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1504779420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xd0e543ca83ad0b81a85ec5881114b71bb48860ce"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[10], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247725", timeStamp: "1504779804", hash: "0x497c357891c4883447b2c0d8ebdb616cf21d9bbf3c14e5f72d87e9ebab0dc779", nonce: "21", blockHash: "0x74b5ac99c5dfdbd9e152275b63d5e2ca5cc3d8750da979ea2f5892790629cb20", transactionIndex: "160", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000006a67f70686d9e3c8f475cfa792d35245e3bf07a7000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6649651", gasUsed: "56555", confirmations: "3456821"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[10]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[10], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1504779804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x6a67f70686d9e3c8f475cfa792d35245e3bf07a7"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[11], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247727", timeStamp: "1504779836", hash: "0xb390565729632b766f272106feaa49098530c0a01181dfe1c6d40b164c511f37", nonce: "22", blockHash: "0x2d7838776690d8f838d1945fe038af4d0f827984ae679320d75e318a31216504", transactionIndex: "101", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000065efaa289fd2b85bab5b8c0df33148b05c27f96a000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4325243", gasUsed: "56555", confirmations: "3456819"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[11]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[11], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1504779836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x65efaa289fd2b85bab5b8c0df33148b05c27f96a"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[12], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247734", timeStamp: "1504780033", hash: "0x2f3d6ac5184a061dedfb6b2e24a32911cab4ba2151806a6e710c04de16cb9dc9", nonce: "23", blockHash: "0x18b56ed15d8aa02c35a1011e42bbb78e237f10ffe9da72f0262df957099e03ca", transactionIndex: "134", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000134695a70a231f06961caf5627c55b9fdc0f6a02000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "3277695", gasUsed: "56555", confirmations: "3456812"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[12]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[12], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1504780033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x134695a70a231f06961caf5627c55b9fdc0f6a02"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[13], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247736", timeStamp: "1504780048", hash: "0x1ca70a3869ac91c4ad20bebf473cf093e267ac841538939006b646345529eb84", nonce: "24", blockHash: "0x2ef04082f7588965f22d8d7c338046b2b4880d3dee6d9a32aab8ffbc8d38fee8", transactionIndex: "98", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000005c3e219d680a054cd1ed68ae44e043839fb0e382000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6548800", gasUsed: "56555", confirmations: "3456810"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[13]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[13], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1504780048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x5c3e219d680a054cd1ed68ae44e043839fb0e382"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[14], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247739", timeStamp: "1504780123", hash: "0x53cec90e8e97d7c3fc901a5dce24716dcc4e998f072ab8a66318d85768a1c15e", nonce: "25", blockHash: "0x3199c0d7212df59aa3e3962324261149df46d34ba267c7558d900f75a02cebb7", transactionIndex: "129", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000000776257b04000a0b85f294575d37134ae043f667000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5089576", gasUsed: "56491", confirmations: "3456807"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[14]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[14], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1504780123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x0776257b04000a0b85f294575d37134ae043f667"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[15], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247742", timeStamp: "1504780159", hash: "0x473716b4d0ab88977d0f9af67950167b357670291c901a1b5d7d2c6407004be3", nonce: "26", blockHash: "0xa8efe82884fd9ee30e16a6e31ef393537a2b3e622c0703ef5cf283130787751e", transactionIndex: "81", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000007d6ae1bf42ef612a862eadac1149bc06b34571a000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4015564", gasUsed: "56555", confirmations: "3456804"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[15]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[15], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1504780159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x07d6ae1bf42ef612a862eadac1149bc06b34571a"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[16], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247743", timeStamp: "1504780199", hash: "0x00bd25e4eed7680d742e07e17b7207c6355f41ff107ea7cd69e826b7ce187aaf", nonce: "27", blockHash: "0x169869d05ab9f869e44fd3acb204f8e45db24e5886601b4baed0d0a7667de948", transactionIndex: "181", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000087f4ec71df913b67b3d3fe6973d3c54065fc6488000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6649782", gasUsed: "56555", confirmations: "3456803"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[16]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[16], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1504780199 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x87f4ec71df913b67b3d3fe6973d3c54065fc6488"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[17], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247744", timeStamp: "1504780214", hash: "0x44eaa017dd682aeea2a98a89d271b74d17f7bbd62122ef6fedfe99bae184fe0a", nonce: "28", blockHash: "0xe0ca1c82522146869d5e05053dcbe2f59737a0bfb67476d17876ef8eabe3f8d5", transactionIndex: "94", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000067c95fbcae618e33b68ad0a345528b1c5913e5af000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4632325", gasUsed: "56555", confirmations: "3456802"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[17]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[17], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1504780214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x67c95fbcae618e33b68ad0a345528b1c5913e5af"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[18], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247752", timeStamp: "1504780445", hash: "0x5b85368004a4b6d0e56d2361a728a0792b57707bda7ce3e81184e3ff6c1e1499", nonce: "29", blockHash: "0x496c398dab591c7ea977d5236c7c5d0c179ea5f74dc8a9490e4bc0df5f7b909a", transactionIndex: "63", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000a89191001ad92d8744b0523c1915dcbdd0148e68000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4562242", gasUsed: "56491", confirmations: "3456794"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[18]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[18], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1504780445 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xa89191001ad92d8744b0523c1915dcbdd0148e68"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[19], \"966000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247754", timeStamp: "1504780469", hash: "0xd48fc9f7f2b26bcf9cce4f996a4fd59e47234704111d5af30ce711aa1f9a91cf", nonce: "30", blockHash: "0xd443ee843200332df554b436b09f99a2e499a338b735c6c131769d87e4542157", transactionIndex: "107", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000b273d19b969048fe293ae19c81522a64dff217b5000000000000000000000000000000000000000000001474b24d5f43ce600000", contractAddress: "", cumulativeGasUsed: "6529949", gasUsed: "56555", confirmations: "3456792"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[19]}, {type: "uint256", name: "_amount", value: "96600000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[19], "96600000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1504780469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xb273d19b969048fe293ae19c81522a64dff217b5"}, {name: "amount", type: "uint256", value: "96600000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[20], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247755", timeStamp: "1504780470", hash: "0x824aba7a8f2bba6cef1f082139f6b955064dd804d58c929d6f354a02635396dd", nonce: "31", blockHash: "0xd9940021fb96a06126a21dd31bc3237cf84133a6296d4ce7e7991f6cdfecb56f", transactionIndex: "38", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000003c1dc86e40b7673df95bb39496146ce3c3973625000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "2630827", gasUsed: "56555", confirmations: "3456791"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[20]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[20], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1504780470 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x3c1dc86e40b7673df95bb39496146ce3c3973625"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[21], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247756", timeStamp: "1504780484", hash: "0x373f56afb569de5d020de2253f2721ecfc133e18244f7d8e1f3dcc4af40232d0", nonce: "32", blockHash: "0x57e686d14c84d8578e1ac50408e79fe5b4bdace1de14f3222273e3739f14c404", transactionIndex: "99", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000008325e604cfb88f2813fa4d84c1c85223f92ddfff000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4957511", gasUsed: "56555", confirmations: "3456790"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[21]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[21], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1504780484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x8325e604cfb88f2813fa4d84c1c85223f92ddfff"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[22], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247758", timeStamp: "1504780543", hash: "0x8582b041f4f7a25ac493b3065da9a0aef3caa47f83ccae4b3e603e817e9062c7", nonce: "33", blockHash: "0x439b2f52986ab2785a546a76a7cf7150a71d6f5298c693f758a77791a9c8c9b3", transactionIndex: "139", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000014c94f79d4ab175984ea0d605ac744e17c999e76000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "3821404", gasUsed: "56555", confirmations: "3456788"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[22]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[22], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1504780543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x14c94f79d4ab175984ea0d605ac744e17c999e76"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[23], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247760", timeStamp: "1504780567", hash: "0xa3d565f39a7f0ab64d15d027d500e2724823312c43cc52968f48d515efe084bb", nonce: "34", blockHash: "0x69dddb8df0ba6aca82a8ef93a38700284e6f1b30acb1583d4eaddf8022884010", transactionIndex: "103", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000233d2a3d6b4c2302845190dee9e82fe66e964e15000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4815453", gasUsed: "56555", confirmations: "3456786"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[23]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[23], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1504780567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x233d2a3d6b4c2302845190dee9e82fe66e964e15"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[24], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247761", timeStamp: "1504780602", hash: "0x06eedc1e532264b939bbcb4f16f055eea9ae9d1c6d416dce35e1be2d51373af2", nonce: "35", blockHash: "0x7fa9635d9bdab226f4dd5e44fba733986264444f67a6a8cfe27b1170e5f97e71", transactionIndex: "164", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000006ba8f4c5fa2c5f39cb706de32a8c3fab68d364c3000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6560573", gasUsed: "56555", confirmations: "3456785"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[24]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[24], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1504780602 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x6ba8f4c5fa2c5f39cb706de32a8c3fab68d364c3"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[25], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247764", timeStamp: "1504780703", hash: "0x41c51b103b0408e2f7a89ef682ce0c937271bf54e70ffb6b80decdd5994a93e0", nonce: "36", blockHash: "0xc7114695a3cba9b5387c0b1b1c4245bfd0de3d4b97e6914f7e98bc4991fd0b06", transactionIndex: "226", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000001f53cd8160fc0e18d091cabc4d2ed6837e4daed4000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5393023", gasUsed: "56555", confirmations: "3456782"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[25]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[25], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1504780703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x1f53cd8160fc0e18d091cabc4d2ed6837e4daed4"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[26], \"120387475965156225000... )", async function( ) {
		const txOriginal = {blockNumber: "4247777", timeStamp: "1504780977", hash: "0x446b059efecaa5601d36d87f6dd7b9c001d26d79d5161572ea91487d8d2aca48", nonce: "37", blockHash: "0x54bbf658553b77be4cdfac02476563cea60eccdca35378e50c2efaa3d018b854", transactionIndex: "111", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000001e9f07acaa1c952b7e440a0ba0419dd67b28ff00000000000000000000000000000000000000000000197e37d89e20156d2240", contractAddress: "", cumulativeGasUsed: "2719504", gasUsed: "56619", confirmations: "3456769"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[26]}, {type: "uint256", name: "_amount", value: "120387475965156225000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[26], "120387475965156225000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1504780977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x001e9f07acaa1c952b7e440a0ba0419dd67b28ff"}, {name: "amount", type: "uint256", value: "120387475965156225000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[27], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247778", timeStamp: "1504780989", hash: "0x048b8d34f3b90b1c3e97d92ff9d7aecc4e7a7e2b2fe0bd49d03005c569482255", nonce: "38", blockHash: "0x5ee578d2238d182bd210d0506ddee3a131bf166e10fe39602418fc9fdaafb66d", transactionIndex: "89", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000d3705d24d96d19f2f9230426d0503716f66d74e5000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4791434", gasUsed: "56555", confirmations: "3456768"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[27]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[27], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1504780989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xd3705d24d96d19f2f9230426d0503716f66d74e5"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[28], \"245525000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247782", timeStamp: "1504781058", hash: "0xd891716bcbc2650eab4fa06e9e174a738a04bc473fd68d20f35e71ee3989e609", nonce: "39", blockHash: "0x6c874803e33129fe280b7688bf2d5b4225cf09681146dd2a1cbb96faa514f076", transactionIndex: "99", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000c72c2aae3fb9b076ed4cce2147d033a1ad880138000000000000000000000000000000000000000000000532fe629947a2520000", contractAddress: "", cumulativeGasUsed: "6604454", gasUsed: "56555", confirmations: "3456764"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[28]}, {type: "uint256", name: "_amount", value: "24552500000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[28], "24552500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1504781058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xc72c2aae3fb9b076ed4cce2147d033a1ad880138"}, {name: "amount", type: "uint256", value: "24552500000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[29], \"925750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247784", timeStamp: "1504781094", hash: "0x92ca195631ff30ca6b395d2cbfc7b3fd7f092e75e8d02839fa04a9c37689730d", nonce: "40", blockHash: "0x5715a653cb62e1fa6d4e9f7717bd5fbd3c071991b24978c77974213be3c5ea59", transactionIndex: "127", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000003e1748fe842a7421eaad23854831d5c17b40f1ca0000000000000000000000000000000000000000000001f5d99ee1a9b2b60000", contractAddress: "", cumulativeGasUsed: "4772834", gasUsed: "56555", confirmations: "3456762"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[29]}, {type: "uint256", name: "_amount", value: "9257500000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[29], "9257500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1504781094 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x3e1748fe842a7421eaad23854831d5c17b40f1ca"}, {name: "amount", type: "uint256", value: "9257500000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[30], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247786", timeStamp: "1504781128", hash: "0xdf4fed50de88eb2502ebab803480f4be7ba4494c6fb5349c7a3eaab894aeb7cd", nonce: "41", blockHash: "0x1eb8dae3c958ec0a1d9d4b4684c21c9aaf3643c7abac6d5a20dd1118ce6dee7d", transactionIndex: "101", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000473623e9980195179495662a297e9f3b0459a36d000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5213170", gasUsed: "56555", confirmations: "3456760"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[30]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[30], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1504781128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x473623e9980195179495662a297e9f3b0459a36d"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[31], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247788", timeStamp: "1504781166", hash: "0x43d12f28f7ce33f5bd316da4d9a97c5c0559c64293bee4971381f95da9d05db8", nonce: "42", blockHash: "0xf5aadcee84c847e83a7cb6b4640aadeb83753b7fc35afb7fb8b322982ab0b3fd", transactionIndex: "120", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000dd5ae2a233fa7ad24ec431a443d97a32971601fa000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5513741", gasUsed: "56555", confirmations: "3456758"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[31]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[31], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1504781166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xdd5ae2a233fa7ad24ec431a443d97a32971601fa"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[32], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247790", timeStamp: "1504781198", hash: "0x91d48a9af621a465529bda86aad3e7a55d7cadc339b61a4425279e446c119f58", nonce: "43", blockHash: "0xfb71f0eabe298fc1acaec43cec5c784712b9cbb6ebd00c8410cc10fc90119575", transactionIndex: "89", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000be37ab5c88b56172bae3348ab9d095ad740425b2000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "4122046", gasUsed: "56555", confirmations: "3456756"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[32]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[32], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1504781198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xbe37ab5c88b56172bae3348ab9d095ad740425b2"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[33], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247792", timeStamp: "1504781271", hash: "0x62ac60e38187e6a2a4147f7e06c0049b317e008b7a33535202ef628ff93b4a05", nonce: "44", blockHash: "0x05ef4c7c8fb1751d015521a9110f1eb950fdc25160d90942f58d3e22449542a4", transactionIndex: "125", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000003fab3ba4724fac00bac3fe256c223bf8dc0d2584000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "3157800", gasUsed: "56491", confirmations: "3456754"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[33]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[33], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1504781271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x3fab3ba4724fac00bac3fe256c223bf8dc0d2584"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[34], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247795", timeStamp: "1504781353", hash: "0xf7fe907bc2e1b26b7895ad134171123b6ce2cdec58f1f7904105fcbda2ad9d58", nonce: "45", blockHash: "0x4ef009981537e834fa29d27d4084e8264217686934dcadf3855830735e1740d8", transactionIndex: "159", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000840c59f8f0547f2eed4539b69a408914a78e3a9e000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6136345", gasUsed: "56555", confirmations: "3456751"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[34]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[34], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1504781353 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x840c59f8f0547f2eed4539b69a408914a78e3a9e"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[35], \"120459925965156225000... )", async function( ) {
		const txOriginal = {blockNumber: "4247798", timeStamp: "1504781467", hash: "0xa3b38634bebdbf2d25ca220e4cd9ed6822c923e537f29a059426ee46bc345077", nonce: "46", blockHash: "0xed9b88388eb184956f1c1aa881a6ce50e886b679b2934cd4730f0fc0a898e561", transactionIndex: "151", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000000593f8bd480c885486b893362551b601c9e5ad2000000000000000000000000000000000000000000001982254ab944ce7a2240", contractAddress: "", cumulativeGasUsed: "6588181", gasUsed: "56619", confirmations: "3456748"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[35]}, {type: "uint256", name: "_amount", value: "120459925965156225000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[35], "120459925965156225000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1504781467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x00593f8bd480c885486b893362551b601c9e5ad2"}, {name: "amount", type: "uint256", value: "120459925965156225000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[36], \"117691000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247799", timeStamp: "1504781471", hash: "0x9b25ea3cdb934f9a498dcd85817112639583910bdd4602d7048f3ab164b58633", nonce: "47", blockHash: "0x772c4c2d365890e9a0170d6a5c802f29a926ea62f3f73ba90e34b033077153fc", transactionIndex: "48", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000009eeef68e335ba48b6cd56090f8d22184b20a4b30000000000000000000000000000000000000000000018ec0ab9925b920c0000", contractAddress: "", cumulativeGasUsed: "2959926", gasUsed: "56555", confirmations: "3456747"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[36]}, {type: "uint256", name: "_amount", value: "117691000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[36], "117691000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1504781471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x09eeef68e335ba48b6cd56090f8d22184b20a4b3"}, {name: "amount", type: "uint256", value: "117691000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[37], \"117691000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247814", timeStamp: "1504781777", hash: "0x63fd427dfaea7827da8af35ca1735df0373da3d3ff54f1b04b14a193257aaf2c", nonce: "48", blockHash: "0x7eb75bf37eb2303a9c6b60cb58edb0e09799b27b9be535bc1327e62d32bba07f", transactionIndex: "210", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000000952e83e5f2e73674d771c32e7e64f63e328aa9e0000000000000000000000000000000000000000000018ec0ab9925b920c0000", contractAddress: "", cumulativeGasUsed: "5404891", gasUsed: "56555", confirmations: "3456732"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[37]}, {type: "uint256", name: "_amount", value: "117691000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[37], "117691000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1504781777 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x0952e83e5f2e73674d771c32e7e64f63e328aa9e"}, {name: "amount", type: "uint256", value: "117691000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[38], \"117691000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247825", timeStamp: "1504782044", hash: "0x53f6232137dab51ab835932b58c601eefc61b9768badb2915eb0db00e83909f9", nonce: "49", blockHash: "0x5ebc6ad4292e85f980968a529b9ee4d29385dbb094cbc5f13555615577309a55", transactionIndex: "132", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000002e9b363c0117d142b2b5dcd495fbc40179b62010000000000000000000000000000000000000000000018ec0ab9925b920c0000", contractAddress: "", cumulativeGasUsed: "3312348", gasUsed: "56555", confirmations: "3456721"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[38]}, {type: "uint256", name: "_amount", value: "117691000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[38], "117691000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1504782044 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x02e9b363c0117d142b2b5dcd495fbc40179b6201"}, {name: "amount", type: "uint256", value: "117691000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[39], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247829", timeStamp: "1504782113", hash: "0xbb71d554e3329ea976ec3c1857bafdd75605c3c056a0c9e447f060e8b1c3304d", nonce: "50", blockHash: "0x969694ebbb16a234e168dad4337f078771ac716b6b1e47083ece10faba2e1132", transactionIndex: "86", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000007ec82728f50ac4aceb98caf5f386fe25fdbf0c8b000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "6063650", gasUsed: "56555", confirmations: "3456717"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[39]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[39], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1504782113 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x7ec82728f50ac4aceb98caf5f386fe25fdbf0c8b"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[40], \"925750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247831", timeStamp: "1504782134", hash: "0xa1e84f362af6b3ed22f907fa8cd66ccb72abfb46bb118c5fe4f9627b7e14578e", nonce: "51", blockHash: "0x2b6ffe5b5114845d6f03ce60b282f5976cf98477009b23edd55d14c8469b2ac2", transactionIndex: "117", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000dbea615bf6c26e595517645dec43ada12e01f7d10000000000000000000000000000000000000000000001f5d99ee1a9b2b60000", contractAddress: "", cumulativeGasUsed: "5704906", gasUsed: "56555", confirmations: "3456715"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[40]}, {type: "uint256", name: "_amount", value: "9257500000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[40], "9257500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1504782134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xdbea615bf6c26e595517645dec43ada12e01f7d1"}, {name: "amount", type: "uint256", value: "9257500000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[41], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247843", timeStamp: "1504782364", hash: "0x42e0785422ebf81d644471e8478af8e9db938ad9d7feb00813a89442c7eba38e", nonce: "52", blockHash: "0xa2b802492b43cdecc7ed05f0e5cd34474da5882bdef5f59fb69e97d32db0eb4c", transactionIndex: "109", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000e8fa669978ee39c3d57f693c47ad3296736c6a86000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5049485", gasUsed: "56555", confirmations: "3456703"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[41]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[41], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1504782364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xe8fa669978ee39c3d57f693c47ad3296736c6a86"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[42], \"112700000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247844", timeStamp: "1504782385", hash: "0x36f8da7617417f51b75d1600d5bec482ab2021f2209660a1ee50bf934f321f22", nonce: "53", blockHash: "0x22d9e784a4134ccdaab7c0e1e2fc9575eabc9b9926a6be45418d363cae5e71d1", transactionIndex: "99", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000c562b9310436d9fa01ed015e481458894d4cc9a10000000000000000000000000000000000000000000017dd7aaf99cf1b700000", contractAddress: "", cumulativeGasUsed: "4194758", gasUsed: "56555", confirmations: "3456702"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[42]}, {type: "uint256", name: "_amount", value: "112700000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[42], "112700000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1504782385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xc562b9310436d9fa01ed015e481458894d4cc9a1"}, {name: "amount", type: "uint256", value: "112700000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[43], \"112700000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247850", timeStamp: "1504782561", hash: "0x3f97a03ee2619c870f21dd68521ba8f70e7cd9d0532445624c0507b030ad8b95", nonce: "54", blockHash: "0x011d2cf353c11def00f38c35a7208a770f6da220728d4820522638c08223b931", transactionIndex: "147", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000005c0c7d6a401e8c5c75f9089c7391547b4446080f0000000000000000000000000000000000000000000017dd7aaf99cf1b700000", contractAddress: "", cumulativeGasUsed: "5343707", gasUsed: "56555", confirmations: "3456696"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[43]}, {type: "uint256", name: "_amount", value: "112700000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[43], "112700000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1504782561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x5c0c7d6a401e8c5c75f9089c7391547b4446080f"}, {name: "amount", type: "uint256", value: "112700000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[44], \"112700000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247853", timeStamp: "1504782640", hash: "0x76fe2b3820da2c887c0c440fb7a20338b96a66075f938e651e25059c7dc46eea", nonce: "55", blockHash: "0xde3ee7f13e9ffcb22d42e85eb7d375ea2413cae8143ae8c926256e7888c44338", transactionIndex: "124", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000008c3269824e0aee47bb238bac87b2f92de7a7b7860000000000000000000000000000000000000000000017dd7aaf99cf1b700000", contractAddress: "", cumulativeGasUsed: "3401894", gasUsed: "56555", confirmations: "3456693"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[44]}, {type: "uint256", name: "_amount", value: "112700000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[44], "112700000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1504782640 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x8c3269824e0aee47bb238bac87b2f92de7a7b786"}, {name: "amount", type: "uint256", value: "112700000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[45], \"112700000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247856", timeStamp: "1504782680", hash: "0xe72da9e507f331fb5394db886e0de253de6415934f016ea441659e84fe8f8f51", nonce: "56", blockHash: "0xa56eed993af6ffd82d0245e55c6e50af493c1d5666c7f9a806aadc9a43238c1b", transactionIndex: "158", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000043d88e3c6abd13f4c32757b900b25c2117d4e21c0000000000000000000000000000000000000000000017dd7aaf99cf1b700000", contractAddress: "", cumulativeGasUsed: "6641924", gasUsed: "56491", confirmations: "3456690"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[45]}, {type: "uint256", name: "_amount", value: "112700000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[45], "112700000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1504782680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x43d88e3c6abd13f4c32757b900b25c2117d4e21c"}, {name: "amount", type: "uint256", value: "112700000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[46], \"575092000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247879", timeStamp: "1504783463", hash: "0x6f420b7aac25ea0a80267e2dfcc7a0e3529baf41ab966e7a46bc739c9cdd29bc", nonce: "57", blockHash: "0xe4b086774a1eba50238bb3d9a376183bd9484ec190b634e5636aea60428df2cb", transactionIndex: "109", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000000af7cd420b5fa9ddc81c01a734cd04988540c8a000000000000000000000000000000000000000000000c2d94797f331e880000", contractAddress: "", cumulativeGasUsed: "2643817", gasUsed: "56491", confirmations: "3456667"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[46]}, {type: "uint256", name: "_amount", value: "57509200000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[46], "57509200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1504783463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x00af7cd420b5fa9ddc81c01a734cd04988540c8a"}, {name: "amount", type: "uint256", value: "57509200000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[47], \"120146250000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247891", timeStamp: "1504783933", hash: "0x24bc2933686d419c0d9d65a1b06f23792b52ff5e2bd3c930a2bb50220ad60091", nonce: "58", blockHash: "0x9591ed71175742f38449eebace4a6770e578e6a187c03a615b3c7b00efbbc99c", transactionIndex: "105", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000fc10cae24414b1206accd748bcc89020695881ec0000000000000000000000000000000000000000000019712429d4e2bbe10000", contractAddress: "", cumulativeGasUsed: "3018522", gasUsed: "56555", confirmations: "3456655"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[47]}, {type: "uint256", name: "_amount", value: "120146250000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[47], "120146250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1504783933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xfc10cae24414b1206accd748bcc89020695881ec"}, {name: "amount", type: "uint256", value: "120146250000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[48], \"798962500000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247904", timeStamp: "1504784296", hash: "0x60f26ad1ee76e4c087d207af0d251bbaa403f14a9edb90b11b7ee2cf6f2a8c38", nonce: "59", blockHash: "0x6e7c6f9261bbb650f7733742e30c9d94d50af97f088abb7684a55b15f5c01438", transactionIndex: "121", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b4000000000000000000000000e9f754708fc7ff60bf18e675119a5c0a3e30dd500000000000000000000000000000000000000000000010eb2f3442867b390000", contractAddress: "", cumulativeGasUsed: "6650808", gasUsed: "56555", confirmations: "3456642"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[48]}, {type: "uint256", name: "_amount", value: "79896250000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[48], "79896250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1504784296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0xe9f754708fc7ff60bf18e675119a5c0a3e30dd50"}, {name: "amount", type: "uint256", value: "79896250000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[49], \"120568600965156225000... )", async function( ) {
		const txOriginal = {blockNumber: "4247918", timeStamp: "1504784538", hash: "0xbc13db03937ecf15bfe9feee9edfce7cb6abd13a07681ce935f7d98b2b65023a", nonce: "60", blockHash: "0x3f6f62cb212971187c5904c7a7047ba0eca990aaa37d4085589cf82cad521991", transactionIndex: "169", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000000ec0f22f8267c107550f323b29493688f41d2b70000000000000000000000000000000000000000000019880975e1fbe40da240", contractAddress: "", cumulativeGasUsed: "4269098", gasUsed: "56619", confirmations: "3456628"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[49]}, {type: "uint256", name: "_amount", value: "120568600965156225000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[49], "120568600965156225000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1504784538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x00ec0f22f8267c107550f323b29493688f41d2b7"}, {name: "amount", type: "uint256", value: "120568600965156225000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[50], \"402500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247920", timeStamp: "1504784559", hash: "0x0ba4864fd37ec18dde5588a4236c3634734ccd61261abd927df93804d3612e70", nonce: "61", blockHash: "0xfc69d2cf3f7f5fa1132d78a82937c8ffcb85435508fa9a439c5bcb6ea8ab6e78", transactionIndex: "34", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b40000000000000000000000006dcabd1308fb517d2a862bac24560b46da5963ed000000000000000000000000000000000000000000000885f4f5925c40a80000", contractAddress: "", cumulativeGasUsed: "1376197", gasUsed: "56555", confirmations: "3456626"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[50]}, {type: "uint256", name: "_amount", value: "40250000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[50], "40250000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1504784559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x6dcabd1308fb517d2a862bac24560b46da5963ed"}, {name: "amount", type: "uint256", value: "40250000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setCredit( addressList[51], \"120750000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4247928", timeStamp: "1504784709", hash: "0x8fc47ac4c0af64e3f9804d3a5f665300726dff9d209a456a8241b2dad4d483f3", nonce: "62", blockHash: "0x3eb0dbe00d5593cc4e91b578d85d18946b00f9f40f22e55fddfc9f2e21ec6ff9", transactionIndex: "84", from: "0x5cd9f1c602ca78444142568958151027b1334d36", to: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xb40ee8b400000000000000000000000058c3d7d551d4bd0fe926f1c5cbd6c2787711c119000000000000000000000000000000000000000000001991dee0b714c1f80000", contractAddress: "", cumulativeGasUsed: "5715721", gasUsed: "56555", confirmations: "3456618"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[51]}, {type: "uint256", name: "_amount", value: "120750000000000000000000"}], name: "setCredit", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCredit(address,uint256)" ]( addressList[51], "120750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1504784709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onSetCredit", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSetCredit", events: [{name: "account", type: "address", value: "0x58c3d7d551d4bd0fe926f1c5cbd6c2787711c119"}, {name: "amount", type: "uint256", value: "120750000000000000000000"}], address: "0x6de20d9d444354ff9b271a6ea6f9274f2467df35"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "16938981825762808" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
