const Rates = artifacts.require( "./Rates.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Rates" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4272dB2EB82068E898588C3D6e4B5D55c3848793", "0x23445fFDDA92567a4c6168D376C35d93AcB96e01", "0xde36a8773531406dCBefFdfd3C7b89fCed7A9F84", "0x8C58187a978979947b88824DCdA5Cb5fD4410387"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "bytes32"}], name: "permissions", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "bSymbol", type: "bytes32"}, {name: "value", type: "uint256"}], name: "convertToWei", outputs: [{name: "weiValue", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "bSymbol", type: "bytes32"}, {name: "weiValue", type: "uint256"}], name: "convertFromWei", outputs: [{name: "value", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "rates", outputs: [{name: "rate", type: "uint256"}, {name: "lastUpdated", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "agent", type: "address"}, {indexed: false, name: "grantedPermission", type: "bytes32"}], name: "PermissionGranted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "agent", type: "address"}, {indexed: false, name: "revokedPermission", type: "bytes32"}], name: "PermissionRevoked", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RateChanged(bytes32,uint256)", "PermissionGranted(address,bytes32)", "PermissionRevoked(address,bytes32)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9de72aa82d2cf62928e15749581b4bb9120a74b0de039e0908d84c73a28c82d7", "0xc65937e3dbcb9fb30f646815dd67a3dbd09ba17718cbcb54efbe3635f8e0a6fe", "0x789770131846de4d1f28418f0f957cdf4fcabe5eccf70067083e20ecece69a34"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6697932 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6723434 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "permissionGranterContract", value: 4}], name: "Rates", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "permissions", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "permissions(address,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "bSymbol", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "uint256", name: "value", value: random.range( maxRandom )}], name: "convertToWei", outputs: [{name: "weiValue", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "convertToWei(bytes32,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "bSymbol", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "uint256", name: "weiValue", value: random.range( maxRandom )}], name: "convertFromWei", outputs: [{name: "value", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "convertFromWei(bytes32,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "rates", outputs: [{name: "rate", type: "uint256"}, {name: "lastUpdated", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rates(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Rates", function( accounts ) {

	it( "TEST: Rates( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6697932", timeStamp: "1542128330", hash: "0x3a0ca0223275fc414b93f60548060dc1e4329deaaa14b46460a9ca28bfc322ea", nonce: "4", blockHash: "0x53b7c2600e4c5a5b1a6f17cac0d7d2af20838dfc6636880985160487f921f027", transactionIndex: "0", from: "0x23445ffdda92567a4c6168d376c35d93acb96e01", to: 0, value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x823d6cff000000000000000000000000de36a8773531406dcbeffdfd3c7b89fced7a9f84", contractAddress: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", cumulativeGasUsed: "1282944", gasUsed: "1282944", confirmations: "1012692"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "permissionGranterContract", value: addressList[4]}], name: "Rates", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Rates.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542128330 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Rates.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "agent", type: "address"}, {indexed: false, name: "grantedPermission", type: "bytes32"}], name: "PermissionGranted", type: "event"} ;
		console.error( "eventCallOriginal[0,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PermissionGranted", events: [{name: "agent", type: "address", value: "0xde36a8773531406dcbeffdfd3c7b89fced7a9f84"}, {name: "grantedPermission", type: "bytes32", value: "0x5065726d697373696f6e4772616e746572000000000000000000000000000000"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[0,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "499376608756097561" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6703808", timeStamp: "1542211348", hash: "0x2cc0fd3dc982dc364ffc5616092f03172e8a9af0cbc4ec3119c03500df07dfa5", nonce: "3682", blockHash: "0x80d028b46d8f4e0277261cbe38bb51d3b1de9b6f3f5c051d3216b05f3b5b7adc", transactionIndex: "180", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5200000000", isError: "0", txreceipt_status: "1", input: "0x680819eb4555520000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000414b", contractAddress: "", cumulativeGasUsed: "7917664", gasUsed: "64162", confirmations: "1006816"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "16715"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "16715", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542211348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "16715"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235781024763915852" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6704298", timeStamp: "1542218506", hash: "0x754ac2f504381481f22d678d51988d027f52d88064571f985c1b6c65ddf39e13", nonce: "3684", blockHash: "0x5148fe8ce8200284a546315c16f7f08b73df2efd0392f0bbedd3f1d2e0f38316", transactionIndex: "74", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb455552000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040ec", contractAddress: "", cumulativeGasUsed: "4692092", gasUsed: "34162", confirmations: "1006326"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "16620"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "16620", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542218506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "16620"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6704575", timeStamp: "1542222198", hash: "0x4a766406c199efeac6f858c24ab5a7e153fafc6cb16fbf30c37a2547d11cb822", nonce: "3685", blockHash: "0x701cec55e6038b46ac5c726acdcae3e4c123b05e8af25f0b1fcf1132782784d5", transactionIndex: "80", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d39", contractAddress: "", cumulativeGasUsed: "6121936", gasUsed: "34162", confirmations: "1006049"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15673"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15673", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542222198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15673"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6704840", timeStamp: "1542225774", hash: "0xf6426878e10ffff4bdbb1d2b97530969fc2add33bdc0850a23ab9542546c705e", nonce: "3686", blockHash: "0x4fe178ce9cc56bc695194627fb2df215795a77eb7346a322e789fe8c85fefd03", transactionIndex: "68", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cfc", contractAddress: "", cumulativeGasUsed: "7127555", gasUsed: "34162", confirmations: "1005784"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15612"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15612", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542225774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15612"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6705101", timeStamp: "1542229426", hash: "0xff49109052b9d5c7c9fb1b59a179af883de46f95359654d8f7306d788c70be1e", nonce: "3687", blockHash: "0xa86aaafc64c6bff64d9551155318dae9fa6e7c1c43b1beb5e9baac7e7c041fbe", transactionIndex: "70", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003bb2", contractAddress: "", cumulativeGasUsed: "4864941", gasUsed: "34162", confirmations: "1005523"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15282"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15282", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542229426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15282"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6705871", timeStamp: "1542240260", hash: "0x277444624742adb0674ff917fd8408f1dabe1e25171d8d3a948ce97716ec80c4", nonce: "3690", blockHash: "0xdf36f44fba7ce961940f314a37fdc69c4e350078a159d036457a099c545977ba", transactionIndex: "13", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d9b", contractAddress: "", cumulativeGasUsed: "733246", gasUsed: "34162", confirmations: "1004753"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15771"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15771", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542240260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15771"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6706113", timeStamp: "1542243732", hash: "0x7700d99682f072c9c890d92e488f9a227b67e9105dc7d015297c06d8c594247a", nonce: "3691", blockHash: "0x06d7a22fbf0480f452af1fd645ff3d621d7b690a5249b6269721e0214a788fa7", transactionIndex: "125", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003dbf", contractAddress: "", cumulativeGasUsed: "6830467", gasUsed: "34162", confirmations: "1004511"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15807"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15807", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542243732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15807"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6706858", timeStamp: "1542254551", hash: "0x539c49d35587d9131c1c0d38599109fc14246294a1e1228f1f854b5901febb00", nonce: "3694", blockHash: "0x2f879c1c78cc42b24b3efd1d90e20cd8823c177dbc93c2c6f1ecf049c3513b43", transactionIndex: "84", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "10332841300", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c93", contractAddress: "", cumulativeGasUsed: "6033685", gasUsed: "34162", confirmations: "1003766"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15507"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15507", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542254551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15507"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6707110", timeStamp: "1542258170", hash: "0x3667639a4b8c2003728100ffa3fbf10593f197e955ade53a9a0bd258c41473ae", nonce: "3695", blockHash: "0x0476cdaa2f2edd729b03991d4b594e5100c93bc855dad6b02cc91f87591dafb7", transactionIndex: "38", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c27", contractAddress: "", cumulativeGasUsed: "1178319", gasUsed: "34162", confirmations: "1003514"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15399"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15399", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542258170 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15399"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6707346", timeStamp: "1542261671", hash: "0xfea55101e520f39e6293168ec52c016efe9001e916de01ad0005c2a6591cb3f9", nonce: "3696", blockHash: "0x48933654bfefd8769a9fb4b540e55b5f7847186350d18d141b0e5c1a54420396", transactionIndex: "79", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "7562500000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c92", contractAddress: "", cumulativeGasUsed: "2849210", gasUsed: "34162", confirmations: "1003278"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15506"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15506", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542261671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15506"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6707863", timeStamp: "1542268946", hash: "0xee904e7cbd14244ffc05059b0fc21d6a13dd149320965f33b8b1385e99482220", nonce: "3698", blockHash: "0x92de6169ad5ade25d754d5d44ef402a810724e58299c343ef650373a47a1055b", transactionIndex: "72", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003dc3", contractAddress: "", cumulativeGasUsed: "4774040", gasUsed: "34162", confirmations: "1002761"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15811"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15811", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542268946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15811"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708150", timeStamp: "1542272543", hash: "0xb032c853cdb14ff3e855ddeb4b244618a56322fccfa58b847cad6a6d64e20917", nonce: "3699", blockHash: "0x0ab3de2e35b234870d43fa1bc89e3986ace8d661d5436306667d094c21d63a10", transactionIndex: "237", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cb3", contractAddress: "", cumulativeGasUsed: "7905599", gasUsed: "34162", confirmations: "1002474"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15539"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15539", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542272543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15539"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708390", timeStamp: "1542276148", hash: "0x789c62e88ccef2504ae85100d1d6961e458519dba8dcb26c82c90eccd690277d", nonce: "3700", blockHash: "0x16dbd1774b0627932aaf07a18405eb7e14aab3926280e316eb4eb9e728372d5f", transactionIndex: "19", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d42", contractAddress: "", cumulativeGasUsed: "1197559", gasUsed: "34162", confirmations: "1002234"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15682"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15682", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542276148 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15682"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708903", timeStamp: "1542283343", hash: "0xd1c2bc928444992491b21e97d5847a4a4d8d9e3f4bb71ee1b47909cb6c58efae", nonce: "3702", blockHash: "0x014e05370c9b05fa5d0dc5f05f04c11cce5b5a491d57326bdf8dcabba96b5a5f", transactionIndex: "123", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ba8", contractAddress: "", cumulativeGasUsed: "7603833", gasUsed: "34162", confirmations: "1001721"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15272"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15272", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542283343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15272"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6709143", timeStamp: "1542286954", hash: "0x6085a91d5e2478a646452a7160baa54c223f2560f6197a45cfd32345e42e71d0", nonce: "3703", blockHash: "0x365ff0d81ed5d957a2ef27bb3de583e3b4b1344fb1523241a6729ca4a21e0879", transactionIndex: "93", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003bb7", contractAddress: "", cumulativeGasUsed: "6192159", gasUsed: "34162", confirmations: "1001481"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15287"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15287", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542286954 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15287"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6709422", timeStamp: "1542290520", hash: "0xeb37f7672a6db2b3b14d39bba104c1ea2b4e945302eb542b006d0bbfb38cd4cc", nonce: "3704", blockHash: "0x4fe666cf9f7ceba50952c10d93ac9e951383197433e93def97d48d3e3c4968ef", transactionIndex: "123", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003bc6", contractAddress: "", cumulativeGasUsed: "7619558", gasUsed: "34162", confirmations: "1001202"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15302"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15302", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542290520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15302"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6709925", timeStamp: "1542297732", hash: "0xbf626ab57e8f1c3a65580c772d3e3b628e98f284b565ae7b17dd138c22775aa5", nonce: "3706", blockHash: "0x141f11dedc60f8fc835f58c9a701c4af99a1732db9f98c929652db6f1c4e136b", transactionIndex: "59", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003bf4", contractAddress: "", cumulativeGasUsed: "3046349", gasUsed: "34162", confirmations: "1000699"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15348"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15348", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542297732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15348"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6710173", timeStamp: "1542301303", hash: "0x7e5c9c373e23687404d08f9cd5e0e49b15dafb0ce7c574593ec556e600057bc3", nonce: "3707", blockHash: "0x44303d7648502d798935eb904895c001618903ee7e92720b244e14569609906a", transactionIndex: "48", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "10450000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cf3", contractAddress: "", cumulativeGasUsed: "2759304", gasUsed: "34162", confirmations: "1000451"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15603"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15603", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542301303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15603"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6710663", timeStamp: "1542308561", hash: "0xd7f031075e9486efb9d7da563854e649ecbf66825b32c9a7f236508249df1e16", nonce: "3709", blockHash: "0x23bb842a9ea27dc8562d7b4f5af0a37c9d256ced7ff043472d30ff6f38292c41", transactionIndex: "71", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c9b", contractAddress: "", cumulativeGasUsed: "7689446", gasUsed: "34162", confirmations: "999961"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15515"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15515", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542308561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15515"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6710923", timeStamp: "1542312123", hash: "0x2e525defd44235ae8b20c22d9c4859eee978a84b132c01871cf19cb6db42e8b3", nonce: "3710", blockHash: "0xe449d2aa649adb9e6f97bdba3da58cf27ce9cb3bdb4b1822ef0a98754784f314", transactionIndex: "141", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003da9", contractAddress: "", cumulativeGasUsed: "7259229", gasUsed: "34162", confirmations: "999701"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15785"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15785", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542312123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15785"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6711186", timeStamp: "1542315731", hash: "0xd832e3ad166109fd4d7d3371fc430c4f9c6e1ddefc58949207222cecfededf54", nonce: "3711", blockHash: "0x07e63fc9bc2ce0e84ada691c0127f2fc3016ccbaa7d8ca1bea75a1955f9db72b", transactionIndex: "92", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3100051033", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c85", contractAddress: "", cumulativeGasUsed: "7567992", gasUsed: "34162", confirmations: "999438"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15493"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15493", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542315731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15493"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6711449", timeStamp: "1542319412", hash: "0xd96569610dbb84d1cd7ca85e85675934505e8e949c999d449533b21b93e6b728", nonce: "3712", blockHash: "0x94d76055e3eccfb70a9810cae096dc0e105a5650eb59b596c20daf946451fa09", transactionIndex: "92", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cc4", contractAddress: "", cumulativeGasUsed: "7860363", gasUsed: "34162", confirmations: "999175"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15556"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15556", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542319412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15556"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6711679", timeStamp: "1542322971", hash: "0x0d330cdfc91165289e1aac36559eade1605079ffc93569c8bcc598026ce7ee61", nonce: "3713", blockHash: "0x5a05012517975dda86e46a49cde071cf331caa3d3e0fa0b692df6cc1e2de8d8e", transactionIndex: "99", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c96", contractAddress: "", cumulativeGasUsed: "7674719", gasUsed: "34162", confirmations: "998945"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15510"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15510", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542322971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15510"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6712201", timeStamp: "1542330191", hash: "0xc683a4c9904f35bec15d46f589e80f9792ba703286ef55a61487c3971a8ef0dd", nonce: "3715", blockHash: "0x9a8ec64398ecd7afb1837a91e1f405dc4ca2d919dcff8271f02d743465d49d66", transactionIndex: "61", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d08", contractAddress: "", cumulativeGasUsed: "3829254", gasUsed: "34162", confirmations: "998423"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15624"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15624", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542330191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15624"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6713496", timeStamp: "1542348060", hash: "0xceb364fb6aa55ddfed165b36905e8ef7de7a2ae55785cefed0fc9bb8c0aa889f", nonce: "3720", blockHash: "0xd8c17b62c2f4582cb0807b98bf4ab9c54f7d3a856030639337cec5a3489407ec", transactionIndex: "133", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cd6", contractAddress: "", cumulativeGasUsed: "7100162", gasUsed: "34162", confirmations: "997128"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15574"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15574", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542348060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15574"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6713799", timeStamp: "1542352147", hash: "0x9585fecfd677a76809e7c4dd07fa0ce751824b40d8fe5e7f1c802bafdd746aa8", nonce: "3721", blockHash: "0x1a059ad85a6e646266cdd2b11e46dcc1a53001b2371913a1544a74ee87acec98", transactionIndex: "204", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "6000200000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d12", contractAddress: "", cumulativeGasUsed: "7715878", gasUsed: "34162", confirmations: "996825"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15634"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15634", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542352147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15634"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6714300", timeStamp: "1542358976", hash: "0xd413c283895a352a2f9179dfca5e86e97481b685497e7d99756db23628da64ea", nonce: "3723", blockHash: "0xa2fc2ab8ae7c7ea2f81e9d43dd4ac2709c42fb489a527e6cf1f677548fd1b7a8", transactionIndex: "52", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cd5", contractAddress: "", cumulativeGasUsed: "4657686", gasUsed: "34162", confirmations: "996324"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15573"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15573", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542358976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15573"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6715082", timeStamp: "1542369801", hash: "0x013c305abdb6151c2e0cdeb8bc72d31610c88d5c8765d63db85f1c76f0bcdefe", nonce: "3726", blockHash: "0xf2369c3d78223ab56eed2de7f5d1209eab38ff35e06b28108f930479372c7764", transactionIndex: "61", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cf9", contractAddress: "", cumulativeGasUsed: "4818003", gasUsed: "34162", confirmations: "995542"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15609"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15609", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542369801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15609"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6715603", timeStamp: "1542377043", hash: "0x66232001f462593cddda3f324e056475a23a4276030ced0dbd990e922c37c9fa", nonce: "3728", blockHash: "0xe6337ac08aaa2057c642962aa34753f7b700269da08667dbd2d1ef53d8d45123", transactionIndex: "64", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003cac", contractAddress: "", cumulativeGasUsed: "5921442", gasUsed: "34162", confirmations: "995021"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15532"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15532", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542377043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15532"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6715845", timeStamp: "1542380622", hash: "0xa08a2f9a4f013769ce5dd2cfddb0db9704e308fe0e5ea04f40cac3e266bc0f16", nonce: "3729", blockHash: "0x8c20f72d3ab31d7ba52ad993d81363c027e03da3548631d536457736b3304d9b", transactionIndex: "58", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c5d", contractAddress: "", cumulativeGasUsed: "5007280", gasUsed: "34162", confirmations: "994779"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15453"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15453", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542380622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15453"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6716088", timeStamp: "1542384186", hash: "0xf39dc0e08220ec1c366fcfb5debe0f2a378e420fdce42c8991a1c97d8cbde64f", nonce: "3730", blockHash: "0x66f0b1e57dc133473c4fb0b9ddbbf8dc0381f8b4221a466cc1462176f8d83873", transactionIndex: "60", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c0a", contractAddress: "", cumulativeGasUsed: "6223447", gasUsed: "34162", confirmations: "994536"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15370"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15370", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542384186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15370"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6717064", timeStamp: "1542398549", hash: "0x8207132cc1a27b88f3bfdf5a74668123b4b456415e47438a74450db8c76b4d83", nonce: "3734", blockHash: "0x1ec63344dde9cf8e64d15628c10214182f39a4ec7c5d8c4704db0eec46efc839", transactionIndex: "67", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b36", contractAddress: "", cumulativeGasUsed: "3252792", gasUsed: "34162", confirmations: "993560"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15158"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15158", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542398549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15158"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235635409238915852" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6717588", timeStamp: "1542405807", hash: "0xe6dd03f90677527be53202299c2c80bcec1adce1548e87f2557ed8233125bb0a", nonce: "3736", blockHash: "0x59f14017a83255ecaa2d8afd2d6ee69c218a15e6cb36ed9de5763bb22c8fbef8", transactionIndex: "14", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003a8c", contractAddress: "", cumulativeGasUsed: "4459042", gasUsed: "34162", confirmations: "993036"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "14988"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "14988", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542405807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "14988"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6717851", timeStamp: "1542409389", hash: "0x1917561d67f558496d6074d3ab9aa40a111c85610ca5387c3c8929b9b383f3f6", nonce: "3737", blockHash: "0xcea0b095950e57b220a987ec0436ebe0ee54edb2303e27d1ebd596293d4a7c3d", transactionIndex: "67", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003a6f", contractAddress: "", cumulativeGasUsed: "7466624", gasUsed: "34162", confirmations: "992773"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "14959"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "14959", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542409389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "14959"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6718366", timeStamp: "1542416580", hash: "0x151bcd6331051540a5d89cd111029b5550755ae3dc9aa3db62b74e274be7b7c5", nonce: "3739", blockHash: "0x6c9dfa328da719261f5f224ad0039664a35bb3187e87d634f9edbb5cee34924e", transactionIndex: "83", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003aea", contractAddress: "", cumulativeGasUsed: "6758482", gasUsed: "34162", confirmations: "992258"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15082"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15082", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542416580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15082"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6718614", timeStamp: "1542420191", hash: "0xd75fc2a4476e8cf1850b641b74f81e4f5e8a34476c9ca1d0f525f47ecda6d426", nonce: "3740", blockHash: "0x22893b5a666f4ab195c92a528161150c061e002a0116a3d762a17fbca04c0793", transactionIndex: "57", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003acb", contractAddress: "", cumulativeGasUsed: "5639987", gasUsed: "34162", confirmations: "992010"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15051"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15051", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542420191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15051"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6718878", timeStamp: "1542423796", hash: "0xd77829399713fc5e4acc3cc7a7c4887d6022b6ea88c87733e8116d71855e5874", nonce: "3741", blockHash: "0x2376170ce1f23a715a52a521563f1e4d0f3c6452fc19b93104e06de462d9bfb8", transactionIndex: "166", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003a99", contractAddress: "", cumulativeGasUsed: "5739648", gasUsed: "34162", confirmations: "991746"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15001"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542423796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15001"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6719366", timeStamp: "1542430995", hash: "0x63ed6d5b5b4f34250c3a15ce179b6f6d177ac282bf2c4314b70556d102930ae3", nonce: "3743", blockHash: "0x0fa0c9f91414b6ac6c6579b051f9968a56fbce1c252d3fffced8af298b090039", transactionIndex: "12", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ace", contractAddress: "", cumulativeGasUsed: "4175913", gasUsed: "34162", confirmations: "991258"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15054"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15054", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542430995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15054"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6719626", timeStamp: "1542434644", hash: "0x121e48b6c3bdfc314fe6972ac0d36fed7c3d038035f86227d6ab10721fe8e975", nonce: "3744", blockHash: "0xde27bb421cf74512c1bd7caf1d392770980a38fe9921d92ff21211ff676c4b86", transactionIndex: "125", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ac1", contractAddress: "", cumulativeGasUsed: "6183304", gasUsed: "34162", confirmations: "990998"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15041"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15041", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542434644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15041"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6719885", timeStamp: "1542438206", hash: "0x0e8a069ff93af6c93f1b36ca0ecc82e3ebca2e42ea6fb2b9487d3fbc989cc733", nonce: "3745", blockHash: "0x38231a7ad45cf5a8aa4dec4552f589981792642875b765bdeb4e84dafcffbe3d", transactionIndex: "78", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003aee", contractAddress: "", cumulativeGasUsed: "7681528", gasUsed: "34162", confirmations: "990739"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15086"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15086", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542438206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15086"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6720131", timeStamp: "1542441743", hash: "0xb4e0bec0e26f35950953741c6b49293c9f74d9026e7ba8c117212ccb65d98b6b", nonce: "3746", blockHash: "0xc368c300c3e25331b07fb12b297a38d1504ccb4b8bf0b218300daf90fde04786", transactionIndex: "165", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b52", contractAddress: "", cumulativeGasUsed: "7834932", gasUsed: "34162", confirmations: "990493"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15186"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15186", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542441743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15186"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6720638", timeStamp: "1542448950", hash: "0x211917caef5d7c754103f94f5db64f443203e2530c89213b043efc3e37238bff", nonce: "3748", blockHash: "0x753a117fd8886e7095d115ecafcf758f2abca9b96304760404f1182ee5c3ccfd", transactionIndex: "106", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "2640000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b1e", contractAddress: "", cumulativeGasUsed: "6135254", gasUsed: "34162", confirmations: "989986"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15134"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15134", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542448950 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15134"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6720891", timeStamp: "1542452635", hash: "0x5293259325f8956c3f52e72e6f2e3c27c43b0c5404d2f03a8760b799ed5bfa0a", nonce: "3749", blockHash: "0xd2cf86b1f197479c123e15051baf970faf4649461930aa08ad01e2575ed746c0", transactionIndex: "33", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ae7", contractAddress: "", cumulativeGasUsed: "5479502", gasUsed: "34162", confirmations: "989733"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15079"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15079", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542452635 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15079"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6721151", timeStamp: "1542456195", hash: "0xfaf8399d244bfe4d513d624b58caa87dac3899bdeac573f7533af4c4233219a2", nonce: "3750", blockHash: "0x23096155bf51343111223a5dc5bb929c2149d60116c55ee5fd36e44b01fce69a", transactionIndex: "76", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b19", contractAddress: "", cumulativeGasUsed: "4234392", gasUsed: "34162", confirmations: "989473"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15129"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15129", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542456195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15129"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6721628", timeStamp: "1542463238", hash: "0x7a7ad0a471e2da9abdaefbe7e7b5539df48ef1697ceaa48482d5bc1bbfe911aa", nonce: "3752", blockHash: "0x5a20569ace44f62e5441a0cc94cbd8a2b1bf0710124b39e0dc763bf5c48c6240", transactionIndex: "160", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b10", contractAddress: "", cumulativeGasUsed: "4474245", gasUsed: "34162", confirmations: "988996"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15120"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15120", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542463238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15120"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6722398", timeStamp: "1542474127", hash: "0x72b8a09b9cdefefb9132186dd53beb47d6832be3be1bf6d2ced3a937d38c2d0d", nonce: "3756", blockHash: "0xc6c03ffc2053b7a6c989eb10c2ad79bad796e5cac45ee1d0a8494a2f7ede164c", transactionIndex: "40", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003af7", contractAddress: "", cumulativeGasUsed: "2045914", gasUsed: "34162", confirmations: "988226"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15095"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15095", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542474127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15095"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6722658", timeStamp: "1542477746", hash: "0x578189fb267afb7b1a8696c44a0d18b4ee6ee20829e1b707f59a0930b096810e", nonce: "3757", blockHash: "0x87719872c7f11de6ac7eb06528567e292144fd0e151390d5af150bb812e09b08", transactionIndex: "161", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ab4", contractAddress: "", cumulativeGasUsed: "7224080", gasUsed: "34162", confirmations: "987966"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15028"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15028", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542477746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15028"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6722902", timeStamp: "1542481361", hash: "0xd65d7727b9771b55c2f7167585da7bce7b6845d1639b499f647372bf03743c6c", nonce: "3758", blockHash: "0xd24a9a813512c26f9c84174162dfe655f43085177fb8a183eaa014c04b042d66", transactionIndex: "86", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b05", contractAddress: "", cumulativeGasUsed: "4117781", gasUsed: "34162", confirmations: "987722"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15109"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15109", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542481361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15109"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setRate( \"0x455552000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6723434", timeStamp: "1542488568", hash: "0x6c77a68a994628c5c515fe0dc13cdbf1220786380a16ad2d57f99df712c190ad", nonce: "3760", blockHash: "0x960a94812d5b36f55a73e900a05a648611f4851046314300b84859c94d9fe9f3", transactionIndex: "206", from: "0x8c58187a978979947b88824dcda5cb5fd4410387", to: "0x4272db2eb82068e898588c3d6e4b5d55c3848793", value: "0", gas: "80000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x680819eb45555200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003b28", contractAddress: "", cumulativeGasUsed: "5938971", gasUsed: "34162", confirmations: "987190"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "symbol", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "newRate", value: "15144"}], name: "setRate", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRate(bytes32,uint256)" ]( "0x4555520000000000000000000000000000000000000000000000000000000000", "15144", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542488568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "symbol", type: "bytes32"}, {indexed: false, name: "newRate", type: "uint256"}], name: "RateChanged", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RateChanged", events: [{name: "symbol", type: "bytes32", value: "0x4555520000000000000000000000000000000000000000000000000000000000"}, {name: "newRate", type: "uint256", value: "15144"}], address: "0x4272db2eb82068e898588c3d6e4b5d55c3848793"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2235490220738915852" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
