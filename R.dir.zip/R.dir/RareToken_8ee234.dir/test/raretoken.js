const RareToken = artifacts.require( "./RareToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "RareToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5dDAB66DA218Fb05dfeDA07f1AfC4ea0738ee234", "0x00000217d2795F1Da57e392D2a5bC87125BAA38D", "0x003359E6922510Dd30552ED6C3204C68638C1F77", "0x262B667BEF4177fD4d02610326f75682f20fd210", "0x731aDA89bEFf4087A0997211C3d7A5B5408dD68b", "0x1A2D543EA30fFb007072d2a75D7Cf9bF7e8DA616", "0xd7f38952d2C515c921E9817471c34A09Fb09d4e4", "0x3FE666Fc563e5fa99f8E0E6988eE2070CEA1fA6b", "0x378FF330eFf4091213A7f05C75DeA07A411b17b8", "0x8d25F564B59EB49173f5574c5AD54856f5A31E7a", "0xD493F258234C6123699a2237EB72F7ea1c695b31", "0xB18fe88C589d6eE2EebeF724ad28d7Be13940491", "0xD81d8766A6d8d82503675DF36Ec2D021336c0704", "0xec9D33F9A515A434fB7c2d7392D8A58c34ec6733", "0xFa99b13542dEDe3034C241106fBaE67C5257cD10", "0x072fE4d35215Cc543C9795Fb5417E1C854f6edb5", "0x8d12A197cB00D4747a1fe03395095ce2A5CC6819", "0xFd9c0050Bee089E1FaC7BEc29a88f2E552056662", "0x26EEE9cc7A4509AD5F73EE3b9c8f372056488402", "0x28d08a4bC76f32247dfd04bc7aC91fE428B7479E", "0xad0F6420314893d93F6e8b4628182D9A54E3754F", "0xf4105564C4e9b7F0DB64116d31677F320Bc771F9", "0x9B30126036B75CD84CC079550271F6DF2a847dc2", "0x9FC974571131FC8F93934638F99fCEeD8ED8632f", "0x5521677480e948d872AD82b180731f809fd4b0e8", "0x20BD47E6f3db30f4Cdb9948b74F3F52B14AEb6Bd", "0xEF8b50345ae5DE32CCfDD974c10893E2E3f28184", "0x0025165361865B09c7c625F4Db69BA6b0Ac85A95", "0x738DBef7ba212575df41E0916FF1f0DA5426EC18", "0x93157b7162bB6b0B8d1100d490F84Ea148E33A6C", "0x5165a5eB7C22EA5D8D7F2DdD0Bae9888cAb182F5", "0x00011675f9d83C2fBBD93883F056093BA322e600", "0x09629301dEaf0a3a6c4B3973335C5b70EB6A697C", "0x579061A9bf4Df9f1D92b09EC7E72c0d9c7B02a0E", "0x558F72bb1E5E297a1eFEd0E6F6996b7E0c902BFE"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "sealed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Approval(address,address,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3834667 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3929006 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "RareToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sealed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sealed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "RareToken", function( accounts ) {

	it( "TEST: RareToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3834667", timeStamp: "1496838644", hash: "0x8423def6ac9e422dbd8fc3454b5a03c87d8ade40ef2c94a39f91b5538a30e437", nonce: "17", blockHash: "0xcf4634acae248c2775399b6379792bb79c6d110b2b9355bd3cfab6488647e1b6", transactionIndex: "18", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: 0, value: "0", gas: "1047367", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x4766ae68", contractAddress: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", cumulativeGasUsed: "3358866", gasUsed: "947366", confirmations: "3840499"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "RareToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = RareToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1496838644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = RareToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"3215303602127986420048106631975822643... )", async function( ) {
		const txOriginal = {blockNumber: "3834691", timeStamp: "1496839015", hash: "0xf681a8f0fb5d281a622189a814fd5742341dc734eb2a3367c7cadaf93396bebb", nonce: "18", blockHash: "0xb6b3604aadfbdaca1b0e7ed15b4130c1432bb11f35b0e7f1dc783bdd85a201b1", transactionIndex: "82", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "727860", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc200000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000c816bdd9c000000000000000000000000000000000000000000000000000000000746a528800ff0e5e57c69eb4b5fedf1a73d3a817d0620455d800000000000000174876e800b0f6e2069a158a27b9e6da13aff1fb2dfae1787f00000000000000174876e800ff37fc60c1cf53b3e054e5c649f067495187eba3000000000001d90737bf68001a2d543ea30ffb007072d2a75d7cf9bf7e8da61600000000000000174876e800ffb7df19eb39dd36c747d57a48c73da5452e952100000000000000174876e800ffcff213ba710c479285828871aba77b8fecd68300000000000000746a5288002f2635ae076922e78d0b9785387f4853716f010a00000000000000174876e800653b12e66c4e802ec6cdbfd4805f2fc7ad7803b600000000000000174876e800719de009aa856b553df248556df1784164c730ff0000000000038d95ed3d68008d25f564b59eb49173f5574c5ad54856f5a31e7a00000000000000174876e8003d0fbe5c4c70d29b530884edf2df1fc03f01591200000000000000174876e8000a0bc1a04d648ebc413ee99d4b1fe855ffb7eeb400000000000000174876e800ff1a6466c8e6af588e26e78045bb07134893365900000000000000174876e8007eac94ecd60738ebce2baa48004e31e69481a83700000000000000746a528800ff01207110391d92c4a2d33c25c8fc7533a0423700000000000000a2fb4058006eb050f2e2742e0e28633c71b66bdc0ca1e4956c00000000000000174876e8004680dc15395806fc000b81a78d75cc409e5e969800000000000000800e8dfc00ff17a3c1e9807a7bbdc014ae0c645b20e09b93f600000000000000174876e8009234b60c9d95158aa251667d0257d9eab2f31448", contractAddress: "", cumulativeGasUsed: "4565701", gasUsed: "627859", confirmations: "3840475"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["321530360212798642004810663197582264324305159454720000000000000","730750818666907572177258729564451740946674052019269054780888","146150163734100579868975445292232389719951038482099485112447","146150163734547332993135261068900256503623410840426364005283","760127001575802757202368803121600114287909492158192697108964886","146150163734550184938159384436584027731493695220940178101537","146150163734550721809071042032596040622109435734744825124483","730750818665720633772558817702084134894277823631429974556938","146150163733668217278618459756395674481963503135708511994806","146150163733738928510908997974020577068620268788044278477055","1461647787494636814309708239410846473760648514216608958488190586","146150163733438891351308627369666737293644719692908144449810","146150163733147643903493141721181490108272262439697894600372","146150163734546673032508162132342020547802539488207850124889","146150163733813473358875883104393347751336636777423603607607","730750818666907276875214315454509583393408083067558984434231","1023051146132263963710157162742019026200121480962444464788844","146150163733492794841636621710223968354518324132006449813144","803825900533452924841013784190902233038601473221358039831542","146150163733924979970387978302470328639798087956517140763720"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["321530360212798642004810663197582264324305159454720000000000000","730750818666907572177258729564451740946674052019269054780888","146150163734100579868975445292232389719951038482099485112447","146150163734547332993135261068900256503623410840426364005283","760127001575802757202368803121600114287909492158192697108964886","146150163734550184938159384436584027731493695220940178101537","146150163734550721809071042032596040622109435734744825124483","730750818665720633772558817702084134894277823631429974556938","146150163733668217278618459756395674481963503135708511994806","146150163733738928510908997974020577068620268788044278477055","1461647787494636814309708239410846473760648514216608958488190586","146150163733438891351308627369666737293644719692908144449810","146150163733147643903493141721181490108272262439697894600372","146150163734546673032508162132342020547802539488207850124889","146150163733813473358875883104393347751336636777423603607607","730750818666907276875214315454509583393408083067558984434231","1023051146132263963710157162742019026200121480962444464788844","146150163733492794841636621710223968354518324132006449813144","803825900533452924841013784190902233038601473221358039831542","146150163733924979970387978302470328639798087956517140763720"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1496839015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "220000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff0e5e57c69eb4b5fedf1a73d3a817d0620455d8"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb0f6e2069a158a27b9e6da13aff1fb2dfae1787f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff37fc60c1cf53b3e054e5c649f067495187eba3"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "value", type: "uint256", value: "520100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xffb7df19eb39dd36c747d57a48c73da5452e9521"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xffcff213ba710c479285828871aba77b8fecd683"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2f2635ae076922e78d0b9785387f4853716f010a"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x653b12e66c4e802ec6cdbfd4805f2fc7ad7803b6"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x719de009aa856b553df248556df1784164c730ff"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8d25f564b59eb49173f5574c5ad54856f5a31e7a"}, {name: "value", type: "uint256", value: "1000100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3d0fbe5c4c70d29b530884edf2df1fc03f015912"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0a0bc1a04d648ebc413ee99d4b1fe855ffb7eeb4"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff1a6466c8e6af588e26e78045bb071348933659"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7eac94ecd60738ebce2baa48004e31e69481a837"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff01207110391d92c4a2d33c25c8fc7533a04237"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6eb050f2e2742e0e28633c71b66bdc0ca1e4956c"}, {name: "value", type: "uint256", value: "700000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4680dc15395806fc000b81a78d75cc409e5e9698"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff17a3c1e9807a7bbdc014ae0c645b20e09b93f6"}, {name: "value", type: "uint256", value: "550000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9234b60c9d95158aa251667d0257d9eab2f31448"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637338907296346405515054472421... )", async function( ) {
		const txOriginal = {blockNumber: "3834700", timeStamp: "1496839223", hash: "0x83d758f343271010d5b7a61ed261b3c6b9a3d9d1c7384d28d60005ceb3d7ef52", nonce: "19", blockHash: "0xa3ac4f35316f0bf7b8adcd5be7ead3c483679d941cd61d7f852e9ad276b3a808", transactionIndex: "35", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "729076", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e8008c34df7a27447fd9ab0068942622c58a35e5f1ef00000000000000174876e8008b7a5b22175614ee194e9e02e9fe0a1b5414c75e00000000000000174876e8007be3d38036a7a7dc46e9132df59fcb34628cd23100000000000000174876e8001d394e3009b87bf874900b82a4d6799dd91afd1b00000000000000174876e800f877a551b354a18f689676ef702e7fcedee56ae300000000000000174876e8004533da47ae2771b36e027bad27f5031180cdc44100000000000000174876e800a66afe19f10323663387cb7d87b0d39d9ea3477f000000000000002e90edd000f9d178f32ace577cc77e50d084162ff4e23a39a300000000000000174876e80048596b2ea4697f926b4ef52135dfb6bcfc50cebd000000000000619a97d24e00ff5d24f952d20fed0e9ad391cc6a1679277d4c1200000000000000174876e800fe29898fa553ad052a4868b3187e1216241b3e0200000000000000174876e800ffa5373011bb94172dd05ec4cb273e305cd590fd00000000000000800e8dfc00fff3a9b28954f2b0ba88b2860d9623987ac737c300000000000000800e8dfc00b3c9d1e59906e7176c37b0890b84aa25ba807df1000000000000012309ce54004ef763e5394d18439b3b5f5a927dc40b7ee3443300000000000000174876e8000179352defdfbcf10155845404af3831944e90a500000000000000517da02c00b64a2e2292d1bd103dc97179ccabed79f8485c07000000000000012eae09c800a13d747c03cc53267902f6dc2b33e773c0cc096200000000000000174876e80069e3e1069d4efa3efa0529da3868151ab3a7a13e00000000000000ae9f7bcc00ff37345300722630b026e056bdba5ce91a6f7269", contractAddress: "", cumulativeGasUsed: "2797139", gasUsed: "614075", confirmations: "3840466"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163733890729634640551505447242152714364432457400709615","146150163733886570167245857172959542902094312362476678989662","146150163733797578378661005381816579088859157222068033737265","146150163733257130506303468101859489961543167178384334322971","146150163734508789721539842319840235267018138737305408858851","146150163733485368536430324912673237960534988670030385628225","146150163734040370302664330960686413400058142141940161005439","292300327467606793734638421421476374472206179448663758748067","146150163733503333259076593689487659612552637247118615039677","156843386612787033981534309951414584872349187205038947943926802","146150163734541301789974186476390171999273876897502368316930","146150163734549768897419170601218656248929472880709115154685","803825900533457831522399109104170896010177031857410903848899","803825900533023015094384859411059900746298640936474494664177","1826877046664079466020911473006071251979696060241285753291827","146150163733098703833891037416667417739544219328580183560357","511525573066856711965654231158595435513317231810239552576519","1899952128531094311671575261244000690274572401111593604876642","146150163733694817722980180590792158944097402020091774083390","1096126227999634212398392520402566125057313456853514439324265"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163733890729634640551505447242152714364432457400709615","146150163733886570167245857172959542902094312362476678989662","146150163733797578378661005381816579088859157222068033737265","146150163733257130506303468101859489961543167178384334322971","146150163734508789721539842319840235267018138737305408858851","146150163733485368536430324912673237960534988670030385628225","146150163734040370302664330960686413400058142141940161005439","292300327467606793734638421421476374472206179448663758748067","146150163733503333259076593689487659612552637247118615039677","156843386612787033981534309951414584872349187205038947943926802","146150163734541301789974186476390171999273876897502368316930","146150163734549768897419170601218656248929472880709115154685","803825900533457831522399109104170896010177031857410903848899","803825900533023015094384859411059900746298640936474494664177","1826877046664079466020911473006071251979696060241285753291827","146150163733098703833891037416667417739544219328580183560357","511525573066856711965654231158595435513317231810239552576519","1899952128531094311671575261244000690274572401111593604876642","146150163733694817722980180590792158944097402020091774083390","1096126227999634212398392520402566125057313456853514439324265"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1496839223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8c34df7a27447fd9ab0068942622c58a35e5f1ef"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8b7a5b22175614ee194e9e02e9fe0a1b5414c75e"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7be3d38036a7a7dc46e9132df59fcb34628cd231"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1d394e3009b87bf874900b82a4d6799dd91afd1b"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf877a551b354a18f689676ef702e7fcedee56ae3"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4533da47ae2771b36e027bad27f5031180cdc441"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa66afe19f10323663387cb7d87b0d39d9ea3477f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf9d178f32ace577cc77e50d084162ff4e23a39a3"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x48596b2ea4697f926b4ef52135dfb6bcfc50cebd"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff5d24f952d20fed0e9ad391cc6a1679277d4c12"}, {name: "value", type: "uint256", value: "107316600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xfe29898fa553ad052a4868b3187e1216241b3e02"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xffa5373011bb94172dd05ec4cb273e305cd590fd"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xfff3a9b28954f2b0ba88b2860d9623987ac737c3"}, {name: "value", type: "uint256", value: "550000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb3c9d1e59906e7176c37b0890b84aa25ba807df1"}, {name: "value", type: "uint256", value: "550000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4ef763e5394d18439b3b5f5a927dc40b7ee34433"}, {name: "value", type: "uint256", value: "1250000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0179352defdfbcf10155845404af3831944e90a5"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb64a2e2292d1bd103dc97179ccabed79f8485c07"}, {name: "value", type: "uint256", value: "350000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa13d747c03cc53267902f6dc2b33e773c0cc0962"}, {name: "value", type: "uint256", value: "1300000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x69e3e1069d4efa3efa0529da3868151ab3a7a13e"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff37345300722630b026e056bdba5ce91a6f7269"}, {name: "value", type: "uint256", value: "750000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637345483000447286291662863866... )", async function( ) {
		const txOriginal = {blockNumber: "3834705", timeStamp: "1496839285", hash: "0x838dd32e0ecfc2bcf752bd81b9a5c2bf30772eaf46e8df6b4dae0eedadbb133b", nonce: "20", blockHash: "0xfb02ef305e1840cd8a7c9df94f4a91206104514a4ed0f436e1415174faf9f0b7", transactionIndex: "17", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "714204", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e800ff635995f82ed3e5ced4ad89607cd7cbc217dd9500000000000000174876e800ff4df7ff98ea3304fbf37dd0768e81a675e652d70000000000000022ecb25c00600d9b45cfd503572817cb038770c27d7fe11e25000000000000419acbcd53004b43041e418b16bb7dcf94a09f721cc73574fc040000000000000022ecb25c007a0adfbce72d62b2be29912ab4cd24d96d2ed5ac00000000000000174876e800ff814339224a803cb3b0e62b1928fe9bb3e5538600000000000000174876e8005d6560804fb079643534632f94924811ad54d80800000000000000174876e80067936306c1490db7c491b0fe56bcf067ede1fd2800000000000000174876e80013ecd4746729c26cf8a236f2894d92e112b9751600000000000000174876e800420a94c26b66e040c874738ba8b4233f8adfc1c20000000000000022ecb25c0011cd63dab133d3f0f3ef8f1a2511d088e083c6110000000000000022ecb25c00af9ed73f963fa9ef72f66b9620bb7fc90a205159000000000000b6322bd502005521677480e948d872ad82b180731f809fd4b0e8000000000000003a35294400021da453b87fe277143327e9219231d31acd4ad100000000000000174876e8007af4a9cdb9f0530d178fea497d41ab1bdc39c51d00000000000000174876e800d659275676dc27a0047b3f25adc147dbaf379194000000000000002e90edd000a9d4a2bcbe5b9e0869d70f0fe2e1d6aacd45edc500000000000000174876e800bcac7e0c34b4d2a032a1bafc1f74aff1d8d020d100000000000000174876e800c480334141e5abb335b8e931d8601b326d20da88000000000000085e0abb6000cba72fd90ff3523a7dac85216234c6d21f1f0754", contractAddress: "", cumulativeGasUsed: "1344530", gasUsed: "614203", confirmations: "3840461"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163734548300044728629166286386644731166602096203521429","146150163734547823228018736605531863703221739063474167108311","219225245600183804280399453362363491548737477220717322903077","105422643755754182957894703233067708764436732497766637328727044","219225245600332177102365353721524301309550384900128482710956","146150163734548967119024005725904978913137032462301621736326","146150163733623488743761669673208035667936018872759968126984","146150163733681604705722444509104245917605282647246400257320","146150163733204044128295488856809384285508649536938237850902","146150163733467321177470700627858618383656101397097860809154","219225245599737070924955834651199829493417152870633653388817","219225245600638053383967243867879926120874089042014254420313","292777653900933342542974611145492110493143503993974057713578216","365375409332737808568977184475493100003432375696889505204945","146150163733792244868218795866848861672273568598198232663325","146150163734314004038448881061627483726448187466265113629076","292300327467150145015404718864754957981449281034321366740421","146150163734167428793758986915420360628390256426027058208977","146150163734212112971767896445970827411375634294292504173192","13445815063445469500992965769257728097286230283624079620507476"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163734548300044728629166286386644731166602096203521429","146150163734547823228018736605531863703221739063474167108311","219225245600183804280399453362363491548737477220717322903077","105422643755754182957894703233067708764436732497766637328727044","219225245600332177102365353721524301309550384900128482710956","146150163734548967119024005725904978913137032462301621736326","146150163733623488743761669673208035667936018872759968126984","146150163733681604705722444509104245917605282647246400257320","146150163733204044128295488856809384285508649536938237850902","146150163733467321177470700627858618383656101397097860809154","219225245599737070924955834651199829493417152870633653388817","219225245600638053383967243867879926120874089042014254420313","292777653900933342542974611145492110493143503993974057713578216","365375409332737808568977184475493100003432375696889505204945","146150163733792244868218795866848861672273568598198232663325","146150163734314004038448881061627483726448187466265113629076","292300327467150145015404718864754957981449281034321366740421","146150163734167428793758986915420360628390256426027058208977","146150163734212112971767896445970827411375634294292504173192","13445815063445469500992965769257728097286230283624079620507476"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1496839285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff635995f82ed3e5ced4ad89607cd7cbc217dd95"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff4df7ff98ea3304fbf37dd0768e81a675e652d7"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x600d9b45cfd503572817cb038770c27d7fe11e25"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04"}, {name: "value", type: "uint256", value: "72133100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7a0adfbce72d62b2be29912ab4cd24d96d2ed5ac"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff814339224a803cb3b0e62b1928fe9bb3e55386"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5d6560804fb079643534632f94924811ad54d808"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67936306c1490db7c491b0fe56bcf067ede1fd28"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x13ecd4746729c26cf8a236f2894d92e112b97516"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x420a94c26b66e040c874738ba8b4233f8adfc1c2"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x11cd63dab133d3f0f3ef8f1a2511d088e083c611"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaf9ed73f963fa9ef72f66b9620bb7fc90a205159"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5521677480e948d872ad82b180731f809fd4b0e8"}, {name: "value", type: "uint256", value: "200326600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x021da453b87fe277143327e9219231d31acd4ad1"}, {name: "value", type: "uint256", value: "250000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7af4a9cdb9f0530d178fea497d41ab1bdc39c51d"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd659275676dc27a0047b3f25adc147dbaf379194"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa9d4a2bcbe5b9e0869d70f0fe2e1d6aacd45edc5"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbcac7e0c34b4d2a032a1bafc1f74aff1d8d020d1"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc480334141e5abb335b8e931d8601b326d20da88"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcba72fd90ff3523a7dac85216234c6d21f1f0754"}, {name: "value", type: "uint256", value: "9200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637340324113242361304877035607... )", async function( ) {
		const txOriginal = {blockNumber: "3834708", timeStamp: "1496839329", hash: "0x6a90885bd390e60cc79d49062e0b34dd7b4f491d8912c2d7bfad8c403f7db664", nonce: "21", blockHash: "0x51dcc0e80c8d78aa9a3909bb14706d73989d595374195cac139b4cf05a6023b4", transactionIndex: "34", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "714012", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e800a50619827d62cdb8ea7ee457194cf272dd244bba000000000000002e90edd000e961f5e8edcbe61d194d5f9e89e43ae6f290b98100000000000000174876e800589f4535fd5f9aaaeb6216aa3cba81683b93e51f00000000000000174876e800114040c5a7d2c7a5ff99db6e8a3fdfc4b51b7d1800000000000000174876e800d07c4b3541e7b7e06b8ad05bd212bad4ee73fafd00000000000000174876e8009af41c3f89fed7c6db78fa2920a3eeb1617a3bb800000000000000174876e8001bd662f1dcd812d33e556f435a432de9677bc64f0000000000000045d964b8001e2520bdcc56c78ac1c60ae9710656dbbdf6d5c900000000000000174876e800bfee6cd2154e3df9188512f8cd17d2d2684fee2300000000000000174876e800828c32c2c4a8c15312b18e156ad7195a70f733d30000000000000045d964b8008971efd56c2ba5a7f7d308fb98ec4a1d535be7c300000000000000174876e800dbd87656827e2c8d35f6bb6de39ee7a0d0f6d25700000000000000174876e800a7430f984baa14e47e0cb85ff80a1bdd53f80ebf00000000000000174876e8004459ceb7978a480d67badce4e2c5424f5a3efccc00000000000000174876e8009d1e422e21fb3824ec9377103d6f2c20c46bed1600000000000000174876e800ed1a6957e952cb55bf214487d629ec884223d2c500000000000000174876e800ebc95bc7925d5b6995e12c77a50d3f12fa2c73f500000000000000174876e8006deab6a7d409d1afbcf261df42e240be4a81eaa000000000000000174876e80050259e6cd03d1a96b58003f52ecaa2c9557a93f800000000000000174876e800b531ba5eb3f791d28088693039986b9e33ae8ba1", contractAddress: "", cumulativeGasUsed: "1974041", gasUsed: "614011", confirmations: "3840458"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163734032411324236130487703560779271104521375756602298","292300327467512963084394826768288771214511810781037540194689","146150163733596234855807033345274938659975027198649835971871","146150163733188777553610195926489622269204800094178448735512","146150163734280533744648472988528273041724206994096341121789","146150163733974920241669018691010535895032921682303042337720","146150163733249215549958836309599158083594727346683013482063","438450491199442973163980640893916323733869402185773788616137","146150163734186026114567584636597068865542982736354602905123","146150163733835587146793857381825673649959859500410643887059","438450491200055548073376014887193754982476965091998760167363","146150163734345388068829265017413853262773507325533659517527","146150163734045188787532149986213109258584602038648444554943","146150163733480505966711180099603860984514423631090489949388","146150163733987278158852811299279362479670469443944960486678","146150163734443911629133623807503761674437782060914914349765","146150163734436395096425753047580796465712131578719963476981","146150163733717806100309780120471587876064696216507813849760","146150163733547850010375205604718193264118671186782274098168","146150163734124728121513269290219171788340994339694611172257"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163734032411324236130487703560779271104521375756602298","292300327467512963084394826768288771214511810781037540194689","146150163733596234855807033345274938659975027198649835971871","146150163733188777553610195926489622269204800094178448735512","146150163734280533744648472988528273041724206994096341121789","146150163733974920241669018691010535895032921682303042337720","146150163733249215549958836309599158083594727346683013482063","438450491199442973163980640893916323733869402185773788616137","146150163734186026114567584636597068865542982736354602905123","146150163733835587146793857381825673649959859500410643887059","438450491200055548073376014887193754982476965091998760167363","146150163734345388068829265017413853262773507325533659517527","146150163734045188787532149986213109258584602038648444554943","146150163733480505966711180099603860984514423631090489949388","146150163733987278158852811299279362479670469443944960486678","146150163734443911629133623807503761674437782060914914349765","146150163734436395096425753047580796465712131578719963476981","146150163733717806100309780120471587876064696216507813849760","146150163733547850010375205604718193264118671186782274098168","146150163734124728121513269290219171788340994339694611172257"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1496839329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa50619827d62cdb8ea7ee457194cf272dd244bba"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe961f5e8edcbe61d194d5f9e89e43ae6f290b981"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x589f4535fd5f9aaaeb6216aa3cba81683b93e51f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x114040c5a7d2c7a5ff99db6e8a3fdfc4b51b7d18"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd07c4b3541e7b7e06b8ad05bd212bad4ee73fafd"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9af41c3f89fed7c6db78fa2920a3eeb1617a3bb8"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1bd662f1dcd812d33e556f435a432de9677bc64f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1e2520bdcc56c78ac1c60ae9710656dbbdf6d5c9"}, {name: "value", type: "uint256", value: "300000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbfee6cd2154e3df9188512f8cd17d2d2684fee23"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x828c32c2c4a8c15312b18e156ad7195a70f733d3"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8971efd56c2ba5a7f7d308fb98ec4a1d535be7c3"}, {name: "value", type: "uint256", value: "300000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdbd87656827e2c8d35f6bb6de39ee7a0d0f6d257"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa7430f984baa14e47e0cb85ff80a1bdd53f80ebf"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4459ceb7978a480d67badce4e2c5424f5a3efccc"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9d1e422e21fb3824ec9377103d6f2c20c46bed16"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xed1a6957e952cb55bf214487d629ec884223d2c5"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xebc95bc7925d5b6995e12c77a50d3f12fa2c73f5"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6deab6a7d409d1afbcf261df42e240be4a81eaa0"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x50259e6cd03d1a96b58003f52ecaa2c9557a93f8"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb531ba5eb3f791d28088693039986b9e33ae8ba1"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637333522317462607338789263951... )", async function( ) {
		const txOriginal = {blockNumber: "3834708", timeStamp: "1496839329", hash: "0xec72251ede76e871ec9f89e1b4b82bd8451858987ed6006fe55d1e19557399cc", nonce: "22", blockHash: "0x51dcc0e80c8d78aa9a3909bb14706d73989d595374195cac139b4cf05a6023b4", transactionIndex: "42", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "713948", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e8002de1cae1da55e3a7da74d9d93a487fa94d2c90d900000000000000174876e80070a108331ff4299cde3bc6747aa45dde63ed4d8600000000000000174876e8005397cd1807b0a3b78571fd58dd9b03ebe51948a7000000000000002e90edd000a1fbd84000dfc92f9eac0fbf55749bb472995c8500000000000000174876e800d771e43a1ccbe75baeee1d6a994ed6913845e7cf00000000000000174876e800e85184f8e2b8be53df91d5a47f95d4a9717f765f00000000000000174876e80021b637f563b2230ebd06f1bad5ce724c6c2e5bbf00000000000000174876e8002ad8f4992c434b04a5762dd4fa971f198b86d19200000000000000174876e8004c7bc258ae2c52f8753e625833e2ba75ada817ee00000000000000174876e800113f4e2581ce9b305c09e8e122676a0bbb99224900000000000000174876e800900bcd02cd2dd805c3ae491156f3412fe450098000000000000000174876e80037fdfa13477c6278cf970b62f5a2d670c390995f00000000000000746a5288001dabc369fa13d375d46fae68d54aafa0347117ec000000000000002e90edd0003c606952781ffc466c61cf8849da04bac51441a400000000000000174876e80078cc2aac243e046e62213a539f87ac8f5150988f00000000000000174876e8005a3a7fce9e0e45921df82946214c564a0ee58658000000000000008bb2c97000279646ba53f923be56274a8c1ebb109380c7474e00000000000000174876e8006cb7652a5b6a4b9cc849932622ade4979b466dcc00000000000000174876e8006de078fe0822149faa6c811f9c8fa48eb220d28f00000000000000174876e80019be6baac8296c12a1ef44c8f9ce0bf1bd8cf195", contractAddress: "", cumulativeGasUsed: "3723856", gasUsed: "613947", confirmations: "3840458"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163733352231746260733878926395159742079648402215047385","146150163733733289920972878728028016068097848091283406278022","146150163733567523333067454653977525469357503435780342237351","292300327467105347479917430598956616773091756321421775166597","146150163734320264701678889565148867448362276331088893044687","146150163734416595623073829780442467070087862294942238864991","146150163733282752126109227203258801662818957061360349764543","146150163733334907701225772071901331361829168152720309670290","146150163733526935040570349207817671884711234805474978699246","146150163733188756417941289398386181036343651582552122663497","146150163733912649658536210518616588359304395998254030915968","146150163733409950185930891634434379881154938992601343236447","730750818665620850284583071602358516714657754434830775425004","292300327466525273133378306214318570499848267610449387995556","146150163733779923782180594726117519514228478799828764104847","146150163733605405566532716650769027229297526293169164355160","876900982398767752835316963965730227636435874432201949398862","146150163733710952672743039227430440926018752293360768544204","146150163733717577721229596428859069013081990465932425745039","146150163733237263110355457828341595893372026499921123013013"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163733352231746260733878926395159742079648402215047385","146150163733733289920972878728028016068097848091283406278022","146150163733567523333067454653977525469357503435780342237351","292300327467105347479917430598956616773091756321421775166597","146150163734320264701678889565148867448362276331088893044687","146150163734416595623073829780442467070087862294942238864991","146150163733282752126109227203258801662818957061360349764543","146150163733334907701225772071901331361829168152720309670290","146150163733526935040570349207817671884711234805474978699246","146150163733188756417941289398386181036343651582552122663497","146150163733912649658536210518616588359304395998254030915968","146150163733409950185930891634434379881154938992601343236447","730750818665620850284583071602358516714657754434830775425004","292300327466525273133378306214318570499848267610449387995556","146150163733779923782180594726117519514228478799828764104847","146150163733605405566532716650769027229297526293169164355160","876900982398767752835316963965730227636435874432201949398862","146150163733710952672743039227430440926018752293360768544204","146150163733717577721229596428859069013081990465932425745039","146150163733237263110355457828341595893372026499921123013013"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1496839329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2de1cae1da55e3a7da74d9d93a487fa94d2c90d9"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x70a108331ff4299cde3bc6747aa45dde63ed4d86"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5397cd1807b0a3b78571fd58dd9b03ebe51948a7"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa1fbd84000dfc92f9eac0fbf55749bb472995c85"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd771e43a1ccbe75baeee1d6a994ed6913845e7cf"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe85184f8e2b8be53df91d5a47f95d4a9717f765f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x21b637f563b2230ebd06f1bad5ce724c6c2e5bbf"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2ad8f4992c434b04a5762dd4fa971f198b86d192"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4c7bc258ae2c52f8753e625833e2ba75ada817ee"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x113f4e2581ce9b305c09e8e122676a0bbb992249"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x900bcd02cd2dd805c3ae491156f3412fe4500980"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x37fdfa13477c6278cf970b62f5a2d670c390995f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1dabc369fa13d375d46fae68d54aafa0347117ec"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3c606952781ffc466c61cf8849da04bac51441a4"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x78cc2aac243e046e62213a539f87ac8f5150988f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5a3a7fce9e0e45921df82946214c564a0ee58658"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x279646ba53f923be56274a8c1ebb109380c7474e"}, {name: "value", type: "uint256", value: "600000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6cb7652a5b6a4b9cc849932622ade4979b466dcc"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6de078fe0822149faa6c811f9c8fa48eb220d28f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x19be6baac8296c12a1ef44c8f9ce0bf1bd8cf195"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637342337098713408266031184226... )", async function( ) {
		const txOriginal = {blockNumber: "3834708", timeStamp: "1496839329", hash: "0xa101e698afbf065a283adb679be162c9067e68030ea8e95e74872faae8be55b3", nonce: "23", blockHash: "0x51dcc0e80c8d78aa9a3909bb14706d73989d595374195cac139b4cf05a6023b4", transactionIndex: "45", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "714140", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e800c848a380dd94ae23c5b5ca172ae54fad5df4a39b00000000000000174876e800831be85dc378994f0a3ef3d1f20fa55944d86c3300000000000000174876e800aea087a20f96e637c7eaa5ad142ac2cfef0c840200000000000000174876e8001374c83bf4af8e0c847d449840bb7a9b0963a1c800000000000000174876e800e4497eb1e2ae95a9f919e4e6c2b68b52504c28ed00000000000000174876e8009f78b10d59572c8bac8871eba01388617950263a00000000000000174876e800ec9d33f9a515a434fb7c2d7392d8a58c34ec673300000000000000174876e800bf5f578cd3a533ef917705f3440a5aa8865969e200000000000000174876e800ab67e90da1b14acf3b79746c1d918cacd1828ed500000000000000174876e80049ddc20d6105094ddb5f5685665c9410732e3c7400000000000000174876e8000e4ad8029b466478a2e371db43a807a4bdb07a110000000000000045d964b8005b345628c40a42bb7baeec062508cc43144f237700000000000000174876e8004fff9c903ed8252e0a6776e8b4dd162407727cfc00000000000000517da02c000bb160b09bce2160023d4d4be8925d84ed9718fb000000000000886c98b76000ef8b50345ae5de32ccfdd974c10893e2e3f281840000000000009184e72a00009b30126036b75cd84cc079550271f6df2a847dc2000000000000ec77f7a440009fc974571131fc8f93934638f99fceed8ed8632f000000000000da475abf000028d08a4bc76f32247dfd04bc7ac91fe428b7479e000000000000ec77f7a44000fd9c0050bee089e1fac7bec29a88f2e55205666200000000000012309ce540000025165361865b09c7c625f4db69ba6b0ac85a95", contractAddress: "", cumulativeGasUsed: "4379995", gasUsed: "614139", confirmations: "3840458"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163734233709871340826603118422638520270053307669848987","146150163733838791973423188512424112323587694651800689339443","146150163734087236149028662411212026018932865730259918291970","146150163733201366974316254939273516709195299262808365179336","146150163734393580707195129787686435912634276024292328876269","146150163734000712865770332047237896172232966489344517875258","146150163734441119386955405578318212067651796279584797517619","146150163734182835255079429351503836820221974295629667068386","146150163734068846520736027615747695312167861568156756774613","146150163733511993515663601621857227266432383682326291168372","146150163733171886763445430123060703021260728994313475750417","438450491199791560765529209575847639209635486369586613265271","146150163733547002419889992520114406600798405756898373696764","511525573065882775924545140262256154665997900243537860434171","219225245599636805286137332782528390903939138004297263965438340","233840261972945352878195581443582760825613562688311199059443138","379990425706035670955075054991800516817904399577820234341966639","350760392959416933379117475829693616085766672165158838469085086","379990425706036206586566802216954390763405426277879972171703906","29230032746618059191146112359641724283598428216129178714004117"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163734233709871340826603118422638520270053307669848987","146150163733838791973423188512424112323587694651800689339443","146150163734087236149028662411212026018932865730259918291970","146150163733201366974316254939273516709195299262808365179336","146150163734393580707195129787686435912634276024292328876269","146150163734000712865770332047237896172232966489344517875258","146150163734441119386955405578318212067651796279584797517619","146150163734182835255079429351503836820221974295629667068386","146150163734068846520736027615747695312167861568156756774613","146150163733511993515663601621857227266432383682326291168372","146150163733171886763445430123060703021260728994313475750417","438450491199791560765529209575847639209635486369586613265271","146150163733547002419889992520114406600798405756898373696764","511525573065882775924545140262256154665997900243537860434171","219225245599636805286137332782528390903939138004297263965438340","233840261972945352878195581443582760825613562688311199059443138","379990425706035670955075054991800516817904399577820234341966639","350760392959416933379117475829693616085766672165158838469085086","379990425706036206586566802216954390763405426277879972171703906","29230032746618059191146112359641724283598428216129178714004117"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1496839329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc848a380dd94ae23c5b5ca172ae54fad5df4a39b"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x831be85dc378994f0a3ef3d1f20fa55944d86c33"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaea087a20f96e637c7eaa5ad142ac2cfef0c8402"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1374c83bf4af8e0c847d449840bb7a9b0963a1c8"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe4497eb1e2ae95a9f919e4e6c2b68b52504c28ed"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9f78b10d59572c8bac8871eba01388617950263a"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xec9d33f9a515a434fb7c2d7392d8a58c34ec6733"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbf5f578cd3a533ef917705f3440a5aa8865969e2"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xab67e90da1b14acf3b79746c1d918cacd1828ed5"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x49ddc20d6105094ddb5f5685665c9410732e3c74"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0e4ad8029b466478a2e371db43a807a4bdb07a11"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5b345628c40a42bb7baeec062508cc43144f2377"}, {name: "value", type: "uint256", value: "300000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4fff9c903ed8252e0a6776e8b4dd162407727cfc"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0bb160b09bce2160023d4d4be8925d84ed9718fb"}, {name: "value", type: "uint256", value: "350000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xef8b50345ae5de32ccfdd974c10893e2e3f28184"}, {name: "value", type: "uint256", value: "150000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "value", type: "uint256", value: "160000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9fc974571131fc8f93934638f99fceed8ed8632f"}, {name: "value", type: "uint256", value: "260000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x28d08a4bc76f32247dfd04bc7ac91fe428b7479e"}, {name: "value", type: "uint256", value: "240000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xfd9c0050bee089e1fac7bec29a88f2e552056662"}, {name: "value", type: "uint256", value: "260000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0025165361865b09c7c625f4db69ba6b0ac85a95"}, {name: "value", type: "uint256", value: "20000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637331649577648161738699458536... )", async function( ) {
		const txOriginal = {blockNumber: "3834711", timeStamp: "1496839373", hash: "0x032843d73f7ddf9e8389b79b3e79e5c10495dc82b0d4d35969ba88296df81f43", nonce: "24", blockHash: "0x41559412f8806de898b2f1e195ceb2227b85e2780e340deae878429a91ed833e", transactionIndex: "21", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "713948", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e8000d142301be201e9bbe2eaf53fd84499b285d2ff000000000000000174876e8003cc84301da33135ade1d27cd6ef299c985a40299000000000000002e90edd000c59056dc3dd76e6780bb563c11033499247b3cb800000000000000174876e800438921272b641c6e818af885528dd8387694573800000000000000174876e800c1a17ec8d2cc179f6c5aaab28fd568527b16fb2400000000000000174876e8002b1cd75791153c880aabed6f4300f1d8be4d3d7c00000000000000174876e8008679b60973a7e365f92ca208024f2756e8df43a000000000000000174876e8000ac2faf04bd9c033cd94c105ba398e19d6cfb6cb0000000000000022ecb25c007a2fcbcebaf90a77828241fa0ade5bf9ead1b95800000000000000174876e8005043bf2276abcc19da847fddce7c6645cc41a99700000000000000174876e800cd0279459136f1d22d849037609decf2ceeb9a8d00000000000000174876e80049c06cdfd6917c34875bb28fc49ef505440c38ed00000000000000174876e800d113b74adb5c89f5bab1d8131f26daa43e487f4100000000000000174876e80068a59be07577bf56edf158336c747a78df95dd4f00000000000000174876e800debb3a4c1b757c20975f49b25d32663c33e5039900000000000000174876e800bfe48b7920d0f32a7a1e843a49f145146032cfa100000000000000174876e800e19bf2f80b14b5cea5661099c2a7dbabdab04a7600000000000000174876e800cf40ccd0c73e86e984aa7f6e3e615742977b76a9000000000000002e90edd0007abddc1e68f690375704a0c5f71b97f572762a3700000000000000174876e8000a969901173e9468d5d0db653cf899b2d001d39e", contractAddress: "", cumulativeGasUsed: "3545305", gasUsed: "613947", confirmations: "3840455"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163733164957764816173869945853665684099473974434279408","146150163733437297252811096465354016480338894930532756619929","292300327467308473696498763684083450544598930830265392250040","146150163733475852292140003883294315628219244546718388475704","146150163734195728503599146102910062304319546288458226400036","146150163733336421603318356804538716549560252729264358374780","146150163733858010831480213801205785733669730346300820374432","146150163733151729932485310335276059417869351095567695984331","219225245600333000493758305503156348841700205641118002559320","146150163733548521882136646352761774282366799691431911991703","146150163734260690094136871844008867127446605159428401109645","146150163733511339374011800083339417696459721750586684356845","146150163734283910572650239898853977351825646938221810581313","146150163733687720062275631187755845155179926126467975863631","146150163734361863089254043972840736602307440497325496402841","146150163734185805777326632740543543678244269674896087502753","146150163734378292524887570934919257721824320057475773516406","146150163734273497999571627441581671659552488770558750324393","292300327466881314530670893189509507369482402908425325783607","146150163733150740168407428362991344425080800832124358874014"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163733164957764816173869945853665684099473974434279408","146150163733437297252811096465354016480338894930532756619929","292300327467308473696498763684083450544598930830265392250040","146150163733475852292140003883294315628219244546718388475704","146150163734195728503599146102910062304319546288458226400036","146150163733336421603318356804538716549560252729264358374780","146150163733858010831480213801205785733669730346300820374432","146150163733151729932485310335276059417869351095567695984331","219225245600333000493758305503156348841700205641118002559320","146150163733548521882136646352761774282366799691431911991703","146150163734260690094136871844008867127446605159428401109645","146150163733511339374011800083339417696459721750586684356845","146150163734283910572650239898853977351825646938221810581313","146150163733687720062275631187755845155179926126467975863631","146150163734361863089254043972840736602307440497325496402841","146150163734185805777326632740543543678244269674896087502753","146150163734378292524887570934919257721824320057475773516406","146150163734273497999571627441581671659552488770558750324393","292300327466881314530670893189509507369482402908425325783607","146150163733150740168407428362991344425080800832124358874014"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1496839373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0d142301be201e9bbe2eaf53fd84499b285d2ff0"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3cc84301da33135ade1d27cd6ef299c985a40299"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc59056dc3dd76e6780bb563c11033499247b3cb8"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x438921272b641c6e818af885528dd83876945738"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc1a17ec8d2cc179f6c5aaab28fd568527b16fb24"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2b1cd75791153c880aabed6f4300f1d8be4d3d7c"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8679b60973a7e365f92ca208024f2756e8df43a0"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0ac2faf04bd9c033cd94c105ba398e19d6cfb6cb"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7a2fcbcebaf90a77828241fa0ade5bf9ead1b958"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5043bf2276abcc19da847fddce7c6645cc41a997"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcd0279459136f1d22d849037609decf2ceeb9a8d"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x49c06cdfd6917c34875bb28fc49ef505440c38ed"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd113b74adb5c89f5bab1d8131f26daa43e487f41"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x68a59be07577bf56edf158336c747a78df95dd4f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdebb3a4c1b757c20975f49b25d32663c33e50399"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbfe48b7920d0f32a7a1e843a49f145146032cfa1"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe19bf2f80b14b5cea5661099c2a7dbabdab04a76"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcf40ccd0c73e86e984aa7f6e3e615742977b76a9"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7abddc1e68f690375704a0c5f71b97f572762a37"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0a969901173e9468d5d0db653cf899b2d001d39e"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637340975177960430731353083939... )", async function( ) {
		const txOriginal = {blockNumber: "3834711", timeStamp: "1496839373", hash: "0x19741741b78c140f1363d4012b7e4f11c083cf3a58a006073baec925636bad33", nonce: "25", blockHash: "0x41559412f8806de898b2f1e195ceb2227b85e2780e340deae878429a91ed833e", transactionIndex: "25", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "713820", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e800b06d93270472390b53b38f9eb967889ab615adbd00000000000000174876e800215deb431ebb049f3d10d0b2277464297452a44100000000000000174876e800df00afb687a38c3f54a1149b88dd9f0e36b055ac00000000000000174876e800373ee62c54831fa3fe104c0f17852561081b8ae7000000000000002e90edd00020bd47e6f3db30f4cdb9948b74f3f52b14aeb6bd000000000000002e90edd0002f3c7a797cd7a66c3734375941bab14f1cbcf35700000000000000174876e800370b7adc3ba4e0cf785e9891fbe70894b00079e700000000000000174876e8000730144be224f0f151c9c92f58079795bd6b000400000000000000174876e8003377accfaa1e6fb1a87f7ea875d733e741d7943100000000000000174876e800868585bf7cc6886fc010b1393cf3ba35388a324000000000000000174876e8000e854453db4d70631430ae6338d993d6a47f5fa400000000000000174876e80096f6296c4716b1f9ba1015553447df5ced112a5a00000000000000174876e800e84a53319880a70f1a06f4ceda8e1ce8f10e364800000000000000174876e8005bfd721c27c90834b0f761cf224703380f41359600000000000000174876e800c701c1b7059dfba9634e66103ab2835cb980ef2f00000000000000174876e800f22adeb03b3a6d19139b424764d1161b6e366f2900000000000000174876e80012598bc5fb3e6e8a181298b50347aa078e5496e400000000000000174876e800cc87831f237068deaf15ed440c1dcc857231212c00000000000000174876e80065f26dd40a0961b955b597c541777d597b86c33600000000000000174876e800a88c512622ae11276b79702a86d53cf774a31707", contractAddress: "", cumulativeGasUsed: "4222124", gasUsed: "613819", confirmations: "3840455"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163734097517796043073135308393971568878760852341501373","146150163733280782979336093764372906201301594306770615051329","146150163734363412069023923291560071604435160643629357225388","146150163733405689009876627777755839302546527336377819564775","292300327466367492449807237751537928385802319604076470253245","292300327466450254920716592901223333918680931371090114835287","146150163733404542323601263227805577789188831724078169618919","146150163733131326959601273109115947892809782216245891497988","146150163733384119192336881240526910337002160749875123688497","146150163733858274233864098460282210919666206048740702827072","146150163733173189642441804429394770676248394898723812892580","146150163733952130027759609591191070660545163783066293971546","146150163734416435181540584280305402305927804992742363117128","146150163733615462009430067120380808214943071264647850046870","146150163734226420159457950278723999068152631858830508093231","146150163734472823617102091969263116233321718460915379498793","146150163733195050596543312797976492411430029615658379286244","146150163734257947960523665247951438912529788628968726929708","146150163733672306235952104816188983226966151662054291194678","146150163734052531443266670573949120631350963070859558983431"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163734097517796043073135308393971568878760852341501373","146150163733280782979336093764372906201301594306770615051329","146150163734363412069023923291560071604435160643629357225388","146150163733405689009876627777755839302546527336377819564775","292300327466367492449807237751537928385802319604076470253245","292300327466450254920716592901223333918680931371090114835287","146150163733404542323601263227805577789188831724078169618919","146150163733131326959601273109115947892809782216245891497988","146150163733384119192336881240526910337002160749875123688497","146150163733858274233864098460282210919666206048740702827072","146150163733173189642441804429394770676248394898723812892580","146150163733952130027759609591191070660545163783066293971546","146150163734416435181540584280305402305927804992742363117128","146150163733615462009430067120380808214943071264647850046870","146150163734226420159457950278723999068152631858830508093231","146150163734472823617102091969263116233321718460915379498793","146150163733195050596543312797976492411430029615658379286244","146150163734257947960523665247951438912529788628968726929708","146150163733672306235952104816188983226966151662054291194678","146150163734052531443266670573949120631350963070859558983431"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1496839373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb06d93270472390b53b38f9eb967889ab615adbd"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x215deb431ebb049f3d10d0b2277464297452a441"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdf00afb687a38c3f54a1149b88dd9f0e36b055ac"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x373ee62c54831fa3fe104c0f17852561081b8ae7"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x20bd47e6f3db30f4cdb9948b74f3f52b14aeb6bd"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2f3c7a797cd7a66c3734375941bab14f1cbcf357"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x370b7adc3ba4e0cf785e9891fbe70894b00079e7"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0730144be224f0f151c9c92f58079795bd6b0004"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3377accfaa1e6fb1a87f7ea875d733e741d79431"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x868585bf7cc6886fc010b1393cf3ba35388a3240"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0e854453db4d70631430ae6338d993d6a47f5fa4"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x96f6296c4716b1f9ba1015553447df5ced112a5a"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe84a53319880a70f1a06f4ceda8e1ce8f10e3648"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5bfd721c27c90834b0f761cf224703380f413596"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc701c1b7059dfba9634e66103ab2835cb980ef2f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf22adeb03b3a6d19139b424764d1161b6e366f29"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x12598bc5fb3e6e8a181298b50347aa078e5496e4"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcc87831f237068deaf15ed440c1dcc857231212c"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x65f26dd40a0961b955b597c541777d597b86c336"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa88c512622ae11276b79702a86d53cf774a31707"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637337448339837387364139638867... )", async function( ) {
		const txOriginal = {blockNumber: "3834712", timeStamp: "1496839375", hash: "0xf1d4b376164a1dc2d9be00c28d4323a645a54aa59cf1d2ee8b50cb4349f4f9a9", nonce: "26", blockHash: "0x4ba101f1c6344607cdce0a36639e12caaf2b951738c142c0dd96880e4e250e74", transactionIndex: "6", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "713948", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e80072a6af8a8ab54492fbe8f58629063b661af3652900000000000000174876e8006fa58e8f5ace80bbc84f5ca965e1684761b37db600000000000000174876e800115290c9c9d0befef9df3309afdca8aac967ba1b00000000000000174876e8007e7f2c5d174c2a14064dbed0ef40b7ae76b685bd00000000000000174876e800087061c93b8d8b1d2840a8131f97e596a520ad720000000000000022ecb25c000d36c0a3514c9056fec80cd8320facd8a606284a00000000000000174876e800bab529e6d538e9e591529da48abe7cc6eeb1a51f00000000000000174876e8002a1bbb20fd0a2cf6cd9210ec2c6b8c50e1d7f2f400000000000000174876e80028167032ece491f76a4b806acd3cef8131abd8de00000000000000174876e800fe21b7137dfda14c8e9e290e84b8abd5f55403ee000000000000002e90edd000f5ecd2a0b82a79db4b93ff81e70fb46eb30042ae00000000000000746a528800005ac13a2ff669fcc35b112f7a6c99d626c8b6a90000000000001b6033cec8001853078d0b27b68b60205f905e8355b1029df22f00000000000000174876e80000cca4dcbaca9911f9a4a492c3b2ee8a8de7589000000000000000174876e80032bd7da1803eb5b3128f6898e319e352d763bf0300000000000000174876e800771c49783b15c63004290a65934b042ee1b3e33e00000000000000150ceab38f0f4b62b9f88e9cb36553b6ce94f8d210607ef51500000000000000174876e800aa5293d1765cba62ad9272e78d0c3ab53f3d674500000000000000174876e8008420537853d39bcaffef48cd5128e8898a18abfa00000000000000174876e800ff81a7ebd827da90e1b311ca18362877080aff94", contractAddress: "", cumulativeGasUsed: "739947", gasUsed: "613947", confirmations: "3840454"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163733744833983738736413963886751391180318498941527337","146150163733727681837613370535085347630720756658530650652086","146150163733189185937412956677980472516357595948433722030619","146150163733812460716750309273830801898044676119359139513789","146150163733138469948364959936639947628767167672415105887602","219225245599710875631947145190766735216894040853236354000970","146150163734156204188774740135626170900696622884509189252383","146150163733330687854086297356989009835752335199099508224756","146150163733319151841500831840741920545683340028182226786526","146150163734541127348930450927081906737299661176098530788334","292300327467584567703725683329995479466200718646299462746798","730750818665453483001381599395874337342863042077166223799977","43991199283660316705329045357918567413520779689936469855433263","146150163733094855533914285405850314577827307632525792729232","146150163733379967143743866871085054698393125618005724872451","146150163733770292543071373591177310053004709758120603411262","132135855515184789533263208020481201821333868422236796286229","146150163734062661789297192532237807706518762882580610901829","146150163733844599497228624093524777600380020276066038361082","146150163734548975891064599810785764956055843490269282107284"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163733744833983738736413963886751391180318498941527337","146150163733727681837613370535085347630720756658530650652086","146150163733189185937412956677980472516357595948433722030619","146150163733812460716750309273830801898044676119359139513789","146150163733138469948364959936639947628767167672415105887602","219225245599710875631947145190766735216894040853236354000970","146150163734156204188774740135626170900696622884509189252383","146150163733330687854086297356989009835752335199099508224756","146150163733319151841500831840741920545683340028182226786526","146150163734541127348930450927081906737299661176098530788334","292300327467584567703725683329995479466200718646299462746798","730750818665453483001381599395874337342863042077166223799977","43991199283660316705329045357918567413520779689936469855433263","146150163733094855533914285405850314577827307632525792729232","146150163733379967143743866871085054698393125618005724872451","146150163733770292543071373591177310053004709758120603411262","132135855515184789533263208020481201821333868422236796286229","146150163734062661789297192532237807706518762882580610901829","146150163733844599497228624093524777600380020276066038361082","146150163734548975891064599810785764956055843490269282107284"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1496839375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x72a6af8a8ab54492fbe8f58629063b661af36529"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6fa58e8f5ace80bbc84f5ca965e1684761b37db6"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x115290c9c9d0befef9df3309afdca8aac967ba1b"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7e7f2c5d174c2a14064dbed0ef40b7ae76b685bd"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x087061c93b8d8b1d2840a8131f97e596a520ad72"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0d36c0a3514c9056fec80cd8320facd8a606284a"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbab529e6d538e9e591529da48abe7cc6eeb1a51f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2a1bbb20fd0a2cf6cd9210ec2c6b8c50e1d7f2f4"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x28167032ece491f76a4b806acd3cef8131abd8de"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xfe21b7137dfda14c8e9e290e84b8abd5f55403ee"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf5ecd2a0b82a79db4b93ff81e70fb46eb30042ae"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x005ac13a2ff669fcc35b112f7a6c99d626c8b6a9"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1853078d0b27b68b60205f905e8355b1029df22f"}, {name: "value", type: "uint256", value: "30100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x00cca4dcbaca9911f9a4a492c3b2ee8a8de75890"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x32bd7da1803eb5b3128f6898e319e352d763bf03"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x771c49783b15c63004290a65934b042ee1b3e33e"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0f4b62b9f88e9cb36553b6ce94f8d210607ef515"}, {name: "value", type: "uint256", value: "90411021199"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaa5293d1765cba62ad9272e78d0c3ab53f3d6745"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8420537853d39bcaffef48cd5128e8898a18abfa"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xff81a7ebd827da90e1b311ca18362877080aff94"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"1461501637333041125535992567998814857... )", async function( ) {
		const txOriginal = {blockNumber: "3834716", timeStamp: "1496839405", hash: "0x454bb51f91943d473fb3870f95de7583475a5f3e490e12d42bae8151402252c6", nonce: "27", blockHash: "0x045df3fb3d1abc19da49f632467bd63c1edf6250c1288c34ecf98d43d0c5a487", transactionIndex: "12", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "714908", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000174876e80025740da400ee2a5a236653d248562c1a149fbdaa00000000000009184e72a000d74653379a5ddca1afa767b5560384474c8a30d900000000000000174876e80022d12dadebee1b03a59a2b916cdb7ce5c785244500000000000000001dcd6500dcd55c15999606ca3917a64dd3fa4d18e233d99200000000000000746a52880026c66f18bde464be7f892aa01e22ed33c6c73b9900000000000000018a6f96029a504ff27a1bad8ba0f133a79cb952fad1adc8840000000000000000000493e10b85e81af385a7079e40b75274154b70ab0b60650000000000000001241006960055ceb412a67dec3241a6e77ff82842b7da68ef000000000000003e1299346ae75eaae551efad295ee4c5917404db197d3aa1100000000000006bf21c3cbc00f085548d7bbf66b8731e1a16bd891cad98cb102a00000000000000345e0846608d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000174876e80008c61f4e693585ec9426c15f52b60ef6426061940000000000010ac8f52fd4000fa5f36737fb8aba824a3a9405fb280dce10ed19000000000000e18dffe78000f06e1b1066b1c3150689170e44f9060d9c6ed122000000000001360bdf8fe4003fe666fc563e5fa99f8e0e6988ee2070cea1fa6b0000000000027cd3fe4faf32378ff330eff4091213a7f05c75dea07a411b17b80000000000016be38a5fe8004ae74a1b6a24e1d8bc057d8efb8f3910c83312f50000000000004d4e94d86f0017cceb5416303cc5b49303348ea8b6914ca47a62000000000000880f6aeffe002e20c53dbe1dde7110df7ff20131135a54e276af0000000000005b0a58f12800e4e75f8d3ffa8eaf564ec08d829a9f319a685713", contractAddress: "", cumulativeGasUsed: "1005559", gasUsed: "614907", confirmations: "3840450"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["146150163733304112553599256799881485796737868892133799214506","14615016373310258183353979800790811247162240451711918290907353","146150163733289062341558308015798044811983656463834607330373","730750819926187509090760427301067531757375735109822699922","730750818665672825976565956533155170969847446427871411125145","9671539702900172851083730217491495984950317252726022326404","438452018486025018204905843408122737966943454374879333","7161354126559972744759269419850031634463829689224071375087","389636340410102971142520707504737167977678471324890411213072","173462121730876646325741349398415120257608048739619861223378986","328714956112559010849238402401570515494416060150387089106969","146150163733140382021247118403200130169685324664960106652052","428706952083513301221713052866108297657690352322949428267773209","362452406058065296327738420815769661781855387035771122920378658","498225323565450237259030154521955076363115743604246802950388331","1023343300309007882522478741334046569974305215781607549026637752","584746805096094685196539121267011652444180606413305154486080245","124227493022963150833661140267220744958019897672075539789412962","218640352644375873727069044748333858541196570039440981581002415","146296313896824688921880472470470419760373309609621988630353683"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["146150163733304112553599256799881485796737868892133799214506","14615016373310258183353979800790811247162240451711918290907353","146150163733289062341558308015798044811983656463834607330373","730750819926187509090760427301067531757375735109822699922","730750818665672825976565956533155170969847446427871411125145","9671539702900172851083730217491495984950317252726022326404","438452018486025018204905843408122737966943454374879333","7161354126559972744759269419850031634463829689224071375087","389636340410102971142520707504737167977678471324890411213072","173462121730876646325741349398415120257608048739619861223378986","328714956112559010849238402401570515494416060150387089106969","146150163733140382021247118403200130169685324664960106652052","428706952083513301221713052866108297657690352322949428267773209","362452406058065296327738420815769661781855387035771122920378658","498225323565450237259030154521955076363115743604246802950388331","1023343300309007882522478741334046569974305215781607549026637752","584746805096094685196539121267011652444180606413305154486080245","124227493022963150833661140267220744958019897672075539789412962","218640352644375873727069044748333858541196570039440981581002415","146296313896824688921880472470470419760373309609621988630353683"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1496839405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x25740da400ee2a5a236653d248562c1a149fbdaa"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd74653379a5ddca1afa767b5560384474c8a30d9"}, {name: "value", type: "uint256", value: "10000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x22d12dadebee1b03a59a2b916cdb7ce5c7852445"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdcd55c15999606ca3917a64dd3fa4d18e233d992"}, {name: "value", type: "uint256", value: "500000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x26c66f18bde464be7f892aa01e22ed33c6c73b99"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9a504ff27a1bad8ba0f133a79cb952fad1adc884"}, {name: "value", type: "uint256", value: "6617536002"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0b85e81af385a7079e40b75274154b70ab0b6065"}, {name: "value", type: "uint256", value: "300001"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0055ceb412a67dec3241a6e77ff82842b7da68ef"}, {name: "value", type: "uint256", value: "4899997334"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe75eaae551efad295ee4c5917404db197d3aa110"}, {name: "value", type: "uint256", value: "266600002666"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf085548d7bbf66b8731e1a16bd891cad98cb102a"}, {name: "value", type: "uint256", value: "118687600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "value", type: "uint256", value: "224915900000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x08c61f4e693585ec9426c15f52b60ef642606194"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0fa5f36737fb8aba824a3a9405fb280dce10ed19"}, {name: "value", type: "uint256", value: "293333200000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf06e1b1066b1c3150689170e44f9060d9c6ed122"}, {name: "value", type: "uint256", value: "248000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3fe666fc563e5fa99f8e0e6988ee2070cea1fa6b"}, {name: "value", type: "uint256", value: "340899600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "700199900000050"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4ae74a1b6a24e1d8bc057d8efb8f3910c83312f5"}, {name: "value", type: "uint256", value: "400100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x17cceb5416303cc5b49303348ea8b6914ca47a62"}, {name: "value", type: "uint256", value: "84999900000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2e20c53dbe1dde7110df7ff20131135a54e276af"}, {name: "value", type: "uint256", value: "149599800000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe4e75f8d3ffa8eaf564ec08d829a9f319a685713"}, {name: "value", type: "uint256", value: "100100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"2192252455998166049606952481633609970... )", async function( ) {
		const txOriginal = {blockNumber: "3834716", timeStamp: "1496839405", hash: "0x2cdeb3abf9d7fa1d177e676afeeba25fc01aa028816ed5f4492140023f20617c", nonce: "28", blockHash: "0x045df3fb3d1abc19da49f632467bd63c1edf6250c1288c34ecf98d43d0c5a487", transactionIndex: "17", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "714652", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc2000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000140000000000000022ecb25c001fbbd1cef775eff433faeda5cf4729eb4f1c8b5f00000000000000174876e8002c34f83c296eaa773ac369751a858163bd79674f00000000000115fd5691900064d70458a92c0301661824a57350986b51c90e4a00000000000019b554a6ea006197d623263a39424b796edbe6911f2488f46ba100000000000048845b05f50094ca9ce1d20c46a91d9e4650d380c290d75b2d83000000000000794413fbb500d23c268d3cc9beff7239ac43e4f589c182182e150000000000000022ecb25c005b96101117c64d6ce83c18c9dcd10127bdcc6fb10000000000000c20669c3500e147b83bfc08dbbf302bd27de2fc3df90552e3a3000000000000061030532a00f3fc6604602b71d83aa6e23d23e18cf22d1c2d820000000000005af3107a4000921dd7b8841b3d494f064f6bb1920e19b60a13c1000000000000002e90edd000fc3c0d21b725d61aeec3e086e7924f4d5eb1946c00000000000000174876e8003cbaf780c0bc0fe3dbc4f8e91c9343eb80d22df40000000000000000458ba1b069139c934085ed31954322ee174fbfc4bf942dfd00000000000000000bd75f406d6045105d6e5946ef7acad8a46a938f6e2db46c00000000000000000bebc200d564564a90c275a4e8d1b643539bb2537c1b971800000000000000003b9aca002017b38a0e12c0f59a22f064c5faa71f07f8f3c50000000000000000182e7d9e86efc7205051cc7b28b80b5864db23fd592fcdc10000000000004a311619a8e876a26f8f5b57012f8d7caf68a229e09be7dd5359000000000000b5e620f48000e551b5d60f5359f9a97942b6be81c24bd87f36810000000000000002540be3ce75a57367bb270d482d2b21a473bcfa2798ff58a5", contractAddress: "", cumulativeGasUsed: "1929664", gasUsed: "614651", confirmations: "3840450"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["219225245599816604960695248163360997016653574776207712226143","146150163733342668677353981852832987035018842619634272266063","446712067654775579171243158365369300346175983690408075721248330","41311682181778257585867562468233363604991257996399082051234721","116530348499796931097060835243384324150673348910443778992188803","194866836260733678293192283304495509910568901634154472836443669","219225245600158302402090450932493896792424794583443012612017","19486639781025414001610607722165740502286917816591051499168675","9743246815431590307928727654480425600728785758528995698945410","146150163733091125998534563339959310703402888848750355942085569","292300327467620588503628966342807911065252957329562782504044","146150163733437000765771796698936721964038285506581519019508","1705249127202867494537348046627375936425924449084298767869","290347761903133379217312620778759266342171632391064237164","292300328684433209375971654140707698004881322495339894552","1461501637514119180086468888963345745340146800329261380549","592931212112496026986971540240367802303697257525586939329","119221535156349903224900798924602710297927094417220362615739225","292300327466181892821824010834863304008629360809584542724601473","14615016300905588911846583543596239529571728670437698132133"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["219225245599816604960695248163360997016653574776207712226143","146150163733342668677353981852832987035018842619634272266063","446712067654775579171243158365369300346175983690408075721248330","41311682181778257585867562468233363604991257996399082051234721","116530348499796931097060835243384324150673348910443778992188803","194866836260733678293192283304495509910568901634154472836443669","219225245600158302402090450932493896792424794583443012612017","19486639781025414001610607722165740502286917816591051499168675","9743246815431590307928727654480425600728785758528995698945410","146150163733091125998534563339959310703402888848750355942085569","292300327467620588503628966342807911065252957329562782504044","146150163733437000765771796698936721964038285506581519019508","1705249127202867494537348046627375936425924449084298767869","290347761903133379217312620778759266342171632391064237164","292300328684433209375971654140707698004881322495339894552","1461501637514119180086468888963345745340146800329261380549","592931212112496026986971540240367802303697257525586939329","119221535156349903224900798924602710297927094417220362615739225","292300327466181892821824010834863304008629360809584542724601473","14615016300905588911846583543596239529571728670437698132133"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1496839405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1fbbd1cef775eff433faeda5cf4729eb4f1c8b5f"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2c34f83c296eaa773ac369751a858163bd79674f"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x64d70458a92c0301661824a57350986b51c90e4a"}, {name: "value", type: "uint256", value: "305652800000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6197d623263a39424b796edbe6911f2488f46ba1"}, {name: "value", type: "uint256", value: "28266600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x94ca9ce1d20c46a91d9e4650d380c290d75b2d83"}, {name: "value", type: "uint256", value: "79733300000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd23c268d3cc9beff7239ac43e4f589c182182e15"}, {name: "value", type: "uint256", value: "133333300000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5b96101117c64d6ce83c18c9dcd10127bdcc6fb1"}, {name: "value", type: "uint256", value: "150000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe147b83bfc08dbbf302bd27de2fc3df90552e3a3"}, {name: "value", type: "uint256", value: "13333300000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf3fc6604602b71d83aa6e23d23e18cf22d1c2d82"}, {name: "value", type: "uint256", value: "6666600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x921dd7b8841b3d494f064f6bb1920e19b60a13c1"}, {name: "value", type: "uint256", value: "100000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xfc3c0d21b725d61aeec3e086e7924f4d5eb1946c"}, {name: "value", type: "uint256", value: "200000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3cbaf780c0bc0fe3dbc4f8e91c9343eb80d22df4"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x69139c934085ed31954322ee174fbfc4bf942dfd"}, {name: "value", type: "uint256", value: "1166778800"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6d6045105d6e5946ef7acad8a46a938f6e2db46c"}, {name: "value", type: "uint256", value: "198664000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd564564a90c275a4e8d1b643539bb2537c1b9718"}, {name: "value", type: "uint256", value: "200000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x2017b38a0e12c0f59a22f064c5faa71f07f8f3c5"}, {name: "value", type: "uint256", value: "1000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x86efc7205051cc7b28b80b5864db23fd592fcdc1"}, {name: "value", type: "uint256", value: "405699998"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x76a26f8f5b57012f8d7caf68a229e09be7dd5359"}, {name: "value", type: "uint256", value: "81574684633320"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe551b5d60f5359f9a97942b6be81c24bd87f3681"}, {name: "value", type: "uint256", value: "200000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x75a57367bb270d482d2b21a473bcfa2798ff58a5"}, {name: "value", type: "uint256", value: "9999999950"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: fill( [\"2192252455996358480405920247030003069... )", async function( ) {
		const txOriginal = {blockNumber: "3834722", timeStamp: "1496839438", hash: "0xbb67c6b6b727163eb31fc8ccc41d3b701b27a9ea38a6ec16fc964bd1a2e7d11f", nonce: "29", blockHash: "0x19440e8171e93721e31518b0f562bd0e6c69b3d32651cdf153ae4bc072729c4d", transactionIndex: "1", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "478147", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x884b5dc20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000c0000000000000da475abf000072fe4d35215cc543c9795fb5417e1c854f6edb5000000000006849504a960b8003359e6922510dd30552ed6c3204c68638c1f77000000000000000017d784006fbf77feeb2638c60c435a8536ea2114f22106b600000000000000746a528800558f72bb1e5e297a1efed0e6f6996b7e0c902bfe0000000000001840cd386a0098ae486929deb9fe12213873499c4e8a168c66a60000000000000006c67ec300ad6ee8d1aeb39b295a6f09189951724cf43ce00800000000000012ee3f72bb003676f6af1a65370ad04ddf0674750ee519941d73000000000000000005f5e1007cf1a4951c2b03a923dcc7cff945efcf1155951500000000000119f17fe16000f1e0ef185dcfee96135a1f0bebda182b12f7546b00000000000110d93764a100928767b8cd6206ffe41c87d1a7f5fd1b31d9fbdd000000000000c816bdd9c0000362371f43e5bbebfba6755ca762256b3a9a05c6000000000001c6bf52634000262b667bef4177fd4d02610326f75682f20fd210", contractAddress: "", cumulativeGasUsed: "411717", gasUsed: "378146", confirmations: "3840444"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "data", value: ["21922524559963584804059202470300030699731666796668103700180405","2681308060285453942536124918025215280971825752820764526817058679","584600655570329038282153584480134949947504939089352787638","730750818665939922318399597188726648978476187468948057369598","38973279562049127411805081618471684251389883376686962586707622","42529697647319403686453160332589183782176145656707467239432","30420390754185093787759325814975374315674471515904334238063987","146150164446393964149777671248711153785034190439667045653","453065507572581285526113118970577622869777623693145361031320683","438450637349435445083685862672783794033593025843779053343603677","321530360212798661322057819855846472842054965884675179620730310","730750818665451677011351377122455010063260959463021411853914640"]}], name: "fill", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fill(uint256[])" ]( ["21922524559963584804059202470300030699731666796668103700180405","2681308060285453942536124918025215280971825752820764526817058679","584600655570329038282153584480134949947504939089352787638","730750818665939922318399597188726648978476187468948057369598","38973279562049127411805081618471684251389883376686962586707622","42529697647319403686453160332589183782176145656707467239432","30420390754185093787759325814975374315674471515904334238063987","146150164446393964149777671248711153785034190439667045653","453065507572581285526113118970577622869777623693145361031320683","438450637349435445083685862672783794033593025843779053343603677","321530360212798661322057819855846472842054965884675179620730310","730750818665451677011351377122455010063260959463021411853914640"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1496839438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x072fe4d35215cc543c9795fb5417e1c854f6edb5"}, {name: "value", type: "uint256", value: "15000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "value", type: "uint256", value: "1834625423466680"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6fbf77feeb2638c60c435a8536ea2114f22106b6"}, {name: "value", type: "uint256", value: "400000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x558f72bb1e5e297a1efed0e6f6996b7e0c902bfe"}, {name: "value", type: "uint256", value: "500000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x98ae486929deb9fe12213873499c4e8a168c66a6"}, {name: "value", type: "uint256", value: "26666600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xad6ee8d1aeb39b295a6f09189951724cf43ce008"}, {name: "value", type: "uint256", value: "29100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3676f6af1a65370ad04ddf0674750ee519941d73"}, {name: "value", type: "uint256", value: "20814476000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7cf1a4951c2b03a923dcc7cff945efcf11559515"}, {name: "value", type: "uint256", value: "100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf1e0ef185dcfee96135a1f0bebda182b12f7546b"}, {name: "value", type: "uint256", value: "310000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x928767b8cd6206ffe41c87d1a7f5fd1b31d9fbdd"}, {name: "value", type: "uint256", value: "300000100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0362371f43e5bbebfba6755ca762256b3a9a05c6"}, {name: "value", type: "uint256", value: "220000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x262b667bef4177fd4d02610326f75682f20fd210"}, {name: "value", type: "uint256", value: "500000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: seal(  )", async function( ) {
		const txOriginal = {blockNumber: "3834845", timeStamp: "1496841360", hash: "0x5ce235c608945b141d3f3c012ddc84f63d4e641ffbc53fc6243429c43d4dc85f", nonce: "30", blockHash: "0xdba13272eacd64de0afc6ed3d4fafd08fabfa689e42b3b8baca2d45c5c908e56", transactionIndex: "34", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "142266", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x3fb27b85", contractAddress: "", cumulativeGasUsed: "4030322", gasUsed: "42265", confirmations: "3840321"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "seal", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "seal()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1496841360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "3837322", timeStamp: "1496882066", hash: "0xee456706816d98dccaa415ec60c3e08e90fa9277bb2daf5d8278ce8302a4d3dd", nonce: "31", blockHash: "0x2e29ec6da9ac651da9fe888f4b199af1a81eac473f5da0b4deaf45b21f60ee93", transactionIndex: "85", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "143784", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xf2fde38b000000000000000000000000003359e6922510dd30552ed6c3204c68638c1f77", contractAddress: "", cumulativeGasUsed: "4335982", gasUsed: "43783", confirmations: "3837844"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newOwner", value: addressList[4]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1496882066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: acceptOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "3838443", timeStamp: "1496900850", hash: "0xc2c1f61b2ab845ed8864c3ba083a9bbb267a5cdb5e84ea87f1d273955da2f16c", nonce: "38", blockHash: "0x42baaaa3814f53dde6768f7e03efe8e7079c4ef33ba84805c3d67962c49f1d32", transactionIndex: "19", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "71000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x79ba5097", contractAddress: "", cumulativeGasUsed: "879860", gasUsed: "29414", confirmations: "3836723"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1496900850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "_from", type: "address", value: "0x00000217d2795f1da57e392d2a5bc87125baa38d"}, {name: "_to", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3839277", timeStamp: "1496914564", hash: "0x319cb021cafba18d4d678d5b26b7937f4a975bfbcf781959984a396e2b6b8b46", nonce: "0", blockHash: "0xe9ede1d1f27178714292e9c36c057320f8281b7ce0a57dfc3e7f8213e63a3ad9", transactionIndex: "11", from: "0x262b667bef4177fd4d02610326f75682f20fd210", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51966", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000731ada89beff4087a0997211c3d7a5b5408dd68b0000000000000000000000000000000000000000000000000000b5e620f48000", contractAddress: "", cumulativeGasUsed: "295536", gasUsed: "51965", confirmations: "3835889"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_amount", value: "200000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1496914564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x262b667bef4177fd4d02610326f75682f20fd210"}, {name: "to", type: "address", value: "0x731ada89beff4087a0997211c3d7a5b5408dd68b"}, {name: "value", type: "uint256", value: "200000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "722936000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3839336", timeStamp: "1496915710", hash: "0xe29801eeb119fb657e53bf34a74ab065c104604d6ce577a3903bee958387d897", nonce: "20", blockHash: "0x739bf485f488a5627e2b867376cb8866d972008436e0cb4fca1c435dfcc8c275", transactionIndex: "6", from: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51838", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d7f38952d2c515c921e9817471c34a09fb09d4e4000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "668585", gasUsed: "51837", confirmations: "3835830"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_amount", value: "1000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1496915710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "to", type: "address", value: "0xd7f38952d2c515c921e9817471c34a09fb09d4e4"}, {name: "value", type: "uint256", value: "1000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "32973695108777777777" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"150000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3839744", timeStamp: "1496922438", hash: "0xd21dbf07172b7558dc8d24eb3843f953faf605a8dc8e0188e310d68cb92ab2a0", nonce: "21", blockHash: "0xb402f49c81e033e42917dcc5d4a4d75fc35847a347e15ac6264efefd983469d2", transactionIndex: "13", from: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36966", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d7f38952d2c515c921e9817471c34a09fb09d4e40000000000000000000000000000000000000000000000000000886c98b76000", contractAddress: "", cumulativeGasUsed: "1007694", gasUsed: "36965", confirmations: "3835422"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_amount", value: "150000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "150000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1496922438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "to", type: "address", value: "0xd7f38952d2c515c921e9817471c34a09fb09d4e4"}, {name: "value", type: "uint256", value: "150000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "32973695108777777777" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"30000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3840072", timeStamp: "1496927984", hash: "0xbb563c024cb9a323086db5595f3924b471c94c9e4fc65905aa6b25726e12b407", nonce: "65", blockHash: "0xe34c99a32551a11b21788cd48b8b36b50f3be11384210e263b72fa857f82bccd", transactionIndex: "0", from: "0x3fe666fc563e5fa99f8e0e6988ee2070cea1fa6b", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "136902", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b80000000000000000000000000000000000000000000000000000000001c9c380", contractAddress: "", cumulativeGasUsed: "36901", gasUsed: "36901", confirmations: "3835094"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "30000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "30000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1496927984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x3fe666fc563e5fa99f8e0e6988ee2070cea1fa6b"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "30000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "536928388882423760" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"100000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3840780", timeStamp: "1496939959", hash: "0xcbdc608d872c868b1173fec705e3cd0bd88e46fd77a4c6e9ad7494b91446da4f", nonce: "3", blockHash: "0x3f9ef69934821e22930b3ffdcfdd14950acc92a339c9f8ef0387d47f65af4578", transactionIndex: "7", from: "0x8d25f564b59eb49173f5574c5ad54856f5a31e7a", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36838", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b80000000000000000000000000000000000000000000000000000000005f5e100", contractAddress: "", cumulativeGasUsed: "1353547", gasUsed: "36837", confirmations: "3834386"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1496939959 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d25f564b59eb49173f5574c5ad54856f5a31e7a"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "78222731814182017" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"300000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3840952", timeStamp: "1496942593", hash: "0xb90240d5c47e83c2c299449a5ce71a513b948f40c965206c573da17ae23b3f7d", nonce: "1", blockHash: "0x186f86d174413735494b9fdb266fa13bcac01af27fbcb55c808f0a1222f73413", transactionIndex: "21", from: "0x262b667bef4177fd4d02610326f75682f20fd210", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "52029", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d493f258234c6123699a2237eb72f7ea1c695b31000000000000000000000000000000000000000000000000000110d9316ec000", contractAddress: "", cumulativeGasUsed: "794668", gasUsed: "37029", confirmations: "3834214"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_amount", value: "300000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "300000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1496942593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x262b667bef4177fd4d02610326f75682f20fd210"}, {name: "to", type: "address", value: "0xd493f258234c6123699a2237eb72f7ea1c695b31"}, {name: "value", type: "uint256", value: "300000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "722936000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"400000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3844170", timeStamp: "1496996003", hash: "0x070c58da9b6c55f48b2f6c06eac1b3da324cf7e5312e9334cdcb9c776ae721ec", nonce: "40", blockHash: "0x0aeff31df7a1ee3490b40dcefd6e16e9c76a183041d834afbb3d1ca4001a11b6", transactionIndex: "53", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "61000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b800000000000000000000000000000000000000000000000000016bcc41e90000", contractAddress: "", cumulativeGasUsed: "2043985", gasUsed: "36965", confirmations: "3830996"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "400000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "400000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1496996003 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "400000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3845442", timeStamp: "1497016971", hash: "0xe5c942bb2c882e54193bb26518f099488ab579e9ff15d35376463f20d8abd710", nonce: "63", blockHash: "0xfa5395926a4b0e09fef568ea986db03a244f5d1e5c5378dbe9d1d3ebc5ef4af3", transactionIndex: "4", from: "0x378ff330eff4091213a7f05c75dea07a411b17b8", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51966", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000b18fe88c589d6ee2eebef724ad28d7be139404910000000000000000000000000000000000000000000000000000b5e620f48000", contractAddress: "", cumulativeGasUsed: "135965", gasUsed: "51965", confirmations: "3829724"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_amount", value: "200000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1497016971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "to", type: "address", value: "0xb18fe88c589d6ee2eebef724ad28d7be13940491"}, {name: "value", type: "uint256", value: "200000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1018508044250765117" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3845445", timeStamp: "1497017013", hash: "0x6dd103d0ec7f35788590bb61bef7abc42bc0547db50e510db0a41f3978d0486b", nonce: "64", blockHash: "0x596944729783bf1c7b48a8e60eba19912f3ff8c94cbb93c4e3cce87286f086a8", transactionIndex: "5", from: "0x378ff330eff4091213a7f05c75dea07a411b17b8", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51966", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d81d8766a6d8d82503675df36ec2d021336c07040000000000000000000000000000000000000000000000000000b5e620f48000", contractAddress: "", cumulativeGasUsed: "188018", gasUsed: "51965", confirmations: "3829721"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_amount", value: "200000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1497017013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "to", type: "address", value: "0xd81d8766a6d8d82503675df36ec2d021336c0704"}, {name: "value", type: "uint256", value: "200000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1018508044250765117" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3870868", timeStamp: "1497433850", hash: "0x6ab084b57514df5408a24e9c077818746dfd00618dd1d3e0223d1ebb8126e963", nonce: "13", blockHash: "0x5386e239f19a170e9dd5066d65f1a1028ee25e0afeea75b3ba4c7be4e45d61d2", transactionIndex: "40", from: "0xec9d33f9a515a434fb7c2d7392d8a58c34ec6733", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51838", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000fa99b13542dede3034c241106fbae67c5257cd10000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1235520", gasUsed: "51837", confirmations: "3804298"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_amount", value: "1000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1497433850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec9d33f9a515a434fb7c2d7392d8a58c34ec6733"}, {name: "to", type: "address", value: "0xfa99b13542dede3034c241106fbae67c5257cd10"}, {name: "value", type: "uint256", value: "1000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "112248806127531" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[18], \"15000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3875873", timeStamp: "1497515395", hash: "0x9bb2b03d56599bd402fa1906261f144839d7fc874d808bc3c58bda0312702d01", nonce: "0", blockHash: "0x7f8aa5f59a2da5dab746c86b7914e3b3a7b2f4ec96d9280558d7abf6c3a4e1c7", transactionIndex: "10", from: "0x072fe4d35215cc543c9795fb5417e1c854f6edb5", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000000000000da475abf000", contractAddress: "", cumulativeGasUsed: "473285", gasUsed: "45420", confirmations: "3799293"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[18]}, {type: "uint256", name: "_amount", value: "15000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[18], "15000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1497515395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x072fe4d35215cc543c9795fb5417e1c854f6edb5"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "15000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "882028000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[18], \"20000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3876206", timeStamp: "1497521235", hash: "0x7e46d40ad62d6da113f6306957f845e31a831ed65aeee97b4785a8696636197a", nonce: "65", blockHash: "0x398fbe10c7793dcf77b5d6035568e0883f57bcaa0859ffd51a46848bc76788f5", transactionIndex: "30", from: "0x378ff330eff4091213a7f05c75dea07a411b17b8", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "250000", gasPrice: "22320805702", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000012309ce54000", contractAddress: "", cumulativeGasUsed: "900185", gasUsed: "45420", confirmations: "3798960"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[18]}, {type: "uint256", name: "_amount", value: "20000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[18], "20000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1497521235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "20000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1018508044250765117" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3877375", timeStamp: "1497539413", hash: "0xcb96cfd4b88a2be392355b674e6e0846966f1bcd146beac0e4bf69305eb09262", nonce: "0", blockHash: "0xcb712082853a70c67d701b92664a01a78f84a4755fc96869c54f5a45d7bbba7e", transactionIndex: "20", from: "0xfd9c0050bee089e1fac7bec29a88f2e552056662", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "51966", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000026eee9cc7a4509ad5f73ee3b9c8f3720564884020000000000000000000000000000000000000000000000000000b5e620f48000", contractAddress: "", cumulativeGasUsed: "572277", gasUsed: "51965", confirmations: "3797791"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_amount", value: "200000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1497539413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xfd9c0050bee089e1fac7bec29a88f2e552056662"}, {name: "to", type: "address", value: "0x26eee9cc7a4509ad5f73ee3b9c8f372056488402"}, {name: "value", type: "uint256", value: "200000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "1448814000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"60000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3877693", timeStamp: "1497544471", hash: "0x2001e3eaac827dc51f36ee4f4214ca17fe2d1d4c2d964a10ef9e257a7624f04a", nonce: "1", blockHash: "0x512f40bc9810e34dbba83dee82bca82d9f83e39e98fa9fd0c4f2c98a95201a55", transactionIndex: "6", from: "0xfd9c0050bee089e1fac7bec29a88f2e552056662", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36901", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000001a2d543ea30ffb007072d2a75d7cf9bf7e8da61600000000000000000000000000000000000000000000000000003691d6afc000", contractAddress: "", cumulativeGasUsed: "147901", gasUsed: "21901", confirmations: "3797473"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_amount", value: "60000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "60000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1497544471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xfd9c0050bee089e1fac7bec29a88f2e552056662"}, {name: "to", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "value", type: "uint256", value: "60000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "1448814000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"90000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3877696", timeStamp: "1497544522", hash: "0x16f729b74dd4197412ad64562758f71b5c02d75fae2c097444e6cd059ee7b2b9", nonce: "0", blockHash: "0x6a28d985de383caf0e8fcdd0177a44b0e8e2fbec8e6f6bafb35f1bce9c10aee0", transactionIndex: "9", from: "0x28d08a4bc76f32247dfd04bc7ac91fe428b7479e", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36902", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000001a2d543ea30ffb007072d2a75d7cf9bf7e8da616000000000000000000000000000000000000000000000000000051dac207a000", contractAddress: "", cumulativeGasUsed: "225901", gasUsed: "36901", confirmations: "3797470"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_amount", value: "90000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "90000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1497544522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x28d08a4bc76f32247dfd04bc7ac91fe428b7479e"}, {name: "to", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "value", type: "uint256", value: "90000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "765158000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"150000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3877715", timeStamp: "1497544893", hash: "0x13e0493b16cb9ae0b74d23b218a9df0a02c6df4d6e67802b7906767169f76a40", nonce: "1", blockHash: "0x72bec6113fbb465e7cb64cf25330e7f7a67ce08d3bd0f594ff29e2bf73fe1d43", transactionIndex: "57", from: "0x28d08a4bc76f32247dfd04bc7ac91fe428b7479e", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36901", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000001a2d543ea30ffb007072d2a75d7cf9bf7e8da6160000000000000000000000000000000000000000000000000000886c98b76000", contractAddress: "", cumulativeGasUsed: "1457119", gasUsed: "21901", confirmations: "3797451"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_amount", value: "150000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "150000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1497544893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x28d08a4bc76f32247dfd04bc7ac91fe428b7479e"}, {name: "to", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "value", type: "uint256", value: "150000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "765158000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3879052", timeStamp: "1497566787", hash: "0x3501993b3af53f3cdd911b115329a2877dc799b746d07e7a4968ffe793ef2e38", nonce: "46", blockHash: "0x40c5a8104676af62c6d3be5e43b4dadd392d4c9682a874937ee105178157170c", transactionIndex: "16", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "62051", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ad0f6420314893d93f6e8b4628182d9a54e3754f000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "463165", gasUsed: "51837", confirmations: "3796114"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_amount", value: "1000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1497566787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0xad0f6420314893d93f6e8b4628182d9a54e3754f"}, {name: "value", type: "uint256", value: "1000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"47745400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3880345", timeStamp: "1497588671", hash: "0xa6ecedd2495792423186dfe3b75292f8fc7f5f57302a1e1850ba23a5e48db49c", nonce: "47", blockHash: "0x8526afdf6567b9c832083546d6c45e996e60d766d28c6c20b5e90e248a9d753b", transactionIndex: "21", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "62358", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000f4105564c4e9b7f0db64116d31677f320bc771f900000000000000000000000000000000000000000000000000002b6c979b4e00", contractAddress: "", cumulativeGasUsed: "1615667", gasUsed: "51965", confirmations: "3794821"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_amount", value: "47745400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "47745400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1497588671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0xf4105564c4e9b7f0db64116d31677f320bc771f9"}, {name: "value", type: "uint256", value: "47745400000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"100000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3880943", timeStamp: "1497598387", hash: "0x82e335ebc6f09fc743a69ede172bf38b1adc93ef3391622c9a56edc9f0576117", nonce: "0", blockHash: "0x262192b34050205d70eac70fcdfb8b31f15a70a8cf1259b95190e61e33a56479", transactionIndex: "62", from: "0x9b30126036b75cd84cc079550271f6df2a847dc2", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36838", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b80000000000000000000000000000000000000000000000000000000005f5e100", contractAddress: "", cumulativeGasUsed: "4674708", gasUsed: "36837", confirmations: "3794223"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1497598387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "9125814000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"100000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3880954", timeStamp: "1497598591", hash: "0x57b47c339b9fc8a1de7c736d8e250ee0dfd507228b9d7261cecc6b3a07a8eef4", nonce: "0", blockHash: "0x6e3a7e0fa5ce79b48ec455746170b4bb8dafb00294ba5e8cad2861ed680df1df", transactionIndex: "43", from: "0x9fc974571131fc8f93934638f99fceed8ed8632f", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36838", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b80000000000000000000000000000000000000000000000000000000005f5e100", contractAddress: "", cumulativeGasUsed: "1869225", gasUsed: "36837", confirmations: "3794212"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1497598591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9fc974571131fc8f93934638f99fceed8ed8632f"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "324158000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"14000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3881757", timeStamp: "1497610969", hash: "0xcac6aecb61cf7794191229a6403a07ce630735bb8a46895de92b07e07a7cd33e", nonce: "22", blockHash: "0x6a1cd254ffa360c62530506b73cde0569db6c4d31616a8289a73efe8d6571cc6", transactionIndex: "33", from: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36838", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000378ff330eff4091213a7f05c75dea07a411b17b80000000000000000000000000000000000000000000000000000000000d59f80", contractAddress: "", cumulativeGasUsed: "1220095", gasUsed: "36837", confirmations: "3793409"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "14000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "14000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1497610969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1a2d543ea30ffb007072d2a75d7cf9bf7e8da616"}, {name: "to", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "value", type: "uint256", value: "14000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "32973695108777777777" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"30000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3882328", timeStamp: "1497620601", hash: "0x3ebea81b5a8506800c774b58620334787dba96ffb601b0eb80f6749f6c95c0b4", nonce: "15", blockHash: "0xe5af02a0ed7b9adc52d020638d3b36ef175f3e55a34cb66ced2712559d5e7c50", transactionIndex: "4", from: "0x5521677480e948d872ad82b180731f809fd4b0e8", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36966", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000020bd47e6f3db30f4cdb9948b74f3f52b14aeb6bd00000000000000000000000000000000000000000000000000001b48eb57e000", contractAddress: "", cumulativeGasUsed: "120965", gasUsed: "36965", confirmations: "3792838"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_amount", value: "30000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "30000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1497620601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x5521677480e948d872ad82b180731f809fd4b0e8"}, {name: "to", type: "address", value: "0x20bd47e6f3db30f4cdb9948b74f3f52b14aeb6bd"}, {name: "value", type: "uint256", value: "30000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "465974008407888320" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"259999900000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3882489", timeStamp: "1497623037", hash: "0xf65f4b9627a68d13f10db3a54618498a4dde65c10eac017a7875d59862ebb83f", nonce: "1", blockHash: "0xca1f0f1cceecc18a8cd4cec927ed23becb5a07d585d1e2d78af6ff71311fa5a1", transactionIndex: "37", from: "0x9fc974571131fc8f93934638f99fceed8ed8632f", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36965", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009b30126036b75cd84cc079550271f6df2a847dc20000000000000000000000000000000000000000000000000000ec77f1ae5f00", contractAddress: "", cumulativeGasUsed: "1801046", gasUsed: "21965", confirmations: "3792677"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_amount", value: "259999900000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "259999900000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1497623037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9fc974571131fc8f93934638f99fceed8ed8632f"}, {name: "to", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "value", type: "uint256", value: "259999900000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "324158000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"150000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3882511", timeStamp: "1497623380", hash: "0xb0fe99474ba2671c2d3f1ae30e03d6bdc15c63eee5e884e6be65bb3a1ebd4a21", nonce: "0", blockHash: "0x633d9ed72b5be9f9391c37074ea9c3e3b7cb422216a9ba498d7ce17ff5e2db9e", transactionIndex: "96", from: "0xef8b50345ae5de32ccfdd974c10893e2e3f28184", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "36965", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009b30126036b75cd84cc079550271f6df2a847dc20000000000000000000000000000000000000000000000000000886c98b76000", contractAddress: "", cumulativeGasUsed: "3065877", gasUsed: "21965", confirmations: "3792655"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_amount", value: "150000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "150000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1497623380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xef8b50345ae5de32ccfdd974c10893e2e3f28184"}, {name: "to", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "value", type: "uint256", value: "150000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "758081000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"20000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3882539", timeStamp: "1497623753", hash: "0x471c33a4a973872b0c7c2f5591eec357de16800642ce8b892ecdefa4aa38c177", nonce: "5", blockHash: "0xd1e3b36f10eeff3bee0d42e0208b9faf25bb217d9c23fa29c4aea364a3048121", transactionIndex: "44", from: "0x0025165361865b09c7c625f4db69ba6b0ac85a95", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "65000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009b30126036b75cd84cc079550271f6df2a847dc2000000000000000000000000000000000000000000000000000012309ce54000", contractAddress: "", cumulativeGasUsed: "1881717", gasUsed: "21965", confirmations: "3792627"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_amount", value: "20000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "20000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1497623753 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0025165361865b09c7c625f4db69ba6b0ac85a95"}, {name: "to", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "value", type: "uint256", value: "20000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "10046600000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"589999800000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3882588", timeStamp: "1497624529", hash: "0x8432bbf1e469f10546e55ec4c47c6d6aa18e6a230b2737eb5392e4eaf471704f", nonce: "4", blockHash: "0x1b45a0258fb819bb1277a834488eb6519a4aca62f455c1f835a77daa5dbde844", transactionIndex: "16", from: "0x9b30126036b75cd84cc079550271f6df2a847dc2", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "52029", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000738dbef7ba212575df41e0916ff1f0da5426ec180000000000000000000000000000000000000000000000000002189a087f1e00", contractAddress: "", cumulativeGasUsed: "435885", gasUsed: "37029", confirmations: "3792578"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_amount", value: "589999800000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "589999800000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1497624529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9b30126036b75cd84cc079550271f6df2a847dc2"}, {name: "to", type: "address", value: "0x738dbef7ba212575df41e0916ff1f0da5426ec18"}, {name: "value", type: "uint256", value: "589999800000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "9125814000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"218832900000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3886234", timeStamp: "1497683005", hash: "0xb55141b2d7f06ad9789b66c971de5b394929586694f5befbcca245642fe12700", nonce: "49", blockHash: "0x5e1394579c7bee24bda066c1cf4b1d1824ea122e7afa52204aa23d9441effd88", transactionIndex: "23", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "44358", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000f4105564c4e9b7f0db64116d31677f320bc771f90000000000000000000000000000000000000000000000000000c70701450900", contractAddress: "", cumulativeGasUsed: "3105075", gasUsed: "36965", confirmations: "3788932"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_amount", value: "218832900000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "218832900000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1497683005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0xf4105564c4e9b7f0db64116d31677f320bc771f9"}, {name: "value", type: "uint256", value: "218832900000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"437665800000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3890139", timeStamp: "1497747302", hash: "0x5bbeae2d1e59e20619677ccdf48262a9d6772d7a62665d5a3b75d513ea1454f5", nonce: "50", blockHash: "0xb7355f2ca963a7475bb6f36735d74629d569d119922347c422c87cec8fa092b1", transactionIndex: "8", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "71000", gasPrice: "21076412651", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000093157b7162bb6b0b8d1100d490f84ea148e33a6c00000000000000000000000000000000000000000000000000018e0e028a1200", contractAddress: "", cumulativeGasUsed: "293462", gasUsed: "51965", confirmations: "3785027"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_amount", value: "437665800000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "437665800000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1497747302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0x93157b7162bb6b0b8d1100d490f84ea148e33a6c"}, {name: "value", type: "uint256", value: "437665800000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"318302400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3890836", timeStamp: "1497758490", hash: "0x8904aad254352ce461b2d8138e256dda0d92187fcc46bf9cb122c014f68e8703", nonce: "51", blockHash: "0xeef74375f853c0810ab159ee48501699cef1269fdc54a995dd0d53a9fee69294", transactionIndex: "85", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "61000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000005165a5eb7c22ea5d8d7f2ddd0bae9888cab182f50000000000000000000000000000000000000000000000000001217e8d7bb000", contractAddress: "", cumulativeGasUsed: "3724411", gasUsed: "52029", confirmations: "3784330"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_amount", value: "318302400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "318302400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1497758490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0x5165a5eb7c22ea5d8d7f2ddd0bae9888cab182f5"}, {name: "value", type: "uint256", value: "318302400000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3891230", timeStamp: "1497764496", hash: "0x8320b7422ea5ae682dbaa13df5a1d545b0b726f798c3b6faa351a46e63a0d3c1", nonce: "420", blockHash: "0x212f24e69c5e774aff81f077ceeef0b9648a6b0c1819638e07b7a99c6f6c1833", transactionIndex: "18", from: "0x00011675f9d83c2fbbd93883f056093ba322e600", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "61000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000003359e6922510dd30552ed6c3204c68638c1f7700000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "430685", gasUsed: "21901", confirmations: "3783936"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_amount", value: "100000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1497764496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00011675f9d83c2fbbd93883f056093ba322e600"}, {name: "to", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "value", type: "uint256", value: "100000000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3891234", timeStamp: "1497764567", hash: "0x199c372c3425d8f2ffadf1f10ac29fab4c06be2355eaae128c4bca94cf5bdde9", nonce: "421", blockHash: "0xd09911896d42647b45236bbf812566a692a0352a41f2a1476f1409b3c97a81fa", transactionIndex: "58", from: "0x00011675f9d83c2fbbd93883f056093ba322e600", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "61000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000003359e6922510dd30552ed6c3204c68638c1f7700000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "1981892", gasUsed: "24030", confirmations: "3783932"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_amount", value: "100000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1497764567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"477453600000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3891598", timeStamp: "1497770444", hash: "0x3a0189e3ffc621bb8aa378f2aeb6678fe3e6b13529b1bb7019695ed8175568c9", nonce: "52", blockHash: "0x994b7e158198198f93f1de399b448ca12ef8a9e184778c8aad0d0688d5881b5e", transactionIndex: "89", from: "0x003359e6922510dd30552ed6c3204c68638c1f77", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "62435", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000009629301deaf0a3a6c4b3973335c5b70eb6a697c0000000000000000000000000000000000000000000000000001b23dd4398800", contractAddress: "", cumulativeGasUsed: "4353226", gasUsed: "52029", confirmations: "3783568"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_amount", value: "477453600000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "477453600000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1497770444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x003359e6922510dd30552ed6c3204c68638c1f77"}, {name: "to", type: "address", value: "0x09629301deaf0a3a6c4b3973335c5b70eb6a697c"}, {name: "value", type: "uint256", value: "477453600000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"100000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3892395", timeStamp: "1497783143", hash: "0x3e9b266d19ab274f593fe6ba1e53683f4d0944c7c91747ca6d3fac610fb321ba", nonce: "69", blockHash: "0x0fd5cd1f8dacf30bf53fd73e7264ff6defb45b2a38e03e1350c1e19883293417", transactionIndex: "82", from: "0x378ff330eff4091213a7f05c75dea07a411b17b8", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000579061a9bf4df9f1d92b09ec7e72c0d9c7b02a0e0000000000000000000000000000000000000000000000000000000005f5e100", contractAddress: "", cumulativeGasUsed: "2509921", gasUsed: "51837", confirmations: "3782771"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_amount", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1497783143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x378ff330eff4091213a7f05c75dea07a411b17b8"}, {name: "to", type: "address", value: "0x579061a9bf4df9f1d92b09ec7e72c0d9c7b02a0e"}, {name: "value", type: "uint256", value: "100000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1018508044250765117" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[18], \"400000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3929006", timeStamp: "1498414807", hash: "0x7d653e96f137853212e73f3e20479455e68e877b2fd9b299605997b430acdd89", nonce: "3", blockHash: "0xb8a9627b7972962ad179d25870c507b6784c022ba38e5f2a319d4c81374ddde8", transactionIndex: "14", from: "0x558f72bb1e5e297a1efed0e6f6996b7e0c902bfe", to: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234", value: "0", gas: "250000", gasPrice: "37282495770", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000000000005d21dba000", contractAddress: "", cumulativeGasUsed: "1239790", gasUsed: "45356", confirmations: "3746160"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[18]}, {type: "uint256", name: "_amount", value: "400000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[18], "400000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1498414807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x558f72bb1e5e297a1efed0e6f6996b7e0c902bfe"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "400000000000"}], address: "0x5ddab66da218fb05dfeda07f1afc4ea0738ee234"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "1110562967584909634" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
