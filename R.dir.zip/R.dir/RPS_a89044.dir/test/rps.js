const RPS = artifacts.require( "./RPS.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "RPS" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5Df4BEa3540899a33C76C4d25108F4FE2cA89044", "0x8654d2125045132EBBd57dA77Dc258C99bFcB11E", "0x1337F2f751dd3D33717890b905665DB457b90771", "0xA35E44dB428e93C039EFA40251B8B0580191e6B2", "0xc86749e8926F8954eDaCC046B38D3bfa013b3f0B", "0xEbA905f3CF978B3F024e39EA5d638c2828046D3C", "0x8D00D4cADC3D83cDF8F8E977e0187F1cA7888f73", "0x188c7085DD919afE3e30AeeBFBab3a4e58C0C16A", "0xCD8d25D50F5C438d59375Db4595d18587bfa1ECC", "0x37d7Fe126b896eA132A23679358dea887640E666", "0x7cfDC5AaE341061b058bb342A0319d22358361B6", "0x6fe67750C9a987bD6AEdDb54cce122c45f4EFE3D", "0xbe71c086C0CC6D6FE626aF3AD9a5Fe88fAB8C6A3", "0xE5551F7D6afA91ddd4956a11a7FFF8c5d277b5D8", "0xc6f2712F59B7f6093cBC9E1f82BEFA8ACa2146D6", "0x05F138f70934BfbD1cdAFBF7518b99a6b7261bF9", "0x3632eba80749a7bE8c434Ed9fa13dd2C4c36F722", "0xA675d0598631414eff11d81c4831ebfEA776c87B", "0x42B2e01aC32ae5edF144f6158833642b27Ff0cF5", "0x5a21a1490a82B401a004AdE111d4E824d268ACEb"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "games", outputs: [{name: "player1", type: "address"}, {name: "player2", type: "address"}, {name: "value", type: "uint256"}, {name: "hiddenMove1", type: "bytes32"}, {name: "move1", type: "uint8"}, {name: "move2", type: "uint8"}, {name: "gameStart", type: "uint256"}, {name: "state", type: "uint8"}, {name: "result", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balances", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "playerNames", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "totalLost", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner2", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "nameTaken", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner1", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "player", type: "address"}], name: "totalProfit", outputs: [{name: "", type: "int256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "secretTaken", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "totalWon", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "NewName", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Donate", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Withdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewName(address,string)", "Donate(address,uint256)", "Deposit(address,uint256)", "Withdraw(address,uint256)", "GameCreated(address,address,uint256,uint256,bytes32)", "GameJoined(address,address,uint256,uint256,uint8,uint256)", "GameEnded(address,address,uint256,uint256,uint8)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc6d417def143b62f5379652b209985e71c375db7c091b7f127f7e668d718b22c", "0x0553260a2e46b0577270d8992db02d30856ca880144c72d6e9503760946aef13", "0xe1fffcc4923d04b559f4d29a8bfc6cda04eb5b0d3c460751c2402c5c5cc9109c", "0x884edad9ce6fa2440d8a54cc123490eb96d2768479d49ff9c7366125a9424364", "0x5535e7a81d614219e8d90f34c6a8c0167b0e19f05fa40fc22ebfd3454d48c377", "0x787fd167590b16236099dc28d7d1f50d807d22eeffa20dd2525015771da5aceb", "0x3f14710d11bcc64177ff65ea86aaf313db9809e6e41fe150ca95ca8634da2ddf"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4250143 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4774985 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "otherOwner", value: 4}], name: "RPS", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "games", outputs: [{name: "player1", type: "address"}, {name: "player2", type: "address"}, {name: "value", type: "uint256"}, {name: "hiddenMove1", type: "bytes32"}, {name: "move1", type: "uint8"}, {name: "move2", type: "uint8"}, {name: "gameStart", type: "uint256"}, {name: "state", type: "uint8"}, {name: "result", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "games(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balances", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balances(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "playerNames", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playerNames(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "totalLost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalLost(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner2", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "nameTaken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nameTaken(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner1", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "totalProfit", outputs: [{name: "", type: "int256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalProfit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "secretTaken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secretTaken(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "totalWon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWon(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "RPS", function( accounts ) {

	it( "TEST: RPS( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4250143", timeStamp: "1504837616", hash: "0xa3abb834d2f0913b0f148fd1c75e91cddf3a29659bf73cefb157d8ac62cbe725", nonce: "4", blockHash: "0x9fa65b47f7b8f164d2925ee4d98afde7e524cf872a6570ebfc61175d8df52ba5", transactionIndex: "51", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: 0, value: "0", gas: "4046154", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0xc253400b0000000000000000000000001337f2f751dd3d33717890b905665db457b90771", contractAddress: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", cumulativeGasUsed: "6309470", gasUsed: "3946153", confirmations: "3454847"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "otherOwner", value: addressList[4]}], name: "RPS", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = RPS.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1504837616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = RPS.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: pause( false )", async function( ) {
		const txOriginal = {blockNumber: "4288395", timeStamp: "1505760206", hash: "0x4f8ac61999e0bb7016a6625444f3990fd7fc320caafdd623750770f257c8c525", nonce: "6", blockHash: "0xceebfd516683b526cdeb7ba2304c1d77d3cc41d9d6de70e3f7487aa36d21d6d9", transactionIndex: "144", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "40770", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x02329a290000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6587130", gasUsed: "27179", confirmations: "3416595"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "pause", value: false}], name: "pause", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pause(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1505760206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x18e5557aa9d2a12781b88743f7b480ef6e61... )", async function( ) {
		const txOriginal = {blockNumber: "4288404", timeStamp: "1505760388", hash: "0xbf1f4569cd09c91f1c97e0fd0cd1e829e9422163cca78d1ccadf99e81af608a8", nonce: "7", blockHash: "0xe36129b8a87f934dc2cf5f0bab52db6bfbac1528ee3bdee558493222fcec7680", transactionIndex: "79", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "224309", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x8047cb9318e5557aa9d2a12781b88743f7b480ef6e61b12962c38b3b2c4737074d747899000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2706362", gasUsed: "209309", confirmations: "3416586"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x18e5557aa9d2a12781b88743f7b480ef6e61b12962c38b3b2c4737074d747899"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x18e5557aa9d2a12781b88743f7b480ef6e61b12962c38b3b2c4737074d747899", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1505760388 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "0"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x18e5557aa9d2a12781b88743f7b480ef6e61b12962c38b3b2c4737074d747899"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4294020", timeStamp: "1505893662", hash: "0x21edd4c95849cb50f84f5208f5eefdb0e60618092528c2b4ff8db6ef698a747c", nonce: "583", blockHash: "0xc86e10e8409e750dbfd10a6712d903cb0784d77225fd4bad52dd521c2e4d2860", transactionIndex: "61", from: "0xa35e44db428e93c039efa40251b8b0580191e6b2", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93707", gasPrice: "26741182479", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2391673", gasUsed: "93706", confirmations: "3410970"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "0"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1505893662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0xa35e44db428e93c039efa40251b8b0580191e6b2"}, {name: "gameId", type: "uint256", value: "0"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "3"}, {name: "gameStart", type: "uint256", value: "1505893662"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "67288137613308903" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4294024", timeStamp: "1505893713", hash: "0x1358a5f7aad4b299210c7fab073723f5a2869b612a049ac0fe820622787652dd", nonce: "584", blockHash: "0xbb11f5665cb19cbca1ca695a1434ba6ce64a20c298f516426918eedfeff44399", transactionIndex: "27", from: "0xa35e44db428e93c039efa40251b8b0580191e6b2", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93707", gasPrice: "26741182479", isError: "1", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1575049", gasUsed: "93707", confirmations: "3410966"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "0"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "67288137613308903" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: revealMove( \"0\", \"1\", `11a8c0d96f08af5faa1847e50... )", async function( ) {
		const txOriginal = {blockNumber: "4296355", timeStamp: "1505950311", hash: "0xd5ef2b0bfbeaac4eba60e04984ba820658743004dc227c90a93c4ff5ed88d1fe", nonce: "8", blockHash: "0xa040f786b21d471adb30f51b888c24797d26632949e03057370e28b62ad1f462", transactionIndex: "100", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "139851", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xbd675c0e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004031316138633064393666303861663566616131383437653530623066666162646533343330393364343737373233623030333538366666393534373762323666", contractAddress: "", cumulativeGasUsed: "3056903", gasUsed: "139850", confirmations: "3408635"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "0"}, {type: "uint8", name: "move", value: "1"}, {type: "string", name: "secret", value: `11a8c0d96f08af5faa1847e50b0ffabde343093d477723b003586ff95477b26f`}], name: "revealMove", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "revealMove(uint256,uint8,string)" ]( "0", "1", `11a8c0d96f08af5faa1847e50b0ffabde343093d477723b003586ff95477b26f`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1505950311 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[5,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0xa35e44db428e93c039efa40251b8b0580191e6b2"}, {name: "gameId", type: "uint256", value: "0"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "result", type: "uint8", value: "2"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[5,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x41007cc8b701299f4464a1cc1e6ad03e3141... )", async function( ) {
		const txOriginal = {blockNumber: "4296868", timeStamp: "1505962565", hash: "0x002f9b62edffd195156b6f21f0a31a738ef065943bcebe6bb21b2befbfdfd3bf", nonce: "50", blockHash: "0x9c99b85c0b8b623a3a0ac0f48d01a04f0aa09e76c6d2ecce9ee115d95f5f9619", transactionIndex: "91", from: "0xc86749e8926f8954edacc046b38d3bfa013b3f0b", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "50000000000000000", gas: "194245", gasPrice: "10000000000", isError: "0", txreceipt_status: "", input: "0x8047cb9341007cc8b701299f4464a1cc1e6ad03e3141763cb6f7cc73a0b0011e7554e1d200000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4707740", gasUsed: "179245", confirmations: "3408122"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x41007cc8b701299f4464a1cc1e6ad03e3141763cb6f7cc73a0b0011e7554e1d2"}, {type: "uint256", name: "val", value: "50000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x41007cc8b701299f4464a1cc1e6ad03e3141763cb6f7cc73a0b0011e7554e1d2", "50000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1505962565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0xc86749e8926f8954edacc046b38d3bfa013b3f0b"}, {name: "amount", type: "uint256", value: "50000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0xc86749e8926f8954edacc046b38d3bfa013b3f0b"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "1"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x41007cc8b701299f4464a1cc1e6ad03e3141763cb6f7cc73a0b0011e7554e1d2"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "900641499177361547" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x91453b698098c0183307c2f35d2b545c2f15... )", async function( ) {
		const txOriginal = {blockNumber: "4297060", timeStamp: "1505966955", hash: "0x08c1f423d783942c7803f2a5a1f042debf4614ce9978d620b8709a53450cae45", nonce: "9", blockHash: "0x9ffbc2f9a6ada179b33d8c1f38a32650aa7c72b7316ed760713f15b917c4bb61", transactionIndex: "114", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "179310", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x8047cb9391453b698098c0183307c2f35d2b545c2f15049bb30f7f9ad3ffe9e1e6d6b035000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6252279", gasUsed: "179309", confirmations: "3407930"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x91453b698098c0183307c2f35d2b545c2f15049bb30f7f9ad3ffe9e1e6d6b035"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x91453b698098c0183307c2f35d2b545c2f15049bb30f7f9ad3ffe9e1e6d6b035", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1505966955 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "2"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x91453b698098c0183307c2f35d2b545c2f15049bb30f7f9ad3ffe9e1e6d6b035"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x55c637c68af5b8271fe5016a92b6af2cfb05... )", async function( ) {
		const txOriginal = {blockNumber: "4297064", timeStamp: "1505967028", hash: "0x8530e00995049a2446fce10669a51d00e1c807ba8ca04690a402e86837e3b5b5", nonce: "10", blockHash: "0xa8d270e3fdac63b782758bbb2fc53b0150c9825518dd63c061788b5ecceb684f", transactionIndex: "131", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "179310", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x8047cb9355c637c68af5b8271fe5016a92b6af2cfb0530728b15eb632df7fd9c3cf9f8c0000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6637366", gasUsed: "179309", confirmations: "3407926"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x55c637c68af5b8271fe5016a92b6af2cfb0530728b15eb632df7fd9c3cf9f8c0"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x55c637c68af5b8271fe5016a92b6af2cfb0530728b15eb632df7fd9c3cf9f8c0", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1505967028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "3"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x55c637c68af5b8271fe5016a92b6af2cfb0530728b15eb632df7fd9c3cf9f8c0"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"1\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4297124", timeStamp: "1505968502", hash: "0x3528b5d9c8f1d4cd53909cea72a9e4463c6e142067accb3ea4eb6f08c0bca7a0", nonce: "11", blockHash: "0x67130a890506754f97c36755983d988932a9c6622c9dd5c6e1a5915fc5a33854", transactionIndex: "73", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "50000000000000000", gas: "93771", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6601507", gasUsed: "93770", confirmations: "3407866"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "1"}, {type: "uint8", name: "move", value: "2"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "1", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1505968502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0xc86749e8926f8954edacc046b38d3bfa013b3f0b"}, {name: "player2", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "gameId", type: "uint256", value: "1"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "move2", type: "uint8", value: "2"}, {name: "gameStart", type: "uint256", value: "1505968502"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `Owner 1` )", async function( ) {
		const txOriginal = {blockNumber: "4297254", timeStamp: "1505971234", hash: "0xb077afbadb89dd705781ed25837623404fa954fcf2d86bd7e4767382483bf3ae", nonce: "12", blockHash: "0x90dc8b548d60764bb648c4fb898773c422959c178bed326d37dc9e3507041a52", transactionIndex: "27", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "73456", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xc47f0027000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000074f776e6572203100000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "918567", gasUsed: "73455", confirmations: "3407736"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Owner 1`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `Owner 1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1505971234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "NewName", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewName", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "name", type: "string", value: "Owner 1"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"3\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4300615", timeStamp: "1506053256", hash: "0x68f0823352311881c51893369030f88fd04e1932fb9e990a3ebff958bb7548ef", nonce: "6", blockHash: "0x26f12adb2b3cdc3e151d9cb645c419e7cc41ce126879ba23fb1741995b411df5", transactionIndex: "304", from: "0xeba905f3cf978b3f024e39ea5d638c2828046d3c", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93771", gasPrice: "22182951829", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6581362", gasUsed: "93770", confirmations: "3404375"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "move", value: "2"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "3", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1506053256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0xeba905f3cf978b3f024e39ea5d638c2828046d3c"}, {name: "gameId", type: "uint256", value: "3"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "2"}, {name: "gameStart", type: "uint256", value: "1506053256"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7808705606994670" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: revealMove( \"3\", \"3\", `e0737d5f481fc10b1fc89e615... )", async function( ) {
		const txOriginal = {blockNumber: "4302245", timeStamp: "1506099854", hash: "0xdd08e843a60a04f28b9884e91eff8c70fed834f16d3d9ddb694f71741e45b4cb", nonce: "13", blockHash: "0x2db85601891b68cb53529846ccfbb488fe81e5a192c5d2bbee74563f23ed7a13", transactionIndex: "42", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "94915", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xbd675c0e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004065303733376435663438316663313062316663383965363135323136333766336438626238343139303830316534336631626438316536336535653533373163", contractAddress: "", cumulativeGasUsed: "1355269", gasUsed: "94914", confirmations: "3402745"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "move", value: "3"}, {type: "string", name: "secret", value: `e0737d5f481fc10b1fc89e61521637f3d8bb84190801e43f1bd81e63e5e5371c`}], name: "revealMove", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "revealMove(uint256,uint8,string)" ]( "3", "3", `e0737d5f481fc10b1fc89e61521637f3d8bb84190801e43f1bd81e63e5e5371c`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1506099854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[12,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0xeba905f3cf978b3f024e39ea5d638c2828046d3c"}, {name: "gameId", type: "uint256", value: "3"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "result", type: "uint8", value: "2"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[12,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4305805", timeStamp: "1506206422", hash: "0xd3d3d1e2636f10b8e634b97b0f1ae05099d9757faa1434aaa95aca92990535c9", nonce: "0", blockHash: "0x0d9a356da33174dd8c47df7922cf0dcb196018e826fc86919016047ef1e56508", transactionIndex: "39", from: "0x8d00d4cadc3d83cdf8f8e977e0187f1ca7888f73", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "32887", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5610570", gasUsed: "21924", confirmations: "3399185"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1506206422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "697355970000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `thewhistler` )", async function( ) {
		const txOriginal = {blockNumber: "4305807", timeStamp: "1506206660", hash: "0xc21b5960607ddec5f308eb433bb249537965197aaf07cf043066073f891e94d7", nonce: "1", blockHash: "0x1ecf2bdda539f5b6f1ee73b812b995798f1a975fcf1c69925d5e92f4ba7554e8", transactionIndex: "206", from: "0x8d00d4cadc3d83cdf8f8e977e0187f1ca7888f73", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "78167", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xc47f00270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b74686577686973746c6572000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5745666", gasUsed: "78166", confirmations: "3399183"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `thewhistler`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `thewhistler`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1506206660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "NewName", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewName", events: [{name: "player", type: "address", value: "0x8d00d4cadc3d83cdf8f8e977e0187f1ca7888f73"}, {name: "name", type: "string", value: "thewhistler"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "697355970000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4305811", timeStamp: "1506206751", hash: "0xb3d1b58a58721b62da7d33c4c72caa7559cc3cefde006a9c66ccf87c3deecb77", nonce: "2", blockHash: "0x0673291ac2d9245f0cb721f7e301f7b42fd263a35455f6dc918d6d909c859fbe", transactionIndex: "31", from: "0x8d00d4cadc3d83cdf8f8e977e0187f1ca7888f73", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "200000000000000000", gas: "65572", gasPrice: "10000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "2884868", gasUsed: "43714", confirmations: "3399179"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1506206751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8d00d4cadc3d83cdf8f8e977e0187f1ca7888f73"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "697355970000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4310034", timeStamp: "1506332457", hash: "0xef363b87b54a122cf359b1df677381bdeb9509facd74cc1c8711118d9d0271c8", nonce: "0", blockHash: "0xcf4b406dab5ffbee659d41d0c2ca433ef1012a43bc3071f1ab8fe9cabe316e72", transactionIndex: "51", from: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "143715", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "1998361", gasUsed: "43714", confirmations: "3394956"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1506332457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a"}, {name: "amount", type: "uint256", value: "20000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"2\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4310043", timeStamp: "1506332909", hash: "0xc91840461b5b2ec87ec6c7c51e8a32d62e121bcca6b30fae4e9118e92f35f0d9", nonce: "1", blockHash: "0x49b65c574f74942131b2b1faf945d09a469c16364185a7828e5750959ec2e53c", transactionIndex: "120", from: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93771", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5114084", gasUsed: "93770", confirmations: "3394947"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1506332909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a"}, {name: "gameId", type: "uint256", value: "2"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "3"}, {name: "gameStart", type: "uint256", value: "1506332909"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4310159", timeStamp: "1506336255", hash: "0x800c7fc44b64800c41832189992999f61f2599f737827201a13354d7385d3dca", nonce: "2", blockHash: "0x24885e876482e8c5716a09916fc1ff06fe95a8f1169ffa8b4927e2e53e44d792", transactionIndex: "81", from: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "136705", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4535817", gasUsed: "20967", confirmations: "3394831"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1506336255 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "player", type: "address", value: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a"}, {name: "amount", type: "uint256", value: "20000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x607a42df595fe1f6a15d3a921635137ef0bd... )", async function( ) {
		const txOriginal = {blockNumber: "4311524", timeStamp: "1506376958", hash: "0x4aca684327bfe56f369a7f25fe72e356249e73afa329620e5812c42458b2d8ce", nonce: "14", blockHash: "0x01ab12f3b7bdc7589891ec4a7b462ea6f9cf7a08858d86cfdd2ec87aac3c8568", transactionIndex: "85", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "179310", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x8047cb93607a42df595fe1f6a15d3a921635137ef0bd314c37256bf4df7b47b35cd7ec0a00000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3942067", gasUsed: "179309", confirmations: "3393466"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x607a42df595fe1f6a15d3a921635137ef0bd314c37256bf4df7b47b35cd7ec0a"}, {type: "uint256", name: "val", value: "20000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x607a42df595fe1f6a15d3a921635137ef0bd314c37256bf4df7b47b35cd7ec0a", "20000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1506376958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "amount", type: "uint256", value: "20000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "4"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x607a42df595fe1f6a15d3a921635137ef0bd314c37256bf4df7b47b35cd7ec0a"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: abortGame( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4311556", timeStamp: "1506377703", hash: "0xdcb87e956ee1c543c10dc07ef775b32bd3514474a8c144ca64aca0506408dbd2", nonce: "15", blockHash: "0x852abf898c057c43a8a3d0da449015213770afeb1018026bf8ea5eb84fd4c439", transactionIndex: "87", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "41689", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x9e231e2d0000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "6706276", gasUsed: "39510", confirmations: "3393434"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "4"}], name: "abortGame", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "abortGame(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1506377703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "4"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "result", type: "uint8", value: "0"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x502fb666a5e066c80cc067f3669b0978b37e... )", async function( ) {
		const txOriginal = {blockNumber: "4311571", timeStamp: "1506378048", hash: "0x8b4df11587cdcdaa30354bb694e345961d618245a3ab39b8bc65c94c0cd8c7b1", nonce: "16", blockHash: "0x75da7e68b5d534147a24e4cfac1557a5780a11a9703b96724f55733d67d8abdf", transactionIndex: "48", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "179310", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x8047cb93502fb666a5e066c80cc067f3669b0978b37e3296c9a9ac27092fb0718aec853b00000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2545835", gasUsed: "179309", confirmations: "3393419"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x502fb666a5e066c80cc067f3669b0978b37e3296c9a9ac27092fb0718aec853b"}, {type: "uint256", name: "val", value: "20000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x502fb666a5e066c80cc067f3669b0978b37e3296c9a9ac27092fb0718aec853b", "20000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1506378048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "amount", type: "uint256", value: "20000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "5"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x502fb666a5e066c80cc067f3669b0978b37e3296c9a9ac27092fb0718aec853b"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: revealMove( \"2\", \"3\", `28b834fe1c6acaae5b7a05553... )", async function( ) {
		const txOriginal = {blockNumber: "4311695", timeStamp: "1506382381", hash: "0x9835223271df04c226800230f14d1c5ba685a1c07b8003a4e60e399a204ceadd", nonce: "17", blockHash: "0xa080d95183880a09ec5d6908c3206983a2bcda06b4397d96decb25d9fca6ccec", transactionIndex: "202", from: "0x8654d2125045132ebbd57da77dc258c99bfcb11e", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "75710", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xbd675c0e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004032386238333466653163366163616165356237613035353533313637333836643339646265663732623537663238356236326563303762376636663734333062", contractAddress: "", cumulativeGasUsed: "5527291", gasUsed: "75709", confirmations: "3393295"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "move", value: "3"}, {type: "string", name: "secret", value: `28b834fe1c6acaae5b7a05553167386d39dbef72b57f285b62ec07b7f6f7430b`}], name: "revealMove", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "revealMove(uint256,uint8,string)" ]( "2", "3", `28b834fe1c6acaae5b7a05553167386d39dbef72b57f285b62ec07b7f6f7430b`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1506382381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[22,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a"}, {name: "gameId", type: "uint256", value: "2"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "result", type: "uint8", value: "1"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[22,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "387517251961233640" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4313136", timeStamp: "1506425619", hash: "0x30d0a86b289b62020f760078af0a728a9a8335e1f306745bc57b07720095e508", nonce: "3", blockHash: "0x297877a2e00a200dec4b68aba0ff1731fbbee97ca2baea6b8ab79d07f53e596e", transactionIndex: "36", from: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "136705", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1461524", gasUsed: "20967", confirmations: "3391854"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1506425619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "player", type: "address", value: "0x188c7085dd919afe3e30aeebfbab3a4e58c0c16a"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4319620", timeStamp: "1506620232", hash: "0xc8dd7bbcc2ed78c9fd0f3fc5ca8086a11ee79a0333d1e56be7bc629da2cb9f94", nonce: "2", blockHash: "0x1758f95be4141e46d1bebe37780390f6c9e453a3616fcf4663af60a95736fbda", transactionIndex: "200", from: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "93771", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6669363", gasUsed: "93770", confirmations: "3385370"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "5"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1506620232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x8654d2125045132ebbd57da77dc258c99bfcb11e"}, {name: "player2", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "gameId", type: "uint256", value: "5"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "move2", type: "uint8", value: "1"}, {name: "gameStart", type: "uint256", value: "1506620232"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "68786812000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `Alejandro` )", async function( ) {
		const txOriginal = {blockNumber: "4319623", timeStamp: "1506620290", hash: "0x14d88b4a12938e2b6fc7d30b1da940eed1d06153d00cbd84688798087c0d9221", nonce: "3", blockHash: "0x75f88fdc6f63a8e46c5e84d8c34f94653b236cae97051dbb6f70037a06f33a95", transactionIndex: "27", from: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "75949", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xc47f002700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009416c656a616e64726f0000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1008477", gasUsed: "75948", confirmations: "3385367"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Alejandro`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `Alejandro`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1506620290 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "NewName", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewName", events: [{name: "player", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "name", type: "string", value: "Alejandro"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "68786812000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x8ce7d46442cb7be05d338cbb55245f36255d... )", async function( ) {
		const txOriginal = {blockNumber: "4319659", timeStamp: "1506621135", hash: "0x20589ad9039440051fef90613e6e8b6ff7a53f83ab4f2c9984ab0e974490f878", nonce: "4", blockHash: "0x0e7d635d3b6d68f10fdd90d78fb11b419589c4761d2c4273cc642a13c99c83a3", transactionIndex: "72", from: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "194309", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x8047cb938ce7d46442cb7be05d338cbb55245f36255d475a9a652c443dfff03ee37aa09b000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3032608", gasUsed: "179309", confirmations: "3385331"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x8ce7d46442cb7be05d338cbb55245f36255d475a9a652c443dfff03ee37aa09b"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x8ce7d46442cb7be05d338cbb55245f36255d475a9a652c443dfff03ee37aa09b", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1506621135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "6"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x8ce7d46442cb7be05d338cbb55245f36255d475a9a652c443dfff03ee37aa09b"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "68786812000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"6\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4319665", timeStamp: "1506621358", hash: "0xb51443fe89271a1fbcb689d66611dd571d6b1e8cb4039008a96d2d06b730a39c", nonce: "5", blockHash: "0xc6b878cd8dcd3bfd179ce322ac2e2c309c08d8a3cf77ac1a5c9feface4f703b2", transactionIndex: "28", from: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93771", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2583487", gasUsed: "93770", confirmations: "3385325"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6"}, {type: "uint8", name: "move", value: "2"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "6", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1506621358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "player2", type: "address", value: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc"}, {name: "gameId", type: "uint256", value: "6"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "2"}, {name: "gameStart", type: "uint256", value: "1506621358"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "68786812000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"6\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4319667", timeStamp: "1506621467", hash: "0xd9f05af96272990f5ccee17a473ba47c31e526908849b7ffb2eec8914b0bc47e", nonce: "6", blockHash: "0xbb8c600898a7cb85ce6b8bc2970aafb524b0bfb06e70ec10a10f82165d678244", transactionIndex: "61", from: "0xcd8d25d50f5c438d59375db4595d18587bfa1ecc", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93771", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3842784", gasUsed: "93771", confirmations: "3385323"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6"}, {type: "uint8", name: "move", value: "2"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "68786812000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x86cdb4e037b8463782822e09fe9119117e77... )", async function( ) {
		const txOriginal = {blockNumber: "4569615", timeStamp: "1510921545", hash: "0x5753027383888b1c5701b5aa41d68a73e61df210a4e2c25f274471220499b906", nonce: "133", blockHash: "0x3a79d7ebaad2a3107ed836dfd7b7748eeb75f58b7b7a836d60c36ab16226f62c", transactionIndex: "54", from: "0x37d7fe126b896ea132a23679358dea887640e666", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "194309", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb9386cdb4e037b8463782822e09fe9119117e77054e80af2d9233973322949907ea000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2562294", gasUsed: "179309", confirmations: "3135375"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x86cdb4e037b8463782822e09fe9119117e77054e80af2d9233973322949907ea"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x86cdb4e037b8463782822e09fe9119117e77054e80af2d9233973322949907ea", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510921545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x37d7fe126b896ea132a23679358dea887640e666"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x37d7fe126b896ea132a23679358dea887640e666"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "7"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x86cdb4e037b8463782822e09fe9119117e77054e80af2d9233973322949907ea"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"7\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4581061", timeStamp: "1511080024", hash: "0xd09fa714b7a4507c763aa04991b94601fc9b1257540e1b1db8d47f27c26c6139", nonce: "42", blockHash: "0x9d0e449dc4ad317c886ec0aa834759f67277ce340eaaedb544e6056ca9c374a3", transactionIndex: "23", from: "0x7cfdc5aae341061b058bb342a0319d22358361b6", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93770", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "912443", gasUsed: "93770", confirmations: "3123929"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "7"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "7", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511080024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x37d7fe126b896ea132a23679358dea887640e666"}, {name: "player2", type: "address", value: "0x7cfdc5aae341061b058bb342a0319d22358361b6"}, {name: "gameId", type: "uint256", value: "7"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "3"}, {name: "gameStart", type: "uint256", value: "1511080024"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "222792116545159880" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x3a8f7e6ecf22d395bd697fcdffd515040705... )", async function( ) {
		const txOriginal = {blockNumber: "4585036", timeStamp: "1511134967", hash: "0xddb1b7ebef2e4cc1dae2e6a48cd47268f39c3bbbbdbbd69ca12d831e9fda8ac0", nonce: "0", blockHash: "0x0654aa4ed2add50a410b73098f18242d5623293417b3c4d3b2081799b128dae2", transactionIndex: "50", from: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "194373", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb933a8f7e6ecf22d395bd697fcdffd51504070591b54dfb9133645fa9d98f7cead400000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2007062", gasUsed: "179373", confirmations: "3119954"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x3a8f7e6ecf22d395bd697fcdffd51504070591b54dfb9133645fa9d98f7cead4"}, {type: "uint256", name: "val", value: "1000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x3a8f7e6ecf22d395bd697fcdffd51504070591b54dfb9133645fa9d98f7cead4", "1000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511134967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "8"}, {name: "value", type: "uint256", value: "1000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x3a8f7e6ecf22d395bd697fcdffd51504070591b54dfb9133645fa9d98f7cead4"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "5755524000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"8\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4585042", timeStamp: "1511135048", hash: "0xfdfdf37e8ade3e378d37cd67fc37ae22a2d6a10bb5c149b4f5d52d1b12789c06", nonce: "1", blockHash: "0xe051c8ca32ba93b19b58596a92574bac9858322f79551e4f7c35872c72d7cd8c", transactionIndex: "34", from: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "93770", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "974808", gasUsed: "93770", confirmations: "3119948"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "8"}, {type: "uint8", name: "move", value: "2"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "8", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511135048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "player2", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "gameId", type: "uint256", value: "8"}, {name: "value", type: "uint256", value: "1000000000000000"}, {name: "move2", type: "uint8", value: "2"}, {name: "gameStart", type: "uint256", value: "1511135048"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "5755524000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: revealMove( \"8\", \"2\", `058d65a0c82154116713fa9d4... )", async function( ) {
		const txOriginal = {blockNumber: "4585055", timeStamp: "1511135214", hash: "0x25dab451b77e2f1c385a6d51c63e688ec4602f2a3ebbb1e653bfa0bde626e104", nonce: "2", blockHash: "0x492b1958d9a9cbccb0efa9931acaf447d86e0fb8ed24a6431ef55203adfa7c7a", transactionIndex: "51", from: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "75709", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbd675c0e000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004030353864363561306338323135343131363731336661396434663966303862353866386630646430653536323561616539616439363764303336623338363837", contractAddress: "", cumulativeGasUsed: "1224179", gasUsed: "75709", confirmations: "3119935"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "8"}, {type: "uint8", name: "move", value: "2"}, {type: "string", name: "secret", value: `058d65a0c82154116713fa9d4f9f08b58f8f0dd0e5625aae9ad967d036b38687`}], name: "revealMove", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "revealMove(uint256,uint8,string)" ]( "8", "2", `058d65a0c82154116713fa9d4f9f08b58f8f0dd0e5625aae9ad967d036b38687`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511135214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "player2", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "gameId", type: "uint256", value: "8"}, {name: "value", type: "uint256", value: "1000000000000000"}, {name: "result", type: "uint8", value: "1"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "5755524000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4585058", timeStamp: "1511135280", hash: "0xd1cb539f788d50b22f706a9a150b75747b743da90f0e1c4077a8a7378b987a59", nonce: "3", blockHash: "0xfb8470909ea6de2e0b2f594362e3187267d3de27207fb1a337503f5146ad965e", transactionIndex: "52", from: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "55057", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1348733", gasUsed: "20967", confirmations: "3119932"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511135280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "player", type: "address", value: "0x6fe67750c9a987bd6aeddb54cce122c45f4efe3d"}, {name: "amount", type: "uint256", value: "2000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "5755524000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0xe7440affa38797d601ca3a932307eb28dc58... )", async function( ) {
		const txOriginal = {blockNumber: "4665340", timeStamp: "1512262728", hash: "0x4fd735f2ec276a2fef8546c966e27bece6cfd83dcc819fbc9889e619fbb81f86", nonce: "4", blockHash: "0xcf974e269b6af5af7c027e517998612027357db3da84f153aefa693d5ad8181b", transactionIndex: "6", from: "0xbe71c086c0cc6d6fe626af3ad9a5fe88fab8c6a3", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "194309", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb93e7440affa38797d601ca3a932307eb28dc58f6348b577ab8f57cfdf85a5702a5000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "309737", gasUsed: "179309", confirmations: "3039650"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0xe7440affa38797d601ca3a932307eb28dc58f6348b577ab8f57cfdf85a5702a5"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0xe7440affa38797d601ca3a932307eb28dc58f6348b577ab8f57cfdf85a5702a5", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1512262728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0xbe71c086c0cc6d6fe626af3ad9a5fe88fab8c6a3"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0xbe71c086c0cc6d6fe626af3ad9a5fe88fab8c6a3"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "9"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0xe7440affa38797d601ca3a932307eb28dc58f6348b577ab8f57cfdf85a5702a5"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "8546228715303" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"9\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4671172", timeStamp: "1512346141", hash: "0x774a4d437b8a12574e0814999806e4068e333120d66cdea1bd139ffd56a1f6de", nonce: "28", blockHash: "0xa6c0d5871df33e46d4597fd957fb633db7b8b316ae95255877c7addbc0bb4018", transactionIndex: "83", from: "0xe5551f7d6afa91ddd4956a11a7fff8c5d277b5d8", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93770", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c500000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5743909", gasUsed: "93770", confirmations: "3033818"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "9"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "9", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1512346141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0xbe71c086c0cc6d6fe626af3ad9a5fe88fab8c6a3"}, {name: "player2", type: "address", value: "0xe5551f7d6afa91ddd4956a11a7fff8c5d277b5d8"}, {name: "gameId", type: "uint256", value: "9"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "3"}, {name: "gameStart", type: "uint256", value: "1512346141"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "42375270577632" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x5da9fc7d963438ae1f19a6d25779a64f14b7... )", async function( ) {
		const txOriginal = {blockNumber: "4678318", timeStamp: "1512455328", hash: "0xa93137107d2c03fa3e9de7faedc54665f6ede229efa1206c88b5932ab4ad6016", nonce: "8", blockHash: "0x9a97aaf6d3b4b2ebc55dc6998b2489c9b3fa518073897ae9e8af06a5f45deb6c", transactionIndex: "29", from: "0xc6f2712f59b7f6093cbc9e1f82befa8aca2146d6", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "194309", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb935da9fc7d963438ae1f19a6d25779a64f14b77fab0bff10cd96bc4a093e2a7b2100000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2350946", gasUsed: "179309", confirmations: "3026672"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x5da9fc7d963438ae1f19a6d25779a64f14b77fab0bff10cd96bc4a093e2a7b21"}, {type: "uint256", name: "val", value: "20000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x5da9fc7d963438ae1f19a6d25779a64f14b77fab0bff10cd96bc4a093e2a7b21", "20000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1512455328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0xc6f2712f59b7f6093cbc9e1f82befa8aca2146d6"}, {name: "amount", type: "uint256", value: "20000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0xc6f2712f59b7f6093cbc9e1f82befa8aca2146d6"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "10"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x5da9fc7d963438ae1f19a6d25779a64f14b77fab0bff10cd96bc4a093e2a7b21"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "93120667712962963" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"10\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4684323", timeStamp: "1512548945", hash: "0x5afde39aa43d624195c9d422e720b09f4eef62990974aac2a811d9d727375947", nonce: "598", blockHash: "0x407c484dabb80629b9bf253f64791df33f9972ee012967d682466e425eff28cc", transactionIndex: "79", from: "0x05f138f70934bfbd1cdafbf7518b99a6b7261bf9", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "20000000000000000", gas: "93770", gasPrice: "35000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6699141", gasUsed: "93770", confirmations: "3020667"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "10"}, {type: "uint8", name: "move", value: "3"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "10", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1512548945 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0xc6f2712f59b7f6093cbc9e1f82befa8aca2146d6"}, {name: "player2", type: "address", value: "0x05f138f70934bfbd1cdafbf7518b99a6b7261bf9"}, {name: "gameId", type: "uint256", value: "10"}, {name: "value", type: "uint256", value: "20000000000000000"}, {name: "move2", type: "uint8", value: "3"}, {name: "gameStart", type: "uint256", value: "1512548945"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "31441201096425855" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claimGame( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4711153", timeStamp: "1512951780", hash: "0xf2f079bcc2ecae4cab57ac6b5109f00051a0b4a4eb7ea0a0fd4d880cb9a0d0ec", nonce: "32", blockHash: "0x50c081f8cd878842dd72531fcd5728e833eb80065dce37e3daa8d82731c95637", transactionIndex: "55", from: "0xe5551f7d6afa91ddd4956a11a7fff8c5d277b5d8", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "100489", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x39236bef0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "3701905", gasUsed: "98312", confirmations: "2993837"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "9"}], name: "claimGame", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGame(uint256)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1512951780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0xbe71c086c0cc6d6fe626af3ad9a5fe88fab8c6a3"}, {name: "player2", type: "address", value: "0xe5551f7d6afa91ddd4956a11a7fff8c5d277b5d8"}, {name: "gameId", type: "uint256", value: "9"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "result", type: "uint8", value: "4"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "42375270577632" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0xd0f51fa1910b7d462f75c260d1b78acbe401... )", async function( ) {
		const txOriginal = {blockNumber: "4746695", timeStamp: "1513487111", hash: "0x0df979fcade3d76c3b13bffa1fd85c3affb708e94643d138b6d45aa4d3e0e04c", nonce: "217", blockHash: "0x4c2b4912fa6994ce4c9a965f3247846b1cd883be8b2f755bc3d548f641bb55f5", transactionIndex: "126", from: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "194309", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb93d0f51fa1910b7d462f75c260d1b78acbe4010670050ef4d3c6d2137b48c78fbe000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7676124", gasUsed: "179309", confirmations: "2958295"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0xd0f51fa1910b7d462f75c260d1b78acbe4010670050ef4d3c6d2137b48c78fbe"}, {type: "uint256", name: "val", value: "10000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0xd0f51fa1910b7d462f75c260d1b78acbe4010670050ef4d3c6d2137b48c78fbe", "10000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1513487111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "11"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0xd0f51fa1910b7d462f75c260d1b78acbe4010670050ef4d3c6d2137b48c78fbe"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1212965671764323350" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"11\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4751543", timeStamp: "1513559535", hash: "0xd1e0b2d0cae1013c07a14d9af786985f33318b54683779de5ce46790e0e7f52c", nonce: "11", blockHash: "0x06d18cb53b771e2d6b978815ca87950616ff74aff5ceaae69193f36fb2d2795c", transactionIndex: "89", from: "0xa675d0598631414eff11d81c4831ebfea776c87b", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "10000000000000000", gas: "93770", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4947067", gasUsed: "93770", confirmations: "2953447"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "11"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "11", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1513559535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "player2", type: "address", value: "0xa675d0598631414eff11d81c4831ebfea776c87b"}, {name: "gameId", type: "uint256", value: "11"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "move2", type: "uint8", value: "1"}, {name: "gameStart", type: "uint256", value: "1513559535"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15547244506999999947" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: revealMove( \"11\", \"1\", `85dbfe07cf1904a07f2920b4... )", async function( ) {
		const txOriginal = {blockNumber: "4769303", timeStamp: "1513831405", hash: "0x1daf6872a83389b6ad7cc02810f54b8c987092dd01b5e467137daf38b9889ded", nonce: "221", blockHash: "0x84f99433f30871938d3accf4d38ca053630a9a8b056e5caab56d22d433a83258", transactionIndex: "44", from: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "0", gas: "90709", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xbd675c0e000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004038356462666530376366313930346130376632393230623462316464666331313963633261353538343139306238393064666239316538356534303566633637", contractAddress: "", cumulativeGasUsed: "1689307", gasUsed: "90709", confirmations: "2935687"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "11"}, {type: "uint8", name: "move", value: "1"}, {type: "string", name: "secret", value: `85dbfe07cf1904a07f2920b4b1ddfc119cc2a5584190b890dfb91e85e405fc67`}], name: "revealMove", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "revealMove(uint256,uint8,string)" ]( "11", "1", `85dbfe07cf1904a07f2920b4b1ddfc119cc2a5584190b890dfb91e85e405fc67`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1513831405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}], name: "GameEnded", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameEnded", events: [{name: "player1", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "player2", type: "address", value: "0xa675d0598631414eff11d81c4831ebfea776c87b"}, {name: "gameId", type: "uint256", value: "11"}, {name: "value", type: "uint256", value: "10000000000000000"}, {name: "result", type: "uint8", value: "1"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1212965671764323350" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x4f1c4723403ebf85a25e43e2f8ea2cd883e5... )", async function( ) {
		const txOriginal = {blockNumber: "4769355", timeStamp: "1513832185", hash: "0x1c82af5eb490bb5474ab8090731212a058a9b946c11aef1efce8c2c1e3069db5", nonce: "222", blockHash: "0xe3b6e0a87db441a1ffc00a6c4f874f9b40567aa158f1b5bb07422258b4cadca9", transactionIndex: "23", from: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "100000000000000000", gas: "179309", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb934f1c4723403ebf85a25e43e2f8ea2cd883e5ec3582875f0ab2003986faa489a0000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1342245", gasUsed: "179309", confirmations: "2935635"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x4f1c4723403ebf85a25e43e2f8ea2cd883e5ec3582875f0ab2003986faa489a0"}, {type: "uint256", name: "val", value: "100000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x4f1c4723403ebf85a25e43e2f8ea2cd883e5ec3582875f0ab2003986faa489a0", "100000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1513832185 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x3632eba80749a7be8c434ed9fa13dd2c4c36f722"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "12"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x4f1c4723403ebf85a25e43e2f8ea2cd883e5ec3582875f0ab2003986faa489a0"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1212965671764323350" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"0x0f04592be663cefa3a4e82496776f62b0431... )", async function( ) {
		const txOriginal = {blockNumber: "4773828", timeStamp: "1513901810", hash: "0x2a9268631b2e2b1aa4a9f704949e00de0657bddfa9ec25d768e25fccb957cb4c", nonce: "1", blockHash: "0x20cac665a8bffcbc7813f687ea3742a2685ecdc55dd9f006c2f24f8ff9af2400", transactionIndex: "105", from: "0x42b2e01ac32ae5edf144f6158833642b27ff0cf5", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "194373", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x8047cb930f04592be663cefa3a4e82496776f62b043133125e6bc8277b1d5b464409bb6000000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3398728", gasUsed: "179373", confirmations: "2931162"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "move", value: "0x0f04592be663cefa3a4e82496776f62b043133125e6bc8277b1d5b464409bb60"}, {type: "uint256", name: "val", value: "1000000000000000"}, {type: "address", name: "player2", value: addressList[0]}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(bytes32,uint256,address)" ]( "0x0f04592be663cefa3a4e82496776f62b043133125e6bc8277b1d5b464409bb60", "1000000000000000", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1513901810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x42b2e01ac32ae5edf144f6158833642b27ff0cf5"}, {name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "hiddenMove1", type: "bytes32"}], name: "GameCreated", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameCreated", events: [{name: "player1", type: "address", value: "0x42b2e01ac32ae5edf144f6158833642b27ff0cf5"}, {name: "player2", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "gameId", type: "uint256", value: "13"}, {name: "value", type: "uint256", value: "1000000000000000"}, {name: "hiddenMove1", type: "bytes32", value: "0x0f04592be663cefa3a4e82496776f62b043133125e6bc8277b1d5b464409bb60"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1791271440000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4774901", timeStamp: "1513918072", hash: "0xfd44a90967b690d6d59a7b35b59d41ffb55bae6c2515f6a0f64cf43f9e983b0e", nonce: "5", blockHash: "0xbf5b5ac16f96daf1cbb57ffeb26495d6fb338e059eaca007def78ef17d1d4e30", transactionIndex: "234", from: "0x5a21a1490a82b401a004ade111d4e824d268aceb", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "93770", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5762396", gasUsed: "93770", confirmations: "2930089"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "13"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1513918072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player1", type: "address"}, {indexed: true, name: "player2", type: "address"}, {indexed: true, name: "gameId", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "move2", type: "uint8"}, {indexed: false, name: "gameStart", type: "uint256"}], name: "GameJoined", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameJoined", events: [{name: "player1", type: "address", value: "0x42b2e01ac32ae5edf144f6158833642b27ff0cf5"}, {name: "player2", type: "address", value: "0x5a21a1490a82b401a004ade111d4e824d268aceb"}, {name: "gameId", type: "uint256", value: "13"}, {name: "value", type: "uint256", value: "1000000000000000"}, {name: "move2", type: "uint8", value: "1"}, {name: "gameStart", type: "uint256", value: "1513918072"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7079156999999999" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4774903", timeStamp: "1513918095", hash: "0x64d4220d64ae2c29c7a8c353d6a0985db5e07eb589b2cd77a566ede44b33046d", nonce: "6", blockHash: "0x77bcd1587d4bc2ab36488b24f45f77fdf869f4c3a2f23309528a71878d9f8c9b", transactionIndex: "41", from: "0x5a21a1490a82b401a004ade111d4e824d268aceb", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "93770", gasPrice: "40000000000", isError: "0", txreceipt_status: "0", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1183972", gasUsed: "23214", confirmations: "2930087"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "13"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1513918095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7079156999999999" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4774903", timeStamp: "1513918095", hash: "0xce64ed536507a41ad731c7439d56a3c5a10cfd21b347de67da24a836d1de3d3b", nonce: "7", blockHash: "0x77bcd1587d4bc2ab36488b24f45f77fdf869f4c3a2f23309528a71878d9f8c9b", transactionIndex: "81", from: "0x5a21a1490a82b401a004ade111d4e824d268aceb", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "93770", gasPrice: "40000000000", isError: "0", txreceipt_status: "0", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2591614", gasUsed: "23214", confirmations: "2930087"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "13"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1513918095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7079156999999999" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: joinGame( \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4774903", timeStamp: "1513918095", hash: "0x1656564c46dba38adf1509ec3a91ea164d99dc857e2de819f453e6fc042f6266", nonce: "8", blockHash: "0x77bcd1587d4bc2ab36488b24f45f77fdf869f4c3a2f23309528a71878d9f8c9b", transactionIndex: "86", from: "0x5a21a1490a82b401a004ade111d4e824d268aceb", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "93770", gasPrice: "40000000000", isError: "0", txreceipt_status: "0", input: "0xca6649c5000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2722627", gasUsed: "23214", confirmations: "2930087"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "13"}, {type: "uint8", name: "move", value: "1"}], name: "joinGame", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinGame(uint256,uint8)" ]( "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1513918095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7079156999999999" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4774985", timeStamp: "1513919504", hash: "0x7b832e561b0962cb8c85b3a6c727ed1b82b25b968ad22a6194e768c236840f7c", nonce: "9", blockHash: "0x70a22cf5dd1a3e47e7b1eadfe6e73e8cc6883854846de4f578f4bd974d07a78e", transactionIndex: "95", from: "0x5a21a1490a82b401a004ade111d4e824d268aceb", to: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044", value: "1000000000000000", gas: "65571", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "2595839", gasUsed: "43714", confirmations: "2930005"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1513919504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "player", type: "address", value: "0x5a21a1490a82b401a004ade111d4e824d268aceb"}, {name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x5df4bea3540899a33c76c4d25108f4fe2ca89044"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7079156999999999" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "289082322961233640" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
