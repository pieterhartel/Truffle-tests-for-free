ganache-cli -p 9545 -a 1000 -e 1000000 -d -l 10000000 -t "2018-10-21T17:53:41.000Z" >ganache.log&
Pid=$!
sleep 10
truffle test 2>replay.js
kill $Pid
node replay.js
# node mutasol.js -f GameCity.sol -o 1 -m 50 -n 500 -v 0.4.25
