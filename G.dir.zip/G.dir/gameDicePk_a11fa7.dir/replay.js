var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "gameDicePk"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x1D1112a2b7eA8E75A2f2B121d6E7C0F958a11fa7","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0xD5eF5a7cC2270361bF5C7aA02e910602C9a3F9E2","0x0E540542622F7386686A57CB287F1d1ca289bc15","0x000042427B681cCF127A5112923322629183b109","0x00004242F7b5c47ae90EAf0F1C2DddF630774C80","0xf86567235e3aCD1856DaF7Fa54CcE09041aE026d","0x0D54b2278362d194815d1b0EB683033946FB4EB9","0x000042420e7913CeFee6988cf825c4a2B739684d","0x9Dfa08Cb7111E2Cb4E5B7194485D4d7460aDca72","0x2fe8E10633eAe71b503C60180C4190710a132237"]
addressListOriginal.length = 19
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"getMyInfo","outputs":[{"name":"","type":"uint256"},{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_tableId","type":"uint256"}],"name":"getTableInfo","outputs":[{"name":"","type":"uint256"},{"name":"","type":"uint256"},{"name":"","type":"uint256"},{"name":"","type":"uint256"},{"name":"","type":"uint8"},{"name":"","type":"uint8"},{"name":"","type":"uint8"},{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getOpenTableList","outputs":[{"name":"","type":"uint256[200]"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"_addr","type":"address"},{"indexed":false,"name":"_tableId","type":"uint256"},{"indexed":false,"name":"_amount","type":"uint256"},{"indexed":false,"name":"_position","type":"uint8"},{"indexed":true,"name":"_status","type":"uint8"},{"indexed":false,"name":"_posStatus","type":"uint8"},{"indexed":false,"name":"_endTime","type":"uint256"}],"name":"Bet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_tableId","type":"uint256"}],"name":"Cancel","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"_tableId","type":"uint256"},{"indexed":false,"name":"_amount","type":"uint256"},{"indexed":true,"name":"pos1","type":"uint256"},{"indexed":true,"name":"pos2","type":"uint256"},{"indexed":true,"name":"pos3","type":"uint256"},{"indexed":false,"name":"_position","type":"uint8"},{"indexed":false,"name":"_diceA","type":"uint8"},{"indexed":false,"name":"_diceB","type":"uint8"}],"name":"Finish","type":"event"}]
eventSignatureListOriginal = ["Bet(address,uint256,uint256,uint8,uint8,uint8,uint256)","Cancel(uint256)","Finish(uint256,uint256,uint256,uint256,uint256,uint8,uint8,uint8)"]
topicListOriginal = ["0x1e319564e7ac5e8260fae47753075a4af889324e54a2f3665b4d779bcc2fa4de","0x8bf30e7ff26833413be5f69e1d373744864d600b664204b4a2f9844a8eedb9ed","0x535eeba2270dbb6bc24dba7beae36e6a1ff5283a350594d9a6cce1df2548956e"]
nBlocksOriginal = 50
fromBlockOriginal = 6703435
toBlockOriginal = 6819506
constructorPrototypeOriginal = {"inputs":[],"name":"gameDicePk","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6703435","timeStamp":"1542206022","hash":"0xe73ef1993edfb63f7ca3b679396dd7747ca1c366e5610ad5e52c014b157b1b01","nonce":"25","blockHash":"0xe76942830f7ed08c1b8e466467634a71daa0ef8c92b8d898603f5dadcd9fb991","transactionIndex":"62","from":"0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2","to":0,"value":"0","gas":"3470961","gasPrice":"6100000000","isError":"0","txreceipt_status":"1","input":"0x4696e536","contractAddress":"0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7","cumulativeGasUsed":"6275011","gasUsed":"3470961","confirmations":"1006498"}
txOptions[0] = {"from":"0x28a8746e75304c0780E011BEd21C72cD78cd535E","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"gameDicePk","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
