const gameDicePk = artifacts.require( "./gameDicePk.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "gameDicePk" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x1D1112a2b7eA8E75A2f2B121d6E7C0F958a11fa7", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0xD5eF5a7cC2270361bF5C7aA02e910602C9a3F9E2", "0x0E540542622F7386686A57CB287F1d1ca289bc15", "0x000042427B681cCF127A5112923322629183b109", "0x00004242F7b5c47ae90EAf0F1C2DddF630774C80", "0xf86567235e3aCD1856DaF7Fa54CcE09041aE026d", "0x0D54b2278362d194815d1b0EB683033946FB4EB9", "0x000042420e7913CeFee6988cf825c4a2B739684d", "0x9Dfa08Cb7111E2Cb4E5B7194485D4d7460aDca72", "0x2fe8E10633eAe71b503C60180C4190710a132237"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getMyInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tableId", type: "uint256"}], name: "getTableInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint8"}, {name: "", type: "uint8"}, {name: "", type: "uint8"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getOpenTableList", outputs: [{name: "", type: "uint256[200]"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_tableId", type: "uint256"}], name: "Cancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Bet(address,uint256,uint256,uint8,uint8,uint8,uint256)", "Cancel(uint256)", "Finish(uint256,uint256,uint256,uint256,uint256,uint8,uint8,uint8)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1e319564e7ac5e8260fae47753075a4af889324e54a2f3665b4d779bcc2fa4de", "0x8bf30e7ff26833413be5f69e1d373744864d600b664204b4a2f9844a8eedb9ed", "0x535eeba2270dbb6bc24dba7beae36e6a1ff5283a350594d9a6cce1df2548956e"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6703435 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6819506 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "gameDicePk", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getMyInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMyInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tableId", value: random.range( maxRandom )}], name: "getTableInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint8"}, {name: "", type: "uint8"}, {name: "", type: "uint8"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTableInfo(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getOpenTableList", outputs: [{name: "", type: "uint256[200]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOpenTableList()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "gameDicePk", function( accounts ) {

	it( "TEST: gameDicePk(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6703435", timeStamp: "1542206022", hash: "0xe73ef1993edfb63f7ca3b679396dd7747ca1c366e5610ad5e52c014b157b1b01", nonce: "25", blockHash: "0xe76942830f7ed08c1b8e466467634a71daa0ef8c92b8d898603f5dadcd9fb991", transactionIndex: "62", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: 0, value: "0", gas: "3470961", gasPrice: "6100000000", isError: "0", txreceipt_status: "1", input: "0x4696e536", contractAddress: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", cumulativeGasUsed: "6275011", gasUsed: "3470961", confirmations: "1006498"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameDicePk", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = gameDicePk.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542206022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = gameDicePk.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750534", timeStamp: "1542874252", hash: "0x2473aa00fb839d8b422cff716cb85da96d09a51d3b8969eb8eec77bc19755a0b", nonce: "35", blockHash: "0xd91f8c7e4ce9cf287a098aad8240f32cf0067d1bee9ea5f6a5f33c57ed598c37", transactionIndex: "43", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "202440", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2952116", gasUsed: "134960", confirmations: "959399"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542874252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "1"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"1\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750549", timeStamp: "1542874460", hash: "0x74f9d90e507d9414db97402dee6bb847a4786adfe191a7521796dd1a0e068ba9", nonce: "2", blockHash: "0x2908e35dcd3b7a757da78cbaec9f1a63459e2ee2e5ccbafb295ce44630f3ec90", transactionIndex: "114", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "348129", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7080409", gasUsed: "232086", confirmations: "959384"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "1"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "1", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542874460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "1"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542874580"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xbe74be580627af1ed2079fce833d2d5ae75c... )", async function( ) {
		const txOriginal = {blockNumber: "6750561", timeStamp: "1542874630", hash: "0x7a6e23cd0845747f77877bd247f29883dbfe86c0e58279d6bbcbe14dd704f965", nonce: "2806", blockHash: "0x935a79619b218306d6350c2b2e8ff02764160f329f34b2108373ff24b0fb9e50", transactionIndex: "37", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ebe74be580627af1ed2079fce833d2d5ae75cd5548427981eb167128675e59d3000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003327c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1714909", gasUsed: "75309", confirmations: "959372"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xbe74be580627af1ed2079fce833d2d5ae75cd5548427981eb167128675e59d30"}, {type: "string", name: "result", value: `2|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xbe74be580627af1ed2079fce833d2d5ae75cd5548427981eb167128675e59d30", `2|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542874630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "1"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "123458"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "2"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750566", timeStamp: "1542874718", hash: "0xf0143f1a8b801bca4b9e78e46d706976e74050a30962fd66456890f2be2fe411", nonce: "3", blockHash: "0x7ec4684c2eb92967811dd67c6248ff220cb7be89b9913967ed757b5ead05f201", transactionIndex: "95", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "179940", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5672559", gasUsed: "119960", confirmations: "959367"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542874718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "2"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750571", timeStamp: "1542874779", hash: "0xdac346af95c5670619864def9583331b53ebb1bca7ea15893d313fab6d048586", nonce: "36", blockHash: "0xd5718d05419b74d1a762e91e30ea4bfe5a60fc030fb4e30776e29e0be9877dbc", transactionIndex: "109", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5603663", gasUsed: "133444", confirmations: "959362"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "2"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542874779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "2"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542874899"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750576", timeStamp: "1542874820", hash: "0x61ec79cc7c6550dbe04768932ce5b993e3a7899bd034f8607ae57e96a03793a5", nonce: "37", blockHash: "0xe84c19aac5f1531c0df7f737902fa83d6f852b6ae0e8db4459f3f7257d8f4690", transactionIndex: "120", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "180400", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7374516", gasUsed: "120267", confirmations: "959357"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542874820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "3"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"3\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6750578", timeStamp: "1542874854", hash: "0xf3a73c5355ce5a294828805fad97cc4a43bad80af121094b38c9a5606a8fe4e7", nonce: "4", blockHash: "0xe5abcf7b45466168dacd3f1abbd3812a489ac1708914486cf5046175845d3333", transactionIndex: "79", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "20000000000000000", gas: "200641", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7852677", gasUsed: "133761", confirmations: "959355"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "3"}, {type: "uint8", name: "_position", value: "3"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "3", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542874854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "3"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_position", type: "uint8", value: "3"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "3"}, {name: "_endTime", type: "uint256", value: "1542874974"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd1acf920802107f04ba34fec7c335915d24b... )", async function( ) {
		const txOriginal = {blockNumber: "6750584", timeStamp: "1542874920", hash: "0x1da8b11b1536aa46539092c552417d50230a3b278366f33f18914ddb67fee413", nonce: "2807", blockHash: "0x98386823c58915a779afa5f4c67b094a09cbb47d91ef9171aa372c59e534f2c0", transactionIndex: "61", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ed1acf920802107f04ba34fec7c335915d24b363192654042e8a0167c725fe66a00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003337c310000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2433520", gasUsed: "45043", confirmations: "959349"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd1acf920802107f04ba34fec7c335915d24b363192654042e8a0167c725fe66a"}, {type: "string", name: "result", value: `3|1`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xd1acf920802107f04ba34fec7c335915d24b363192654042e8a0167c725fe66a", `3|1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542874920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "2"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "123458"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "3"}, {name: "_diceB", type: "uint8", value: "1"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe66a3fea8f25ea3459f8235962c0490fa730... )", async function( ) {
		const txOriginal = {blockNumber: "6750590", timeStamp: "1542875017", hash: "0xa7b17d15f7ef4723a08e85295fa4fc0dfd8eedc349aee6ae7e42b272f267fede", nonce: "2788", blockHash: "0xe7c4ff2bdfeaacc81344d94690072c919d9f1d501731a9107ffd19945cddde57", transactionIndex: "159", from: "0x00004242f7b5c47ae90eaf0f1c2dddf630774c80", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ee66a3fea8f25ea3459f8235962c0490fa73020bd524ab9608c05af99ed1fac7700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003337c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5993439", gasUsed: "54114", confirmations: "959343"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe66a3fea8f25ea3459f8235962c0490fa73020bd524ab9608c05af99ed1fac77"}, {type: "string", name: "result", value: `3|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xe66a3fea8f25ea3459f8235962c0490fa73020bd524ab9608c05af99ed1fac77", `3|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542875017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "3"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "0"}, {name: "pos3", type: "uint256", value: "123458"}, {name: "_position", type: "uint8", value: "3"}, {name: "_diceA", type: "uint8", value: "3"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "787187580000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750597", timeStamp: "1542875134", hash: "0xf4b7cc336bc56e7fd9d57634212f054bb88e39ebbf7089b3fc440bdee9b13e38", nonce: "38", blockHash: "0x40e3ab4559f8f34785399148a42f996a71667f8b050e21046fef0fdaccd1052d", transactionIndex: "77", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "179940", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6792080", gasUsed: "119960", confirmations: "959336"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542875134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "4"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750599", timeStamp: "1542875151", hash: "0x781cf332720b2d73de31c41a726d7451c7bb6305829d7867100fba053a95ee80", nonce: "5", blockHash: "0x9d3697b4a45d755b5d73a1b1b5232ac936bfb636e3e3c346d30e81ca82cadbee", transactionIndex: "68", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "180861", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7579183", gasUsed: "120267", confirmations: "959334"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542875151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "5"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750601", timeStamp: "1542875162", hash: "0xff8e94ed910b22578b777e7702e2a875e0790f0d19fa461faaf969d94af0268c", nonce: "39", blockHash: "0xd97873a23c0e193ceba97fb76885cd9f573465450ad83ea1fbf5c37354ea26dc", transactionIndex: "51", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "180400", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7439386", gasUsed: "120574", confirmations: "959332"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542875162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "6"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123457\" )", async function( ) {
		const txOriginal = {blockNumber: "6750609", timeStamp: "1542875258", hash: "0xa025a56526f56cc2a1f5f8f42315127f25152304458dd01d703aced8d7be1e1d", nonce: "40", blockHash: "0x102659a02fd81e8db2f9134b7fbd14daa7c5ef5dad6dbb40e92d9a8a8f90be03", transactionIndex: "143", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e241", contractAddress: "", cumulativeGasUsed: "7123358", gasUsed: "21630", confirmations: "959324"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123457"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542875258 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"6\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750616", timeStamp: "1542875361", hash: "0x271f9d75bb8523bee2136b5324f1b134f1948f6eb1b21203689f3ec30f8e4e6d", nonce: "6", blockHash: "0xb3bb6cd87edada52f9230bc1a6caeba1696acb9a7cdd7e148038d1ddd77b1532", transactionIndex: "75", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7153427", gasUsed: "133444", confirmations: "959317"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "6"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "6", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542875361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "6"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542875481"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123458\" )", async function( ) {
		const txOriginal = {blockNumber: "6750616", timeStamp: "1542875361", hash: "0xdcf0c9a73bfdb07a60724bac40586d4064e61a1c589384b31c2506b0a4b95d5d", nonce: "7", blockHash: "0xb3bb6cd87edada52f9230bc1a6caeba1696acb9a7cdd7e148038d1ddd77b1532", transactionIndex: "76", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e242", contractAddress: "", cumulativeGasUsed: "7175057", gasUsed: "21630", confirmations: "959317"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123458"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123458", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542875361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2887aa1422766374e3e7b81102ec28d85436... )", async function( ) {
		const txOriginal = {blockNumber: "6750627", timeStamp: "1542875541", hash: "0x6bebea86040f658bb738dfe9e17597f266a1930eda32e9c3dba3def752bc5cea", nonce: "2789", blockHash: "0x985a75da39a6a8432e5266f7759634192ca2e65d970d5510f98418e3a4a48d87", transactionIndex: "115", from: "0x00004242f7b5c47ae90eaf0f1c2dddf630774c80", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e2887aa1422766374e3e7b81102ec28d854363fa49b66300b47e5ccd8f712c95300000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003337c330000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4632057", gasUsed: "83715", confirmations: "959306"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x2887aa1422766374e3e7b81102ec28d854363fa49b66300b47e5ccd8f712c953"}, {type: "string", name: "result", value: `3|3`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x2887aa1422766374e3e7b81102ec28d854363fa49b66300b47e5ccd8f712c953", `3|3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542875541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "6"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "123458"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "3"}, {name: "_diceB", type: "uint8", value: "3"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "787187580000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123457\" )", async function( ) {
		const txOriginal = {blockNumber: "6750645", timeStamp: "1542875702", hash: "0x2109a1f4f14b96d780400984436ed0bbdfc4ff135c10cb436cb4e87d19486420", nonce: "41", blockHash: "0x06f334a2f75e73a73bdd30a76b5beddd7e1c7d1e93129ab1cb9b3bda0a3aa4e4", transactionIndex: "114", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e241", contractAddress: "", cumulativeGasUsed: "7844206", gasUsed: "21630", confirmations: "959288"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123457"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542875702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"5\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750649", timeStamp: "1542875747", hash: "0xa6a4e1a8b92864a4bbf65051188fb477de1fbf0052c78eacbf4522319fe2d90a", nonce: "42", blockHash: "0x2ce5b9a8f73cc89fc6452ca260abf1fd3631e766160cad65b0ff189e20b45e80", transactionIndex: "85", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6214420", gasUsed: "133444", confirmations: "959284"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "5"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "5", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542875747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "5"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542875867"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750649", timeStamp: "1542875747", hash: "0xca57ab44bda3d3e816b71738c3d52726e8a103236f539d1d9bf9ba071c42c121", nonce: "8", blockHash: "0x2ce5b9a8f73cc89fc6452ca260abf1fd3631e766160cad65b0ff189e20b45e80", transactionIndex: "99", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7610620", gasUsed: "133444", confirmations: "959284"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "4"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542875747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "4"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542875867"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750651", timeStamp: "1542875766", hash: "0x443f8e4d4f274e54bf0ea148bcbcca81e5971a6d66beb12e3539c48132b8ac03", nonce: "9", blockHash: "0xaa636fe2b5f020ce094ab527f22953834c7a353d42e31e0e2a063d41ccdeab03", transactionIndex: "151", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7012751", gasUsed: "121138", confirmations: "959282"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "4"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542875766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0e540542622f7386686a57cb287f1d1ca289bc15"}, {name: "_tableId", type: "uint256", value: "7"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"7\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750662", timeStamp: "1542875853", hash: "0x25d07f1ed5f74ad043c138c39568c477de96e082a4f811a44c4fec4141b48969", nonce: "43", blockHash: "0x6d96e75d4db832b28c596f8ad803913875438aa563686e9778fd1747b84f6dcc", transactionIndex: "73", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7437515", gasUsed: "133444", confirmations: "959271"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "7"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "7", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542875853 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "7"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542875973"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x438c3bf64033897d784ade85f8fa13a745ec... )", async function( ) {
		const txOriginal = {blockNumber: "6750664", timeStamp: "1542875908", hash: "0xae886c05e3ce4de933c21333d0d3fa5b7ef1b25e6ee35c0ab5f0d985cd66bc33", nonce: "2809", blockHash: "0xbcb342740e12e6b869608abca57140556147eabf96fcd7a96bd6920783b1e2aa", transactionIndex: "36", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e438c3bf64033897d784ade85f8fa13a745ec031c455768cde3c39a16ba9e5c4100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003327c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1141663", gasUsed: "60309", confirmations: "959269"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x438c3bf64033897d784ade85f8fa13a745ec031c455768cde3c39a16ba9e5c41"}, {type: "string", name: "result", value: `2|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x438c3bf64033897d784ade85f8fa13a745ec031c455768cde3c39a16ba9e5c41", `2|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542875908 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "5"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123458"}, {name: "pos2", type: "uint256", value: "123457"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "2"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xc201bfc019355fd32b0ce10b45da696c7c76... )", async function( ) {
		const txOriginal = {blockNumber: "6750664", timeStamp: "1542875908", hash: "0xadad995b42c46bdbf977c4e4c3f326d72cf80f4c35f555cfdcf75c45e68689f8", nonce: "2790", blockHash: "0xbcb342740e12e6b869608abca57140556147eabf96fcd7a96bd6920783b1e2aa", transactionIndex: "37", from: "0x00004242f7b5c47ae90eaf0f1c2dddf630774c80", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ec201bfc019355fd32b0ce10b45da696c7c765a9481f1d7d488b4aa15293a758b00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003347c350000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1186972", gasUsed: "45309", confirmations: "959269"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xc201bfc019355fd32b0ce10b45da696c7c765a9481f1d7d488b4aa15293a758b"}, {type: "string", name: "result", value: `4|5`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xc201bfc019355fd32b0ce10b45da696c7c765a9481f1d7d488b4aa15293a758b", `4|5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542875908 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "4"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123458"}, {name: "pos2", type: "uint256", value: "123457"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "4"}, {name: "_diceB", type: "uint8", value: "5"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "787187580000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x98c4d20c5961e98775eed14464a5c0950ca8... )", async function( ) {
		const txOriginal = {blockNumber: "6750670", timeStamp: "1542876105", hash: "0xdbf38cfbef88e3e1a0ff15e7f2cb1db5b911b38a6ffcae353cc19ac7ca2f8158", nonce: "2810", blockHash: "0x3d4bdc8af99c5636bad5d98b8c6ad6770cf8062cb175fd43f847b146683d2246", transactionIndex: "139", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e98c4d20c5961e98775eed14464a5c0950ca8f009792dbf1cca2630876a2aa66500000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003367c340000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6547983", gasUsed: "45043", confirmations: "959263"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x98c4d20c5961e98775eed14464a5c0950ca8f009792dbf1cca2630876a2aa665"}, {type: "string", name: "result", value: `6|4`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x98c4d20c5961e98775eed14464a5c0950ca8f009792dbf1cca2630876a2aa665", `6|4`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542876105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "7"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123458"}, {name: "pos2", type: "uint256", value: "123457"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "6"}, {name: "_diceB", type: "uint8", value: "4"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750783", timeStamp: "1542877745", hash: "0x0ea3c4ac5d37c62c4f8d3d8cb09dc47e47570bfea04ed355137233d0f4858607", nonce: "0", blockHash: "0x138c734bc96bbf8821c0aab72220e736472820b7aee8098e41f421b282e78a3e", transactionIndex: "102", from: "0xf86567235e3acd1856daf7fa54cce09041ae026d", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "316027", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5888592", gasUsed: "210685", confirmations: "959150"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542877745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xf86567235e3acd1856daf7fa54cce09041ae026d"}, {name: "_tableId", type: "uint256", value: "8"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "255857784700000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750832", timeStamp: "1542878432", hash: "0x74f3f73e1d3289e5806436043b4f6bce2ed32b8de19c53faf5e471966f1ae754", nonce: "17", blockHash: "0xfa8707605e49fb51b34179d7cf5b75d4ba6dde9ba4666be4bfb00eb3ecfe164a", transactionIndex: "137", from: "0x0d54b2278362d194815d1b0eb683033946fb4eb9", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "316027", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7701843", gasUsed: "210992", confirmations: "959101"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542878432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0d54b2278362d194815d1b0eb683033946fb4eb9"}, {name: "_tableId", type: "uint256", value: "9"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "64492057000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"7\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6750834", timeStamp: "1542878444", hash: "0xa92e223e7dcc4f30733a8e21b7fa8434b5f6f902c4477e8bbd778530d7373476", nonce: "44", blockHash: "0xd0418d94d4fc3fda5e7a3f602c61c16a2fbd3fa8e9cb6f98698525218002b565", transactionIndex: "60", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7650138", gasUsed: "121138", confirmations: "959099"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "7"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "7", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542878444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "10"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750855", timeStamp: "1542878745", hash: "0x9edd920c6b1ec2ef77af17dec04c052ae31a538d6bf1f203680f8bbe7071f4a6", nonce: "45", blockHash: "0x1dc3496529006a4c51f9b1318a0c2e4ad253ff9507936da2cdd938cb78ac0d60", transactionIndex: "110", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "179940", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7836721", gasUsed: "120881", confirmations: "959078"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542878745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "11"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6750894", timeStamp: "1542879329", hash: "0xd9c7b8feb78458af4fa8cd6169f082e90ed34f1d6f8b4b478c7a711f5776f21b", nonce: "18", blockHash: "0xabe9cc0a29bf1a48d4e22abd73a5fd69b617f6f0e4c28b6a574dbdc6858208c0", transactionIndex: "74", from: "0x0d54b2278362d194815d1b0eb683033946fb4eb9", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "316027", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7643898", gasUsed: "121188", confirmations: "959039"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542879329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0d54b2278362d194815d1b0eb683033946fb4eb9"}, {name: "_tableId", type: "uint256", value: "12"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "64492057000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"8\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6750895", timeStamp: "1542879332", hash: "0xe532455c998efb04c250af3503d81a6eeb73eb08561feceb3c8f26406add51d9", nonce: "19", blockHash: "0x134050d81293889cf46bc48ebe2b11fc6acad2f04ef60c62cb908cf736357d7e", transactionIndex: "56", from: "0x0d54b2278362d194815d1b0eb683033946fb4eb9", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "20000000000000000", gas: "200641", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2816864", gasUsed: "133761", confirmations: "959038"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "8"}, {type: "uint8", name: "_position", value: "3"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "8", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542879332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x0d54b2278362d194815d1b0eb683033946fb4eb9"}, {name: "_tableId", type: "uint256", value: "8"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_position", type: "uint8", value: "3"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "3"}, {name: "_endTime", type: "uint256", value: "1542879452"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "64492057000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xcc7caf2c352ceb4c4a57b043c009ad29e4e9... )", async function( ) {
		const txOriginal = {blockNumber: "6750906", timeStamp: "1542879484", hash: "0x8ce1a895d9d0b79ddabf0f59f04562c73316bbb080de6bd889af1ba63dfea0eb", nonce: "2923", blockHash: "0xc1315617a9f429a09c7c468fab299da48bc4c8d8312525932634b981c77d54f4", transactionIndex: "51", from: "0x000042420e7913cefee6988cf825c4a2b739684d", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ecc7caf2c352ceb4c4a57b043c009ad29e4e9f2171fcc2a5cad5bbe2b5ef636a100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003317c330000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1987691", gasUsed: "84114", confirmations: "959027"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xcc7caf2c352ceb4c4a57b043c009ad29e4e9f2171fcc2a5cad5bbe2b5ef636a1"}, {type: "string", name: "result", value: `1|3`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xcc7caf2c352ceb4c4a57b043c009ad29e4e9f2171fcc2a5cad5bbe2b5ef636a1", `1|3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542879484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "8"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123459"}, {name: "pos2", type: "uint256", value: "0"}, {name: "pos3", type: "uint256", value: "123460"}, {name: "_position", type: "uint8", value: "3"}, {name: "_diceA", type: "uint8", value: "1"}, {name: "_diceB", type: "uint8", value: "3"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "742180600000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6751852", timeStamp: "1542892447", hash: "0xaec864aad59ff0ffaef0b30f3dcd8a1a17c02382d8cc4dc703f6649750720a94", nonce: "46", blockHash: "0x0116f80eae8926d9b7e4b1f98b97e5c66770e7652b92d6cac1ff22771dc939d7", transactionIndex: "107", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "179940", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5308419", gasUsed: "119960", confirmations: "958081"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542892447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "13"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123457\" )", async function( ) {
		const txOriginal = {blockNumber: "6751852", timeStamp: "1542892447", hash: "0x49c32c1b856a085db9cb16d9b57debd7dab3c8f0e76f429e9c10d233c954b523", nonce: "47", blockHash: "0x0116f80eae8926d9b7e4b1f98b97e5c66770e7652b92d6cac1ff22771dc939d7", transactionIndex: "108", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e241", contractAddress: "", cumulativeGasUsed: "5330049", gasUsed: "21630", confirmations: "958081"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123457"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542892447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123457\" )", async function( ) {
		const txOriginal = {blockNumber: "6751858", timeStamp: "1542892528", hash: "0x632fb7a8706cfaa7bb4670c0f15a74d7d0f23f522fe2701fc7a0cf0af6089e60", nonce: "50", blockHash: "0xb1c17f60a10fd031e8f78738af4b3c113013c91ad666e9336958da255ad6d869", transactionIndex: "127", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e241", contractAddress: "", cumulativeGasUsed: "6785756", gasUsed: "23708", confirmations: "958075"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123457"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542892528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"9\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6757006", timeStamp: "1542965388", hash: "0x075928bbc1989ef0f538133dc0f5562a072a5f724481805dafb73cd553ac2492", nonce: "0", blockHash: "0x1e9076311c489f59340a2fe39c645d1951aa961bf147a539b0c337531d6619c7", transactionIndex: "108", from: "0x9dfa08cb7111e2cb4e5b7194485d4d7460adca72", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "336253", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6370257", gasUsed: "224169", confirmations: "952927"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "9"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "9", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542965388 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x9dfa08cb7111e2cb4e5b7194485d4d7460adca72"}, {name: "_tableId", type: "uint256", value: "9"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1542965508"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "213489994440827238" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4782e3b759f10e3fbbf7bb0f2ca6f4ceed6f... )", async function( ) {
		const txOriginal = {blockNumber: "6757023", timeStamp: "1542965550", hash: "0xb7fe797afa3f8be2fe012fa7b85ffcdb8f049897b308e4af62b61de4aac7b3a3", nonce: "2821", blockHash: "0x8351bd0d102c967236362be9c05641f0235ebe707ba48d488ff4a9bc4af58eb8", transactionIndex: "49", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e4782e3b759f10e3fbbf7bb0f2ca6f4ceed6f6c64859db8bbbc60a1be900f21e400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003367c340000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2724835", gasUsed: "75043", confirmations: "952910"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4782e3b759f10e3fbbf7bb0f2ca6f4ceed6f6c64859db8bbbc60a1be900f21e4"}, {type: "string", name: "result", value: `6|4`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x4782e3b759f10e3fbbf7bb0f2ca6f4ceed6f6c64859db8bbbc60a1be900f21e4", `6|4`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542965550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "9"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123461"}, {name: "pos2", type: "uint256", value: "123460"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "6"}, {name: "_diceB", type: "uint8", value: "4"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"12\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6808145", timeStamp: "1543692350", hash: "0x04e96762ef049b372b38b02d521a1b402e378f4c9616cc34d361b700feb0f421", nonce: "4543", blockHash: "0xb948e8dd305c3a8a3af268bf8a7d0f50860e60af140b913642ecb89ef686431f", transactionIndex: "72", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "336253", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4567509", gasUsed: "224169", confirmations: "901788"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "12"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "12", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543692350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x2fe8e10633eae71b503c60180c4190710a132237"}, {name: "_tableId", type: "uint256", value: "12"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1543692470"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x86fe5568332f18253327d49d797065416a68... )", async function( ) {
		const txOriginal = {blockNumber: "6808158", timeStamp: "1543692502", hash: "0x57f0ea81ec65cbff054d980e1f395ba0d93479761e64553daba5c1b8c5af2523", nonce: "2915", blockHash: "0x46ac09f360d5e2ee81ded30aac09669358a23f3b0e72f06e7c3763a4062b4830", transactionIndex: "14", from: "0x00004242f7b5c47ae90eaf0f1c2dddf630774c80", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e86fe5568332f18253327d49d797065416a687d8405549218ffad6f40725a9d8500000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003337c350000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1178355", gasUsed: "60309", confirmations: "901775"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x86fe5568332f18253327d49d797065416a687d8405549218ffad6f40725a9d85"}, {type: "string", name: "result", value: `3|5`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x86fe5568332f18253327d49d797065416a687d8405549218ffad6f40725a9d85", `3|5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543692502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "12"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123460"}, {name: "pos2", type: "uint256", value: "123462"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "3"}, {name: "_diceB", type: "uint8", value: "5"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "787187580000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"11\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6809917", timeStamp: "1543717514", hash: "0x03b37ef2d19c1672e8eee3a58e6482ddde6ace8cd0d5ed18bd178b5a1ee38b8c", nonce: "4544", blockHash: "0xa2fd0846be5f35758a8071671462a2e795ce126bd7a62b84a899b49da3bc322a", transactionIndex: "177", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6749258", gasUsed: "133444", confirmations: "900016"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "11"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "11", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543717514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x2fe8e10633eae71b503c60180c4190710a132237"}, {name: "_tableId", type: "uint256", value: "11"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1543717634"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"13\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6809919", timeStamp: "1543717535", hash: "0x8b379522ee649337139ea4b1bc25d33048e34719bc56c3e0b7370bffe5a5690a", nonce: "4545", blockHash: "0xe7039192639cf10c2f118ac6746f29e816a1678405cd6c00311dc671b0ee3b20", transactionIndex: "185", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4417466", gasUsed: "133444", confirmations: "900014"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "13"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "13", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543717535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x2fe8e10633eae71b503c60180c4190710a132237"}, {name: "_tableId", type: "uint256", value: "13"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1543717655"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa7863df3208054156013d2f64349ebaf8ae3... )", async function( ) {
		const txOriginal = {blockNumber: "6809934", timeStamp: "1543717872", hash: "0xf4b47d2c3ced43dd0218a4cd9090303c4c739a9d46f0e06ad749068604682ca3", nonce: "2897", blockHash: "0x3486ee8999c23cae84225939273bffe880c0d92f4c32bc2db177f03aa5edb28c", transactionIndex: "78", from: "0x000042427b681ccf127a5112923322629183b109", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ea7863df3208054156013d2f64349ebaf8ae3981f98c5725eecd5e83da939164200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003327c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4601007", gasUsed: "45309", confirmations: "899999"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa7863df3208054156013d2f64349ebaf8ae3981f98c5725eecd5e83da9391642"}, {type: "string", name: "result", value: `2|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xa7863df3208054156013d2f64349ebaf8ae3981f98c5725eecd5e83da9391642", `2|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543717872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "11"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "123462"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "2"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691289660000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9e7851691c6764aa2cdd8072b7e069015822... )", async function( ) {
		const txOriginal = {blockNumber: "6809947", timeStamp: "1543717964", hash: "0x3a03dcb3d2d6dabc913fe74449997c9e78a6f27bc5de1571d737d1b80b9de3f2", nonce: "3007", blockHash: "0x4a0be21019426108bcff2a1a08951f6a58a9b0790a205995acc3d6cc2332b765", transactionIndex: "28", from: "0x000042420e7913cefee6988cf825c4a2b739684d", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e9e7851691c6764aa2cdd8072b7e069015822d805c8bf5eee278b288eedba85a600000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003367c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1744710", gasUsed: "53715", confirmations: "899986"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x9e7851691c6764aa2cdd8072b7e069015822d805c8bf5eee278b288eedba85a6"}, {type: "string", name: "result", value: `6|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x9e7851691c6764aa2cdd8072b7e069015822d805c8bf5eee278b288eedba85a6", `6|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543717964 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "13"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123457"}, {name: "pos2", type: "uint256", value: "123462"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "6"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "742180600000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"10\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6809968", timeStamp: "1543718206", hash: "0xe0ba8ff8c8c7df6e23fcd8954febfd892667b54f794c762b4057d11d5b76b185", nonce: "4548", blockHash: "0x268e59654a5a40d07238d6180716d65e5e017850dccee32ee0276de583bc43c0", transactionIndex: "84", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3568271", gasUsed: "133444", confirmations: "899965"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "10"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "10", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543718206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x2fe8e10633eae71b503c60180c4190710a132237"}, {name: "_tableId", type: "uint256", value: "10"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1543718326"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xebaa608daa43d67890aff3026aa45028e635... )", async function( ) {
		const txOriginal = {blockNumber: "6809988", timeStamp: "1543718435", hash: "0x195885e502d3734cb929b1c614b22a307faf6e034d77c298bb4617657ecf7069", nonce: "2916", blockHash: "0xed2e3e39a52def49eb39fde622e638c2b6e6a3443b9f33a9634ffcb983c1bf5e", transactionIndex: "115", from: "0x00004242f7b5c47ae90eaf0f1c2dddf630774c80", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "150000", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x27dc297eebaa608daa43d67890aff3026aa45028e635580ac429b278a449205066940aec00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000003317c360000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3449032", gasUsed: "45309", confirmations: "899945"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xebaa608daa43d67890aff3026aa45028e635580ac429b278a449205066940aec"}, {type: "string", name: "result", value: `1|6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xebaa608daa43d67890aff3026aa45028e635580ac429b278a449205066940aec", `1|6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543718435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "pos1", type: "uint256"}, {indexed: true, name: "pos2", type: "uint256"}, {indexed: true, name: "pos3", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: false, name: "_diceA", type: "uint8"}, {indexed: false, name: "_diceB", type: "uint8"}], name: "Finish", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Finish", events: [{name: "_tableId", type: "uint256", value: "10"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "pos1", type: "uint256", value: "123462"}, {name: "pos2", type: "uint256", value: "123457"}, {name: "pos3", type: "uint256", value: "0"}, {name: "_position", type: "uint8", value: "1"}, {name: "_diceA", type: "uint8", value: "1"}, {name: "_diceB", type: "uint8", value: "6"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "787187580000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123462\" )", async function( ) {
		const txOriginal = {blockNumber: "6810023", timeStamp: "1543719102", hash: "0xeff95f54be41937561cbc4a758b7bf2324e061238147c90c3e5ffff028061049", nonce: "4551", blockHash: "0x9047b0aa55cfc18071dbbc5941299420d2f586e9779e8cc3591cd59f35e138a3", transactionIndex: "91", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e246", contractAddress: "", cumulativeGasUsed: "6132856", gasUsed: "21630", confirmations: "899910"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123462"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123462", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543719102 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123458\" )", async function( ) {
		const txOriginal = {blockNumber: "6810971", timeStamp: "1543732748", hash: "0x9ba68d2ab396b9e62d8fd687d1fbf93645f14338a963a03379aa418d443ed1f2", nonce: "11", blockHash: "0xcf5903472363c11e01bb77cdbd276ea0a916a7021d2dd4ae5b1f8ad8af10a4a0", transactionIndex: "54", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e242", contractAddress: "", cumulativeGasUsed: "7614434", gasUsed: "21630", confirmations: "898962"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123458"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123458", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543732748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"123458\" )", async function( ) {
		const txOriginal = {blockNumber: "6810973", timeStamp: "1543732763", hash: "0xa1ab706321388efd331bd94ae6a867575fba155f00fae99d2792df72d7576172", nonce: "12", blockHash: "0x951fe7355883608425c75531391e3b9baeef444f65c1dc0616baa9ea7c9db935", transactionIndex: "84", from: "0x0e540542622f7386686a57cb287f1d1ca289bc15", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "0", gas: "58315", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x2e1a7d4d000000000000000000000000000000000000000000000000000000000001e242", contractAddress: "", cumulativeGasUsed: "7237153", gasUsed: "23708", confirmations: "898960"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pid", value: "123458"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "123458", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543732763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "217154822000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6817935", timeStamp: "1543832565", hash: "0x381229a07627e19304593f5276d4a5c9156393c6e426890dc8e3d02ffb8e5819", nonce: "143", blockHash: "0x7fa791f6ca46f8b63e3e265cf701dd2e9bf627a3cb0d866ca0b8f83ee668cab0", transactionIndex: "100", from: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "179940", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6582502", gasUsed: "119960", confirmations: "891998"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "0"}, {type: "uint8", name: "_position", value: "1"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543832565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0xd5ef5a7cc2270361bf5c7aa02e910602c9a3f9e2"}, {name: "_tableId", type: "uint256", value: "14"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "1"}, {name: "_status", type: "uint8", value: "1"}, {name: "_posStatus", type: "uint8", value: "0"}, {name: "_endTime", type: "uint256", value: "0"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1132576669005184600" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"14\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6819506", timeStamp: "1543855205", hash: "0xd58765d4619797362bca9fde55cf1c17be148f2ab73a58ec15cbb0f5bc3e3837", nonce: "4580", blockHash: "0x275042cff78b2fb72aeefec4741da6e39e63c64c67c34838b71d92f0bf4decb2", transactionIndex: "39", from: "0x2fe8e10633eae71b503c60180c4190710a132237", to: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7", value: "60000000000000000", gas: "200166", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xc437a0cd000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2614615", gasUsed: "133444", confirmations: "890427"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tableId", value: "14"}, {type: "uint8", name: "_position", value: "2"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint8)" ]( "14", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543855205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_addr", type: "address"}, {indexed: false, name: "_tableId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_position", type: "uint8"}, {indexed: true, name: "_status", type: "uint8"}, {indexed: false, name: "_posStatus", type: "uint8"}, {indexed: false, name: "_endTime", type: "uint256"}], name: "Bet", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Bet", events: [{name: "_addr", type: "address", value: "0x2fe8e10633eae71b503c60180c4190710a132237"}, {name: "_tableId", type: "uint256", value: "14"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_position", type: "uint8", value: "2"}, {name: "_status", type: "uint8", value: "2"}, {name: "_posStatus", type: "uint8", value: "1"}, {name: "_endTime", type: "uint256", value: "1543855325"}], address: "0x1d1112a2b7ea8e75a2f2b121d6e7c0f958a11fa7"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "425685834984611543" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "565200414254820180" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
