ganache-cli -p 9545 -a 1000 -e 1000000 -d -l 10000000 -t "2017-04-18T13:45:16.000Z" >ganache.log&
Pid=$!
sleep 10
truffle test 2>replay.js
kill $Pid
node replay.js
# node mutasol.js -f GnosisToken.sol -o 1 -m 50 -n 500 -v 0.4.10
