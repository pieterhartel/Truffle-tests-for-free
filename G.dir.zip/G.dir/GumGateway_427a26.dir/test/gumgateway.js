const GumGateway = artifacts.require( "./GumGateway.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "GumGateway" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xa30CBce69f520bF2A34c5C15193B7f5AfE427A26", "0xe7aF11370C3BaB51230D8307454350bDf6d68f4a", "0xC3A9B48b0DD3e57B895BF99E4eaFA9291267Cb38", "0x37D0692B70f45CCe8734dCFf16ce85C1a389c157", "0x81d661b2b5865ECb0E331463483055215e624997", "0x7E1DCf785f0353BF657c38Ab7865C1f184EFE208", "0xc5BcFc66e795878539b32eBEF0dc9F9E53D29e2B", "0xB1f72E1a73667aC9b600685539040A48bf5F2d3B", "0x0537544De3935408246EE2Ad09949D046F92574D", "0x078dA415709285050cd9d683e08f395143256ba8", "0xd5e4868B51439ac87279B0d0117B7E2f36475058", "0x8C5fC43ad00Cc53e11F61bEce329DDc5E3ea0929", "0xD3A22d084dD16196b7862BC2D309412B508318fB", "0x1693Ae817e424C2dbC4138313B7B46c91Bb968f4", "0x5C5aaf9E86bD9a2732Fb351add176c7C6A21CBdF", "0x7Ae0048bB33650EDb349F6fC65fD23A39430E752", "0x62b8B7B7Af7CB5847Dd7335e0B6B4229CD1B7d48", "0xB130168eC63Ca7e30A8f8C7268aA56E4d6730Fb5", "0x981E6097e2bdffEFe1b0D09777c3422bB6bB24C8", "0x96080155dD976e98305fa9aEa96834A03ABDA864", "0x5840fEaAa7D7657C1A2F4c724928DdaC62A743B3", "0xF58d0e6fc3C021627A49A53f04152409fcc40055", "0xd868711BD9a2C6F1548F5f4737f71DA67d821090", "0x3c11e8922bC793d2fbd7E3e454241c587AE42010", "0x583780EEBaB14b8f7082c6b2e7ddCfA60B1A7C29", "0x05eCC0958eeE0aCBe1BB2E9aae847466c20EAc47", "0x6Efd9BF1c87A2946aceA38043DC9a4C03ADE8B7f", "0x8bCc48f937a6E076EC25838436Fa6118f0c153d2", "0xae015ccDE814DA988dbcA7f09c10F7c25D6931c3", "0x7da610dC64179389591D04c602CC58F5c82725F4", "0x9a080c9dA2c3e92d4B97a373f73b0a994274eDc3", "0xCD6fB0F2bf2476E43219E5616709Adc58360A8Da", "0x5b8c29115EFC3A70b154960740cE7a6956F3A45A", "0xBac047C74C4d0a3Da65FA4696e12F6c66435c9b1", "0x9F1BeE52A02890fEC054D35476efA97AC4870703", "0x18D43eC07223DB80B8Ca960bF1D09c97434f46AE", "0x9884f51c93CD4C3e0071B3C507c3da8dA002A669", "0x04eC67264c8eae2847C5f3DA0813638797AaB47C", "0xd084ec3B6F1fcAE73Fb8668ED4b99614fc7c39d3", "0x9e315E9701908501f6dC68A2af6e28a20C75d970", "0x40c9afd96646dF172b6fA31211Fb51bf5144081e"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getNumberOfAddresses", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isPauser", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getEthBackRate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isOperator", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "sender", type: "address"}], name: "isInTerm", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "term", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimumAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_account", type: "address"}], name: "isReferrer", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint32"}], name: "addressOfIndex", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "latestActionTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "at", type: "uint256"}], name: "Action", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "term", type: "uint256"}], name: "UpdateTerm", type: "event"}, {anonymous: false, inputs: [], name: "Paused", type: "event"}, {anonymous: false, inputs: [], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "OperatorAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "OperatorRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Sold(address,address,uint256,uint256)", "Action(address,address,uint256)", "UpdateTerm(uint256)", "Paused()", "Unpaused()", "PauserAdded(address)", "PauserRemoved(address)", "ReferrerAdded(address)", "ReferrerRemoved(address)", "OperatorAdded(address)", "OperatorRemoved(address)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x16dd16959a056953a63cf14bf427881e762e54f03d86b864efea8238dd3b822f", "0x03bee8945a564e58a4243604a426d1168e3654790c5ad819fd04206500e60b36", "0x42abe072cac69cb13b03255cb2c26297e10970937da5386e8f1ae78c21d2f01c", "0x9e87fac88ff661f02d44f95383c817fece4bce600a3dab7a54406878b965e752", "0xa45f47fdea8a1efdd9029a5691c7f759c32b7c698632b563573e155625d16933", "0x6719d08c1888103bea251a4ed56406bd0c3e69723c8a1686e017e7bbe159b6f8", "0xcd265ebaf09df2871cc7bd4133404a235ba12eff2041bb89d9c714a2621c7c7e", "0x51e6bb66cce1aac9478cbafcad3421bf2a600ce8ec3874296c671ab32c68ce92", "0x68e673b5cfb652e620fba208d02d6b172a0dc242d4497d94a1f92bb5fa92bc31", "0xac6fa858e9350a46cec16539926e0fde25b7629f84b5a72bffaae4df888ae86d", "0x80c0b871b97b595b16a7741c1b06fed0c6f6f558639f18ccbce50724325dc40d", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6858505 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6865686 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "GumGateway", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getNumberOfAddresses", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumberOfAddresses()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isPauser", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPauser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getEthBackRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEthBackRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isOperator", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOperator(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isInTerm", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isInTerm(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "term", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "term()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isReferrer", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isReferrer(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "_index", value: random.range( maxRandom )}], name: "addressOfIndex", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressOfIndex(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "latestActionTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "latestActionTime(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "GumGateway", function( accounts ) {

	it( "TEST: GumGateway(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6858505", blockHash: "0x68c4d5627ee887b5850766a67eb542d63a12ef5d64359a5354c0127c4d875805", timeStamp: "1544412203", hash: "0x9f7360d23b48d934ef083ea7ac74082c3dbb6a27d6eab790c53514c2ba340dca", nonce: "118", transactionIndex: "83", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: 0, value: "0", gas: "1843623", gasPrice: "5000000000", input: "0xa0034f2a", contractAddress: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", cumulativeGasUsed: "5002836", txreceipt_status: "1", gasUsed: "1843623", confirmations: "822046", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "GumGateway", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = GumGateway.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544412203 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = GumGateway.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addOperator( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6858515", blockHash: "0xf20ff4a8d09718a186fa8c3dae7273a609882fe76bed23e5d7a6e8b2b7c4cbb0", timeStamp: "1544412393", hash: "0x1387c18d22465c892ff59e30e8f3990302715b37b732ec2e575e9e2be86c5622", nonce: "119", transactionIndex: "150", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "45201", gasPrice: "3000000000", input: "0x9870d7fe000000000000000000000000c3a9b48b0dd3e57b895bf99e4eafa9291267cb38", contractAddress: "", cumulativeGasUsed: "7873169", txreceipt_status: "1", gasUsed: "45201", confirmations: "822036", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[4]}], name: "addOperator", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOperator(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544412393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "OperatorAdded", type: "event"} ;
		console.error( "eventCallOriginal[1,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OperatorAdded", events: [{name: "account", type: "address", value: "0xc3a9b48b0dd3e57b895bf99e4eafa9291267cb38"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[1,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: updateEthBackRate( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6858520", blockHash: "0x41c1f3a5b33d42227f3a75fb8704753d89d25d1c9756acd6778060e4326f4b42", timeStamp: "1544412471", hash: "0x41c40452c3d9250bfa90f2dce966242ccb16b950fa2171b48633bd4e60233875", nonce: "120", transactionIndex: "147", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "42244", gasPrice: "5000000000", input: "0x7b049a460000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "7883365", txreceipt_status: "1", gasUsed: "42244", confirmations: "822031", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_newEthBackRate", value: "20"}], name: "updateEthBackRate", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEthBackRate(uint256)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544412471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addOperator( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6860941", blockHash: "0xf838a6e4c0c0c713e60d7649acffe2cf0bd4e6f27a3220613eb6e21e73b48ef4", timeStamp: "1544446612", hash: "0xd4daf43967d3a14aa4846c9cef8e6ddb8dc56929529ab493d012a3e3edef1c20", nonce: "146", transactionIndex: "106", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "45201", gasPrice: "9000000000", input: "0x9870d7fe00000000000000000000000037d0692b70f45cce8734dcff16ce85c1a389c157", contractAddress: "", cumulativeGasUsed: "6748821", txreceipt_status: "1", gasUsed: "45201", confirmations: "819610", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[5]}], name: "addOperator", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOperator(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544446612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "OperatorAdded", type: "event"} ;
		console.error( "eventCallOriginal[3,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OperatorAdded", events: [{name: "account", type: "address", value: "0x37d0692b70f45cce8734dcff16ce85c1a389c157"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[3,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6864508", blockHash: "0x22ba2a1dd131f9bbd4f402f9231746c6a094f4badd0a60556a41c26d7a436106", timeStamp: "1544496732", hash: "0x3e21840bafb92675775f88c37ee1ad9c6a81edd10cc5391decfc9b62b9fed54b", nonce: "91", transactionIndex: "106", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "5000000000", input: "0xfefa9bb100000000000000000000000081d661b2b5865ecb0e331463483055215e624997", contractAddress: "", cumulativeGasUsed: "6039493", txreceipt_status: "1", gasUsed: "92329", confirmations: "816043", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[6]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544496732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[4,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x81d661b2b5865ecb0e331463483055215e624997"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[4,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6864514", blockHash: "0x5c896ecd771e6710678c8a64b2a61dc8bf4174d810771229c18c4089352feb70", timeStamp: "1544496789", hash: "0xc1d6c62d34592f0823473b5a8493323c46fedd38ecbec08c26e179b3892541a7", nonce: "92", transactionIndex: "58", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "5000000000", input: "0xfefa9bb10000000000000000000000007e1dcf785f0353bf657c38ab7865c1f184efe208", contractAddress: "", cumulativeGasUsed: "2459642", txreceipt_status: "1", gasUsed: "92329", confirmations: "816037", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[7]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544496789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[5,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7e1dcf785f0353bf657c38ab7865c1f184efe208"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[5,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6864519", blockHash: "0x60d763a435034449f5ff4ba8de3a7b3466057b270e3c55715a9900e92e1bf68e", timeStamp: "1544496873", hash: "0x6afc912c853c1859412c7ba28609d9b5f1cdb73261513f7495a65d1e39a8211e", nonce: "93", transactionIndex: "92", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "5000000000", input: "0xfefa9bb1000000000000000000000000c5bcfc66e795878539b32ebef0dc9f9e53d29e2b", contractAddress: "", cumulativeGasUsed: "4542319", txreceipt_status: "1", gasUsed: "92329", confirmations: "816032", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[8]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544496873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[6,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xc5bcfc66e795878539b32ebef0dc9f9e53d29e2b"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[6,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6864523", blockHash: "0xf28da4d914e1b03a324e75cc2999c4d7c0f7b825dee90f9f82ca84d04e2d6cd7", timeStamp: "1544496926", hash: "0x562d59de1dd778aed898314a03d843e9c8ee383ad23a10f72a06d0f244d8d9ec", nonce: "94", transactionIndex: "105", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92265", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000b1f72e1a73667ac9b600685539040a48bf5f2d3b", contractAddress: "", cumulativeGasUsed: "5080397", txreceipt_status: "1", gasUsed: "92265", confirmations: "816028", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[9]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544496926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[7,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xb1f72e1a73667ac9b600685539040a48bf5f2d3b"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[7,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6864528", blockHash: "0x29ee965a23fa467dba07a1cbe214bdf6675b252e3a613fe18f6218bb7c06c143", timeStamp: "1544497006", hash: "0x289754d8a4e6ab81108c833bd5b0ce1c8d2f9a6f89073a7d2bcd01e6247fc29c", nonce: "95", transactionIndex: "42", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb10000000000000000000000000537544de3935408246ee2ad09949d046f92574d", contractAddress: "", cumulativeGasUsed: "4686617", txreceipt_status: "1", gasUsed: "92329", confirmations: "816023", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[10]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544497006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[8,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x0537544de3935408246ee2ad09949d046f92574d"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[8,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6864534", blockHash: "0x1c442ea70c5a9762e650313574ffcc3ca3b986ccbe3fb553e31bd47a5608ebed", timeStamp: "1544497145", hash: "0x6f3c704404ca8610f29d1c0ddc51720e0a2a57387df01b6d27800c56acd24f1b", nonce: "96", transactionIndex: "51", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000078da415709285050cd9d683e08f395143256ba8", contractAddress: "", cumulativeGasUsed: "1936957", txreceipt_status: "1", gasUsed: "92329", confirmations: "816017", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[11]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544497145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[9,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x078da415709285050cd9d683e08f395143256ba8"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[9,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6864540", blockHash: "0xd867b9e474328c0561db2cffe46b7ebf0bf47b9ef9aa6d7f82019cb0a4a2af03", timeStamp: "1544497213", hash: "0xe7fac2709f63065acf864211d9666e1409b491d5fc47a9e4d878545a3b201bc3", nonce: "97", transactionIndex: "122", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7000000000", input: "0xfefa9bb1000000000000000000000000d5e4868b51439ac87279b0d0117b7e2f36475058", contractAddress: "", cumulativeGasUsed: "7599586", txreceipt_status: "1", gasUsed: "92329", confirmations: "816011", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[12]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544497213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[10,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd5e4868b51439ac87279b0d0117b7e2f36475058"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[10,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6864546", blockHash: "0xa64a578afb36f3e35b61043d7c5ef5d7af9a6a630972d3824e0fb4be0f123595", timeStamp: "1544497262", hash: "0x8d0ccc678a72f13d571cece27b005e68ef92956e344be01b51f3d5799efe4627", nonce: "98", transactionIndex: "37", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7000000000", input: "0xfefa9bb10000000000000000000000008c5fc43ad00cc53e11f61bece329ddc5e3ea0929", contractAddress: "", cumulativeGasUsed: "3569232", txreceipt_status: "1", gasUsed: "92329", confirmations: "816005", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[13]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544497262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[11,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x8c5fc43ad00cc53e11f61bece329ddc5e3ea0929"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[11,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6864552", blockHash: "0x3716336ea0b3541c4ef9943d4469edbb6ffa503e138a2bd70c05326681f25f5e", timeStamp: "1544497356", hash: "0xe6395f1474031770bc3d146b5d6bb253a1d3bb7aa78c45ef8f5a7a10184a2ccb", nonce: "99", transactionIndex: "43", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000d3a22d084dd16196b7862bc2d309412b508318fb", contractAddress: "", cumulativeGasUsed: "1986737", txreceipt_status: "1", gasUsed: "92329", confirmations: "815999", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[14]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544497356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[12,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd3a22d084dd16196b7862bc2d309412b508318fb"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[12,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6864556", blockHash: "0xbfd83655c83562df5b246f8335931c0ef985c2393590457574f3bdc5a3a7754b", timeStamp: "1544497414", hash: "0x90730b1b00463e22c769eb09e39f639ccfe81479b83aebb79f0590841eb3d5dc", nonce: "100", transactionIndex: "35", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7000000000", input: "0xfefa9bb10000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "1967605", txreceipt_status: "1", gasUsed: "92329", confirmations: "815995", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[15]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544497414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[13,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[13,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6864561", blockHash: "0xdb6346348fe6ef12773cee1298ec834bd6e9796100a6e278d7e72578b9c0a6b3", timeStamp: "1544497461", hash: "0x3db3b9745a1c65af1f9a3da5b1bf611ea603b5eb8b43f492f9869a739dbe5fcc", nonce: "101", transactionIndex: "112", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb10000000000000000000000005c5aaf9e86bd9a2732fb351add176c7c6a21cbdf", contractAddress: "", cumulativeGasUsed: "5436287", txreceipt_status: "1", gasUsed: "92329", confirmations: "815990", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[16]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544497461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[14,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x5c5aaf9e86bd9a2732fb351add176c7c6a21cbdf"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[14,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6864568", blockHash: "0x45e474e8c613f7a2b872cdabd09e169e41198aba5c150692564159569de1be5f", timeStamp: "1544497550", hash: "0x4fdde1ce24c87a733c6165ff1c5db8b3c7cc535e07b5baac70df1e0f45eedfc6", nonce: "102", transactionIndex: "135", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb10000000000000000000000007ae0048bb33650edb349f6fc65fd23a39430e752", contractAddress: "", cumulativeGasUsed: "5247598", txreceipt_status: "1", gasUsed: "92329", confirmations: "815983", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[17]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544497550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[15,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7ae0048bb33650edb349f6fc65fd23a39430e752"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[15,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[18] )", async function( ) {
		const txOriginal = {blockNumber: "6864572", blockHash: "0xa312d153d4ab3c1e97de3e1ecd5404b587e389856d5040a11aecfe4813ad2401", timeStamp: "1544497614", hash: "0x24fe52c2ea2356d74f2d0a8af3f9fc1e87c117106023f0d7e81520f5b99e335b", nonce: "103", transactionIndex: "70", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb100000000000000000000000062b8b7b7af7cb5847dd7335e0b6b4229cd1b7d48", contractAddress: "", cumulativeGasUsed: "2776428", txreceipt_status: "1", gasUsed: "92329", confirmations: "815979", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[18]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544497614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[16,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x62b8b7b7af7cb5847dd7335e0b6b4229cd1b7d48"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[16,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[19] )", async function( ) {
		const txOriginal = {blockNumber: "6864574", blockHash: "0x34a29d16e75c4e0f5d7af2eef39e971808b26db275d84c76b6866a17efae6713", timeStamp: "1544497675", hash: "0x66a0faf35690b9223937f133f243b78cc6669d920d150ac8d86fc493795b1f7d", nonce: "104", transactionIndex: "117", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000b130168ec63ca7e30a8f8c7268aa56e4d6730fb5", contractAddress: "", cumulativeGasUsed: "5782903", txreceipt_status: "1", gasUsed: "92329", confirmations: "815977", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[19]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544497675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[17,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xb130168ec63ca7e30a8f8c7268aa56e4d6730fb5"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[17,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[20] )", async function( ) {
		const txOriginal = {blockNumber: "6864581", blockHash: "0xdded530d070a9ef9654443308be700624c5de29c950907386847e541625e9429", timeStamp: "1544497845", hash: "0x1380c95ba6d95f596e4712c428aa808839eda23f1dd5b230815097cd776ebc79", nonce: "105", transactionIndex: "122", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000981e6097e2bdffefe1b0d09777c3422bb6bb24c8", contractAddress: "", cumulativeGasUsed: "5421585", txreceipt_status: "1", gasUsed: "92329", confirmations: "815970", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[20]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544497845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[18,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x981e6097e2bdffefe1b0d09777c3422bb6bb24c8"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[18,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6864586", blockHash: "0xde9e7530218491ee14989a60a12a9a8c9c56d26f1cc241147b3481886186cfcd", timeStamp: "1544497887", hash: "0x8a9ac56377baee241aefbc1ced9aba296460041d9d5e809378ab9365bae50d2d", nonce: "106", transactionIndex: "130", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb100000000000000000000000096080155dd976e98305fa9aea96834a03abda864", contractAddress: "", cumulativeGasUsed: "5521847", txreceipt_status: "1", gasUsed: "92329", confirmations: "815965", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[21]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544497887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[19,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x96080155dd976e98305fa9aea96834a03abda864"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[19,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6864593", blockHash: "0x0daed711cc019839ac613d1456ef4f175985e0f9123506d1fc7f57120c873fff", timeStamp: "1544497965", hash: "0xdd5c588e2587c476a8eb012bf97e88bce871716ceb5ac7071cbb49e2c127b8e1", nonce: "107", transactionIndex: "87", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb10000000000000000000000005840feaaa7d7657c1a2f4c724928ddac62a743b3", contractAddress: "", cumulativeGasUsed: "3769686", txreceipt_status: "1", gasUsed: "92329", confirmations: "815958", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[22]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544497965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[20,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x5840feaaa7d7657c1a2f4c724928ddac62a743b3"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[20,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[23] )", async function( ) {
		const txOriginal = {blockNumber: "6864598", blockHash: "0x9d93b6e38603892eee2fbc786ff75859f94246a86eba2ba2b0bc60662f17d534", timeStamp: "1544498046", hash: "0x7edaaf2d23a7a09d63f6c55bba6b74324341b20b99fd5908b5212f8902d9ec4b", nonce: "108", transactionIndex: "47", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92265", gasPrice: "5000000000", input: "0xfefa9bb1000000000000000000000000f58d0e6fc3c021627a49a53f04152409fcc40055", contractAddress: "", cumulativeGasUsed: "1797986", txreceipt_status: "1", gasUsed: "92265", confirmations: "815953", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[23]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[23], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544498046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[21,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xf58d0e6fc3c021627a49a53f04152409fcc40055"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[21,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[24] )", async function( ) {
		const txOriginal = {blockNumber: "6864607", blockHash: "0x4461705f0737067dde14243d9c92e50d02e5f6501a4282a1c2072e94858b5453", timeStamp: "1544498210", hash: "0x7ea48db25f7547b29bc153abc20d437a0d11b7ce0cfb982803f29bac279ef521", nonce: "109", transactionIndex: "69", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "4000000000", input: "0xfefa9bb1000000000000000000000000d868711bd9a2c6f1548f5f4737f71da67d821090", contractAddress: "", cumulativeGasUsed: "5190714", txreceipt_status: "1", gasUsed: "92329", confirmations: "815944", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[24]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[24], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544498210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[22,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd868711bd9a2c6f1548f5f4737f71da67d821090"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[22,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[25] )", async function( ) {
		const txOriginal = {blockNumber: "6864614", blockHash: "0x5960e610e2955e367f367bca928da7ad8d23f1458b07743be19d5986c490319c", timeStamp: "1544498377", hash: "0x6a6168b8201baccbcf5fc59569cab09a7efb3949f1c9c33b9968854cdbec2a00", nonce: "110", transactionIndex: "54", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "5000000000", input: "0xfefa9bb10000000000000000000000003c11e8922bc793d2fbd7e3e454241c587ae42010", contractAddress: "", cumulativeGasUsed: "3704066", txreceipt_status: "1", gasUsed: "92329", confirmations: "815937", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[25]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[25], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544498377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[23,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x3c11e8922bc793d2fbd7e3e454241c587ae42010"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[23,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6864621", blockHash: "0x9c40a7f9acb3ee5d7719ea5d9d90a2923e3a52ae62386f4034a29946b6c1e607", timeStamp: "1544498434", hash: "0x3afb5492390cbf82a6bfbd900e1b35055c0363eb42d57ea2177431b7d562be2f", nonce: "111", transactionIndex: "62", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "6000000000", input: "0xfefa9bb1000000000000000000000000583780eebab14b8f7082c6b2e7ddcfa60b1a7c29", contractAddress: "", cumulativeGasUsed: "3659254", txreceipt_status: "1", gasUsed: "92329", confirmations: "815930", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[26]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544498434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[24,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x583780eebab14b8f7082c6b2e7ddcfa60b1a7c29"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[24,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[27] )", async function( ) {
		const txOriginal = {blockNumber: "6864628", blockHash: "0x20682a07fb37abb767f376fd4b7a4964c57ebaab8389a12640edf2d615cc7501", timeStamp: "1544498514", hash: "0x4bb1b910d262cce0533cee450e5c5886b8aa0e944560e8f021d7bf96ef529ec7", nonce: "112", transactionIndex: "102", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7000000000", input: "0xfefa9bb100000000000000000000000005ecc0958eee0acbe1bb2e9aae847466c20eac47", contractAddress: "", cumulativeGasUsed: "6408155", txreceipt_status: "1", gasUsed: "92329", confirmations: "815923", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[27]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[27], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544498514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[25,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x05ecc0958eee0acbe1bb2e9aae847466c20eac47"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[25,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[28] )", async function( ) {
		const txOriginal = {blockNumber: "6864635", blockHash: "0x3776b19cb2c456f094a6ef50d6f66407cf34b8527120452667dc70bc6bffe029", timeStamp: "1544498586", hash: "0x86cc1fae0bdb5fdae1b1a5dd7a48a0b8167ab3260f1bc79abd1ca9e32e3f50e9", nonce: "113", transactionIndex: "83", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "9000000000", input: "0xfefa9bb10000000000000000000000006efd9bf1c87a2946acea38043dc9a4c03ade8b7f", contractAddress: "", cumulativeGasUsed: "5006177", txreceipt_status: "1", gasUsed: "92329", confirmations: "815916", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[28]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[28], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544498586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[26,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x6efd9bf1c87a2946acea38043dc9a4c03ade8b7f"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[26,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[29] )", async function( ) {
		const txOriginal = {blockNumber: "6864637", blockHash: "0xd808b0defa2bb74a354a80d814108aac040ceb55deef19859a172d62bd596008", timeStamp: "1544498630", hash: "0xe448e952e798b25b4cc71e37a1bdb3c6f70afc1722a66080a6afe7e9963df585", nonce: "114", transactionIndex: "108", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "9359375000", input: "0xfefa9bb10000000000000000000000008bcc48f937a6e076ec25838436fa6118f0c153d2", contractAddress: "", cumulativeGasUsed: "5961705", txreceipt_status: "1", gasUsed: "92329", confirmations: "815914", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[29]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[29], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544498630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[27,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x8bcc48f937a6e076ec25838436fa6118f0c153d2"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[27,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[30] )", async function( ) {
		const txOriginal = {blockNumber: "6864644", blockHash: "0xb24931fb8e3cf83604fbd5a24418f7cc9c5408ca0583926dc246c4990b814a9d", timeStamp: "1544498711", hash: "0x90a765b5860fe905bfbd0bababb90f61e2d4de06cf4ccb687de9a5fe69dcc0a0", nonce: "115", transactionIndex: "51", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7000000000", input: "0xfefa9bb1000000000000000000000000ae015ccde814da988dbca7f09c10f7c25d6931c3", contractAddress: "", cumulativeGasUsed: "3069473", txreceipt_status: "1", gasUsed: "92329", confirmations: "815907", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[30]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544498711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[28,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xae015ccde814da988dbca7f09c10f7c25d6931c3"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[28,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[31] )", async function( ) {
		const txOriginal = {blockNumber: "6864648", blockHash: "0x1118d824c6544232538ea3b7042be56a28cfca292aa0bb70e0021709e6d29efb", timeStamp: "1544498782", hash: "0x4f5244d0bf4cf12a025e07e3fab33667b4c61a3dcf8094b30bf4b330719d8a26", nonce: "116", transactionIndex: "94", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "9000000000", input: "0xfefa9bb10000000000000000000000007da610dc64179389591d04c602cc58f5c82725f4", contractAddress: "", cumulativeGasUsed: "3612278", txreceipt_status: "1", gasUsed: "92329", confirmations: "815903", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[31]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[31], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544498782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[29,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7da610dc64179389591d04c602cc58f5c82725f4"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[29,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[32] )", async function( ) {
		const txOriginal = {blockNumber: "6864660", blockHash: "0x3b1470d26bfc3539c1bef2a39734c175e656a25306a824a1913353fd2c7623f9", timeStamp: "1544498952", hash: "0x16a5802a38523208c13b8897dbf1fbe56e3f661b966a7bba440b51949e966b21", nonce: "117", transactionIndex: "83", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "92329", gasPrice: "7800000000", input: "0xfefa9bb10000000000000000000000009a080c9da2c3e92d4b97a373f73b0a994274edc3", contractAddress: "", cumulativeGasUsed: "4486544", txreceipt_status: "1", gasUsed: "92329", confirmations: "815891", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[32]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[32], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544498952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[30,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x9a080c9da2c3e92d4b97a373f73b0a994274edc3"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[30,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6864669", blockHash: "0x3e4be390344d813741ccdbfb5286fc31bdc233bc79ba1385a882cf07dc6fdf9b", timeStamp: "1544499151", hash: "0xa868f67cabf6d05c9902d9094ea164980e19e85e5e6c9ead597a2d005cbb618a", nonce: "118", transactionIndex: "148", from: "0x37d0692b70f45cce8734dcff16ce85c1a389c157", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "62329", gasPrice: "7900000000", input: "0xfefa9bb10000000000000000000000008c5fc43ad00cc53e11f61bece329ddc5e3ea0929", contractAddress: "", cumulativeGasUsed: "5838588", txreceipt_status: "1", gasUsed: "62329", confirmations: "815882", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_account", value: addressList[13]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544499151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[31,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x8c5fc43ad00cc53e11f61bece329ddc5e3ea0929"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[31,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "542324420955563736" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[20] )", async function( ) {
		const txOriginal = {blockNumber: "6865121", blockHash: "0xc824351fa0b616ad6ef952d147e655a2484ec9bf179f404ab441b06444da2835", timeStamp: "1544505828", hash: "0x06a3c38e5368b01ab836fe2929935411f8a34ba127baed57ca7b5e0dbc0e2d1c", nonce: "19", transactionIndex: "71", from: "0xd868711bd9a2c6f1548f5f4737f71da67d821090", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "50000000000000000", gas: "89632", gasPrice: "10000000000", input: "0xf088d547000000000000000000000000981e6097e2bdffefe1b0d09777c3422bb6bb24c8", contractAddress: "", cumulativeGasUsed: "3122852", txreceipt_status: "1", gasUsed: "59616", confirmations: "815430", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[20]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544505828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xd868711bd9a2c6f1548f5f4737f71da67d821090"}, {name: "referrer", type: "address", value: "0x981e6097e2bdffefe1b0d09777c3422bb6bb24c8"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "at", type: "uint256", value: "1544505828"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "518613153445789176" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6865285", blockHash: "0x68be9f8ea768414c054c2941724f4c3fbf12de71e362875471f4e470eaeb676f", timeStamp: "1544508237", hash: "0x8798ddf71e06054c186a4404f938338b19ab602cf442caec4955bb87cfd4ab0b", nonce: "133", transactionIndex: "66", from: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "50000000000000000", gas: "52132", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "3670075", txreceipt_status: "1", gasUsed: "34616", confirmations: "815266", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544508237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da"}, {name: "referrer", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "at", type: "uint256", value: "1544508237"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1563705745731114729" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6865303", blockHash: "0x12b27285a082c658fad439688931f6bc123d1d3526dd1193f139d32ef313339d", timeStamp: "1544508477", hash: "0xbebcb518a1f5b94cb7cac12e55e96d0b6ffe7ecb2fdc040d2fdbab8078d9ea7d", nonce: "134", transactionIndex: "142", from: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "52132", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "6681075", txreceipt_status: "1", gasUsed: "34616", confirmations: "815248", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544508477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da"}, {name: "referrer", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544508477"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1563705745731114729" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6865307", blockHash: "0x86a0ce8b3030a784e184ad330e4faf261c738180d141122abe3ebaa1ad3ca2bd", timeStamp: "1544508570", hash: "0x6a51a95f4149254f48e071eda918a2e171687ce2c10047874bdea6aec6272281", nonce: "135", transactionIndex: "135", from: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "52132", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "4905488", txreceipt_status: "1", gasUsed: "34616", confirmations: "815244", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544508570 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da"}, {name: "referrer", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544508570"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1563705745731114729" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6865512", blockHash: "0x3eaeeeb400cc97c44fe7431bd3e5b367622bce5bd9568f03d314334dd64f163f", timeStamp: "1544511737", hash: "0x57110fa863a07a4258a49d4b0d224d09257f8521194a3ac4305a86e96f19017b", nonce: "138", transactionIndex: "62", from: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "52132", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "3122325", txreceipt_status: "1", gasUsed: "34616", confirmations: "815039", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544511737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xcd6fb0f2bf2476e43219e5616709adc58360a8da"}, {name: "referrer", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544511737"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1563705745731114729" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6865522", blockHash: "0x7afb3e6fbf6150eb8a156fc7e9759d820048abd928413d120b82008f3a2738cc", timeStamp: "1544511834", hash: "0xec968e6d91125949a4298230ecc2e282cb3ed8c907fb2818845bdde3dc8f64bf", nonce: "151", transactionIndex: "131", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "0", gas: "32371", gasPrice: "9000000000", input: "0x7362377b", contractAddress: "", cumulativeGasUsed: "6338827", txreceipt_status: "1", gasUsed: "30116", confirmations: "815029", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawEther", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544511834 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865538", blockHash: "0x79498953fa586517b99f83620baff34a43b4fb69b7338656d0bc3f988db5a2af", timeStamp: "1544512048", hash: "0x98ad1e30b8416ed02138039b4189f904a3aaeaa1cc4a9a6e5167e44469f6bc54", nonce: "205", transactionIndex: "89", from: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "32290", gasPrice: "9100000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4786778", txreceipt_status: "1", gasUsed: "24839", confirmations: "815013", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544512048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544512048"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "435160642787842666" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865547", blockHash: "0x937c9dba64bb6068bba95582241cace99333adf6070845187e257aca5d489438", timeStamp: "1544512228", hash: "0x2d2c2a40589caf5f741a07246be856c80f68d10ffa87f9ebea1ce4df6ca27157", nonce: "206", transactionIndex: "135", from: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "32290", gasPrice: "8100000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7412722", txreceipt_status: "1", gasUsed: "24839", confirmations: "815004", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544512228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544512228"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "435160642787842666" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865549", blockHash: "0x0ce021d46de51b02a2b41b9d488fbec6d0e5b73ec5832c304547613103c994db", timeStamp: "1544512269", hash: "0xfd8bc7950ae7978ab8891a45b5b62a9f547fd2e1711d357f8d90e93881595dae", nonce: "207", transactionIndex: "33", from: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "50000000000000000", gas: "32290", gasPrice: "9100000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1633829", txreceipt_status: "1", gasUsed: "24839", confirmations: "815002", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544512269 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x5b8c29115efc3a70b154960740ce7a6956f3a45a"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "at", type: "uint256", value: "1544512269"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "435160642787842666" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865559", blockHash: "0x8c0b7137f794235491ec2361adcaf29f737fa28949a353f4a9868bf31ab31fbd", timeStamp: "1544512420", hash: "0x81dcb709c6e8cbfeaae8c2b5f79917137a89abdf4a321d7f2356f3faaf53e51f", nonce: "22", transactionIndex: "75", from: "0xbac047c74c4d0a3da65fa4696e12f6c66435c9b1", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "1000000000000000000", gas: "37258", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3900817", txreceipt_status: "1", gasUsed: "24839", confirmations: "814992", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544512420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xbac047c74c4d0a3da65fa4696e12f6c66435c9b1"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "at", type: "uint256", value: "1544512420"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "774017266110549881" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865559", blockHash: "0x8c0b7137f794235491ec2361adcaf29f737fa28949a353f4a9868bf31ab31fbd", timeStamp: "1544512420", hash: "0x2792e3d2578626ce6577158bc425d42b0e720008331c1636f5aff6c896420950", nonce: "535", transactionIndex: "156", from: "0x9f1bee52a02890fec054d35476efa97ac4870703", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "29806", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6273290", txreceipt_status: "1", gasUsed: "24839", confirmations: "814992", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544512420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x9f1bee52a02890fec054d35476efa97ac4870703"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544512420"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "19500000000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6865562", blockHash: "0xa2b9d5d585e37c527a127b815bef6add84db56a5f36c65009d58f1a04bc17853", timeStamp: "1544512469", hash: "0xf81cd72aa1aa2eeb921b5dbb1ae921df71045863a4557b4057f7251afe6c77ef", nonce: "27", transactionIndex: "175", from: "0x18d43ec07223db80b8ca960bf1d09c97434f46ae", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "500000000000000000", gas: "158820", gasPrice: "5090000000", input: "0xf088d547000000000000000000000000d5e4868b51439ac87279b0d0117b7e2f36475058", contractAddress: "", cumulativeGasUsed: "7719018", txreceipt_status: "1", gasUsed: "34616", confirmations: "814989", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544512469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x18d43ec07223db80b8ca960bf1d09c97434f46ae"}, {name: "referrer", type: "address", value: "0xd5e4868b51439ac87279b0d0117b7e2f36475058"}, {name: "value", type: "uint256", value: "500000000000000000"}, {name: "at", type: "uint256", value: "1544512469"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "37221802644767797" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6865588", blockHash: "0xd1210845ed089f647c1b2774baaf7ba64e6628bd363017ffcaff9acab04a1c05", timeStamp: "1544512778", hash: "0xe70b1e803c785fe738a10652fddf6dedad9914af090cb85cc5627ebc01f2bf27", nonce: "14", transactionIndex: "40", from: "0x9884f51c93cd4c3e0071b3c507c3da8da002a669", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "41706", gasPrice: "10000000000", input: "0xf088d547000000000000000000000000d3a22d084dd16196b7862bc2d309412b508318fb", contractAddress: "", cumulativeGasUsed: "1742682", txreceipt_status: "1", gasUsed: "34616", confirmations: "814963", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[14]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544512778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x9884f51c93cd4c3e0071b3c507c3da8da002a669"}, {name: "referrer", type: "address", value: "0xd3a22d084dd16196b7862bc2d309412b508318fb"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544512778"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "41036005945033621" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865613", blockHash: "0x00ed2c9a1bf2c467b3ea69eb2f0e6ae1cf3f270a0f7d6e9aeb21dc2e5825dba4", timeStamp: "1544513178", hash: "0x3cc9277fc506836784552cc1b2b4006fbb2145b3efd59b1ad55aac5a9d451ce2", nonce: "536", transactionIndex: "94", from: "0x9f1bee52a02890fec054d35476efa97ac4870703", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "29806", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3921406", txreceipt_status: "1", gasUsed: "24839", confirmations: "814938", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544513178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x9f1bee52a02890fec054d35476efa97ac4870703"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544513178"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "19500000000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6865641", blockHash: "0xfb38302cf018489707a8018a438005b77095d05fe198340eede70a5906cad509", timeStamp: "1544513655", hash: "0x13239030f79210978e65e4c32c8a649e087cfe43eef090b813e0150810f07188", nonce: "23", transactionIndex: "212", from: "0x04ec67264c8eae2847c5f3da0813638797aab47c", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "50000000000000000", gas: "52132", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000007e1dcf785f0353bf657c38ab7865c1f184efe208", contractAddress: "", cumulativeGasUsed: "6498171", txreceipt_status: "1", gasUsed: "34616", confirmations: "814910", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[7]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544513655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x04ec67264c8eae2847c5f3da0813638797aab47c"}, {name: "referrer", type: "address", value: "0x7e1dcf785f0353bf657c38ab7865c1f184efe208"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "at", type: "uint256", value: "1544513655"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "622787075185020509" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865671", blockHash: "0x4be583c269e13368d1ec9843125736b4235207d1e84d23c9302bb05cb7cb43fd", timeStamp: "1544513965", hash: "0xd3f020021b5f4ff50fc7ba5631aac57bbab06bbfd39f5b79facbbe5c3c9200a1", nonce: "339", transactionIndex: "123", from: "0xd084ec3b6f1fcae73fb8668ed4b99614fc7c39d3", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "500000000000000000", gas: "32290", gasPrice: "10000000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4915456", txreceipt_status: "1", gasUsed: "24839", confirmations: "814880", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544513965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0xd084ec3b6f1fcae73fb8668ed4b99614fc7c39d3"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "500000000000000000"}, {name: "at", type: "uint256", value: "1544513965"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "2128109184129671617" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6865684", blockHash: "0xb1c34208c7b0b6f0b38d8f0b4403fa45d5e8dc57cdedfb11d325594c462f31c3", timeStamp: "1544514126", hash: "0x9cb0bbd5e1e13f3e86de64595a5278147246ab9999fe159678681105aae2f87c", nonce: "3508", transactionIndex: "34", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "100000000000000000", gas: "37258", gasPrice: "14000000000", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1312769", txreceipt_status: "1", gasUsed: "24839", confirmations: "814867", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544514126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "at", type: "uint256", value: "1544514126"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "479715946262692320" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6865686", blockHash: "0xee5a274e64ca8318905c07e6fb92095b828c57556be65607940aa0f69356edd0", timeStamp: "1544514150", hash: "0xbdb9271959216f6819d5022cc43601c8678b72f0c3527f32d267df2484df3262", nonce: "102", transactionIndex: "48", from: "0x40c9afd96646df172b6fa31211fb51bf5144081e", to: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26", value: "50000000000000000", gas: "41706", gasPrice: "10000000000", input: "0xf088d547000000000000000000000000d3a22d084dd16196b7862bc2d309412b508318fb", contractAddress: "", cumulativeGasUsed: "1609320", txreceipt_status: "1", gasUsed: "34616", confirmations: "814865", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referrer", value: addressList[14]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544514150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "at", type: "uint256"}], name: "Sold", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sold", events: [{name: "user", type: "address", value: "0x40c9afd96646df172b6fa31211fb51bf5144081e"}, {name: "referrer", type: "address", value: "0xd3a22d084dd16196b7862bc2d309412b508318fb"}, {name: "value", type: "uint256", value: "50000000000000000"}, {name: "at", type: "uint256", value: "1544514150"}], address: "0xa30cbce69f520bf2a34c5c15193b7f5afe427a26"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "353557541743230238" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
