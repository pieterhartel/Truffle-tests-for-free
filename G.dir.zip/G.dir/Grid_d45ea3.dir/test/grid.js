const Grid = artifacts.require( "./Grid.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Grid" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xaE89C8d6B98432DF28242899B3688Cc8e3D45eA3", "0x3Db54F5eeb627F1ecC3dbefc844a7E0067B30950", "0x5e08B0702308031518987a0eB88ED6A722c4DfD3", "0xFB993DFf9898718cDd1600FF71a250138247b9dA"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "incrementRate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "feeRatio", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "row", type: "uint16"}, {name: "col", type: "uint16"}], name: "getPixelOwner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "size", outputs: [{name: "", type: "uint16"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "row", type: "uint16"}, {name: "col", type: "uint16"}], name: "getKey", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "getUserTotalSales", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "row", type: "uint16"}, {name: "col", type: "uint16"}], name: "getPixelColor", outputs: [{name: "", type: "uint24"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "getUserMessage", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "defaultPrice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "row", type: "uint16"}, {name: "col", type: "uint16"}], name: "getPixelPrice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "checkPendingWithdrawal", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "price", type: "uint256"}], name: "PixelPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "message", type: "string"}], name: "UserMessage", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PixelTransfer(uint16,uint16,uint256,address,address)", "PixelColor(uint16,uint16,address,uint24)", "PixelPrice(uint16,uint16,address,uint256)", "UserMessage(address,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x85760377a37f4d495f6df6325cd9d2cb55db4def18abefa698bd7492a3f6c682", "0xebbf2f6af1ceaedaf4bd83987bcc96e28562a6643e116aa411b84f6908234d9f", "0xdab4d1c1b881dacdd0fe2d91b99c9881d9dc5fa3d21129a3f6a61f16dc381470", "0x1495974175fff28a1e5c4cb09fb6c06414bb7713f0fead9e9bc3922c1bd7ce09"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4024924 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4026174 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint16", name: "_size", value: "1000"}, {type: "uint256", name: "_defaultPrice", value: "2000000000000000"}, {type: "uint256", name: "_feeRatio", value: "40"}, {type: "uint256", name: "_incrementRate", value: "25"}], name: "Grid", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "incrementRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "incrementRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeRatio", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeRatio()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "row", value: random.range( maxRandom )}, {type: "uint16", name: "col", value: random.range( maxRandom )}], name: "getPixelOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPixelOwner(uint16,uint16)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "size", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "size()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "row", value: random.range( maxRandom )}, {type: "uint16", name: "col", value: random.range( maxRandom )}], name: "getKey", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getKey(uint16,uint16)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getUserTotalSales", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getUserTotalSales(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "row", value: random.range( maxRandom )}, {type: "uint16", name: "col", value: random.range( maxRandom )}], name: "getPixelColor", outputs: [{name: "", type: "uint24"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPixelColor(uint16,uint16)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getUserMessage", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getUserMessage(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "defaultPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "defaultPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "row", value: random.range( maxRandom )}, {type: "uint16", name: "col", value: random.range( maxRandom )}], name: "getPixelPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPixelPrice(uint16,uint16)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "checkPendingWithdrawal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkPendingWithdrawal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Grid", function( accounts ) {

	it( "TEST: Grid( \"1000\", \"2000000000000000\", \"40\", ... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4024924", timeStamp: "1500108104", hash: "0xe29b0665e232f0469562f0e721f014e126504d8ec0b95559ecbc9e28c82f49d4", nonce: "6", blockHash: "0xa6d42cc6aa2405fdd00b754a55315ba1b13495c04dbd369583d610df800b0282", transactionIndex: "67", from: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950", to: 0, value: "0", gas: "1250879", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0xa38deeab00000000000000000000000000000000000000000000000000000000000003e800000000000000000000000000000000000000000000000000071afd498d000000000000000000000000000000000000000000000000000000000000000000280000000000000000000000000000000000000000000000000000000000000019", contractAddress: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", cumulativeGasUsed: "4746265", gasUsed: "1250879", confirmations: "3654741"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_size", value: "1000"}, {type: "uint256", name: "_defaultPrice", value: "2000000000000000"}, {type: "uint256", name: "_feeRatio", value: "40"}, {type: "uint256", name: "_incrementRate", value: "25"}], name: "Grid", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Grid.new( "1000", "2000000000000000", "40", "25", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1500108104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Grid.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"479\", \"483\", \"3326403\" )", async function( ) {
		const txOriginal = {blockNumber: "4024947", timeStamp: "1500108536", hash: "0x521eec032f62cb0eeda5c17afb2325e0cc2ff8f957af51da95e00846bb706781", nonce: "7", blockHash: "0x5800d4e62bc6dd13d135a15ab407bf12fe7f676860d4abffeab172fc1788e841", transactionIndex: "30", from: "0x5e08b0702308031518987a0eb88ed6a722c4dfd3", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "218287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001df00000000000000000000000000000000000000000000000000000000000001e3000000000000000000000000000000000000000000000000000000000032c1c3", contractAddress: "", cumulativeGasUsed: "1179974", gasUsed: "145525", confirmations: "3654718"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "479"}, {type: "uint16", name: "col", value: "483"}, {type: "uint24", name: "newColor", value: "3326403"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "479", "483", "3326403", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1500108536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [479]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [483]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0x5e08b0702308031518987a0eb88ed6a722c4dfd3"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [479]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [483]}}, {name: "owner", type: "address", value: "0x5e08b0702308031518987a0eb88ed6a722c4dfd3"}, {name: "color", type: "uint24", value: {s: 1, e: 6, c: [3326403]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setUserMessage( `Welcome to Ethereum Pixels!There is a m... )", async function( ) {
		const txOriginal = {blockNumber: "4025045", timeStamp: "1500110389", hash: "0x092e1269b9f79bb4b545d140f3b9091d5d18bafb279d48b021809a246a3d1510", nonce: "7", blockHash: "0x97315f5cab1363f291595fa91caac8b29107a1ccb21ccff0b7034079a9344451", transactionIndex: "102", from: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "0", gas: "201799", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x7e331a990000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000007757656c636f6d6520746f20457468657265756d20506978656c73210a54686572652069732061206d6574686f6420746f2074686973206d61646e6573732c20492061737375726520796f752e0a5265616368206d6520617420726176656e4063732e7374616e666f72642e6564750a0a2d20526176656e000000000000000000", contractAddress: "", cumulativeGasUsed: "5216574", gasUsed: "134533", confirmations: "3654620"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "message", value: `Welcome to Ethereum Pixels!
There is a method to this madness, I assure you.
Reach me at raven@cs.stanford.edu

- Raven`}], name: "setUserMessage", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setUserMessage(string)" ]( `Welcome to Ethereum Pixels!
There is a method to this madness, I assure you.
Reach me at raven@cs.stanford.edu

- Raven`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1500110389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "message", type: "string"}], name: "UserMessage", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UserMessage", events: [{name: "user", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "message", type: "string", value: "Welcome to Ethereum Pixels!\nThere is a method to this madness, I assure you.\nReach me at raven@cs.stanford.edu\n\n- Raven"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setUserMessage( `Welcome to Ethereum Pixels!I hope you e... )", async function( ) {
		const txOriginal = {blockNumber: "4025068", timeStamp: "1500110955", hash: "0xcad4497c3e5a7f2ace86868e9459cc472da00539cc47d245d35d9bee4f45741e", nonce: "8", blockHash: "0x5c9eee9403b4cf4e5ccbfd36391ca13ee34f147a68d38d95b42702c1f6e36f87", transactionIndex: "90", from: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "0", gas: "258739", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x7e331a990000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000011757656c636f6d6520746f20457468657265756d20506978656c73210a0a4920686f706520796f7520656e6a6f7920796f7572207669736974206173206d756368206173204920656e6a6f796564206d616b696e6720746869732068617070656e2e2054686572652069732061206d6574686f6420746f2074686973206d61646e6573732c20492061737375726520796f752e205265616368206f757420617420726176656e4063732e7374616e666f72642e656475206f7220404461726b4d6972616765206f6e205477697474657220616e642077652063616e20636861742061626f75742074686973206372617a79207363692d666920776f726c64207468617420776520696e68616269742e0a0a2d20526176656e000000000000000000", contractAddress: "", cumulativeGasUsed: "5100674", gasUsed: "172493", confirmations: "3654597"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "message", value: `Welcome to Ethereum Pixels!

I hope you enjoy your visit as much as I enjoyed making this happen. There is a method to this madness, I assure you. Reach out at raven@cs.stanford.edu or @DarkMirage on Twitter and we can chat about this crazy sci-fi world that we inhabit.

- Raven`}], name: "setUserMessage", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setUserMessage(string)" ]( `Welcome to Ethereum Pixels!

I hope you enjoy your visit as much as I enjoyed making this happen. There is a method to this madness, I assure you. Reach out at raven@cs.stanford.edu or @DarkMirage on Twitter and we can chat about this crazy sci-fi world that we inhabit.

- Raven`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1500110955 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "message", type: "string"}], name: "UserMessage", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UserMessage", events: [{name: "user", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "message", type: "string", value: "Welcome to Ethereum Pixels!\n\nI hope you enjoy your visit as much as I enjoyed making this happen. There is a method to this madness, I assure you. Reach out at raven@cs.stanford.edu or @DarkMirage on Twitter and we can chat about this crazy sci-fi world that we inhabit.\n\n- Raven"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"483\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026095", timeStamp: "1500130228", hash: "0x462b66b026e71d7c615a48c29252af845f1eec5f9f8076ebf8c271bd595cb7ed", nonce: "0", blockHash: "0xa1119c190a286352970ca75214b2b9306c83c739c72fa2d86bcba6d08f9eff34", transactionIndex: "91", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001e30000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "3278472", gasUsed: "115525", confirmations: "3653570"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "483"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "483", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1500130228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [483]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [483]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"482\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026115", timeStamp: "1500130527", hash: "0xcf60c18c28eaeb26f58e46597ac57559ab774562767f834cfa1a459617bcbb10", nonce: "1", blockHash: "0xeefaa9f9de17800214b16df67b747a5e13d5c4cb92c7c7508971e2330d057c4c", transactionIndex: "93", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001e20000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "2342348", gasUsed: "115525", confirmations: "3653550"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "482"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "482", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1500130527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [482]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [482]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"481\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026115", timeStamp: "1500130527", hash: "0xdc13573176b5d8887837dda352efaa2b0d4da7bb6bdf2fef17621d7b89475757", nonce: "2", blockHash: "0xeefaa9f9de17800214b16df67b747a5e13d5c4cb92c7c7508971e2330d057c4c", transactionIndex: "132", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001e10000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "5891309", gasUsed: "115525", confirmations: "3653550"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "481"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "481", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1500130527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [481]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [481]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"480\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026115", timeStamp: "1500130527", hash: "0x8efc5e44877bcf8e20d1fe170c2ec3642fd9e96fab1fbd7cb4d5cd2332396d5b", nonce: "3", blockHash: "0xeefaa9f9de17800214b16df67b747a5e13d5c4cb92c7c7508971e2330d057c4c", transactionIndex: "140", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "6364510", gasUsed: "115525", confirmations: "3653550"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "480"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "480", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1500130527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [480]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [480]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"479\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026115", timeStamp: "1500130527", hash: "0xf1be4531a4e1a323d4897dd687b705376aac434526e77f9bb7de039cddd407b1", nonce: "4", blockHash: "0xeefaa9f9de17800214b16df67b747a5e13d5c4cb92c7c7508971e2330d057c4c", transactionIndex: "143", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001df0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "6593893", gasUsed: "115525", confirmations: "3653550"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "479"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "479", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1500130527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [479]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [479]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"477\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026117", timeStamp: "1500130559", hash: "0x3721d6410d25d88d17cb7e4d27582fb4a82127f99047a2b41e8fb0476f7e72bd", nonce: "5", blockHash: "0x958dbdf32e43f18b32de2dd099e5007fcd9a41d9c4406745f24be80528cb9f6b", transactionIndex: "29", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001dd0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "917881", gasUsed: "115525", confirmations: "3653548"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "477"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "477", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1500130559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [477]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [477]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"476\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026117", timeStamp: "1500130559", hash: "0xb6a939d554c75f01d4175717af69c26c0bd31bc0e20f31639b0232a0545f4f9e", nonce: "6", blockHash: "0x958dbdf32e43f18b32de2dd099e5007fcd9a41d9c4406745f24be80528cb9f6b", transactionIndex: "37", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001dc0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1572082", gasUsed: "115525", confirmations: "3653548"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "476"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "476", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1500130559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"476\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026117", timeStamp: "1500130559", hash: "0xf7a516c60df5d16badaa5f13130dddaa917f186d29ce4e92becb5e3f075167e0", nonce: "7", blockHash: "0x958dbdf32e43f18b32de2dd099e5007fcd9a41d9c4406745f24be80528cb9f6b", transactionIndex: "40", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001dc0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1764415", gasUsed: "115525", confirmations: "3653548"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "476"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "476", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1500130559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"475\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026125", timeStamp: "1500130695", hash: "0x33f396efe0650dcdc307fdabd5d922185c9557f9a9bf152569ec315ce09a38e7", nonce: "8", blockHash: "0x298d8ab63779af35d5612a6cd69b28faf19dd009bdfe7c72d56b731704b49b69", transactionIndex: "105", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001db0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "3122053", gasUsed: "115525", confirmations: "3653540"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "475"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "475", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1500130695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [475]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [475]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"474\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026125", timeStamp: "1500130695", hash: "0x6cd1d973fd28000a3c5c0e88ff9f667fe05d1a86d959ec9ddd30e2696424dd5d", nonce: "9", blockHash: "0x298d8ab63779af35d5612a6cd69b28faf19dd009bdfe7c72d56b731704b49b69", transactionIndex: "133", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001da0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "5557033", gasUsed: "115525", confirmations: "3653540"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "474"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "474", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1500130695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"474\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026125", timeStamp: "1500130695", hash: "0xd015fbe170a429ce6b7b281bac01d3dfb773959801e1c77f96877678c3d514b1", nonce: "10", blockHash: "0x298d8ab63779af35d5612a6cd69b28faf19dd009bdfe7c72d56b731704b49b69", transactionIndex: "142", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001da0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "6289701", gasUsed: "115525", confirmations: "3653540"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "474"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "474", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1500130695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"474\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026128", timeStamp: "1500130778", hash: "0x0231ddae17eab716b92fa304964e1bcedcef8e3fb2c32b12bf6f6c4b2f92b0e0", nonce: "11", blockHash: "0xedc0bb23a43d6b3eb622aa3eb254cfdf05af6ea0d02db3e4976aac349517bc6a", transactionIndex: "115", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001da0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "5272769", gasUsed: "115525", confirmations: "3653537"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "474"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "474", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1500130778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"474\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026128", timeStamp: "1500130778", hash: "0x44efa6b587f4c7cfbce817608a328410871759a200f9502e0f883be6d8d010d4", nonce: "12", blockHash: "0xedc0bb23a43d6b3eb622aa3eb254cfdf05af6ea0d02db3e4976aac349517bc6a", transactionIndex: "132", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001da0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "6369755", gasUsed: "115525", confirmations: "3653537"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "474"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "474", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1500130778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"475\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026131", timeStamp: "1500130819", hash: "0x591b63d5a577208b0b859e76ca76b3c6d35a330527269b3404bd1c1e62d3938d", nonce: "13", blockHash: "0x128abf723f1be1edcd399845496fdaef17f9b05dc12fac3d36c828415ffe8b46", transactionIndex: "14", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001db0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "495190", gasUsed: "115525", confirmations: "3653534"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "475"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "475", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1500130819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [475]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [475]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"476\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026131", timeStamp: "1500130819", hash: "0x0a04fbd71622ec06536c6859934eaf5e3e329bc5c2b8779780ce493f49d609de", nonce: "14", blockHash: "0x128abf723f1be1edcd399845496fdaef17f9b05dc12fac3d36c828415ffe8b46", transactionIndex: "20", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001dc0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1100853", gasUsed: "115525", confirmations: "3653534"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "476"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "476", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1500130819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [476]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"477\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026131", timeStamp: "1500130819", hash: "0xebb1c1addcc46049ccc4407b00081277ec0b19155c4c99c0b5b8709dff58c488", nonce: "15", blockHash: "0x128abf723f1be1edcd399845496fdaef17f9b05dc12fac3d36c828415ffe8b46", transactionIndex: "22", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001dd0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1259218", gasUsed: "115525", confirmations: "3653534"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "477"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "477", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1500130819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [477]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [477]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"474\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026131", timeStamp: "1500130819", hash: "0xa40a461b517af8247dd37b155e66eae556975daa44432ac9c9cdfcc9bd1c6949", nonce: "16", blockHash: "0x128abf723f1be1edcd399845496fdaef17f9b05dc12fac3d36c828415ffe8b46", transactionIndex: "24", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001da0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1417583", gasUsed: "115525", confirmations: "3653534"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "474"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "474", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1500130819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [474]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"485\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026131", timeStamp: "1500130819", hash: "0x0d92e3a22874a01df54b097f5e0d9cf0d92bc06f49354c8f7ea1cb8d055ab876", nonce: "17", blockHash: "0x128abf723f1be1edcd399845496fdaef17f9b05dc12fac3d36c828415ffe8b46", transactionIndex: "26", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001e50000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1575948", gasUsed: "115525", confirmations: "3653534"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "485"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "485", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1500130819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"485\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026138", timeStamp: "1500130967", hash: "0x9db6cbd3e8f0bae8e99f2e8796c6b37619ad8a6fe31e3153359426d00f0fb2fd", nonce: "18", blockHash: "0xcbb7f249682fbc283d48c6b2feeb03532bb50f95a5174d2d89f4593dc9690b5d", transactionIndex: "23", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001e50000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "2006448", gasUsed: "115525", confirmations: "3653527"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "485"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "485", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1500130967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"485\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026138", timeStamp: "1500130967", hash: "0x1c7450e8e27266f7d6ddae78871d8d7fae5ce13d16497011896d7b91ccf8dea5", nonce: "19", blockHash: "0xcbb7f249682fbc283d48c6b2feeb03532bb50f95a5174d2d89f4593dc9690b5d", transactionIndex: "57", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001e50000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4187420", gasUsed: "115525", confirmations: "3653527"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "485"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "485", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1500130967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"485\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026138", timeStamp: "1500130967", hash: "0x110dd1fb4c05b84fc463ebbec2e8dbb4cada9a04bcfa034decd9ca27419ec00a", nonce: "20", blockHash: "0xcbb7f249682fbc283d48c6b2feeb03532bb50f95a5174d2d89f4593dc9690b5d", transactionIndex: "62", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001e50000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4506507", gasUsed: "115525", confirmations: "3653527"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "485"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "485", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1500130967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"485\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026141", timeStamp: "1500130990", hash: "0x4c0cc58f39b5f3d8b2d0e89837b7a514fcf324d31036c4e487a95623f86c09e8", nonce: "21", blockHash: "0x1cef4fe5f3e4c237932c60247fdb65943bfc3714278a41a002e5eca82d8eecf5", transactionIndex: "23", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001e50000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1341434", gasUsed: "115525", confirmations: "3653524"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "485"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "485", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1500130990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [485]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"486\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026141", timeStamp: "1500130990", hash: "0x1e943f978445e684dc312369bb80f3472b53516168ac111b41ffd7a3142eefb6", nonce: "22", blockHash: "0x1cef4fe5f3e4c237932c60247fdb65943bfc3714278a41a002e5eca82d8eecf5", transactionIndex: "26", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001e60000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1548681", gasUsed: "115525", confirmations: "3653524"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "486"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "486", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1500130990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"487\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026141", timeStamp: "1500130990", hash: "0x5ddf1f58b6701ce56bf865e7252d287d6a0aed9754517797bf63f3a310e5bfab", nonce: "23", blockHash: "0x1cef4fe5f3e4c237932c60247fdb65943bfc3714278a41a002e5eca82d8eecf5", transactionIndex: "29", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001e70000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1737416", gasUsed: "115525", confirmations: "3653524"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "487"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "487", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1500130990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"488\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026141", timeStamp: "1500130990", hash: "0xbf3d7192454b952da7e29ba77667a7856ec4f5e31c7e0e8472c82f4854fa69b9", nonce: "24", blockHash: "0x1cef4fe5f3e4c237932c60247fdb65943bfc3714278a41a002e5eca82d8eecf5", transactionIndex: "32", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001e80000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "1926151", gasUsed: "115525", confirmations: "3653524"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "488"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "488", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1500130990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [488]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [488]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"486\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026141", timeStamp: "1500130990", hash: "0x583be4ee9e686ea8aa7365114e7f3b7221950a7249a0d38849ea265b238de9b8", nonce: "25", blockHash: "0x1cef4fe5f3e4c237932c60247fdb65943bfc3714278a41a002e5eca82d8eecf5", transactionIndex: "34", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001e60000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "2062676", gasUsed: "115525", confirmations: "3653524"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "486"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "486", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1500130990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"488\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026147", timeStamp: "1500131052", hash: "0xee7b6d5f45971fc30951b9ab1affb265ecb6008ae108856c284db2201f9d4cc7", nonce: "26", blockHash: "0x990f35dede6bcd5c339b4e219eb3425591e82248418cba979fceaab06962790f", transactionIndex: "5", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001e80000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "250187", gasUsed: "115525", confirmations: "3653518"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "488"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "488", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1500131052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [488]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [488]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"487\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026147", timeStamp: "1500131052", hash: "0xc1b7b39e83c312b48e6fecace3db76ef9c324bd97be5cbe70e2f60b6b0fa5efb", nonce: "27", blockHash: "0x990f35dede6bcd5c339b4e219eb3425591e82248418cba979fceaab06962790f", transactionIndex: "11", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001e70000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "620457", gasUsed: "115525", confirmations: "3653518"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "487"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "487", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1500131052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"486\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026147", timeStamp: "1500131052", hash: "0x603b18e3a30b0d682f4615dd493209e7cab42be6e21345e4c959fa315273ff35", nonce: "28", blockHash: "0x990f35dede6bcd5c339b4e219eb3425591e82248418cba979fceaab06962790f", transactionIndex: "14", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001e60000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "777982", gasUsed: "115525", confirmations: "3653518"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "486"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "486", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1500131052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [486]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"487\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0x79cbccc7d940c280885ff2357ddd3b7fdfad0f2e02bed761e34ecdf576c63674", nonce: "29", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "69", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001e70000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "3380668", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "487"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "487", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [487]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"490\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0x1d6291f69dbf0aebc964686a826b2a05502fc031a743910e1ac636e7378e20f2", nonce: "30", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "81", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001ea0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4046551", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "490"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "490", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [490]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [490]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"491\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0xb3019197cf406be9a49e9cacc1894e64379c75f6ca3990a64cc19cd2f98b1bf5", nonce: "31", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "85", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001eb0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4342009", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "491"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "491", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"492\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0xb6fc6b563eb776252fadb0f652e674ab8378d1244854adbad370281461bbcd85", nonce: "32", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "88", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001ec0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4499534", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "492"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "492", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [492]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [492]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"491\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0x91de3ea19f15221b4289001d965c0cfe45e687d4f303bcd142879f5a5ade05d2", nonce: "33", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "91", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001eb0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4657059", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "491"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "491", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"491\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0xd5f41f57fecfdce711ade23ddd62e6ce4a0e26f819fb66aa3574a5e76b01d90d", nonce: "34", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "94", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001eb0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4814584", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "491"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "491", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"491\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0xec4f1ca25570042dd9c2d4721b8a1843731aaeba0d01d985860fcba13956a15d", nonce: "35", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "96", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001eb0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4951109", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "491"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "491", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"491\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026161", timeStamp: "1500131319", hash: "0xc282ecc988adae1425f0009c393acf6690522f04eace02fd6159a0b7d8a365fe", nonce: "36", blockHash: "0x2e465741776b20f505a6e35833f230b3ec8b6651170d7080213aaaed2e33dc1f", transactionIndex: "98", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001eb0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "5087634", gasUsed: "115525", confirmations: "3653504"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "491"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "491", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1500131319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [491]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setUserMessage( `https://www.reddit.com/r/btc/Home of fr... )", async function( ) {
		const txOriginal = {blockNumber: "4026165", timeStamp: "1500131373", hash: "0xaa70dc3bc96d6d8cfa89272fed6fa438213a9c0c4cdde60577e638ab3f827858", nonce: "37", blockHash: "0x61347edc2a4cf6e88894eeb6b9f613d3d54923901336639566a85d2aec03eb3b", transactionIndex: "14", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "0", gas: "268000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x7e331a99000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000a768747470733a2f2f7777772e7265646469742e636f6d2f722f6274632f0a486f6d65206f66206672656520616e64206f70656e20626974636f696e2064697363757373696f6e2c20626974636f696e206e6577732c20616e64206578636c757369766520414d41202841736b204d6520416e797468696e672920696e74657276696577732066726f6d20746f7020626974636f696e20696e647573747279206c6561646572732100000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "738028", gasUsed: "178667", confirmations: "3653500"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "message", value: `https://www.reddit.com/r/btc/
Home of free and open bitcoin discussion, bitcoin news, and exclusive AMA (Ask Me Anything) interviews from top bitcoin industry leaders!`}], name: "setUserMessage", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setUserMessage(string)" ]( `https://www.reddit.com/r/btc/
Home of free and open bitcoin discussion, bitcoin news, and exclusive AMA (Ask Me Anything) interviews from top bitcoin industry leaders!`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1500131373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "message", type: "string"}], name: "UserMessage", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UserMessage", events: [{name: "user", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "message", type: "string", value: "https://www.reddit.com/r/btc/\nHome of free and open bitcoin discussion, bitcoin news, and exclusive AMA (Ask Me Anything) interviews from top bitcoin industry leaders!"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"497\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026169", timeStamp: "1500131433", hash: "0x4500abd969a6d4c3c106748d63f5d0b28c74dd8ae4333c021109ea83223881e1", nonce: "38", blockHash: "0xbbaded01ac4712e8079a002e60fb980d41816bf89231089ad75ed71f998b7d37", transactionIndex: "60", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001f10000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "3445143", gasUsed: "115525", confirmations: "3653496"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "497"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "497", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1500131433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"496\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026169", timeStamp: "1500131433", hash: "0x632d946e7c45c64e9a78a46606cbcdfb5b136a81c56a686bf9f4b36fb86616b5", nonce: "39", blockHash: "0xbbaded01ac4712e8079a002e60fb980d41816bf89231089ad75ed71f998b7d37", transactionIndex: "68", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001f00000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4200597", gasUsed: "115525", confirmations: "3653496"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "496"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "496", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1500131433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"493\", \"495\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026169", timeStamp: "1500131433", hash: "0x625c2d3c7cd7daa9752bf780df3adc8737f3802ec16e3865ed443867aaae6fda", nonce: "40", blockHash: "0xbbaded01ac4712e8079a002e60fb980d41816bf89231089ad75ed71f998b7d37", transactionIndex: "71", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ed00000000000000000000000000000000000000000000000000000000000001ef0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4358122", gasUsed: "115525", confirmations: "3653496"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "493"}, {type: "uint16", name: "col", value: "495"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "493", "495", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1500131433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [493]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"494\", \"494\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026169", timeStamp: "1500131433", hash: "0x68b2aa364e5c846351a31c2a32ad10c45176f8526ba15f3aed51afb9c8086414", nonce: "41", blockHash: "0xbbaded01ac4712e8079a002e60fb980d41816bf89231089ad75ed71f998b7d37", transactionIndex: "73", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ee00000000000000000000000000000000000000000000000000000000000001ee0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4494647", gasUsed: "115525", confirmations: "3653496"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "494"}, {type: "uint16", name: "col", value: "494"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "494", "494", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1500131433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"495\", \"494\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026170", timeStamp: "1500131441", hash: "0x7b0f642277169237448b7b6fa871c744b39e14e86be9271d3cfd767599f12fcc", nonce: "42", blockHash: "0x29ef28e9323d11c25195623b55503465a51d8688b850ab665798e8a81a5554b7", transactionIndex: "13", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001ef00000000000000000000000000000000000000000000000000000000000001ee0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "388525", gasUsed: "115525", confirmations: "3653495"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "495"}, {type: "uint16", name: "col", value: "494"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "495", "494", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1500131441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"496\", \"494\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026174", timeStamp: "1500131520", hash: "0x0aac707c1bc11ca51776a242c50448d39c2530c72fc26072a81526fe74218cd0", nonce: "43", blockHash: "0x2a5a573492f3b28b88961be6caea5c5d95ecc8967424bfb782bb50be09a1fd78", transactionIndex: "109", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000001ee0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "2743857", gasUsed: "115525", confirmations: "3653491"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "496"}, {type: "uint16", name: "col", value: "494"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "496", "494", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1500131520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [494]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"495\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026174", timeStamp: "1500131520", hash: "0xc6336a948ff964681b8f2257f37d9e5ae6a30ab1ed18772cb7756c750fadc242", nonce: "44", blockHash: "0x2a5a573492f3b28b88961be6caea5c5d95ecc8967424bfb782bb50be09a1fd78", transactionIndex: "137", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001ef0000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "4625068", gasUsed: "115525", confirmations: "3653491"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "495"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "495", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1500131520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [495]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyPixel( \"497\", \"496\", \"16749725\" )", async function( ) {
		const txOriginal = {blockNumber: "4026174", timeStamp: "1500131520", hash: "0xbfda04179613d1e1dc88c1f49228bf111af23116e9469d286b5fa3fbcb600f14", nonce: "45", blockHash: "0x2a5a573492f3b28b88961be6caea5c5d95ecc8967424bfb782bb50be09a1fd78", transactionIndex: "145", from: "0xfb993dff9898718cdd1600ff71a250138247b9da", to: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3", value: "2000000000000000", gas: "173287", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x675d43cf00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000000000000001f00000000000000000000000000000000000000000000000000000000000ff949d", contractAddress: "", cumulativeGasUsed: "5259852", gasUsed: "115525", confirmations: "3653491"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "row", value: "497"}, {type: "uint16", name: "col", value: "496"}, {type: "uint24", name: "newColor", value: "16749725"}], name: "buyPixel", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyPixel(uint16,uint16,uint24)" ]( "497", "496", "16749725", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1500131520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "PixelTransfer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PixelTransfer", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "prevOwner", type: "address", value: "0x3db54f5eeb627f1ecc3dbefc844a7e0067b30950"}, {name: "newOwner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "row", type: "uint16"}, {indexed: false, name: "col", type: "uint16"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "color", type: "uint24"}], name: "PixelColor", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PixelColor", events: [{name: "row", type: "uint16", value: {s: 1, e: 2, c: [497]}}, {name: "col", type: "uint16", value: {s: 1, e: 2, c: [496]}}, {name: "owner", type: "address", value: "0xfb993dff9898718cdd1600ff71a250138247b9da"}, {name: "color", type: "uint24", value: {s: 1, e: 7, c: [16749725]}}], address: "0xae89c8d6b98432df28242899b3688cc8e3d45ea3"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "200000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
