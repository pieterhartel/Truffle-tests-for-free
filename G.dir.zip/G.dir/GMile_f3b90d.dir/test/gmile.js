const GMile = artifacts.require( "./GMile.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "GMile" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8ba49452E12449240425DE9895b1aA51f5F3b90D", "0x8D66c8a6f62D78Fb4009229FeF76150868A6a715", "0xF7674BfFecB22c62f625974C27FF5Fb82fE0D9E6", "0x6806e17b1e2E8b4EE88E358004608f938634E119", "0x0bf7087414eCE7dddfd261aF4fAeB4785C68806d", "0x096669875d00C9EDcA7ebDAdf4dfbaeC5DeE2d51", "0x8dcc052B5DFEfcdC90e1E54eeBBE05a73C5030Ac", "0x61ED0817bCbdf6faEF7Be3822a4ac98067cAb00A", "0x5Bcb769562DAaff2243E1A8B405BFaAE13349b8C", "0xC801EeA1Ce1A40BF5BA35d87394b4B37222c95b1", "0x965d1f4e53efcae5c13899A34C00586bE53a94FB", "0x3E40af13E2F9157900C3D768cB38B660F144240B", "0xa3aB319F408A3CA0Cf6Ce94E37CE6Ae72844fd86", "0x1DD3336B8A2Cc25dCf4f6F16CB9E8812Cd49E80d", "0x992A951bc434164904aaA9fbb53b1C7195D62099", "0xb3347cf412D780549249Aa5c816c6293f553185a", "0x17313A73c75Ff5BEBb67B62ADA7dCc9F10c3D51f", "0x9886dF0b6c6A2Af60ef656513e2D34cC5Ade9169", "0x9eaC13555AB4DC3BdDB664CB288CB3C2BF1d8D51", "0x386c3F51Ec5C733987a5D04875F9a693d1Bb933f", "0x86ADA325E4C50Aa884A93Ad1f318d9A300efb009", "0x6f6F4B10C3363C72172C8abeCBd6A294E23f74A0", "0x689013902A9E26E72319a506de57F1Fdf962849A", "0x28D5D57bB644825A73B17bb517d575c3339a3522", "0x68dd7EAB1b8a58620C01725bCEc446661C4E0309", "0xe5FAEE2bFEB6C9A5b6f2FfC81A34703a65270715", "0xC88E49ccF4aAb986152300Ee15e9D46e0EdAd7e2", "0xA3904790896d44CA5F5c162fdC9Bd2fD9b101820", "0xdB5F7600ba614f118BB87a31956C2c8c46d9ab3B", "0x4856E58F3C629FFbef4a79a9e4982A35b8a93252", "0x5F426FFf4F4026A9ab99a1378652f0FC20611d16", "0x97786c7429A1367d85cB6dF475eb5037539A50cF", "0xee7345608041Da1aa0e6A6A460E62080592F5877", "0xBF9cC8073937875DFF6eDf35aFF6C49B219C96de", "0xEe9C65d5Aa29F3BC8F38bfd509BC7280A3E4812E", "0x36be7e57362aedca824cDe8023ff5cd94288bD7b", "0x9bC21E74f2C4C2C418f2C32ed0434061312c1469", "0xAa61ea346CDbafC1BE0f357B00aec1CaB07d2883", "0x59Df84A218E669F04b8Fc86d76e68343fFACC69E", "0x7eB89A9506B3D78e52b9Dc68F40BD10Fe7B3cbf8", "0xABa0031b66FbD916ed6CAaD447a58e7aF091Fe48", "0xBA9DfF11DcAC4dDfa78eeAcDfAbe42ccA47fC5e9", "0x319F2EBf9BdB7BA657dEb79679Aa8F9C99517ee1", "0x328d5AC12E0122C9A8d51c3eaF94428Bd4E27b3C", "0xFb0119aaaAb75f60000330088d79eB80Ffd26537", "0x9f9657e153A305fF66a0Ceb7c25827F9d86d8c51", "0xc74e25790C592D26b32e373DcDbC9584B2F45A85", "0x4dBd253C46360699F75Ae384d2F3Af399c366c1E", "0xd5D829D12Dcd61EbE55DBC7708117b68A0976041", "0x60e4bbF9186571b7E799287208C7fD4b36328a2a"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "standard", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "frozenAccount", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "frozen", type: "bool"}], name: "FrozenFunds", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["FrozenFunds(address,bool)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x48335238b4855f35377ed80f164e8c6f3c366e54ac00b96a6402d4a9814a03a5", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3427281 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3428592 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "initialSupply", value: "1000000000"}, {type: "string", name: "tokenName", value: "GMile"}, {type: "uint8", name: "decimalUnits", value: "0"}, {type: "string", name: "tokenSymbol", value: "GML"}], name: "GMile", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "standard", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "standard()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "frozenAccount", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "frozenAccount(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "GMile", function( accounts ) {

	it( "TEST: GMile( \"1000000000\", `GMile`, \"0\", `GML` )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3427281", timeStamp: "1490608741", hash: "0xf673536d8466ce3cbfc3e0d327a047190a96de52e08de0dd55c5a06ad8be0de2", nonce: "12", blockHash: "0xd80ddb6253e548e7b3863b2096627ddc0d03e0ea26451f128b2784908b0e25d5", transactionIndex: "2", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: 0, value: "0", gas: "4000000", gasPrice: "20947768649", isError: "0", txreceipt_status: "", input: "0xf9097ca0000000000000000000000000000000000000000000000000000000003b9aca000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000005474d696c650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003474d4c0000000000000000000000000000000000000000000000000000000000", contractAddress: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", cumulativeGasUsed: "1256175", gasUsed: "1197817", confirmations: "4246484"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "initialSupply", value: "1000000000"}, {type: "string", name: "tokenName", value: `GMile`}, {type: "uint8", name: "decimalUnits", value: "0"}, {type: "string", name: "tokenSymbol", value: `GML`}], name: "GMile", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = GMile.new( "1000000000", `GMile`, "0", `GML`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1490608741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = GMile.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428416", timeStamp: "1490625263", hash: "0xa6bc01a23fd2b8c868dada5515eb1194d9a4648072d6ed7f2c29bcc73f481bbe", nonce: "13", blockHash: "0x27f7d668cbdc359114bca1d9ced8fef211d3c0a368f228389f12b75e21485480", transactionIndex: "19", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000f7674bffecb22c62f625974c27ff5fb82fe0d9e600000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "607572", gasUsed: "52141", confirmations: "4245349"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1490625263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xf7674bffecb22c62f625974c27ff5fb82fe0d9e6"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428581", timeStamp: "1490627895", hash: "0xef6820cf9da0e4a943e1b911511379b4d77741effd613ce5de6daf3638d2feb8", nonce: "14", blockHash: "0xddac4f924670a782971755032e0a024d2e22fb208f591b20e0752b8603ef6ca9", transactionIndex: "7", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006806e17b1e2e8b4ee88e358004608f938634e11900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "421285", gasUsed: "52141", confirmations: "4245184"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1490627895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x6806e17b1e2e8b4ee88e358004608f938634e119"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428583", timeStamp: "1490627936", hash: "0x9672c05fa0b64f8b15265a6bbf06f01324c2693c6396b87cd0c089e1cec742a4", nonce: "15", blockHash: "0xb121d8dfd68cf446c209d3b3d64348f22abbce40a06cea667ba998cc686d9ef2", transactionIndex: "9", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000bf7087414ece7dddfd261af4faeb4785c68806d00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "340547", gasUsed: "52141", confirmations: "4245182"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1490627936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x0bf7087414ece7dddfd261af4faeb4785c68806d"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428583", timeStamp: "1490627936", hash: "0xe2c634129d94708b3061b3ed0982862b272a5b4c9e64bdbcd9e7ece7b3fea142", nonce: "16", blockHash: "0xb121d8dfd68cf446c209d3b3d64348f22abbce40a06cea667ba998cc686d9ef2", transactionIndex: "21", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000096669875d00c9edca7ebdadf4dfbaec5dee2d5100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "654721", gasUsed: "52077", confirmations: "4245182"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1490627936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x096669875d00c9edca7ebdadf4dfbaec5dee2d51"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428583", timeStamp: "1490627936", hash: "0x19fb1c045e6684523ddf3998b484649476128235b33e168de2be51d595e19500", nonce: "17", blockHash: "0xb121d8dfd68cf446c209d3b3d64348f22abbce40a06cea667ba998cc686d9ef2", transactionIndex: "23", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000008dcc052b5dfefcdc90e1e54eebbe05a73c5030ac00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "727862", gasUsed: "52141", confirmations: "4245182"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1490627936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x8dcc052b5dfefcdc90e1e54eebbe05a73c5030ac"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428584", timeStamp: "1490627975", hash: "0xcc793413f2020f33e94e678226c88ac989d38bc705f0114c5f782c461fa41e28", nonce: "18", blockHash: "0xaec0f31a4697df05d15e8c5661e1b2ee51e56645d01b05b4e947fa991475756c", transactionIndex: "74", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000061ed0817bcbdf6faef7be3822a4ac98067cab00a00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2637641", gasUsed: "52141", confirmations: "4245181"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1490627975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x61ed0817bcbdf6faef7be3822a4ac98067cab00a"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428584", timeStamp: "1490627975", hash: "0x74de17169f4dee7bb9c53dd8afcc92e82675ce6430a86d79052ab2a64eda0549", nonce: "19", blockHash: "0xaec0f31a4697df05d15e8c5661e1b2ee51e56645d01b05b4e947fa991475756c", transactionIndex: "85", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000005bcb769562daaff2243e1a8b405bfaae13349b8c00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3022330", gasUsed: "52141", confirmations: "4245181"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1490627975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x5bcb769562daaff2243e1a8b405bfaae13349b8c"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428585", timeStamp: "1490627991", hash: "0x8c85a04f74c8a7bee181a6a1e39cb674ed85207a610390e88991fe3fc915d0da", nonce: "20", blockHash: "0xec3799e3e946c7eca6206aa26f8f1ef2cd716188017adf264cd78fb36c149df2", transactionIndex: "13", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000c801eea1ce1a40bf5ba35d87394b4b37222c95b100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "424490", gasUsed: "52141", confirmations: "4245180"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1490627991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xc801eea1ce1a40bf5ba35d87394b4b37222c95b1"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xde1acfd1d531dbba6ce1b19f8068fc3c2ade3482cffef07a259987470ac71d29", nonce: "21", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "4", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000965d1f4e53efcae5c13899a34c00586be53a94fb00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "369128", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x965d1f4e53efcae5c13899a34c00586be53a94fb"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x467fcdd4c4075ed8852c75618dc231f49db812e0e999c1b2ec2ba0fd7c07a9f0", nonce: "22", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "37", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000003e40af13e2f9157900c3d768cb38b660f144240b00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1368137", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x3e40af13e2f9157900c3d768cb38b660f144240b"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x646d120ceb8d7507382d1d5da3bbc7bb131b98d79838547eca18fcbc8d05962d", nonce: "23", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "44", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000a3ab319f408a3ca0cf6ce94e37ce6ae72844fd8600000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1622942", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xa3ab319f408a3ca0cf6ce94e37ce6ae72844fd86"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x6537810bb89e98a3a7bb0e5bc06e7fcb92c8f12b61f1d2fba56fcdff180b962a", nonce: "24", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "48", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000001dd3336b8a2cc25dcf4f6f16cb9e8812cd49e80d00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1759923", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x1dd3336b8a2cc25dcf4f6f16cb9e8812cd49e80d"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xb946450299ec129200b192ad6bc963d35262c16eb15195251e45bca4c48d875e", nonce: "25", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "51", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000992a951bc434164904aaa9fbb53b1c7195d6209900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1854064", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x992a951bc434164904aaa9fbb53b1c7195d62099"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x6cd8519d322edd911e789ccc4b11e9e20c20b7e91378be68a90762e4f9162696", nonce: "26", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "54", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000b3347cf412d780549249aa5c816c6293f553185a00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1948205", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xb3347cf412d780549249aa5c816c6293f553185a"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x2d317a7342e33c4d25d232ebc2a8b2a3698144bde88203ae985e1715abecf450", nonce: "27", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "56", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000017313a73c75ff5bebb67b62ada7dcc9f10c3d51f00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2021346", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x17313a73c75ff5bebb67b62ada7dcc9f10c3d51f"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x82136c7d598d5cd34d3b9cc950f8f5eb908554f6ada09760fe5ec0f4b7fc05f3", nonce: "28", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "58", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009886df0b6c6a2af60ef656513e2d34cc5ade916900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2094487", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x9886df0b6c6a2af60ef656513e2d34cc5ade9169"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xcdeb1f99536b37ab97a6ff90892b97c7ec29b4fd83cde7ce9be418091574e7a0", nonce: "29", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "60", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009eac13555ab4dc3bddb664cb288cb3c2bf1d8d5100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2167628", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x9eac13555ab4dc3bddb664cb288cb3c2bf1d8d51"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x7176454f3d9a61b6cd020b985bff59073c97d2ec173bf24ab761f8c5e70dc668", nonce: "30", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "62", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000386c3f51ec5c733987a5d04875f9a693d1bb933f00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2240769", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x386c3f51ec5c733987a5d04875f9a693d1bb933f"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x73d06e60b971d84c5709cfe35efa73302579f3527aa12aa3519ea0fdb64bc50e", nonce: "31", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "64", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000086ada325e4c50aa884a93ad1f318d9a300efb00900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2313846", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x86ada325e4c50aa884a93ad1f318d9a300efb009"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x23596c9919c69e3aa36351d98eff9ecb281f3744cfd048f93a02ba787a52c747", nonce: "32", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "66", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006f6f4b10c3363c72172c8abecbd6a294e23f74a000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2386987", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x6f6f4b10c3363c72172c8abecbd6a294e23f74a0"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x8b735afd88c31d0de78602bab583f5d520e5ccd4287dd0fc8a39432ba86dea94", nonce: "33", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "68", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000689013902a9e26e72319a506de57f1fdf962849a00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2460128", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x689013902a9e26e72319a506de57f1fdf962849a"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x513e608ff33f5364ea8f2efb247bb962f27f238b8fad6a8ca2ce796e2b0bda49", nonce: "34", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "70", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000028d5d57bb644825a73b17bb517d575c3339a352200000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2534692", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x28d5d57bb644825a73b17bb517d575c3339a3522"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xef4ac0767184cd3ee659856095ff3ad3a75ebd919891d5fea0f8148ab33b6632", nonce: "35", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "72", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000068dd7eab1b8a58620c01725bcec446661c4e030900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2607833", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x68dd7eab1b8a58620c01725bcec446661c4e0309"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x844868dbfc414b35ea02790bcbe06e5553f008eae568b3e361cee029b4ca74b8", nonce: "36", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "74", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000e5faee2bfeb6c9a5b6f2ffc81a34703a6527071500000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2680974", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xe5faee2bfeb6c9a5b6f2ffc81a34703a65270715"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xdf584ab3545b55796deb01c1d5227522e4764098638b8fcaaa594e22d4d6ddcd", nonce: "37", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "76", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000c88e49ccf4aab986152300ee15e9d46e0edad7e200000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2754051", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xc88e49ccf4aab986152300ee15e9d46e0edad7e2"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xa8f94336d2b40ed2af72d925261eae1e1b5195bbdff2ecab8068be4afedc7951", nonce: "38", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "78", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000a3904790896d44ca5f5c162fdc9bd2fd9b10182000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2827192", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xa3904790896d44ca5f5c162fdc9bd2fd9b101820"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x8ccf16fa797cf99a85b72558041060f2cdfcc98bd313d57514130f10527a3b2f", nonce: "39", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "80", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000db5f7600ba614f118bb87a31956c2c8c46d9ab3b00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2900269", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xdb5f7600ba614f118bb87a31956c2c8c46d9ab3b"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x98eb71719243cff44b24e0fa199f84e1d028180d214f9f52c0d549839198b6a1", nonce: "40", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "82", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21961999998", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000004856e58f3c629ffbef4a79a9e4982a35b8a9325200000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2973410", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x4856e58f3c629ffbef4a79a9e4982a35b8a93252"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x219e8a117f4835b8c00c7e7c812e645dfe73f3adf061013464cbb2e4d7fee437", nonce: "41", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "84", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21759290737", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000005f426fff4f4026a9ab99a1378652f0fc20611d1600000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3046551", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x5f426fff4f4026a9ab99a1378652f0fc20611d16"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[33], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xf264c2509b971f1796d97ad016a6475a2f47f4c15389c692938fbf774a587832", nonce: "42", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "86", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21759290737", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000097786c7429a1367d85cb6df475eb5037539a50cf00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3119692", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[33], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x97786c7429a1367d85cb6df475eb5037539a50cf"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xde701a682126e270efa77d6bf493824c90a95548c56813341950fd30d031f0f1", nonce: "43", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "88", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21759290737", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ee7345608041da1aa0e6a6a460e62080592f587700000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3192833", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xee7345608041da1aa0e6a6a460e62080592f5877"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x4ae1e3e7b18e5fc1bcc5a47a1f28a08402dd90743e46b7c3cf56d5cd5059efcc", nonce: "44", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "90", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21759290737", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000bf9cc8073937875dff6edf35aff6c49b219c96de00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3265974", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xbf9cc8073937875dff6edf35aff6c49b219c96de"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[36], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x4279b930e677089670bf42cf97080faaf6dc277d6bb75371df61028b4ad53f7f", nonce: "45", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "92", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ee9c65d5aa29f3bc8f38bfd509bc7280a3e4812e00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3339115", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[36], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xee9c65d5aa29f3bc8f38bfd509bc7280a3e4812e"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"250\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xe63e1c71d7d36f7597ba9d95f49705b5e0412f29bc67fb475418abe1f10c0545", nonce: "46", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "94", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000689013902a9e26e72319a506de57f1fdf962849a00000000000000000000000000000000000000000000000000000000000000fa", contractAddress: "", cumulativeGasUsed: "3397192", gasUsed: "37077", confirmations: "4245176"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "250"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "250", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x689013902a9e26e72319a506de57f1fdf962849a"}, {name: "value", type: "uint256", value: "250"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x3779bbe6e2a203d7fe5a2c278e00bbbd60ad8a5c0d35cedff034c4523f2e0552", nonce: "47", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "96", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000036be7e57362aedca824cde8023ff5cd94288bd7b00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3470333", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x36be7e57362aedca824cde8023ff5cd94288bd7b"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x7cb9fc6f6aae5d05b90ccb7030fa6faba75519b7fe726a0ba1006bab27777d8d", nonce: "48", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "98", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009bc21e74f2c4c2c418f2c32ed0434061312c146900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3543474", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x9bc21e74f2c4c2c418f2c32ed0434061312c1469"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xd3994181bdd4bb80cea4e255bb9e1bb07ab566540ae2b996c71e7523add26e30", nonce: "49", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "100", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000aa61ea346cdbafc1be0f357b00aec1cab07d288300000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3616551", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xaa61ea346cdbafc1be0f357b00aec1cab07d2883"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x372d2584efd493b8e95ae4576d52d58446d66fcf70ac4f5753898b1a6a272cc3", nonce: "50", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "102", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000059df84a218e669f04b8fc86d76e68343ffacc69e00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3689692", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x59df84a218e669f04b8fc86d76e68343ffacc69e"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x6e7c9447d821165be27dd4fdc09e44d8d1cccb14804853f4639d8d5c732ebbff", nonce: "51", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "104", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000007eb89a9506b3d78e52b9dc68f40bd10fe7b3cbf800000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3762833", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[41], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x7eb89a9506b3d78e52b9dc68f40bd10fe7b3cbf8"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xbee6ddc017e1d005b642939a000df2404c6b57df662efd79b498cdc4e2731598", nonce: "52", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "106", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000aba0031b66fbd916ed6caad447a58e7af091fe4800000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3835974", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[42], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xaba0031b66fbd916ed6caad447a58e7af091fe48"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xe619b290294bcab329b4850f406b0535632eb18870061f02db0e93b4cc64cba7", nonce: "53", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "108", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ba9dff11dcac4ddfa78eeacdfabe42cca47fc5e900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3909115", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[43], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xba9dff11dcac4ddfa78eeacdfabe42cca47fc5e9"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xd20dc33541c513c5ef15c00b395c9a8d44d01779e873985df61d06c68464d8ad", nonce: "54", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "109", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000319f2ebf9bdb7ba657deb79679aa8f9c99517ee100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3961256", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[44], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x319f2ebf9bdb7ba657deb79679aa8f9c99517ee1"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0x5a9974f16183735579348ccf44f7b3c0b286aaa35a8dceeb3b28a13742cdcc1e", nonce: "55", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "110", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000328d5ac12e0122c9a8d51c3eaf94428bd4e27b3c00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "4013397", gasUsed: "52141", confirmations: "4245176"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x328d5ac12e0122c9a8d51c3eaf94428bd4e27b3c"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428589", timeStamp: "1490628046", hash: "0xde1822fa1ff6b333d9100d703e7f89ce936216491359bffa767a55b7331a3f7b", nonce: "56", blockHash: "0xae32ed25c70dea34adc2fb4feece6544ee4f871e646bb51b9df58315dc30880c", transactionIndex: "111", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000fb0119aaaab75f60000330088d79eb80ffd2653700000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "4065474", gasUsed: "52077", confirmations: "4245176"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[46], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1490628046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xfb0119aaaab75f60000330088d79eb80ffd26537"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[47], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428592", timeStamp: "1490628056", hash: "0x1799e7e55220f601961bb6502d958164e6e372bce79c909af6f73a08563f6338", nonce: "57", blockHash: "0xbda819a95a3f11591db4782669b39ce591719eb628a5bed1bc2ab167d5980ddc", transactionIndex: "3", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009f9657e153a305ff66a0ceb7c25827f9d86d8c5100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "119555", gasUsed: "52141", confirmations: "4245173"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[47]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[47], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1490628056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x9f9657e153a305ff66a0ceb7c25827f9d86d8c51"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428592", timeStamp: "1490628056", hash: "0x60589c339109c6c755288c958f72599bc80cefee55f8d25d0676404719cf7340", nonce: "58", blockHash: "0xbda819a95a3f11591db4782669b39ce591719eb628a5bed1bc2ab167d5980ddc", transactionIndex: "6", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000c74e25790c592d26b32e373dcdbc9584b2f45a8500000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "213696", gasUsed: "52141", confirmations: "4245173"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1490628056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xc74e25790c592d26b32e373dcdbc9584b2f45a85"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[49], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428592", timeStamp: "1490628056", hash: "0x53e1b96491d9e912b28a3d456f31ff9e8339ed61f2d353eaedc017fa3159250e", nonce: "59", blockHash: "0xbda819a95a3f11591db4782669b39ce591719eb628a5bed1bc2ab167d5980ddc", transactionIndex: "8", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000004dbd253c46360699f75ae384d2f3af399c366c1e00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "286837", gasUsed: "52141", confirmations: "4245173"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[49]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[49], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1490628056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x4dbd253c46360699f75ae384d2f3af399c366c1e"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[50], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428592", timeStamp: "1490628056", hash: "0x409f6526956bb1f85dc21e3c0e9af3f21f80aaade1bdbfa6f9ab3dca7684df4d", nonce: "60", blockHash: "0xbda819a95a3f11591db4782669b39ce591719eb628a5bed1bc2ab167d5980ddc", transactionIndex: "9", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d5d829d12dcd61ebe55dbc7708117b68a097604100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "338978", gasUsed: "52141", confirmations: "4245173"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[50]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[50], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1490628056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0xd5d829d12dcd61ebe55dbc7708117b68a0976041"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "3428592", timeStamp: "1490628056", hash: "0x64f24bae3ebdc3f966e0df67bfdcb4ff9c41783549fec7c765caacacb27f0658", nonce: "61", blockHash: "0xbda819a95a3f11591db4782669b39ce591719eb628a5bed1bc2ab167d5980ddc", transactionIndex: "10", from: "0x8d66c8a6f62d78fb4009229fef76150868a6a715", to: "0x8ba49452e12449240425de9895b1aa51f5f3b90d", value: "0", gas: "90000", gasPrice: "21549095988", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000060e4bbf9186571b7e799287208c7fd4b36328a2a00000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "391119", gasUsed: "52141", confirmations: "4245173"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[51]}, {type: "uint256", name: "_value", value: "1000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1490628056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x8d66c8a6f62d78fb4009229fef76150868a6a715"}, {name: "to", type: "address", value: "0x60e4bbf9186571b7e799287208c7fd4b36328a2a"}, {name: "value", type: "uint256", value: "1000"}], address: "0x8ba49452e12449240425de9895b1aa51f5f3b90d"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "822577611347967553" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "8720000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
