const Game = artifacts.require( "./Game.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Game" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xc741BC7FA502DDCF2D5CC9E2c70f0EE7090CFd0D", "0x1Be992Fc3547D2BD687518CC1c9BD1C29F8377a3", "0x5BFa4069020749acfFf62596368eFc65ded87bA1", "0x6c6Fb232cc0517F0Cdea1B40bBeC3Df004eDEb0e", "0x46992A42784657602f71b8005ABE1C7ce8b0Ec22", "0xC7B9e1fFA159d8a8100942ec2e68e47cb0eC33B0", "0xC2E88F19cC2E07C3911cBe084167d61edA9F64e3", "0xBcF5617Bb9FbA43243fE9Fcdf7218fE5865Ab59D", "0x7FCc41fdd97E9d04020dA833Ae4D04B027f1a0A9", "0xc9EcA8224367Fc77CCfa4Cb8D4dbD034D413ab93", "0xD6Ef04f7E21ffe8Df057da2b0Af49410fB9eb1bC", "0x878c01Cbf7d7A407c661280C5b952c0891D92A32", "0xcA2de2472D2d2FAB45996ec0429e06b23C37d5Ff", "0x1Eed37985F76990BBCaf68f83b82Bd82403e1565", "0x4F61fBA36D4E5D71d4FE6F36F9CA90183fEC1406"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "period", type: "uint256"}, {name: "player", type: "address"}], name: "getPlayerCommitted", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}, {name: "offset", type: "uint256"}], name: "getPlayerOrigin", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}, {name: "offset", type: "uint256"}], name: "getPlayerAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getMinAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getGamePeriod", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}, {name: "offset", type: "uint256"}], name: "getPlayerHash", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getContractBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}, {name: "offset", type: "uint256"}], name: "getPlayerValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCommitPhase", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getLuckUser", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getPrizeAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getStartBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBetPhase", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getFinished", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getRandom", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "x", type: "bytes32"}], name: "getsha3", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}], name: "getPlayerNum", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "period", type: "uint256"}, {name: "player", type: "address"}], name: "getPlayerReturned", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["StartGame(uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "Play(uint256,bytes32,uint256,bytes32,address)", "CommitOrigin(address,bytes32,uint256,bytes32,uint256)", "Open(address,bytes32,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9e81aea47a23d34e26feeb2ee500af6cb515fbba3980cd2c10fa6fdcba3b897e", "0x618cb075010cddac61bab4bbd0b922170f54003d179351650a7271877bb91c7e", "0xb9ec8de8310881abb5a9d9029c3a53d86cd2ba1aaf74aa843fcf0063912a57ea", "0xeb6dd3eaf3e68e0d2773121f6bccf7413ad91460e82d0f35f77d225d9dff3252"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6776968 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6828143 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Game", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerCommitted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerCommitted(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "uint256", name: "offset", value: random.range( maxRandom )}], name: "getPlayerOrigin", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerOrigin(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "uint256", name: "offset", value: random.range( maxRandom )}], name: "getPlayerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerAddress(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getMinAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMinAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getGamePeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGamePeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "uint256", name: "offset", value: random.range( maxRandom )}], name: "getPlayerHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerHash(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getContractBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getContractBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "uint256", name: "offset", value: random.range( maxRandom )}], name: "getPlayerValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerValue(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCommitPhase", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCommitPhase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getLuckUser", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLuckUser(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getPrizeAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPrizeAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getStartBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStartBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBetPhase", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBetPhase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getFinished", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFinished()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getRandom", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRandom(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "x", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getsha3", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getsha3(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}], name: "getPlayerNum", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerNum(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "period", value: random.range( maxRandom )}, {type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerReturned", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerReturned(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Game", function( accounts ) {

	it( "TEST: Game(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6776968", timeStamp: "1543247235", hash: "0x44a62cecf2c88e377208c4283d30634f90ea49619b904a0f7aecf988ab3379e2", nonce: "1450", blockHash: "0xd50bd9951760a4a12915f052f10dcd010d8d142ab8981d40151468ba70b4f489", transactionIndex: "145", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: 0, value: "0", gas: "2381995", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xaef99eef", contractAddress: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", cumulativeGasUsed: "6933823", gasUsed: "2381995", confirmations: "926756"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Game", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Game.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543247235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Game.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"5\", \"5\", \"48\", \"1\", \"90\" )", async function( ) {
		const txOriginal = {blockNumber: "6777035", timeStamp: "1543248143", hash: "0x5fcd8aa0d9742426c26be1bc8fd78a1c7ffbf85a42f98a97dec654913dac83fa", nonce: "1451", blockHash: "0x4894c5b93ee12425d27cd6e0e99226e3a1b1f7c086ab8015914413c33db40abf", transactionIndex: "55", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "3213993", gasUsed: "83310", confirmations: "926689"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "5"}, {type: "uint256", name: "iCommitPhase", value: "5"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "5", "5", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543248143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "1"}, {name: "betPhase", type: "uint256", value: "5"}, {name: "commitPhase", type: "uint256", value: "5"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6777035"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6777057", timeStamp: "1543248420", hash: "0xf44bbc146cd489b41c0cc840185674187c4846466c2ee705536716af6ea4b9fc", nonce: "1452", blockHash: "0x64b9d797579b4acc92ebf35584bffecdfa7a990766c7a1e356c6c9d3dc0b34df", transactionIndex: "71", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3287230", gasUsed: "95408", confirmations: "926667"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543248420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "random", type: "bytes32", value: "0x290decd9548b62a8d60345a988386fc84ba6bc95484008f6362f93160ef3e563"}, {name: "prize", type: "uint256", value: "0"}, {name: "id", type: "uint256", value: "1"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"24\", \"24\", \"48\", \"1\", \"90\" )", async function( ) {
		const txOriginal = {blockNumber: "6777067", timeStamp: "1543248596", hash: "0x1333d5ba458c2a74cf8c2e9351eebbfb92d84c515a4610cfb60f236c79967b9e", nonce: "1453", blockHash: "0xe6a6d2b2928a61dde4a821335a3202b5f49a6a4f4af4b5ef202d76c184a10b4b", transactionIndex: "6", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "301147", gasUsed: "53310", confirmations: "926657"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "24"}, {type: "uint256", name: "iCommitPhase", value: "24"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "24", "24", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543248596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "2"}, {name: "betPhase", type: "uint256", value: "24"}, {name: "commitPhase", type: "uint256", value: "24"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6777067"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"2\", \"0x1b3adba63cfe196d8639669bb22e2... )", async function( ) {
		const txOriginal = {blockNumber: "6777091", timeStamp: "1543248941", hash: "0x98e56fc6e5dd93d9857a4bd453b204d8bd4a477883368505c291cf3f5dfb3eb9", nonce: "1454", blockHash: "0x7a1f7fdac8cc9455d44653775dea8e1dc978d6f4f50858cab2f6dc6a7be7c152", transactionIndex: "98", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000021b3adba63cfe196d8639669bb22e2f0a12641b047a5f76385fc62d158c0e636cb167e4e98e644a732028c1d6b45d3c21028bb6679de9c6842c9785040236ab49", contractAddress: "", cumulativeGasUsed: "7572068", gasUsed: "251789", confirmations: "926633"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "bytes32", name: "hash", value: "0x1b3adba63cfe196d8639669bb22e2f0a12641b047a5f76385fc62d158c0e636c"}, {type: "bytes32", name: "sid", value: "0xb167e4e98e644a732028c1d6b45d3c21028bb6679de9c6842c9785040236ab49"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "2", "0x1b3adba63cfe196d8639669bb22e2f0a12641b047a5f76385fc62d158c0e636c", "0xb167e4e98e644a732028c1d6b45d3c21028bb6679de9c6842c9785040236ab49", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543248941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x1b3adba63cfe196d8639669bb22e2f0a12641b047a5f76385fc62d158c0e636c"}, {name: "id", type: "uint256", value: "2"}, {name: "sid", type: "bytes32", value: "0xb167e4e98e644a732028c1d6b45d3c21028bb6679de9c6842c9785040236ab49"}, {name: "player", type: "address", value: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6777125", timeStamp: "1543249441", hash: "0x4e55a4fc9ce20a63ad6c6a14c3b8b04e9c4530c6e2a8a7c31c8cfa57608e36c8", nonce: "1455", blockHash: "0xc84ddfdc2b7c3c7f498b347bcf144577dfebbb8746ef2d8b2479f076825f02fd", transactionIndex: "32", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3118877", gasUsed: "126656", confirmations: "926599"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543249441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "random", type: "bytes32", value: "0x290decd9548b62a8d60345a988386fc84ba6bc95484008f6362f93160ef3e563"}, {name: "prize", type: "uint256", value: "0"}, {name: "id", type: "uint256", value: "2"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"24\", \"24\", \"48\", \"1\", \"90\" )", async function( ) {
		const txOriginal = {blockNumber: "6777132", timeStamp: "1543249550", hash: "0xa54bcb447aec5dba4854ceb5ae81def3834b9ce899cb384539a3bb650ade95b1", nonce: "1456", blockHash: "0x16a53bfec384793d98a77645e069bd355386287f3c34dbe40b7fe6a4b8023cda", transactionIndex: "13", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "567821", gasUsed: "53310", confirmations: "926592"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "24"}, {type: "uint256", name: "iCommitPhase", value: "24"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "24", "24", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543249550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "3"}, {name: "betPhase", type: "uint256", value: "24"}, {name: "commitPhase", type: "uint256", value: "24"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6777132"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"3\", \"0x2601fc6f8eabffbc5ff51ee1fbcd4... )", async function( ) {
		const txOriginal = {blockNumber: "6777143", timeStamp: "1543249673", hash: "0x30eb83e0c5d2cf36b8132b1953c09deb7cd3ab906bfa5b9e793be90c61a55317", nonce: "1457", blockHash: "0x2bf1be838fdc9272e2f4676482b74a8b84c6097567b9b833e4d0b78ed0eb9644", transactionIndex: "36", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000032601fc6f8eabffbc5ff51ee1fbcd4aaaab9166e6e2b07ce28541c499c2898c244ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", contractAddress: "", cumulativeGasUsed: "3715607", gasUsed: "251789", confirmations: "926581"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bytes32", name: "hash", value: "0x2601fc6f8eabffbc5ff51ee1fbcd4aaaab9166e6e2b07ce28541c499c2898c24"}, {type: "bytes32", name: "sid", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "3", "0x2601fc6f8eabffbc5ff51ee1fbcd4aaaab9166e6e2b07ce28541c499c2898c24", "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543249673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x2601fc6f8eabffbc5ff51ee1fbcd4aaaab9166e6e2b07ce28541c499c2898c24"}, {name: "id", type: "uint256", value: "3"}, {name: "sid", type: "bytes32", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}, {name: "player", type: "address", value: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"3\", \"0x78034186f904c7940c8c3eb54bd58... )", async function( ) {
		const txOriginal = {blockNumber: "6777147", timeStamp: "1543249711", hash: "0x0623b36608e1df427e6d1b3cc3780a9c88497cc0f1877cef7772179dbb56f5b6", nonce: "9", blockHash: "0x484407fa299aa96642231b184d48e2ca259f3dc050bf577576c730e0ad2950f3", transactionIndex: "102", from: "0x5bfa4069020749acfff62596368efc65ded87ba1", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000378034186f904c7940c8c3eb54bd58da0a7f1077739834282f4fc6b1126095c7f4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", contractAddress: "", cumulativeGasUsed: "6231014", gasUsed: "121412", confirmations: "926577"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bytes32", name: "hash", value: "0x78034186f904c7940c8c3eb54bd58da0a7f1077739834282f4fc6b1126095c7f"}, {type: "bytes32", name: "sid", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "3", "0x78034186f904c7940c8c3eb54bd58da0a7f1077739834282f4fc6b1126095c7f", "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543249711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x78034186f904c7940c8c3eb54bd58da0a7f1077739834282f4fc6b1126095c7f"}, {name: "id", type: "uint256", value: "3"}, {name: "sid", type: "bytes32", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}, {name: "player", type: "address", value: "0x5bfa4069020749acfff62596368efc65ded87ba1"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "711462183516220265" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6777187", timeStamp: "1543250315", hash: "0x676d1022e2991f16f4de35d0c685a0d071e4cce0494969584a71d1cfa44c99d5", nonce: "1458", blockHash: "0x76ee43ca6ba26060432d32747e163485c859baf86589d954c51223f34489b794", transactionIndex: "43", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1950732", gasUsed: "157763", confirmations: "926537"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543250315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "random", type: "bytes32", value: "0x290decd9548b62a8d60345a988386fc84ba6bc95484008f6362f93160ef3e563"}, {name: "prize", type: "uint256", value: "0"}, {name: "id", type: "uint256", value: "3"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"6000\", \"6000\", \"48\", \"1\", \"90\... )", async function( ) {
		const txOriginal = {blockNumber: "6777197", timeStamp: "1543250418", hash: "0xb9a601eeabfa18b2630bcaebc865b272f338966565b71f0f17cc20b383d92b01", nonce: "1459", blockHash: "0x8d4516b1cc73d9df470e2866e2517a45a2d2540bfb7e01f6adaf19da62abe1c3", transactionIndex: "28", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000001770000000000000000000000000000000000000000000000000000000000000177000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "1621959", gasUsed: "53438", confirmations: "926527"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "6000"}, {type: "uint256", name: "iCommitPhase", value: "6000"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "6000", "6000", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543250418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "4"}, {name: "betPhase", type: "uint256", value: "6000"}, {name: "commitPhase", type: "uint256", value: "6000"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6777197"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"4\", \"0x690212b176365efc1e6034ec41ed9... )", async function( ) {
		const txOriginal = {blockNumber: "6779344", timeStamp: "1543280678", hash: "0xc1f5d7026bcad903ecf0cbab4a4e2c3b95aed569b0efb8c5afd19e20ffd74501", nonce: "10", blockHash: "0x0034261014bfbc9ae4f041d9e27e92ee494720b3dd37634b9404a9ece3693a36", transactionIndex: "46", from: "0x5bfa4069020749acfff62596368efc65ded87ba1", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000004690212b176365efc1e6034ec41ed960044a1891d0335ac24836b81873420ebd04ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", contractAddress: "", cumulativeGasUsed: "2064999", gasUsed: "251725", confirmations: "924380"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bytes32", name: "hash", value: "0x690212b176365efc1e6034ec41ed960044a1891d0335ac24836b81873420ebd0"}, {type: "bytes32", name: "sid", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "4", "0x690212b176365efc1e6034ec41ed960044a1891d0335ac24836b81873420ebd0", "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543280678 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x690212b176365efc1e6034ec41ed960044a1891d0335ac24836b81873420ebd0"}, {name: "id", type: "uint256", value: "4"}, {name: "sid", type: "bytes32", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}, {name: "player", type: "address", value: "0x5bfa4069020749acfff62596368efc65ded87ba1"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "711462183516220265" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"4\", \"0x959ca475a77681e8756bb58e1d844... )", async function( ) {
		const txOriginal = {blockNumber: "6785292", timeStamp: "1543366568", hash: "0x763dcb6302ed28951f89f73ee8d5f350eaaa9a1d00f07f1abf8af6fbe868b9d4", nonce: "11", blockHash: "0x2d2d75ed2d8f335b7d66740bf7eea530206fb7244fa3b5e110a93d50810fce8e", transactionIndex: "31", from: "0x5bfa4069020749acfff62596368efc65ded87ba1", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x25f227800000000000000000000000000000000000000000000000000000000000000004959ca475a77681e8756bb58e1d8444c70473d9b2c657582630a848b647965ab64ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", contractAddress: "", cumulativeGasUsed: "3893713", gasUsed: "112722", confirmations: "918432"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bytes32", name: "origin", value: "0x959ca475a77681e8756bb58e1d8444c70473d9b2c657582630a848b647965ab6"}, {type: "bytes32", name: "sid", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "4", "0x959ca475a77681e8756bb58e1d8444c70473d9b2c657582630a848b647965ab6", "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543366568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x5bfa4069020749acfff62596368efc65ded87ba1"}, {name: "origin", type: "bytes32", value: "0x959ca475a77681e8756bb58e1d8444c70473d9b2c657582630a848b647965ab6"}, {name: "num", type: "uint256", value: "1"}, {name: "sid", type: "bytes32", value: "0x4ce4727b32b947ee117e59168d20038abc77d10ec744c83d223b116425436629"}, {name: "id", type: "uint256", value: "4"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "711462183516220265" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6789207", timeStamp: "1543423241", hash: "0xae08156a4d8032e131ae610f6fabe44f6db73633af645758939cd9d2c8e747b8", nonce: "1460", blockHash: "0x0a3e4641d86657203ca962e95d6a9b23c8292e2fc9fa64dd071f6e3b82a0bd65", transactionIndex: "64", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "3028645", gasUsed: "111975", confirmations: "914517"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543423241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x5bfa4069020749acfff62596368efc65ded87ba1"}, {name: "random", type: "bytes32", value: "0x690212b176365efc1e6034ec41ed960044a1891d0335ac24836b81873420ebd0"}, {name: "prize", type: "uint256", value: "9000000000000000"}, {name: "id", type: "uint256", value: "4"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"6000\", \"6000\", \"48\", \"1\", \"90\... )", async function( ) {
		const txOriginal = {blockNumber: "6789215", timeStamp: "1543423340", hash: "0xa1799fe0055d5a7237e715168ca78520702bdda6b1d3903c689c95e85b23da12", nonce: "1461", blockHash: "0x73378eabe32566d8142f2bddd93771d9421c981a05523303d8b92f3ceb81b672", transactionIndex: "31", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000001770000000000000000000000000000000000000000000000000000000000000177000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "2139428", gasUsed: "53438", confirmations: "914509"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "6000"}, {type: "uint256", name: "iCommitPhase", value: "6000"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "6000", "6000", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543423340 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "5"}, {name: "betPhase", type: "uint256", value: "6000"}, {name: "commitPhase", type: "uint256", value: "6000"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6789215"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"5\", \"0xb71fe4547d1f91c8976f721c65e25... )", async function( ) {
		const txOriginal = {blockNumber: "6794268", timeStamp: "1543493740", hash: "0x2906984cb0056b0191e28c9a7340f68293c5a8db3d9ae19a1aeb8ba76231ab60", nonce: "0", blockHash: "0x920df5df00944e7d600cc6a82d85a4f2c0d0a0ef021fe190717fde4964efcdf7", transactionIndex: "192", from: "0x6c6fb232cc0517f0cdea1b40bbec3df004edeb0e", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000005b71fe4547d1f91c8976f721c65e254364ab37f8ffbc78750521aabffc72fdef67cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083", contractAddress: "", cumulativeGasUsed: "7890318", gasUsed: "251789", confirmations: "909456"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bytes32", name: "hash", value: "0xb71fe4547d1f91c8976f721c65e254364ab37f8ffbc78750521aabffc72fdef6"}, {type: "bytes32", name: "sid", value: "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "5", "0xb71fe4547d1f91c8976f721c65e254364ab37f8ffbc78750521aabffc72fdef6", "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543493740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0xb71fe4547d1f91c8976f721c65e254364ab37f8ffbc78750521aabffc72fdef6"}, {name: "id", type: "uint256", value: "5"}, {name: "sid", type: "bytes32", value: "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083"}, {name: "player", type: "address", value: "0x6c6fb232cc0517f0cdea1b40bbec3df004edeb0e"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"5\", \"0x5420238d7ce7a284b43fca598b4d9... )", async function( ) {
		const txOriginal = {blockNumber: "6794270", timeStamp: "1543493781", hash: "0x337f3ca9d401519cbc741c888f6200ea27a5c65f0a2d18cdb2a26bef63ffe429", nonce: "0", blockHash: "0x17bd9a3e15d3241bcc76476484d8fa8a09a6737a8e8be7911f84e9b4db907cc0", transactionIndex: "50", from: "0x46992a42784657602f71b8005abe1c7ce8b0ec22", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000055420238d7ce7a284b43fca598b4d98c863e4e76e0a3923a10ebea3d3243fa8fa3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166", contractAddress: "", cumulativeGasUsed: "7485853", gasUsed: "121348", confirmations: "909454"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bytes32", name: "hash", value: "0x5420238d7ce7a284b43fca598b4d98c863e4e76e0a3923a10ebea3d3243fa8fa"}, {type: "bytes32", name: "sid", value: "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "5", "0x5420238d7ce7a284b43fca598b4d98c863e4e76e0a3923a10ebea3d3243fa8fa", "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543493781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x5420238d7ce7a284b43fca598b4d98c863e4e76e0a3923a10ebea3d3243fa8fa"}, {name: "id", type: "uint256", value: "5"}, {name: "sid", type: "bytes32", value: "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166"}, {name: "player", type: "address", value: "0x46992a42784657602f71b8005abe1c7ce8b0ec22"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"5\", \"0x6169fb0e00f1a83e52825668a655c... )", async function( ) {
		const txOriginal = {blockNumber: "6797712", timeStamp: "1543543549", hash: "0xb22ba720f33fa3d5ae3f7d5cf81d4f73a295a4f48fc7caa7f7b870ecebb138a5", nonce: "2", blockHash: "0x00eb6e9bcf43e7514aa59df7fcc9a05a830ddfb133395f0cb2fc09180597406f", transactionIndex: "39", from: "0x46992a42784657602f71b8005abe1c7ce8b0ec22", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000056169fb0e00f1a83e52825668a655c2c8b8fe9cf44020d48f11b9d8fb26c9d2623a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166", contractAddress: "", cumulativeGasUsed: "2644314", gasUsed: "112594", confirmations: "906012"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bytes32", name: "origin", value: "0x6169fb0e00f1a83e52825668a655c2c8b8fe9cf44020d48f11b9d8fb26c9d262"}, {type: "bytes32", name: "sid", value: "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "5", "0x6169fb0e00f1a83e52825668a655c2c8b8fe9cf44020d48f11b9d8fb26c9d262", "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543543549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x46992a42784657602f71b8005abe1c7ce8b0ec22"}, {name: "origin", type: "bytes32", value: "0x6169fb0e00f1a83e52825668a655c2c8b8fe9cf44020d48f11b9d8fb26c9d262"}, {name: "num", type: "uint256", value: "1"}, {name: "sid", type: "bytes32", value: "0x3a1e4d31a079001737b55dba5d38e743049da87501b70c7c7f5a754d3a234166"}, {name: "id", type: "uint256", value: "5"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"5\", \"0x5be2d58beaed904aaf9747c93fd5a... )", async function( ) {
		const txOriginal = {blockNumber: "6797712", timeStamp: "1543543549", hash: "0x73920a25c89ecdea3c642c65e6ee7174258c0c95ee0b7cc7735dea33d3d9cd9f", nonce: "2", blockHash: "0x00eb6e9bcf43e7514aa59df7fcc9a05a830ddfb133395f0cb2fc09180597406f", transactionIndex: "40", from: "0x6c6fb232cc0517f0cdea1b40bbec3df004edeb0e", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000055be2d58beaed904aaf9747c93fd5a7491c934264974780325303f13a27cf7bb97cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083", contractAddress: "", cumulativeGasUsed: "2727036", gasUsed: "82722", confirmations: "906012"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bytes32", name: "origin", value: "0x5be2d58beaed904aaf9747c93fd5a7491c934264974780325303f13a27cf7bb9"}, {type: "bytes32", name: "sid", value: "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "5", "0x5be2d58beaed904aaf9747c93fd5a7491c934264974780325303f13a27cf7bb9", "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543543549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x6c6fb232cc0517f0cdea1b40bbec3df004edeb0e"}, {name: "origin", type: "bytes32", value: "0x5be2d58beaed904aaf9747c93fd5a7491c934264974780325303f13a27cf7bb9"}, {name: "num", type: "uint256", value: "2"}, {name: "sid", type: "bytes32", value: "0x7cb07e0b02502c7260d9b42dcfccb21e48f1d48eed920a31259657abe16e1083"}, {name: "id", type: "uint256", value: "5"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6801225", timeStamp: "1543593649", hash: "0x93baa17b273ade17b4463e4c5f2f369e0632dcf9f68447bd5f2a068223b501da", nonce: "1462", blockHash: "0x9923502953ce58a371add0688cb30866fda2ab4453dc61ff8c6d44408fbca91e", transactionIndex: "105", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3190716", gasUsed: "115001", confirmations: "902499"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543593649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x46992a42784657602f71b8005abe1c7ce8b0ec22"}, {name: "random", type: "bytes32", value: "0x5c88ee92513dda556e1b5f7d2e5dabcc2117172626206e6d9cd30a016f8d52d9"}, {name: "prize", type: "uint256", value: "18000000000000000"}, {name: "id", type: "uint256", value: "5"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"6000\", \"6000\", \"48\", \"1\", \"90\... )", async function( ) {
		const txOriginal = {blockNumber: "6801239", timeStamp: "1543593895", hash: "0x82db4978d817ec332c1267da91d6b919a3cc13f30cb1408f45570ea282c4d2da", nonce: "1463", blockHash: "0x2e07e9d56e8454bfbd76b7addd7bbfadd7b9f30950621abf22a70b97b948deaa", transactionIndex: "38", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000001770000000000000000000000000000000000000000000000000000000000000177000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "2375195", gasUsed: "53438", confirmations: "902485"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "6000"}, {type: "uint256", name: "iCommitPhase", value: "6000"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "6000", "6000", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543593895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "6"}, {name: "betPhase", type: "uint256", value: "6000"}, {name: "commitPhase", type: "uint256", value: "6000"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6801239"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6813252", timeStamp: "1543765887", hash: "0x7ebf6238d27bbc82d0860dc49f6e95dd81db16105b9b3ca5c4505d06072ffbe6", nonce: "1464", blockHash: "0xc57a7a1ca44a05d673c5730ff768e20a2f268f2ffe27fa951030db3b4b22687f", transactionIndex: "46", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "5687500000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3204448", gasUsed: "95408", confirmations: "890472"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "6"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543765887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "random", type: "bytes32", value: "0x290decd9548b62a8d60345a988386fc84ba6bc95484008f6362f93160ef3e563"}, {name: "prize", type: "uint256", value: "0"}, {name: "id", type: "uint256", value: "6"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"6000\", \"6000\", \"48\", \"1\", \"90\... )", async function( ) {
		const txOriginal = {blockNumber: "6813261", timeStamp: "1543765966", hash: "0xa3231fa37c2d5f33ba70653382d241691bfe7f5702b0686bc0b2a30efdf10396", nonce: "1465", blockHash: "0x3b1d78a3998fc9836c3468ee3ca5f2e44f8820888d9633ef026869e0f5acd89c", transactionIndex: "50", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "4900000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e630000000000000000000000000000000000000000000000000000000000001770000000000000000000000000000000000000000000000000000000000000177000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000005a", contractAddress: "", cumulativeGasUsed: "3379226", gasUsed: "53438", confirmations: "890463"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "6000"}, {type: "uint256", name: "iCommitPhase", value: "6000"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "90"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "6000", "6000", "48", "1", "90", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543765966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "7"}, {name: "betPhase", type: "uint256", value: "6000"}, {name: "commitPhase", type: "uint256", value: "6000"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "90"}, {name: "startBlock", type: "uint256", value: "6813261"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x596e8f2368e814924f1847c01abf7... )", async function( ) {
		const txOriginal = {blockNumber: "6817082", timeStamp: "1543819991", hash: "0x6b34c8fd414649057f402b2c9038a23e497d65faa1d9d80e0a50e301810bd97e", nonce: "0", blockHash: "0xb01ed70d97c7aa9ed53b98349eb3a6d536d6354309b7ed62883f6532cece9497", transactionIndex: "162", from: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000007596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc9884ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", contractAddress: "", cumulativeGasUsed: "7843154", gasUsed: "251789", confirmations: "886642"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988"}, {type: "bytes32", name: "sid", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988", "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543819991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}, {name: "player", type: "address", value: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x38be71907080caca967636da60e2a... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0x24e18310c3d1d3ec1618f97329481657b91148ef486db08e8719ecb2956edcd4", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "7", from: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000738be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", contractAddress: "", cumulativeGasUsed: "542312", gasUsed: "121348", confirmations: "886640"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc"}, {type: "bytes32", name: "sid", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc", "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}, {name: "player", type: "address", value: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x8c0cd0727e3408a02bf69baf6cbf5... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0xcdfe6cccc70123129e081a07438c8f344b43606411870bb1bb7f4ddbfb8f5368", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "8", from: "0xbcf5617bb9fba43243fe9fcdf7218fe5865ab59d", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000078c0cd0727e3408a02bf69baf6cbf504113ca30da5246367716b0f055d589c119cbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06", contractAddress: "", cumulativeGasUsed: "664019", gasUsed: "121707", confirmations: "886640"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x8c0cd0727e3408a02bf69baf6cbf504113ca30da5246367716b0f055d589c119"}, {type: "bytes32", name: "sid", value: "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x8c0cd0727e3408a02bf69baf6cbf504113ca30da5246367716b0f055d589c119", "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x8c0cd0727e3408a02bf69baf6cbf504113ca30da5246367716b0f055d589c119"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06"}, {name: "player", type: "address", value: "0xbcf5617bb9fba43243fe9fcdf7218fe5865ab59d"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x7f24005483a345a570459d9db6885... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0x59501bf2335c2300add54e1232083d3b500366399d13733c36fd72f1051c546f", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "9", from: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000077f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c14345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", contractAddress: "", cumulativeGasUsed: "785958", gasUsed: "121939", confirmations: "886640"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1"}, {type: "bytes32", name: "sid", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1", "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}, {name: "player", type: "address", value: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x4874d3b044bd41177ce224e595fbc... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0x4a0b3274e3946db14214b79a8c070a543a881e0a56fb7575c9914d14e3008163", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "10", from: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000074874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db398fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", contractAddress: "", cumulativeGasUsed: "908256", gasUsed: "122298", confirmations: "886640"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3"}, {type: "bytes32", name: "sid", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3", "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}, {name: "player", type: "address", value: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0xcab9605ea1a58babd95d4bfa2e309... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0x0d471e931e58b8191a5f5e8f9f4cc19c5afc1f185dbb508840dc33e7e4b41ab6", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "11", from: "0xd6ef04f7e21ffe8df057da2b0af49410fb9eb1bc", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000007cab9605ea1a58babd95d4bfa2e309e858ef4f4d86d8785154113ac090d05afc97d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329", contractAddress: "", cumulativeGasUsed: "1030849", gasUsed: "122593", confirmations: "886640"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0xcab9605ea1a58babd95d4bfa2e309e858ef4f4d86d8785154113ac090d05afc9"}, {type: "bytes32", name: "sid", value: "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0xcab9605ea1a58babd95d4bfa2e309e858ef4f4d86d8785154113ac090d05afc9", "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0xcab9605ea1a58babd95d4bfa2e309e858ef4f4d86d8785154113ac090d05afc9"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329"}, {name: "player", type: "address", value: "0xd6ef04f7e21ffe8df057da2b0af49410fb9eb1bc"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0xdd3b0737f436f4a6ec27acde748cf... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0xc8f7acf2a3f04d19ccf52e80754f8087bf190ef74f38ca3f54bf0cecae049a24", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "12", from: "0x878c01cbf7d7a407c661280c5b952c0891d92a32", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000007dd3b0737f436f4a6ec27acde748cff61168aa6cb90ca5baa2786b7d0aa68c48e58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41", contractAddress: "", cumulativeGasUsed: "1153737", gasUsed: "122888", confirmations: "886640"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0xdd3b0737f436f4a6ec27acde748cff61168aa6cb90ca5baa2786b7d0aa68c48e"}, {type: "bytes32", name: "sid", value: "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0xdd3b0737f436f4a6ec27acde748cff61168aa6cb90ca5baa2786b7d0aa68c48e", "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0xdd3b0737f436f4a6ec27acde748cff61168aa6cb90ca5baa2786b7d0aa68c48e"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41"}, {name: "player", type: "address", value: "0x878c01cbf7d7a407c661280c5b952c0891d92a32"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0xdac67a45b05c5a9e0b694792e77df... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0xde6ba408da2b2cd72588e837d0fbe26d6ee53ece332fcef59a65162c076bd8a2", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "13", from: "0xca2de2472d2d2fab45996ec0429e06b23c37d5ff", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000007dac67a45b05c5a9e0b694792e77df94826f3a980cc1f403067ab7befbfc6a85d113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113", contractAddress: "", cumulativeGasUsed: "1276856", gasUsed: "123119", confirmations: "886640"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0xdac67a45b05c5a9e0b694792e77df94826f3a980cc1f403067ab7befbfc6a85d"}, {type: "bytes32", name: "sid", value: "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0xdac67a45b05c5a9e0b694792e77df94826f3a980cc1f403067ab7befbfc6a85d", "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0xdac67a45b05c5a9e0b694792e77df94826f3a980cc1f403067ab7befbfc6a85d"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113"}, {name: "player", type: "address", value: "0xca2de2472d2d2fab45996ec0429e06b23c37d5ff"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x69eee4ec051a2a91e62725fae7f0c... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0xc54c80651de128942c2ee0faefd1a8b5095b746c95513cc2d9ab4420a11d967d", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "14", from: "0x1eed37985f76990bbcaf68f83b82bd82403e1565", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000769eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", contractAddress: "", cumulativeGasUsed: "1400335", gasUsed: "123479", confirmations: "886640"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae"}, {type: "bytes32", name: "sid", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae", "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}, {name: "player", type: "address", value: "0x1eed37985f76990bbcaf68f83b82bd82403e1565"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"7\", \"0x33eeb085573e3584c1390f31a95c4... )", async function( ) {
		const txOriginal = {blockNumber: "6817084", timeStamp: "1543820054", hash: "0x654acb04502dad45932d366b7dbb4ba2bd03f9a7e4e2d056cf84829d7d9b1b4c", nonce: "0", blockHash: "0x8b065fdb0b509977aec8bc67103e3a728d8dee7dd719d63bfa6cfb975f1a1005", transactionIndex: "15", from: "0x4f61fba36d4e5d71d4fe6f36f9ca90183fec1406", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000733eeb085573e3584c1390f31a95c403bdc0a1176b977ae0181f88943727b0f53c80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9", contractAddress: "", cumulativeGasUsed: "1524109", gasUsed: "123774", confirmations: "886640"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "hash", value: "0x33eeb085573e3584c1390f31a95c403bdc0a1176b977ae0181f88943727b0f53"}, {type: "bytes32", name: "sid", value: "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "7", "0x33eeb085573e3584c1390f31a95c403bdc0a1176b977ae0181f88943727b0f53", "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543820054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x33eeb085573e3584c1390f31a95c403bdc0a1176b977ae0181f88943727b0f53"}, {name: "id", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9"}, {name: "player", type: "address", value: "0x4f61fba36d4e5d71d4fe6f36f9ca90183fec1406"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x34c7cd62a36a3c512f4d256ef297e... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x8bd758a01c4e48ad15ba799d8a82152da40111d03c0a1aeb2cd54c5eb2d3971e", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "33", from: "0x1eed37985f76990bbcaf68f83b82bd82403e1565", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f22780000000000000000000000000000000000000000000000000000000000000000734c7cd62a36a3c512f4d256ef297e57e56e9fff8297ffa576c463e76f2ea4244428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", contractAddress: "", cumulativeGasUsed: "1335929", gasUsed: "112722", confirmations: "881822"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x34c7cd62a36a3c512f4d256ef297e57e56e9fff8297ffa576c463e76f2ea4244"}, {type: "bytes32", name: "sid", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x34c7cd62a36a3c512f4d256ef297e57e56e9fff8297ffa576c463e76f2ea4244", "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x1eed37985f76990bbcaf68f83b82bd82403e1565"}, {name: "origin", type: "bytes32", value: "0x34c7cd62a36a3c512f4d256ef297e57e56e9fff8297ffa576c463e76f2ea4244"}, {name: "num", type: "uint256", value: "1"}, {name: "sid", type: "bytes32", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0xe2930714ba467b6e986cfff261262... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0xdb7d584f7025c06d8bacd4a171d6488200199b0e291fdec82ca2975fef3a19fc", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "34", from: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f227800000000000000000000000000000000000000000000000000000000000000007e2930714ba467b6e986cfff26126216618d9e837d0131d8fdc108d4545e618284ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", contractAddress: "", cumulativeGasUsed: "1418651", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0xe2930714ba467b6e986cfff26126216618d9e837d0131d8fdc108d4545e61828"}, {type: "bytes32", name: "sid", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0xe2930714ba467b6e986cfff26126216618d9e837d0131d8fdc108d4545e61828", "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0"}, {name: "origin", type: "bytes32", value: "0xe2930714ba467b6e986cfff26126216618d9e837d0131d8fdc108d4545e61828"}, {name: "num", type: "uint256", value: "2"}, {name: "sid", type: "bytes32", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x5ab8421cde5862b94ad87ff385d1a... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0xdd53b57e86a7507f2af4d26d95abeb224163ec4f4abbca330b963e3d8929ee75", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "35", from: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000075ab8421cde5862b94ad87ff385d1a05a005de3e6a60e5fca6d451917a552fcb421cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", contractAddress: "", cumulativeGasUsed: "1501245", gasUsed: "82594", confirmations: "881822"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x5ab8421cde5862b94ad87ff385d1a05a005de3e6a60e5fca6d451917a552fcb4"}, {type: "bytes32", name: "sid", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x5ab8421cde5862b94ad87ff385d1a05a005de3e6a60e5fca6d451917a552fcb4", "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3"}, {name: "origin", type: "bytes32", value: "0x5ab8421cde5862b94ad87ff385d1a05a005de3e6a60e5fca6d451917a552fcb4"}, {name: "num", type: "uint256", value: "3"}, {name: "sid", type: "bytes32", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x6f91bf8937d3f678311d2e2e4f14c... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0xd237a7aa021249d1e191816aa58528a4822ef5c8792b7f2b53088f5ee1362a7d", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "36", from: "0xbcf5617bb9fba43243fe9fcdf7218fe5865ab59d", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000076f91bf8937d3f678311d2e2e4f14c088e236cad2a4df6d8d835d0e41f4d265c6cbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06", contractAddress: "", cumulativeGasUsed: "1583967", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x6f91bf8937d3f678311d2e2e4f14c088e236cad2a4df6d8d835d0e41f4d265c6"}, {type: "bytes32", name: "sid", value: "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x6f91bf8937d3f678311d2e2e4f14c088e236cad2a4df6d8d835d0e41f4d265c6", "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xbcf5617bb9fba43243fe9fcdf7218fe5865ab59d"}, {name: "origin", type: "bytes32", value: "0x6f91bf8937d3f678311d2e2e4f14c088e236cad2a4df6d8d835d0e41f4d265c6"}, {name: "num", type: "uint256", value: "4"}, {name: "sid", type: "bytes32", value: "0xcbf5ba8e18f0766a961ace3f749023f6374cbbcc467ce045a75e9583eec38f06"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x1e3d4c8321cc464167a5b660eb411... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x41d8665501742bb8cc476303801e7a5ddbf430ad1adf8f40e23993e1e4096382", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "37", from: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000071e3d4c8321cc464167a5b660eb411348837d037f505b93cf0481870674a95d444345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", contractAddress: "", cumulativeGasUsed: "1666689", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x1e3d4c8321cc464167a5b660eb411348837d037f505b93cf0481870674a95d44"}, {type: "bytes32", name: "sid", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x1e3d4c8321cc464167a5b660eb411348837d037f505b93cf0481870674a95d44", "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9"}, {name: "origin", type: "bytes32", value: "0x1e3d4c8321cc464167a5b660eb411348837d037f505b93cf0481870674a95d44"}, {name: "num", type: "uint256", value: "5"}, {name: "sid", type: "bytes32", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x6d53bddce2cb0965dff02dd880c87... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x2a793b3bf96ddbb95de502b72c5749b663e184902fd6dcdc8b3129bc1852ae67", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "38", from: "0xd6ef04f7e21ffe8df057da2b0af49410fb9eb1bc", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000076d53bddce2cb0965dff02dd880c876ef9d7739bdec3eeb8b900bc5bb76c597be7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329", contractAddress: "", cumulativeGasUsed: "1749411", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x6d53bddce2cb0965dff02dd880c876ef9d7739bdec3eeb8b900bc5bb76c597be"}, {type: "bytes32", name: "sid", value: "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x6d53bddce2cb0965dff02dd880c876ef9d7739bdec3eeb8b900bc5bb76c597be", "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xd6ef04f7e21ffe8df057da2b0af49410fb9eb1bc"}, {name: "origin", type: "bytes32", value: "0x6d53bddce2cb0965dff02dd880c876ef9d7739bdec3eeb8b900bc5bb76c597be"}, {name: "num", type: "uint256", value: "6"}, {name: "sid", type: "bytes32", value: "0x7d06d2dfc08fc62a462788ec2cf6b867ec7785303b9060e1b5346f26a281b329"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0xea4d891849d6bbdf3e859ef116fdf... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x84b2b8718c515567c2714a6aae2988a0c376b67bb348d1497ecd4782c89a33fe", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "39", from: "0x4f61fba36d4e5d71d4fe6f36f9ca90183fec1406", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f227800000000000000000000000000000000000000000000000000000000000000007ea4d891849d6bbdf3e859ef116fdf30dbbf55843799d1091106eb05dd0d78837c80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9", contractAddress: "", cumulativeGasUsed: "1832133", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0xea4d891849d6bbdf3e859ef116fdf30dbbf55843799d1091106eb05dd0d78837"}, {type: "bytes32", name: "sid", value: "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0xea4d891849d6bbdf3e859ef116fdf30dbbf55843799d1091106eb05dd0d78837", "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x4f61fba36d4e5d71d4fe6f36f9ca90183fec1406"}, {name: "origin", type: "bytes32", value: "0xea4d891849d6bbdf3e859ef116fdf30dbbf55843799d1091106eb05dd0d78837"}, {name: "num", type: "uint256", value: "7"}, {name: "sid", type: "bytes32", value: "0xc80a6eac040db858c257fbd4caa696156cc47a3abd7d1402a64b1126c33cbcf9"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x6c09e333640183663bbd56409559b... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0xf01509c0315593502a336ead741805d854d308b06371efd93abeedc11416c7a1", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "40", from: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000076c09e333640183663bbd56409559b347b249915bea41c12c52fb64efc36ed26c98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", contractAddress: "", cumulativeGasUsed: "1914855", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x6c09e333640183663bbd56409559b347b249915bea41c12c52fb64efc36ed26c"}, {type: "bytes32", name: "sid", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x6c09e333640183663bbd56409559b347b249915bea41c12c52fb64efc36ed26c", "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93"}, {name: "origin", type: "bytes32", value: "0x6c09e333640183663bbd56409559b347b249915bea41c12c52fb64efc36ed26c"}, {name: "num", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0xd44bf9195ccd6ce55457f73ffdd1d... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x69f682070100801a645c6cf2b3e13397b8712640142928e3d46f34b7ea2383a1", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "41", from: "0xca2de2472d2d2fab45996ec0429e06b23c37d5ff", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f227800000000000000000000000000000000000000000000000000000000000000007d44bf9195ccd6ce55457f73ffdd1d6399d750eea1f543c838cefd7f7da59541c113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113", contractAddress: "", cumulativeGasUsed: "1997513", gasUsed: "82658", confirmations: "881822"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0xd44bf9195ccd6ce55457f73ffdd1d6399d750eea1f543c838cefd7f7da59541c"}, {type: "bytes32", name: "sid", value: "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0xd44bf9195ccd6ce55457f73ffdd1d6399d750eea1f543c838cefd7f7da59541c", "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0xca2de2472d2d2fab45996ec0429e06b23c37d5ff"}, {name: "origin", type: "bytes32", value: "0xd44bf9195ccd6ce55457f73ffdd1d6399d750eea1f543c838cefd7f7da59541c"}, {name: "num", type: "uint256", value: "9"}, {name: "sid", type: "bytes32", value: "0x113750c851204c002f49a4b98df8b4e5fe9f3f125947a408cc1cc59c50f4d113"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: commitOrigin( \"7\", \"0x5ff76ad6d98b145e23bb7581c964f... )", async function( ) {
		const txOriginal = {blockNumber: "6821902", timeStamp: "1543888874", hash: "0x9d80fa4fcd008caf185bccf8a3edbe175592c4dabfe46918697e116b0bdcbe15", nonce: "1", blockHash: "0xeec2b451c90df4c2b3ca229ca0169bf6f27b2b41240a6755f483256991b5acea", transactionIndex: "42", from: "0x878c01cbf7d7a407c661280c5b952c0891d92a32", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "122722", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x25f2278000000000000000000000000000000000000000000000000000000000000000075ff76ad6d98b145e23bb7581c964ff7a0d067c2e6d54bce4ad4b9c423cd6c01958658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41", contractAddress: "", cumulativeGasUsed: "2080235", gasUsed: "82722", confirmations: "881822"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bytes32", name: "origin", value: "0x5ff76ad6d98b145e23bb7581c964ff7a0d067c2e6d54bce4ad4b9c423cd6c019"}, {type: "bytes32", name: "sid", value: "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41"}], name: "commitOrigin", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "commitOrigin(uint256,bytes32,bytes32)" ]( "7", "0x5ff76ad6d98b145e23bb7581c964ff7a0d067c2e6d54bce4ad4b9c423cd6c019", "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543888874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "origin", type: "bytes32"}, {indexed: false, name: "num", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}], name: "CommitOrigin", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CommitOrigin", events: [{name: "user", type: "address", value: "0x878c01cbf7d7a407c661280c5b952c0891d92a32"}, {name: "origin", type: "bytes32", value: "0x5ff76ad6d98b145e23bb7581c964ff7a0d067c2e6d54bce4ad4b9c423cd6c019"}, {name: "num", type: "uint256", value: "10"}, {name: "sid", type: "bytes32", value: "0x58658ae90c41aa34ffdc75242409d1fdd401e87038a7b98e2565e955b1103b41"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: open( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6825271", timeStamp: "1543936835", hash: "0x9d343b4d97c1299d02bda0269608789515ddb8074fb0bb964f8d791760b60a96", nonce: "1466", blockHash: "0xb5bc0fdcb5ab5e39cbc2389a76b41cde6a8f8171b26cc3d81fc91664a7b5d277", transactionIndex: "25", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x690e7c090000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "1570950", gasUsed: "139101", confirmations: "878453"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}], name: "open", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "open(uint256)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543936835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "random", type: "bytes32"}, {indexed: false, name: "prize", type: "uint256"}, {indexed: false, name: "id", type: "uint256"}], name: "Open", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Open", events: [{name: "user", type: "address", value: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9"}, {name: "random", type: "bytes32", value: "0xedd6641659b1614431eb507eaf8e86dfc20bbb294defec152ca71c1cbfe0a1df"}, {name: "prize", type: "uint256", value: "90000000000000000"}, {name: "id", type: "uint256", value: "7"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"23000\", \"5700\", \"48\", \"1\", \"98... )", async function( ) {
		const txOriginal = {blockNumber: "6825367", timeStamp: "1543938095", hash: "0x3149971a6276512ea4d098d32e4cf7fdbbde9191651a8989a85ef7cb6ec8ac97", nonce: "1467", blockHash: "0xd4b750a7c997cbfb5451bd89a2270d62eddfe48822553736505efbfd0986e678", transactionIndex: "33", from: "0x1be992fc3547d2bd687518cc1c9bd1c29f8377a3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xc1c25e6300000000000000000000000000000000000000000000000000000000000059d80000000000000000000000000000000000000000000000000000000000001644000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000062", contractAddress: "", cumulativeGasUsed: "2905852", gasUsed: "53438", confirmations: "878357"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "iBetPhase", value: "23000"}, {type: "uint256", name: "iCommitPhase", value: "5700"}, {type: "uint256", name: "iOpenPhase", value: "48"}, {type: "uint256", name: "betvalue", value: "1"}, {type: "uint256", name: "iRefund", value: "98"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,uint256,uint256,uint256,uint256)" ]( "23000", "5700", "48", "1", "98", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543938095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "betPhase", type: "uint256"}, {indexed: false, name: "commitPhase", type: "uint256"}, {indexed: false, name: "openPhase", type: "uint256"}, {indexed: false, name: "betValue", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}, {indexed: false, name: "startBlock", type: "uint256"}], name: "StartGame", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StartGame", events: [{name: "id", type: "uint256", value: "8"}, {name: "betPhase", type: "uint256", value: "23000"}, {name: "commitPhase", type: "uint256", value: "5700"}, {name: "openPhase", type: "uint256", value: "48"}, {name: "betValue", type: "uint256", value: "10000000000000000"}, {name: "refund", type: "uint256", value: "98"}, {name: "startBlock", type: "uint256", value: "6825367"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"8\", \"0x69eee4ec051a2a91e62725fae7f0c... )", async function( ) {
		const txOriginal = {blockNumber: "6828143", timeStamp: "1543978846", hash: "0x3e5a4e803bbfeba4b0a4bb96c4d788623fe5bbb5ccef4a49e9870a5873656082", nonce: "3", blockHash: "0x3bb562559d684a10b6ddd297328c946c7cdc11d792ddcbe0c2943e4e3eade672", transactionIndex: "62", from: "0x1eed37985f76990bbcaf68f83b82bd82403e1565", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000869eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", contractAddress: "", cumulativeGasUsed: "2585556", gasUsed: "251789", confirmations: "875581"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bytes32", name: "hash", value: "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae"}, {type: "bytes32", name: "sid", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "8", "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae", "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543978846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x69eee4ec051a2a91e62725fae7f0cbc850115fcdb04bcea4441c6e6ac994bdae"}, {name: "id", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x428feb9dce658a9984f4d7b08f4131045198c78be263bd51c7da36e8b6e4d8dd"}, {name: "player", type: "address", value: "0x1eed37985f76990bbcaf68f83b82bd82403e1565"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"8\", \"0x596e8f2368e814924f1847c01abf7... )", async function( ) {
		const txOriginal = {blockNumber: "6828143", timeStamp: "1543978846", hash: "0x3e8b7cce65f32b13e3a0f672f68c41d810936cd9782f48bfb9c84b833f6c4de1", nonce: "3", blockHash: "0x3bb562559d684a10b6ddd297328c946c7cdc11d792ddcbe0c2943e4e3eade672", transactionIndex: "63", from: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b40000000000000000000000000000000000000000000000000000000000000008596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc9884ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", contractAddress: "", cumulativeGasUsed: "2706968", gasUsed: "121412", confirmations: "875581"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bytes32", name: "hash", value: "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988"}, {type: "bytes32", name: "sid", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "8", "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988", "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543978846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x596e8f2368e814924f1847c01abf7378d05a0854166d66053a1230ce014bc988"}, {name: "id", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x4ed48fcd76c5041b0644f23c4094ca49cd79ae2eb008c135e5c1c5e28e49581a"}, {name: "player", type: "address", value: "0xc7b9e1ffa159d8a8100942ec2e68e47cb0ec33b0"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"8\", \"0x38be71907080caca967636da60e2a... )", async function( ) {
		const txOriginal = {blockNumber: "6828143", timeStamp: "1543978846", hash: "0xdbd6174d92506a7657e756efdbbef8dc45a45d1b7e127e4a74e53ac4435e9d1d", nonce: "3", blockHash: "0x3bb562559d684a10b6ddd297328c946c7cdc11d792ddcbe0c2943e4e3eade672", transactionIndex: "64", from: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b4000000000000000000000000000000000000000000000000000000000000000838be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", contractAddress: "", cumulativeGasUsed: "2828611", gasUsed: "121643", confirmations: "875581"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bytes32", name: "hash", value: "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc"}, {type: "bytes32", name: "sid", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "8", "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc", "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543978846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x38be71907080caca967636da60e2a7b97aa814aea434a8c4ec56c145158bfefc"}, {name: "id", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x21cce7b3a62c4783b159f4d0f62d1e9e8fed48d9154731552f1ce345000363bc"}, {name: "player", type: "address", value: "0xc2e88f19cc2e07c3911cbe084167d61eda9f64e3"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"8\", \"0x7f24005483a345a570459d9db6885... )", async function( ) {
		const txOriginal = {blockNumber: "6828143", timeStamp: "1543978846", hash: "0x5206834844fbbb2711f4995e7e1bc400b19f2ea1174c8f64219e87d3dc6845ce", nonce: "3", blockHash: "0x3bb562559d684a10b6ddd297328c946c7cdc11d792ddcbe0c2943e4e3eade672", transactionIndex: "65", from: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000087f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c14345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", contractAddress: "", cumulativeGasUsed: "2950550", gasUsed: "121939", confirmations: "875581"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bytes32", name: "hash", value: "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1"}, {type: "bytes32", name: "sid", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "8", "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1", "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543978846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x7f24005483a345a570459d9db68853f0cbbffe9dcccd471ad29c2121085ea4c1"}, {name: "id", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x4345cd3508c55a5d181c96fe7cec6943a6194f0c5aea6d641a0c09f3a4b7c980"}, {name: "player", type: "address", value: "0x7fcc41fdd97e9d04020da833ae4d04b027f1a0a9"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"8\", \"0x4874d3b044bd41177ce224e595fbc... )", async function( ) {
		const txOriginal = {blockNumber: "6828143", timeStamp: "1543978846", hash: "0x4b00c0f30a96981798a938a5a9bf583ac944b0fb11d101b5e02278044c61adea", nonce: "3", blockHash: "0x3bb562559d684a10b6ddd297328c946c7cdc11d792ddcbe0c2943e4e3eade672", transactionIndex: "66", from: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93", to: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d", value: "10000000000000000", gas: "261725", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6f0485b400000000000000000000000000000000000000000000000000000000000000084874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db398fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", contractAddress: "", cumulativeGasUsed: "3072848", gasUsed: "122298", confirmations: "875581"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bytes32", name: "hash", value: "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3"}, {type: "bytes32", name: "sid", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256,bytes32,bytes32)" ]( "8", "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3", "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543978846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "value", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "sid", type: "bytes32"}, {indexed: false, name: "player", type: "address"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Play", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x4874d3b044bd41177ce224e595fbc05b808f7a620dfa08340eb2aab946251db3"}, {name: "id", type: "uint256", value: "8"}, {name: "sid", type: "bytes32", value: "0x98fc7ec11272a5763fa244375a79ffe4f509cb5be32d21868fc31c5030ee8f9c"}, {name: "player", type: "address", value: "0xc9eca8224367fc77ccfa4cb8d4dbd034d413ab93"}], address: "0xc741bc7fa502ddcf2d5cc9e2c70f0ee7090cfd0d"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "99900000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
