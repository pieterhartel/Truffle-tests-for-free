const LocalEthereumEscrows = artifacts.require( "./LocalEthereumEscrows.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "LocalEthereumEscrows" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x09678741Bd50C3e74301f38fBd0136307099Ae5d", "0xA38F728C9431A4248753C63423518fAF4De63E18", "0xE5b7965c78e517550536675A88e76a6E2D57605d", "0x8409d8698e49cf687C0a8DA4515c8f5f45ECe3f9", "0x855eafC46509F1aF98ba02623Ff289c37dee7689", "0xF28cff7F74680D89AA518D867f18a15aaC87Fa47", "0xEb7358CB3EcD60d05939Af8694B29663645846bE", "0x4771f3d401954fF0e47130bc8Bc9313fe35Ab9bC", "0x6FC76985CaCf67796C41f75e2B2A13E29Ed6F942", "0xba213026B11DB47b6290AACE276d0DEBCF358eE8", "0xe6de07c042ED5D2F46D4908709e011fDd0EC4609", "0x67619106fDE9592D6A95e7218505A981D020782b", "0x9C88914fD76C638Adc91AE8e9d036e4832da7819", "0x0dfb375b993dC509F0D66AF5D0A7C35C4127f81A", "0x1de58b4417F9C728A492EF0C3E08511C8253036C", "0xbAF3f0BBb104ef70949076c48C200dBb11f002ec", "0x7d6714Cd534CDF77a1C33c78F12e2AF1338e2919", "0xC02b2c3dcD14f518CD1114e2071c26cbD3627AF1", "0x91f84D8703fc5178e672829A32c55ABC8f05c687", "0xE06488934ae632bfadD9bB0eB40bbF5642949165", "0x8d0B2f7dE43f93E974E6dA2dC0D931DF9245AF6D", "0xB4eFBF0c3a323209109f50ae17DDB3554aA5284E", "0x7E9f412eeE96a6FB87b24Bdea6be65A59ede6E26", "0x68A3F7804572010f4f6fb19558B5F1EC2511Ae2E", "0xDd0400e5b9c73b3EEa09e6Ad3a512b2C2A711b1d", "0x71af594b6418e9E85000D684741b34C045B2157F", "0x9eCC8724A82b8f197a3823414c2fB13Bae429064", "0x44C1D404209C64Dc5f255d8634e68a6B98B35aB0", "0xb0F8ad2f6994D874a76dC9C9d468Ce14B97D8Bb2", "0x0cD51F56e4C2e0D48d6d8FE358E9f40F817e217A", "0x27557f359677c9dFC4C52F9916324a23D71e49d1", "0x64Fc295C987540E72497F0D0F1bCc8b8a6D68C98", "0xa9047e8B75eE500e8fbe14B434cA142e16C8B4B0", "0xfB7aE564e2eAa0E2398a26aD9F655f1a98a39819", "0x17662D64d0c1fe50701Afb708a645AADB1e95507", "0xd5Cf837798DdE24A52c48B517A69047aCC04Be8E", "0x6202D19e63eDC550eD5FaF3fb7b35ede3C22Cf04", "0x8375F16aDfA377E88C240e62c6c2792EA309E5F2", "0xF1bF45B8D75A4997198033445151c0a5334F19D6", "0x53368611F901aD5622ab7feD08EE959b8Fb11251", "0x044f778A7A18AB8399528829d023eBF7f3828BEB", "0x783786b177E0B230871f8803115a34811eDCF835", "0xAec2E4076448aB6317ea7016C4F6880b4A9D3A1b", "0xf731b0842685846753c6AD757b67f6c2bEB39ea6", "0x2D6834E076bbB9308aCa6DB03d34C79D704a58cf", "0xdC148e0E2d5584Cb51088F1791cBA5BB4cc0d1De", "0x36f005f60d4C2C54C846eEf28cA308c01210d4F6", "0xD24Ed57Df2450Fd74BA90f1f6c0Ab8004b8715AF", "0xFEdCc13686A73A3A298f757D9616EfE8B1130915", "0x55db5180741eB1f65d4c7c0526FA574D2b4F20E1", "0x25e4dC300c09d83Ee23CcEAaCbEeBA08558E1035", "0xC004dA37499FE78FF3D48d555C7874B1d5d2ee84", "0xcab3Fb089b1c126B57847a8299c252E067C144c8", "0x32Ce8483fCb3faD7F5F9bdcF53CA54A62aC03cEd", "0x6a8bA4d48B7EC2fdd4Ac59016169dD5Cd7B31844", "0xb599250678E2177578075a3A470946C223788601", "0x92bC7a63cBdd46Fb60933353E01c75A4993359cc", "0x4FFb84d438FE4f47FFaFd49bc777Ec7e6e6837aA", "0xB27C7049Bdf3b7dFc881B29C951ae12b594594a3", "0xf46479475790c2f141290E0577baA20B71051098", "0xDa27D307B25DafecA06da45364e0d55a15A59eda", "0xA1524453c682176DC9a236130a241FE5dA250090", "0xb497CB33362CaD354E16328AdCF297CCb93f9098", "0x469CCdF7E46A40A0b81B2520EC533F2E1FCA9d4f", "0x04162077E231f4De6A9eC432f57353b6d4107975", "0x745fA59BAF041f227B08de565Ce17a147a652445", "0x5376EedaC544558758Ac4fd6fFAEF61284d021De", "0x0a43472CAbf314685f6F3E48e9a46F5F7a6b8c8e", "0x451B6AF880Bd6AA8A0274dCa38e3d818df572429", "0xEC0512233A69ae0620F817F62bCc562abBdCc7B0"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "bytes32"}], name: "escrows", outputs: [{name: "exists", type: "bool"}, {name: "sellerCanCancelAfter", type: "uint32"}, {name: "totalGasFeesSpentByRelayer", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "requestCancellationMinimumTime", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "arbitrator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "relayer", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feesAvailableForWithdraw", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "SellerCancelDisabled", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "SellerRequestedCancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledByBuyer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "DisputeResolved", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Created(bytes32)", "SellerCancelDisabled(bytes32)", "SellerRequestedCancel(bytes32)", "CancelledBySeller(bytes32)", "CancelledByBuyer(bytes32)", "Released(bytes32)", "DisputeResolved(bytes32)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x102d25c49d33fcdb8976a3f2744e0785c98d9e43b88364859e6aec4ae82eff5c", "0xe95fa7985c7585e90dab2dc46470726468662be06f67d79a31a5012e4bc0edeb", "0x43e76a2687c7b12792086e4c776772be26c4d6a7041115f446cbc22ccada08ab", "0x366d2b4e6cc37ecebb3d7d41df6d581634fd8137412710a1e086e4ca4656bb58", "0xd9b627ddaa414e8e6c82366cc9c179f6281d73968827cc17038a56852e28ac8b", "0x6eec2dd2382427616d4ea7ef183b16091feac4e2e63c8b55f25215f132df8d14", "0x65e0c7182ce84cd9087c1b07dc4b65875578877b885848e4be19ee312f2c3d31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4398950 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4400983 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "LocalEthereumEscrows", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "escrows", outputs: [{name: "exists", type: "bool"}, {name: "sellerCanCancelAfter", type: "uint32"}, {name: "totalGasFeesSpentByRelayer", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "escrows(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "requestCancellationMinimumTime", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "requestCancellationMinimumTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "arbitrator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "arbitrator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "relayer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "relayer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feesAvailableForWithdraw", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feesAvailableForWithdraw()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "LocalEthereumEscrows", function( accounts ) {

	it( "TEST: LocalEthereumEscrows(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4398950", timeStamp: "1508548135", hash: "0x1e3ca6184edd369d00f84a89fed8e7646ea15fa11fd53bc890805d368a229a83", nonce: "5", blockHash: "0x19fa109b7a4c163de00809b78d2b8cc2fae5c40b06b72afb9ecb4ca7010b4f5d", transactionIndex: "38", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: 0, value: "0", gas: "3236170", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb6e49fd9", contractAddress: "0x09678741bd50c3e74301f38fbd0136307099ae5d", cumulativeGasUsed: "3743133", gasUsed: "2157447", confirmations: "3322537"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "LocalEthereumEscrows", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = LocalEthereumEscrows.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508548135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = LocalEthereumEscrows.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x17f1d830ef45445d973d9a431bf438eb\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399000", timeStamp: "1508548610", hash: "0xe23747ef4a2522b1789fece68d39ed6b4fd5bbf123981b2154f493130a4b0ddb", nonce: "0", blockHash: "0x00481b6cec060cc12074179e8e85d045b7c71473f340e784f1ef917e2c7d4dbd", transactionIndex: "29", from: "0xe5b7965c78e517550536675a88e76a6e2d57605d", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "778700000000000000", gas: "100000", gasPrice: "1200000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6717f1d830ef45445d973d9a431bf438eb000000000000000000000000000000000000000000000000000000008409d8698e49cf687c0a8da4515c8f5f45ece3f9000000000000000000000000855eafc46509f1af98ba02623ff289c37dee76890000000000000000000000000000000000000000000000000ace7f863698c00000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eaae06000000000000000000000000000000000000000000000000000000000000001c7c9488c0e4eb127508bfb265fcb5e47bc6affa7c2d9497a95a4e954fb7a85d596a6083de6654d6e58fb7f2e8f126d6fea0cd0aeef160e57a46aa4d4b54fa9aab", contractAddress: "", cumulativeGasUsed: "828739", gasUsed: "69568", confirmations: "3322487"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "778700000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x17f1d830ef45445d973d9a431bf438eb"}, {type: "address", name: "_seller", value: addressList[5]}, {type: "address", name: "_buyer", value: addressList[6]}, {type: "uint256", name: "_value", value: "778700000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508552198"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x7c9488c0e4eb127508bfb265fcb5e47bc6affa7c2d9497a95a4e954fb7a85d59"}, {type: "bytes32", name: "_s", value: "0x6a6083de6654d6e58fb7f2e8f126d6fea0cd0aeef160e57a46aa4d4b54fa9aab"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x17f1d830ef45445d973d9a431bf438eb", addressList[5], addressList[6], "778700000000000000", "100", "7200", "1508552198", "28", "0x7c9488c0e4eb127508bfb265fcb5e47bc6affa7c2d9497a95a4e954fb7a85d59", "0x6a6083de6654d6e58fb7f2e8f126d6fea0cd0aeef160e57a46aa4d4b54fa9aab", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508548610 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x54ba583dee7a1d8028a11dff6f3e341236c5ad8f149a803ac811cfdb57e1cc1a"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xf60b30f74ee74c6c88134e74c688c855\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399001", timeStamp: "1508548627", hash: "0xfb945d32e020d3a9e96bff4c9679893dd545a5f08f551fb8f9e85695811f3e66", nonce: "0", blockHash: "0x741ec40081a02aadfc91782480999af8f438baa415d52352eff0a14dcc703b4a", transactionIndex: "20", from: "0xf28cff7f74680d89aa518d867f18a15aac87fa47", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "23433899610487175", gas: "100000", gasPrice: "1200000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67f60b30f74ee74c6c88134e74c688c85500000000000000000000000000000000000000000000000000000000eb7358cb3ecd60d05939af8694b29663645846be0000000000000000000000004771f3d401954ff0e47130bc8bc9313fe35ab9bc00000000000000000000000000000000000000000000000000534101edfc3987000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eaae0c000000000000000000000000000000000000000000000000000000000000001b5dede74695bf53ba8353afad95e9d3f17b0aa28a3bdc64e05cc8c58727228fb44c71e4f7d8a8c247d7caf50a20e9222b57817e17f1f5dfed637da26c0adc1bb4", contractAddress: "", cumulativeGasUsed: "882131", gasUsed: "69425", confirmations: "3322486"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "23433899610487175" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xf60b30f74ee74c6c88134e74c688c855"}, {type: "address", name: "_seller", value: addressList[8]}, {type: "address", name: "_buyer", value: addressList[9]}, {type: "uint256", name: "_value", value: "23433899610487175"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508552204"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x5dede74695bf53ba8353afad95e9d3f17b0aa28a3bdc64e05cc8c58727228fb4"}, {type: "bytes32", name: "_s", value: "0x4c71e4f7d8a8c247d7caf50a20e9222b57817e17f1f5dfed637da26c0adc1bb4"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xf60b30f74ee74c6c88134e74c688c855", addressList[8], addressList[9], "23433899610487175", "100", "0", "1508552204", "27", "0x5dede74695bf53ba8353afad95e9d3f17b0aa28a3bdc64e05cc8c58727228fb4", "0x4c71e4f7d8a8c247d7caf50a20e9222b57817e17f1f5dfed637da26c0adc1bb4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508548627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x8e13d1a56673e3a20f9f3bde69f88da24f34780c6cf6d30f31c2fedeb2c10163"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0xf60b30f74ee74c6c88134e74c688c855\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399010", timeStamp: "1508548704", hash: "0xea64cc17fa3a578d4a56d4437c18dbd45011888e4194dfa1ce3d26969ba79ad2", nonce: "6", blockHash: "0x20c96ee441f68832186eaa9e62de9c9be101647a94050c2ed3cf077be82ffd26", transactionIndex: "15", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "287380", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001f60b30f74ee74c6c88134e74c688c855000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000eb7358cb3ecd60d05939af8694b29663645846be00000000000000000000000000000000000000000000000000000000000000010000000000000000000000004771f3d401954ff0e47130bc8bc9313fe35ab9bc000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000534101edfc398700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001568ebf3bd38f8ac100cc268c0daf5af887272a997cf41d23616b82bc88a1396100000000000000000000000000000000000000000000000000000000000000017a1795e2770f9120b3d749dd9c6f8a32a31643b491d612983f72058072951e6d00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "997159", gasUsed: "90220", confirmations: "3322477"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0xf60b30f74ee74c6c88134e74c688c855"]}, {type: "address[]", name: "_seller", value: [addressList[8]]}, {type: "address[]", name: "_buyer", value: [addressList[9]]}, {type: "uint256[]", name: "_value", value: ["23433899610487175"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x568ebf3bd38f8ac100cc268c0daf5af887272a997cf41d23616b82bc88a13961"]}, {type: "bytes32[]", name: "_s", value: ["0x7a1795e2770f9120b3d749dd9c6f8a32a31643b491d612983f72058072951e6d"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0xf60b30f74ee74c6c88134e74c688c855"], [addressList[8]], [addressList[9]], ["23433899610487175"], ["100"], ["30000000000"], ["28"], ["0x568ebf3bd38f8ac100cc268c0daf5af887272a997cf41d23616b82bc88a13961"], ["0x7a1795e2770f9120b3d749dd9c6f8a32a31643b491d612983f72058072951e6d"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508548704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x8e13d1a56673e3a20f9f3bde69f88da24f34780c6cf6d30f31c2fedeb2c10163"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x5b4d0ac8c42a4e7eba96c60fdb7988cc\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399016", timeStamp: "1508548770", hash: "0x7726057d518b28eca0d24a934671fdfb0e0f4151af487ffd6b89e04f4c976ac5", nonce: "0", blockHash: "0x838927ab597ac4306ea1e76c8a3dd2d9b7cf4df3271255b8a879130f71ef56f7", transactionIndex: "54", from: "0x6fc76985cacf67796c41f75e2b2a13e29ed6f942", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "23433899610487175", gas: "100000", gasPrice: "1200000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d675b4d0ac8c42a4e7eba96c60fdb7988cc00000000000000000000000000000000000000000000000000000000ba213026b11db47b6290aace276d0debcf358ee8000000000000000000000000e6de07c042ed5d2f46d4908709e011fdd0ec460900000000000000000000000000000000000000000000000000534101edfc3987000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eaae8d000000000000000000000000000000000000000000000000000000000000001b54864fd55c253c831324879fedb8eda6b99eb55a533a4354bd134ddd81e1136f014a8187d041d085b158a648af6dfdc08d0a1ede55b907faf40fff4d56033c8a", contractAddress: "", cumulativeGasUsed: "2397090", gasUsed: "69568", confirmations: "3322471"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "23433899610487175" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x5b4d0ac8c42a4e7eba96c60fdb7988cc"}, {type: "address", name: "_seller", value: addressList[11]}, {type: "address", name: "_buyer", value: addressList[12]}, {type: "uint256", name: "_value", value: "23433899610487175"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508552333"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x54864fd55c253c831324879fedb8eda6b99eb55a533a4354bd134ddd81e1136f"}, {type: "bytes32", name: "_s", value: "0x014a8187d041d085b158a648af6dfdc08d0a1ede55b907faf40fff4d56033c8a"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x5b4d0ac8c42a4e7eba96c60fdb7988cc", addressList[11], addressList[12], "23433899610487175", "100", "21600", "1508552333", "27", "0x54864fd55c253c831324879fedb8eda6b99eb55a533a4354bd134ddd81e1136f", "0x014a8187d041d085b158a648af6dfdc08d0a1ede55b907faf40fff4d56033c8a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508548770 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x8bf4031eff53b8a01d843cc000faa165b1f7032df83403530b9d8726b7b05699"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x5b4d0ac8c42a4e7eba96c60fdb7988cc\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399041", timeStamp: "1508549184", hash: "0xa12561c1984c9bc0ab2c5720904f90dc2f75671e75e9970edb2e52521dc76135", nonce: "7", blockHash: "0x17623a40a2e77765e4830a4868ebfda0663b1da40a98a2e400f633915ef9bb4a", transactionIndex: "47", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000015b4d0ac8c42a4e7eba96c60fdb7988cc000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ba213026b11db47b6290aace276d0debcf358ee80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e6de07c042ed5d2f46d4908709e011fdd0ec4609000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000534101edfc398700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001034f0ddc308cf028aadf88389c8a9b463c2ad23476f9397fc5718d622547a53000000000000000000000000000000000000000000000000000000000000000016cdba6fd050a2dd13239b250a0dcd188c95124939364022db0e6a3c00929154c00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3863251", gasUsed: "75284", confirmations: "3322446"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x5b4d0ac8c42a4e7eba96c60fdb7988cc"]}, {type: "address[]", name: "_seller", value: [addressList[11]]}, {type: "address[]", name: "_buyer", value: [addressList[12]]}, {type: "uint256[]", name: "_value", value: ["23433899610487175"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x034f0ddc308cf028aadf88389c8a9b463c2ad23476f9397fc5718d622547a530"]}, {type: "bytes32[]", name: "_s", value: ["0x6cdba6fd050a2dd13239b250a0dcd188c95124939364022db0e6a3c00929154c"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x5b4d0ac8c42a4e7eba96c60fdb7988cc"], [addressList[11]], [addressList[12]], ["23433899610487175"], ["100"], ["30000000000"], ["28"], ["0x034f0ddc308cf028aadf88389c8a9b463c2ad23476f9397fc5718d622547a530"], ["0x6cdba6fd050a2dd13239b250a0dcd188c95124939364022db0e6a3c00929154c"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508549184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x8bf4031eff53b8a01d843cc000faa165b1f7032df83403530b9d8726b7b05699"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x2ced9ce1bbdc4aa68d9b848cfcda8db9\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399064", timeStamp: "1508549466", hash: "0xa98206e46b8457a5f33899a1689483346b2ce2f855e4834679946e5a573cf7ab", nonce: "1", blockHash: "0x8c012ccbdf08ac13fcf2de94b1214ed6f3e512570c08b99532dbdda633345111", transactionIndex: "7", from: "0xf28cff7f74680d89aa518d867f18a15aac87fa47", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "23433899610487175", gas: "100000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d672ced9ce1bbdc4aa68d9b848cfcda8db90000000000000000000000000000000000000000000000000000000067619106fde9592d6a95e7218505a981d020782b0000000000000000000000009c88914fd76c638adc91ae8e9d036e4832da781900000000000000000000000000000000000000000000000000534101edfc3987000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eab157000000000000000000000000000000000000000000000000000000000000001bbe554075600c704c200797203636fa582f6242af3bcd5fe2bf7bde50c07e56680b686804eaa316b4d21b19c4e56b3933b9cf1a24c24f7652f55b9b7308d082b9", contractAddress: "", cumulativeGasUsed: "276962", gasUsed: "69568", confirmations: "3322423"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "23433899610487175" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x2ced9ce1bbdc4aa68d9b848cfcda8db9"}, {type: "address", name: "_seller", value: addressList[13]}, {type: "address", name: "_buyer", value: addressList[14]}, {type: "uint256", name: "_value", value: "23433899610487175"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508553047"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xbe554075600c704c200797203636fa582f6242af3bcd5fe2bf7bde50c07e5668"}, {type: "bytes32", name: "_s", value: "0x0b686804eaa316b4d21b19c4e56b3933b9cf1a24c24f7652f55b9b7308d082b9"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x2ced9ce1bbdc4aa68d9b848cfcda8db9", addressList[13], addressList[14], "23433899610487175", "100", "21600", "1508553047", "27", "0xbe554075600c704c200797203636fa582f6242af3bcd5fe2bf7bde50c07e5668", "0x0b686804eaa316b4d21b19c4e56b3933b9cf1a24c24f7652f55b9b7308d082b9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508549466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x2ba269b3a796cf467f1cf4c3f284c942173d117f0a61ff6ced0840200d1ab91a"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x2ced9ce1bbdc4aa68d9b848cfcda8db9\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399178", timeStamp: "1508550929", hash: "0xa75e26d50ae9d5276e6cae716c8c343dfe5e55be7a81d30c51a75025e176ec23", nonce: "8", blockHash: "0x91579904cbc054457d0db79877d4064b562e9b943271cf1165f9e01a22ea97af", transactionIndex: "38", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249680", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000012ced9ce1bbdc4aa68d9b848cfcda8db900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000067619106fde9592d6a95e7218505a981d020782b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000009c88914fd76c638adc91ae8e9d036e4832da7819000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000534101edfc398700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001a41990334bca56c04949d9b20824a3f3812595732004da172c2409fa741cbc3200000000000000000000000000000000000000000000000000000000000000016eb1a4e447f9c2ac05c8a98f80cbfcbb62ab75b5c4108278608b2c9d5db03d4800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1148983", gasUsed: "75140", confirmations: "3322309"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x2ced9ce1bbdc4aa68d9b848cfcda8db9"]}, {type: "address[]", name: "_seller", value: [addressList[13]]}, {type: "address[]", name: "_buyer", value: [addressList[14]]}, {type: "uint256[]", name: "_value", value: ["23433899610487175"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0xa41990334bca56c04949d9b20824a3f3812595732004da172c2409fa741cbc32"]}, {type: "bytes32[]", name: "_s", value: ["0x6eb1a4e447f9c2ac05c8a98f80cbfcbb62ab75b5c4108278608b2c9d5db03d48"]}, {type: "uint8[]", name: "_actionByte", value: ["2"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x2ced9ce1bbdc4aa68d9b848cfcda8db9"], [addressList[13]], [addressList[14]], ["23433899610487175"], ["100"], ["30000000000"], ["28"], ["0xa41990334bca56c04949d9b20824a3f3812595732004da172c2409fa741cbc32"], ["0x6eb1a4e447f9c2ac05c8a98f80cbfcbb62ab75b5c4108278608b2c9d5db03d48"], ["2"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508550929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledByBuyer", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledByBuyer", events: [{name: "_tradeHash", type: "bytes32", value: "0x2ba269b3a796cf467f1cf4c3f284c942173d117f0a61ff6ced0840200d1ab91a"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x94cbd7381fa846b98d1d016ed86d86ce\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399232", timeStamp: "1508551667", hash: "0xa64c12a3e0de68f0af9ba4f91912f72556fa871004045d1fad87070374bdf571", nonce: "0", blockHash: "0xb0c658265ca8efeab3fbe9633a4131d3667f6ba4cefa2dd1ad4bf6325de89878", transactionIndex: "49", from: "0x0dfb375b993dc509f0d66af5d0a7c35c4127f81a", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "471478696741854636", gas: "100000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6794cbd7381fa846b98d1d016ed86d86ce000000000000000000000000000000000000000000000000000000001de58b4417f9c728a492ef0c3e08511c8253036c000000000000000000000000baf3f0bbb104ef70949076c48c200dbb11f002ec000000000000000000000000000000000000000000000000068b07606e765dac000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eab9eb000000000000000000000000000000000000000000000000000000000000001b1afca49e9a50e23c73da8d1d0a588900b3142940d73914a31ffafcd8700788e12ed61e17b6324a8dae8ed50f55a04fd452a121d56f1d6343d3fd5792e7633b0c", contractAddress: "", cumulativeGasUsed: "3463539", gasUsed: "69425", confirmations: "3322255"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "471478696741854636" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x94cbd7381fa846b98d1d016ed86d86ce"}, {type: "address", name: "_seller", value: addressList[16]}, {type: "address", name: "_buyer", value: addressList[17]}, {type: "uint256", name: "_value", value: "471478696741854636"}, {type: "uint16", name: "_fee", value: "25"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508555243"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x1afca49e9a50e23c73da8d1d0a588900b3142940d73914a31ffafcd8700788e1"}, {type: "bytes32", name: "_s", value: "0x2ed61e17b6324a8dae8ed50f55a04fd452a121d56f1d6343d3fd5792e7633b0c"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x94cbd7381fa846b98d1d016ed86d86ce", addressList[16], addressList[17], "471478696741854636", "25", "0", "1508555243", "27", "0x1afca49e9a50e23c73da8d1d0a588900b3142940d73914a31ffafcd8700788e1", "0x2ed61e17b6324a8dae8ed50f55a04fd452a121d56f1d6343d3fd5792e7633b0c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508551667 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x6ec8b17b21b2073240173d4f10492e89f8856d819602593e987f2db82c1fa2aa"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xa27f265eda5f4cb1b1122a8daf9704b4\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399255", timeStamp: "1508551909", hash: "0xf37b9e4a1700cef48c75c21558ebdaaa0904c670538c29ab77c0e6df32a07318", nonce: "0", blockHash: "0xbc46c98e31360bc1c6d8fbb7ac45e8f0800f22027cf6c6ed48c42c9e03b00a87", transactionIndex: "2", from: "0x7d6714cd534cdf77a1c33c78f12e2af1338e2919", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "300000000000000000", gas: "50000", gasPrice: "1000000000", isError: "1", txreceipt_status: "0", input: "0xf1e03d67a27f265eda5f4cb1b1122a8daf9704b400000000000000000000000000000000000000000000000000000000c02b2c3dcd14f518cd1114e2071c26cbd3627af100000000000000000000000091f84d8703fc5178e672829a32c55abc8f05c6870000000000000000000000000000000000000000000000000429d069189e000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eabacd000000000000000000000000000000000000000000000000000000000000001b68bb4814cfbeb07cbc38ac6245683454d3d42c914b32eeb4a8171afb6f373b2134ae3880bee63b8680b73f4b884aa71d52e802d0f96400f07793ee52a2f9d303", contractAddress: "", cumulativeGasUsed: "101981", gasUsed: "50000", confirmations: "3322232"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xa27f265eda5f4cb1b1122a8daf9704b4"}, {type: "address", name: "_seller", value: addressList[19]}, {type: "address", name: "_buyer", value: addressList[20]}, {type: "uint256", name: "_value", value: "300000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508555469"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x68bb4814cfbeb07cbc38ac6245683454d3d42c914b32eeb4a8171afb6f373b21"}, {type: "bytes32", name: "_s", value: "0x34ae3880bee63b8680b73f4b884aa71d52e802d0f96400f07793ee52a2f9d303"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x94cbd7381fa846b98d1d016ed86d86ce\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399286", timeStamp: "1508552227", hash: "0x49359f486057349b0bf14cc260420d5dbf7cb18a98622da3223dcc91b0a002fd", nonce: "9", blockHash: "0x10722114f7cf1c080a2941c06a7aec90129a47980a538111b9b82da0e615d560", transactionIndex: "28", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "191210", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000000194cbd7381fa846b98d1d016ed86d86ce0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000001de58b4417f9c728a492ef0c3e08511c8253036c0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000baf3f0bbb104ef70949076c48c200dbb11f002ec0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000068b07606e765dac00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001a4f8359dcfdacfc7d7555b1638511577b6c64db1acc4308e865f422536bf788d00000000000000000000000000000000000000000000000000000000000000010518288af5582633c30a873a6c0c6148a3be81aa9a7fd6bcb55a7c9957621d3100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "1173515", gasUsed: "58178", confirmations: "3322201"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x94cbd7381fa846b98d1d016ed86d86ce"]}, {type: "address[]", name: "_seller", value: [addressList[16]]}, {type: "address[]", name: "_buyer", value: [addressList[17]]}, {type: "uint256[]", name: "_value", value: ["471478696741854636"]}, {type: "uint16[]", name: "_fee", value: ["25"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xa4f8359dcfdacfc7d7555b1638511577b6c64db1acc4308e865f422536bf788d"]}, {type: "bytes32[]", name: "_s", value: ["0x0518288af5582633c30a873a6c0c6148a3be81aa9a7fd6bcb55a7c9957621d31"]}, {type: "uint8[]", name: "_actionByte", value: ["4"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x94cbd7381fa846b98d1d016ed86d86ce"], [addressList[16]], [addressList[17]], ["471478696741854636"], ["25"], ["30000000000"], ["27"], ["0xa4f8359dcfdacfc7d7555b1638511577b6c64db1acc4308e865f422536bf788d"], ["0x0518288af5582633c30a873a6c0c6148a3be81aa9a7fd6bcb55a7c9957621d31"], ["4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508552227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "SellerRequestedCancel", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SellerRequestedCancel", events: [{name: "_tradeHash", type: "bytes32", value: "0x6ec8b17b21b2073240173d4f10492e89f8856d819602593e987f2db82c1fa2aa"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x94cbd7381fa846b98d1d016ed86d86ce\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399286", timeStamp: "1508552227", hash: "0x13f714bd0c49cfa3fb5a3c0efc2b5828581b941dc0a1658256d24a05d4730d2c", nonce: "10", blockHash: "0x10722114f7cf1c080a2941c06a7aec90129a47980a538111b9b82da0e615d560", transactionIndex: "88", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249840", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000000194cbd7381fa846b98d1d016ed86d86ce0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000001de58b4417f9c728a492ef0c3e08511c8253036c0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000baf3f0bbb104ef70949076c48c200dbb11f002ec0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000068b07606e765dac00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001afacf2d4b5c2445746b1dc1c93faa5c52641f849d2fbb1dff6b0ac662f99dd5300000000000000000000000000000000000000000000000000000000000000011222abc82b3b8b4a2f86358f66a7456ab69de2da052b949602f7c596777ae68600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4899244", gasUsed: "75204", confirmations: "3322201"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x94cbd7381fa846b98d1d016ed86d86ce"]}, {type: "address[]", name: "_seller", value: [addressList[16]]}, {type: "address[]", name: "_buyer", value: [addressList[17]]}, {type: "uint256[]", name: "_value", value: ["471478696741854636"]}, {type: "uint16[]", name: "_fee", value: ["25"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xafacf2d4b5c2445746b1dc1c93faa5c52641f849d2fbb1dff6b0ac662f99dd53"]}, {type: "bytes32[]", name: "_s", value: ["0x1222abc82b3b8b4a2f86358f66a7456ab69de2da052b949602f7c596777ae686"]}, {type: "uint8[]", name: "_actionByte", value: ["2"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x94cbd7381fa846b98d1d016ed86d86ce"], [addressList[16]], [addressList[17]], ["471478696741854636"], ["25"], ["30000000000"], ["27"], ["0xafacf2d4b5c2445746b1dc1c93faa5c52641f849d2fbb1dff6b0ac662f99dd53"], ["0x1222abc82b3b8b4a2f86358f66a7456ab69de2da052b949602f7c596777ae686"], ["2"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508552227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledByBuyer", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledByBuyer", events: [{name: "_tradeHash", type: "bytes32", value: "0x6ec8b17b21b2073240173d4f10492e89f8856d819602593e987f2db82c1fa2aa"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x37ad86ca212941f59d49459064d18177\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399290", timeStamp: "1508552251", hash: "0x85a14fde4e7b120c1fc522e3e6b74d57a85f63ad4ab6922109585836cc294dc3", nonce: "0", blockHash: "0x7319d4863220fbd0b9d4080de6ea11dfa1e57c6ece6ef41b32d08ae5231b254a", transactionIndex: "22", from: "0xe06488934ae632bfadd9bb0eb40bbf5642949165", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "390000000000000000", gas: "100000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6737ad86ca212941f59d49459064d18177000000000000000000000000000000000000000000000000000000008d0b2f7de43f93e974e6da2dc0d931df9245af6d000000000000000000000000b4efbf0c3a323209109f50ae17ddb3554aa5284e00000000000000000000000000000000000000000000000005698eef0667000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eabc34000000000000000000000000000000000000000000000000000000000000001cf330ef30fe50f9bf5e279236f0257640fd380fa4434bfebe5fc29cff028538e9657339595023e90e6426bf08afd16844547f045babf8057670090b6adf149e3f", contractAddress: "", cumulativeGasUsed: "643220", gasUsed: "69504", confirmations: "3322197"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "390000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x37ad86ca212941f59d49459064d18177"}, {type: "address", name: "_seller", value: addressList[22]}, {type: "address", name: "_buyer", value: addressList[23]}, {type: "uint256", name: "_value", value: "390000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508555828"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xf330ef30fe50f9bf5e279236f0257640fd380fa4434bfebe5fc29cff028538e9"}, {type: "bytes32", name: "_s", value: "0x657339595023e90e6426bf08afd16844547f045babf8057670090b6adf149e3f"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x37ad86ca212941f59d49459064d18177", addressList[22], addressList[23], "390000000000000000", "100", "7200", "1508555828", "28", "0xf330ef30fe50f9bf5e279236f0257640fd380fa4434bfebe5fc29cff028538e9", "0x657339595023e90e6426bf08afd16844547f045babf8057670090b6adf149e3f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508552251 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xd550d88719f16b53c0ae870b3938031e6ca78d2e79b27970e8ae3434186f8fd7"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xf59731b1cd434eb382257a001b31026d\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399346", timeStamp: "1508553086", hash: "0x7e051187fbd7c7921bf2ba6c7a1d7d3b1d86077a4248fcb0a1af1490ac95c8f4", nonce: "0", blockHash: "0xb0b5c8e54734d03a601a56891667b5a876e38bb802a580cb9f8801bad146be79", transactionIndex: "58", from: "0x7e9f412eee96a6fb87b24bdea6be65a59ede6e26", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "200000000000000000", gas: "100000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67f59731b1cd434eb382257a001b31026d0000000000000000000000000000000000000000000000000000000068a3f7804572010f4f6fb19558b5f1ec2511ae2e000000000000000000000000dd0400e5b9c73b3eea09e6ad3a512b2c2a711b1d00000000000000000000000000000000000000000000000002c68af0bb14000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eabf80000000000000000000000000000000000000000000000000000000000000001cc4d1da3f4b78837eada91fa2cdfe679c9b18779d04f320155cd65ffc8ebfe8b451c13c745fc45958f097df0b23dc1cef1fd03a2a5bf9df4f5390dd3f7348fe50", contractAddress: "", cumulativeGasUsed: "4039433", gasUsed: "69376", confirmations: "3322141"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xf59731b1cd434eb382257a001b31026d"}, {type: "address", name: "_seller", value: addressList[25]}, {type: "address", name: "_buyer", value: addressList[26]}, {type: "uint256", name: "_value", value: "200000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508556672"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xc4d1da3f4b78837eada91fa2cdfe679c9b18779d04f320155cd65ffc8ebfe8b4"}, {type: "bytes32", name: "_s", value: "0x51c13c745fc45958f097df0b23dc1cef1fd03a2a5bf9df4f5390dd3f7348fe50"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xf59731b1cd434eb382257a001b31026d", addressList[25], addressList[26], "200000000000000000", "100", "7200", "1508556672", "28", "0xc4d1da3f4b78837eada91fa2cdfe679c9b18779d04f320155cd65ffc8ebfe8b4", "0x51c13c745fc45958f097df0b23dc1cef1fd03a2a5bf9df4f5390dd3f7348fe50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508553086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xcdece1e3708f050940ef35bd869ed78cad5caad4606613a03ab5976139297709"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x1056b9e0328f492cba222100426aed32\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399495", timeStamp: "1508555275", hash: "0x0a0c7dd7abf900112b16c203ddca9f5d89e93cf2317864168602ee94ac58ddd4", nonce: "0", blockHash: "0xd2582f7a6792f848f5df9b50b8644fd45da0fcac83be6cda2cc86ef3c7da783d", transactionIndex: "78", from: "0x71af594b6418e9e85000d684741b34c045b2157f", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "500000000000000000", gas: "75000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d671056b9e0328f492cba222100426aed32000000000000000000000000000000000000000000000000000000009ecc8724a82b8f197a3823414c2fb13bae42906400000000000000000000000044c1d404209c64dc5f255d8634e68a6b98b35ab000000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eac808000000000000000000000000000000000000000000000000000000000000001c1577307056360473fff0c9ab0cd7f099c7780294b9b440917a3e6481f98c94d60a6c17a921c9c291aaaede43352317c4d786444479069a1761ed4df27991bfc0", contractAddress: "", cumulativeGasUsed: "3385308", gasUsed: "69440", confirmations: "3321992"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x1056b9e0328f492cba222100426aed32"}, {type: "address", name: "_seller", value: addressList[28]}, {type: "address", name: "_buyer", value: addressList[29]}, {type: "uint256", name: "_value", value: "500000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508558856"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x1577307056360473fff0c9ab0cd7f099c7780294b9b440917a3e6481f98c94d6"}, {type: "bytes32", name: "_s", value: "0x0a6c17a921c9c291aaaede43352317c4d786444479069a1761ed4df27991bfc0"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x1056b9e0328f492cba222100426aed32", addressList[28], addressList[29], "500000000000000000", "100", "7200", "1508558856", "28", "0x1577307056360473fff0c9ab0cd7f099c7780294b9b440917a3e6481f98c94d6", "0x0a6c17a921c9c291aaaede43352317c4d786444479069a1761ed4df27991bfc0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508555275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x0b9df8d9bb24265ea769cc917f0da2b5603a3facceacc16987ff783c363fe836"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xf7773d13ec7249449ad7d0dafc4c0dcc\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399567", timeStamp: "1508556402", hash: "0x3478dd9c6a45c90ad8404094bccc7bee2ad2f9653358be36cd407c3f2fca92d7", nonce: "2", blockHash: "0x2267212dcc60326d93e4dc86de23eb892d4231045a7cc237d0f60a3c4c0350e5", transactionIndex: "12", from: "0xf28cff7f74680d89aa518d867f18a15aac87fa47", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "276300000000000000", gas: "75000", gasPrice: "7200000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67f7773d13ec7249449ad7d0dafc4c0dcc00000000000000000000000000000000000000000000000000000000b0f8ad2f6994d874a76dc9c9d468ce14b97d8bb20000000000000000000000000cd51f56e4c2e0d48d6d8fe358e9f40f817e217a00000000000000000000000000000000000000000000000003d59d62d770c000000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eacc70000000000000000000000000000000000000000000000000000000000000001b1d5892a8d9dbb43a3181228ed7700d7c30f9c25227f036fc34048f7b8899c67b41bd5630575c3185196f320f956556a4a2dd78fa78d02fe8eb9641de65b6f1cb", contractAddress: "", cumulativeGasUsed: "513768", gasUsed: "69568", confirmations: "3321920"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "276300000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xf7773d13ec7249449ad7d0dafc4c0dcc"}, {type: "address", name: "_seller", value: addressList[30]}, {type: "address", name: "_buyer", value: addressList[31]}, {type: "uint256", name: "_value", value: "276300000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508559984"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x1d5892a8d9dbb43a3181228ed7700d7c30f9c25227f036fc34048f7b8899c67b"}, {type: "bytes32", name: "_s", value: "0x41bd5630575c3185196f320f956556a4a2dd78fa78d02fe8eb9641de65b6f1cb"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xf7773d13ec7249449ad7d0dafc4c0dcc", addressList[30], addressList[31], "276300000000000000", "100", "21600", "1508559984", "27", "0x1d5892a8d9dbb43a3181228ed7700d7c30f9c25227f036fc34048f7b8899c67b", "0x41bd5630575c3185196f320f956556a4a2dd78fa78d02fe8eb9641de65b6f1cb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508556402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xe1327f7c5f1d8b06d1b7e082bf11ec0e4a2988e904a8c3dd7eefea5999c4758e"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x79fd976ea1cc4dbf8d993468a709780b\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399623", timeStamp: "1508557295", hash: "0xa73c54f051be448cba851541890f465216a73fcdf13ebc12415934399c43b1ea", nonce: "1", blockHash: "0x7602e0e932090ca0bd926c6a5c5c3c24f2f658aaf79efadb59eb8ff6ef485618", transactionIndex: "9", from: "0x71af594b6418e9e85000d684741b34c045b2157f", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "639200000000000000", gas: "75000", gasPrice: "10080000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6779fd976ea1cc4dbf8d993468a709780b0000000000000000000000000000000000000000000000000000000027557f359677c9dfc4c52f9916324a23d71e49d100000000000000000000000064fc295c987540e72497f0d0f1bcc8b8a6d68c9800000000000000000000000000000000000000000000000008dee5036c6e000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eacfeb000000000000000000000000000000000000000000000000000000000000001b46d5a57fc0ba0c4932480ef9dd7fb534295a388d2ae040f762c32d223dcc5b303900d19650d3787776826e6414e0436b5a6bb09d526e3dbbde835e5913bd1f8b", contractAddress: "", cumulativeGasUsed: "390915", gasUsed: "69440", confirmations: "3321864"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "639200000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x79fd976ea1cc4dbf8d993468a709780b"}, {type: "address", name: "_seller", value: addressList[32]}, {type: "address", name: "_buyer", value: addressList[33]}, {type: "uint256", name: "_value", value: "639200000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508560875"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x46d5a57fc0ba0c4932480ef9dd7fb534295a388d2ae040f762c32d223dcc5b30"}, {type: "bytes32", name: "_s", value: "0x3900d19650d3787776826e6414e0436b5a6bb09d526e3dbbde835e5913bd1f8b"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x79fd976ea1cc4dbf8d993468a709780b", addressList[32], addressList[33], "639200000000000000", "100", "7200", "1508560875", "27", "0x46d5a57fc0ba0c4932480ef9dd7fb534295a388d2ae040f762c32d223dcc5b30", "0x3900d19650d3787776826e6414e0436b5a6bb09d526e3dbbde835e5913bd1f8b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508557295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x2d5df7dbdf33e002e0ea85413e02a1fce359d83afff698961c1266dfbeffce29"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0xf7773d13ec7249449ad7d0dafc4c0dcc\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399654", timeStamp: "1508557615", hash: "0xd0df8be69ea15c4ea7ff980ee33f72ca5eb94f599a54af32b81b855a05e7bb56", nonce: "11", blockHash: "0xf4ab6084c026b4b7123bebcb6a93f8e31d26e62844b71c67e341606c82b3ae7a", transactionIndex: "31", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001f7773d13ec7249449ad7d0dafc4c0dcc000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b0f8ad2f6994d874a76dc9c9d468ce14b97d8bb200000000000000000000000000000000000000000000000000000000000000010000000000000000000000000cd51f56e4c2e0d48d6d8fe358e9f40f817e217a000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000003d59d62d770c00000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001f73aaed546ea61785ed46a5a66558b6f68a175ebc144968905b5355001f17a13000000000000000000000000000000000000000000000000000000000000000140d3c3c5ee322a1ae65d59ee8d7880c7b46c952837c9a2debc83bb77baddaa5e00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "1192977", gasUsed: "75284", confirmations: "3321833"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0xf7773d13ec7249449ad7d0dafc4c0dcc"]}, {type: "address[]", name: "_seller", value: [addressList[30]]}, {type: "address[]", name: "_buyer", value: [addressList[31]]}, {type: "uint256[]", name: "_value", value: ["276300000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xf73aaed546ea61785ed46a5a66558b6f68a175ebc144968905b5355001f17a13"]}, {type: "bytes32[]", name: "_s", value: ["0x40d3c3c5ee322a1ae65d59ee8d7880c7b46c952837c9a2debc83bb77baddaa5e"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0xf7773d13ec7249449ad7d0dafc4c0dcc"], [addressList[30]], [addressList[31]], ["276300000000000000"], ["100"], ["30000000000"], ["27"], ["0xf73aaed546ea61785ed46a5a66558b6f68a175ebc144968905b5355001f17a13"], ["0x40d3c3c5ee322a1ae65d59ee8d7880c7b46c952837c9a2debc83bb77baddaa5e"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508557615 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0xe1327f7c5f1d8b06d1b7e082bf11ec0e4a2988e904a8c3dd7eefea5999c4758e"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x79fd976ea1cc4dbf8d993468a709780b\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399655", timeStamp: "1508557647", hash: "0xbf7feb6e85f2ee6028bb20f43ca8ea8b785ba7b2c2f6b60471f4d42751d9b865", nonce: "12", blockHash: "0xff481fdf274fdcb8c40cddc01981a290ad656f7522a7a34d9841b63225f5f718", transactionIndex: "50", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249520", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000000179fd976ea1cc4dbf8d993468a709780b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000027557f359677c9dfc4c52f9916324a23d71e49d1000000000000000000000000000000000000000000000000000000000000000100000000000000000000000064fc295c987540e72497f0d0f1bcc8b8a6d68c98000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000008dee5036c6e000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001fd0405dcdea8231e8580a31dbb17ff79f129d9e35ad6b72c1c85c7b833347a4e0000000000000000000000000000000000000000000000000000000000000001724b9d94edcbf36738ab6032e606f4a0e2f3309c93a0893ccbd509df744ec1a600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1749148", gasUsed: "75076", confirmations: "3321832"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x79fd976ea1cc4dbf8d993468a709780b"]}, {type: "address[]", name: "_seller", value: [addressList[32]]}, {type: "address[]", name: "_buyer", value: [addressList[33]]}, {type: "uint256[]", name: "_value", value: ["639200000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0xfd0405dcdea8231e8580a31dbb17ff79f129d9e35ad6b72c1c85c7b833347a4e"]}, {type: "bytes32[]", name: "_s", value: ["0x724b9d94edcbf36738ab6032e606f4a0e2f3309c93a0893ccbd509df744ec1a6"]}, {type: "uint8[]", name: "_actionByte", value: ["2"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x79fd976ea1cc4dbf8d993468a709780b"], [addressList[32]], [addressList[33]], ["639200000000000000"], ["100"], ["30000000000"], ["28"], ["0xfd0405dcdea8231e8580a31dbb17ff79f129d9e35ad6b72c1c85c7b833347a4e"], ["0x724b9d94edcbf36738ab6032e606f4a0e2f3309c93a0893ccbd509df744ec1a6"], ["2"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508557647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledByBuyer", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledByBuyer", events: [{name: "_tradeHash", type: "bytes32", value: "0x2d5df7dbdf33e002e0ea85413e02a1fce359d83afff698961c1266dfbeffce29"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x0c0501455f864eaa8e51a4f53fc100ee\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399670", timeStamp: "1508557840", hash: "0xb19552d78bc9645bfe2db48460ba4cde95cf8b60154ed29146158a97e18bf348", nonce: "2", blockHash: "0x8e73dc316f332ffe3527480219bb1ce913dde2955b0494be4add4e635b565bb8", transactionIndex: "10", from: "0x71af594b6418e9e85000d684741b34c045b2157f", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "1000000000000000000", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d670c0501455f864eaa8e51a4f53fc100ee00000000000000000000000000000000000000000000000000000000a9047e8b75ee500e8fbe14b434ca142e16c8b4b0000000000000000000000000fb7ae564e2eaa0e2398a26ad9f655f1a98a398190000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059ead20e000000000000000000000000000000000000000000000000000000000000001b8431d95e37d031d4d9d3ff252801e4347a3b13c00206c6180cf46789300ca380704169728718be4e19c0050a8887188f8451cf9e2ffd24f428ec19fff5c95bf5", contractAddress: "", cumulativeGasUsed: "341065", gasUsed: "69440", confirmations: "3321817"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x0c0501455f864eaa8e51a4f53fc100ee"}, {type: "address", name: "_seller", value: addressList[34]}, {type: "address", name: "_buyer", value: addressList[35]}, {type: "uint256", name: "_value", value: "1000000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508561422"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x8431d95e37d031d4d9d3ff252801e4347a3b13c00206c6180cf46789300ca380"}, {type: "bytes32", name: "_s", value: "0x704169728718be4e19c0050a8887188f8451cf9e2ffd24f428ec19fff5c95bf5"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x0c0501455f864eaa8e51a4f53fc100ee", addressList[34], addressList[35], "1000000000000000000", "100", "7200", "1508561422", "27", "0x8431d95e37d031d4d9d3ff252801e4347a3b13c00206c6180cf46789300ca380", "0x704169728718be4e19c0050a8887188f8451cf9e2ffd24f428ec19fff5c95bf5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508557840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xa2bd905f69474a178771ff7389243a509d3a6dfdeb5f38e82a84543bd455f8d6"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x527a46173f854c6aa0100d580e7dd9e1\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399671", timeStamp: "1508557860", hash: "0x5a72eae7b07d3193257e0eaea4238e652a9d88c86c2f848a7a6c1abc4646ca37", nonce: "0", blockHash: "0x0efcd782629239adb363bbcb1394df195d00c513bf6e2bb7d0c417e2d3f2141b", transactionIndex: "48", from: "0x17662d64d0c1fe50701afb708a645aadb1e95507", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "50100061236213960", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67527a46173f854c6aa0100d580e7dd9e100000000000000000000000000000000000000000000000000000000d5cf837798dde24a52c48b517a69047acc04be8e0000000000000000000000006202d19e63edc550ed5faf3fb7b35ede3c22cf0400000000000000000000000000000000000000000000000000b1fdbd8135b8c800000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059ead219000000000000000000000000000000000000000000000000000000000000001c8fc9ad5e9471ad161f5b1f4d6453662cc4c5666fb50a65b0371356f1bc700ffe69ef975741ff998d49abf82e9e402e3d7dd782f48a2b2dc51251e07385db5185", contractAddress: "", cumulativeGasUsed: "1568774", gasUsed: "69568", confirmations: "3321816"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "50100061236213960" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x527a46173f854c6aa0100d580e7dd9e1"}, {type: "address", name: "_seller", value: addressList[37]}, {type: "address", name: "_buyer", value: addressList[38]}, {type: "uint256", name: "_value", value: "50100061236213960"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508561433"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x8fc9ad5e9471ad161f5b1f4d6453662cc4c5666fb50a65b0371356f1bc700ffe"}, {type: "bytes32", name: "_s", value: "0x69ef975741ff998d49abf82e9e402e3d7dd782f48a2b2dc51251e07385db5185"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x527a46173f854c6aa0100d580e7dd9e1", addressList[37], addressList[38], "50100061236213960", "100", "7200", "1508561433", "28", "0x8fc9ad5e9471ad161f5b1f4d6453662cc4c5666fb50a65b0371356f1bc700ffe", "0x69ef975741ff998d49abf82e9e402e3d7dd782f48a2b2dc51251e07385db5185", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508557860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x7e05f33fb961f45e2f7eb352b75b649bf10d590bf5a70a3ad43369f5ef11f771"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x527a46173f854c6aa0100d580e7dd9e1\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399695", timeStamp: "1508558153", hash: "0x37e881f0cbd7bae58eef82bc92deadcda6c07c76f620227edb2a59a14c6f045e", nonce: "13", blockHash: "0x86af338acec3c22755b192ef8036f7ae45521ac350bd67ffcc618152b04fe1d3", transactionIndex: "97", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001527a46173f854c6aa0100d580e7dd9e1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000d5cf837798dde24a52c48b517a69047acc04be8e00000000000000000000000000000000000000000000000000000000000000010000000000000000000000006202d19e63edc550ed5faf3fb7b35ede3c22cf04000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000b1fdbd8135b8c800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000012213f176435317f3239d70a405295134cbbf390379582f8cbec8e0d1250172030000000000000000000000000000000000000000000000000000000000000001274c33e690f54f7369461f99b2d0a78a4da51b512a1a02c896040274d14224c400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2797287", gasUsed: "75284", confirmations: "3321792"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x527a46173f854c6aa0100d580e7dd9e1"]}, {type: "address[]", name: "_seller", value: [addressList[37]]}, {type: "address[]", name: "_buyer", value: [addressList[38]]}, {type: "uint256[]", name: "_value", value: ["50100061236213960"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x2213f176435317f3239d70a405295134cbbf390379582f8cbec8e0d125017203"]}, {type: "bytes32[]", name: "_s", value: ["0x274c33e690f54f7369461f99b2d0a78a4da51b512a1a02c896040274d14224c4"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x527a46173f854c6aa0100d580e7dd9e1"], [addressList[37]], [addressList[38]], ["50100061236213960"], ["100"], ["30000000000"], ["28"], ["0x2213f176435317f3239d70a405295134cbbf390379582f8cbec8e0d125017203"], ["0x274c33e690f54f7369461f99b2d0a78a4da51b512a1a02c896040274d14224c4"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508558153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x7e05f33fb961f45e2f7eb352b75b649bf10d590bf5a70a3ad43369f5ef11f771"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xc7fd134b3b7849bfa406aaf0d06f35e0\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399708", timeStamp: "1508558286", hash: "0x930f955181184e3c5f60a3bb9e104b7d3e654d35e1f347ac54f91fad906e756d", nonce: "3", blockHash: "0xe76b1b9d3d5951b8217bc8b9cb67ed0e0ad92ce8236aeabc85c3985fe31976f7", transactionIndex: "16", from: "0x71af594b6418e9e85000d684741b34c045b2157f", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "1000000000000000000", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67c7fd134b3b7849bfa406aaf0d06f35e0000000000000000000000000000000000000000000000000000000008375f16adfa377e88c240e62c6c2792ea309e5f2000000000000000000000000f1bf45b8d75a4997198033445151c0a5334f19d60000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059ead3cb000000000000000000000000000000000000000000000000000000000000001c5738e231bbaddb7b4b4cc5b165339c33ddcc03be84cfeedfa7c19e99a86fcd727175533f15569c3fcad21b870578615d0380fce2303fa1a3ff64819115c8ac86", contractAddress: "", cumulativeGasUsed: "722987", gasUsed: "69504", confirmations: "3321779"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xc7fd134b3b7849bfa406aaf0d06f35e0"}, {type: "address", name: "_seller", value: addressList[39]}, {type: "address", name: "_buyer", value: addressList[40]}, {type: "uint256", name: "_value", value: "1000000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508561867"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x5738e231bbaddb7b4b4cc5b165339c33ddcc03be84cfeedfa7c19e99a86fcd72"}, {type: "bytes32", name: "_s", value: "0x7175533f15569c3fcad21b870578615d0380fce2303fa1a3ff64819115c8ac86"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xc7fd134b3b7849bfa406aaf0d06f35e0", addressList[39], addressList[40], "1000000000000000000", "100", "7200", "1508561867", "28", "0x5738e231bbaddb7b4b4cc5b165339c33ddcc03be84cfeedfa7c19e99a86fcd72", "0x7175533f15569c3fcad21b870578615d0380fce2303fa1a3ff64819115c8ac86", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508558286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x7497950b9622d7574c098ed240579cdf502d13c6761e849dc92d9ef42c67f1e2"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x45e23a59684c42c79503a47d0e19b768\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399758", timeStamp: "1508559000", hash: "0xd4894b545b18939c965355b8df4e2d19457347165a750969d5b0cc82ed1b0869", nonce: "0", blockHash: "0x718063ee81c8afc83026664efd6fd633d6bd8020bdf0a03e0f96d575a2f8caa2", transactionIndex: "42", from: "0x53368611f901ad5622ab7fed08ee959b8fb11251", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "22900000000000000", gas: "75000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6745e23a59684c42c79503a47d0e19b76800000000000000000000000000000000000000000000000000000000044f778a7a18ab8399528829d023ebf7f3828beb000000000000000000000000783786b177e0b230871f8803115a34811edcf83500000000000000000000000000000000000000000000000000515b6dbd5b4000000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059ead69d000000000000000000000000000000000000000000000000000000000000001b603df631eea7f0f2f844b1abefab9f666cc408857440c4131fb5ae93c53dfc8b27a04492b29d08e539de65120da9574a8449664e3e1efd18ca9e5192c7c43e2a", contractAddress: "", cumulativeGasUsed: "1439563", gasUsed: "69504", confirmations: "3321729"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "22900000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x45e23a59684c42c79503a47d0e19b768"}, {type: "address", name: "_seller", value: addressList[42]}, {type: "address", name: "_buyer", value: addressList[43]}, {type: "uint256", name: "_value", value: "22900000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508562589"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x603df631eea7f0f2f844b1abefab9f666cc408857440c4131fb5ae93c53dfc8b"}, {type: "bytes32", name: "_s", value: "0x27a04492b29d08e539de65120da9574a8449664e3e1efd18ca9e5192c7c43e2a"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x45e23a59684c42c79503a47d0e19b768", addressList[42], addressList[43], "22900000000000000", "100", "21600", "1508562589", "27", "0x603df631eea7f0f2f844b1abefab9f666cc408857440c4131fb5ae93c53dfc8b", "0x27a04492b29d08e539de65120da9574a8449664e3e1efd18ca9e5192c7c43e2a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508559000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x240be4ce54c48aab5f18f264a5b79818fe6d6bae646133609d4910f690de2937"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x37ad86ca212941f59d49459064d18177\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399798", timeStamp: "1508559515", hash: "0xed31891305f647d2fcfae676715663c53eaa8ebc4291778caee7d9f1bb715d81", nonce: "14", blockHash: "0xdf9781e606fb24dcac9bbbd892b40b6a84d67b18ecb897793d876fdf5c34321a", transactionIndex: "19", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250175", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000000137ad86ca212941f59d49459064d181770000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000008d0b2f7de43f93e974e6da2dc0d931df9245af6d0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b4efbf0c3a323209109f50ae17ddb3554aa5284e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000005698eef0667000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001522124647041ce6be4bbf58d708f9bb8a39712199d04b08b7368cc7231a802360000000000000000000000000000000000000000000000000000000000000001768dbfdc1c403422ebc08c1920ec53b14e4fd165a1775ded1502de9777c209f400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "508745", gasUsed: "75338", confirmations: "3321689"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x37ad86ca212941f59d49459064d18177"]}, {type: "address[]", name: "_seller", value: [addressList[22]]}, {type: "address[]", name: "_buyer", value: [addressList[23]]}, {type: "uint256[]", name: "_value", value: ["390000000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x522124647041ce6be4bbf58d708f9bb8a39712199d04b08b7368cc7231a80236"]}, {type: "bytes32[]", name: "_s", value: ["0x768dbfdc1c403422ebc08c1920ec53b14e4fd165a1775ded1502de9777c209f4"]}, {type: "uint8[]", name: "_actionByte", value: ["3"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x37ad86ca212941f59d49459064d18177"], [addressList[22]], [addressList[23]], ["390000000000000000"], ["100"], ["30000000000"], ["28"], ["0x522124647041ce6be4bbf58d708f9bb8a39712199d04b08b7368cc7231a80236"], ["0x768dbfdc1c403422ebc08c1920ec53b14e4fd165a1775ded1502de9777c209f4"], ["3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508559515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledBySeller", events: [{name: "_tradeHash", type: "bytes32", value: "0xd550d88719f16b53c0ae870b3938031e6ca78d2e79b27970e8ae3434186f8fd7"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0xf59731b1cd434eb382257a001b31026d\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399847", timeStamp: "1508560314", hash: "0x68b54437ff4444f45ca884647f896d38b780d81ca374ebf7af19c715d0447e38", nonce: "15", blockHash: "0xfb59957e4aa8a4af8d6332fa2cc83d00fe1c8cace8f8b2787670a89402270abc", transactionIndex: "24", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249855", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001f59731b1cd434eb382257a001b31026d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000068a3f7804572010f4f6fb19558b5f1ec2511ae2e0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dd0400e5b9c73b3eea09e6ad3a512b2c2a711b1d000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000002c68af0bb14000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001eb0cc05e6b8cf8b72387b3c1ee74a1f04d52988691f111d85aef1ae3ede43418000000000000000000000000000000000000000000000000000000000000000117a4632cf574cba7c87c55f7bdd8fd1e5fa37bc6f2b38645ec230378a969673600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "883045", gasUsed: "75210", confirmations: "3321640"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0xf59731b1cd434eb382257a001b31026d"]}, {type: "address[]", name: "_seller", value: [addressList[25]]}, {type: "address[]", name: "_buyer", value: [addressList[26]]}, {type: "uint256[]", name: "_value", value: ["200000000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xeb0cc05e6b8cf8b72387b3c1ee74a1f04d52988691f111d85aef1ae3ede43418"]}, {type: "bytes32[]", name: "_s", value: ["0x17a4632cf574cba7c87c55f7bdd8fd1e5fa37bc6f2b38645ec230378a9696736"]}, {type: "uint8[]", name: "_actionByte", value: ["3"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0xf59731b1cd434eb382257a001b31026d"], [addressList[25]], [addressList[26]], ["200000000000000000"], ["100"], ["30000000000"], ["27"], ["0xeb0cc05e6b8cf8b72387b3c1ee74a1f04d52988691f111d85aef1ae3ede43418"], ["0x17a4632cf574cba7c87c55f7bdd8fd1e5fa37bc6f2b38645ec230378a9696736"], ["3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508560314 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledBySeller", events: [{name: "_tradeHash", type: "bytes32", value: "0xcdece1e3708f050940ef35bd869ed78cad5caad4606613a03ab5976139297709"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x666d5f1baeef45988548ce174f94a0df\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399918", timeStamp: "1508561356", hash: "0x0ecf95177be877ea4536a6b8987a034e17e782f6afd446942fc78ea9c5e277b7", nonce: "0", blockHash: "0x4fb6d64ebbb00a17221fcd5bc38b58e228644a00221c5f82acc43b5339a97c08", transactionIndex: "58", from: "0xaec2e4076448ab6317ea7016c4f6880b4a9d3a1b", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "133229799940657689", gas: "75000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67666d5f1baeef45988548ce174f94a0df00000000000000000000000000000000000000000000000000000000aec2e4076448ab6317ea7016c4f6880b4a9d3a1b000000000000000000000000f731b0842685846753c6ad757b67f6c2beb39ea600000000000000000000000000000000000000000000000001d953cc12f59219000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eadfa5000000000000000000000000000000000000000000000000000000000000001be546a0f7009547e4f3f0f4f236f227d02b844a4d1a6a2108aff678fff2dddf44703819d31bb6d1698ad6a4fd930c670c1eae063069aece19f58b12640f95f017", contractAddress: "", cumulativeGasUsed: "2004290", gasUsed: "69425", confirmations: "3321569"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "133229799940657689" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x666d5f1baeef45988548ce174f94a0df"}, {type: "address", name: "_seller", value: addressList[44]}, {type: "address", name: "_buyer", value: addressList[45]}, {type: "uint256", name: "_value", value: "133229799940657689"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508564901"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xe546a0f7009547e4f3f0f4f236f227d02b844a4d1a6a2108aff678fff2dddf44"}, {type: "bytes32", name: "_s", value: "0x703819d31bb6d1698ad6a4fd930c670c1eae063069aece19f58b12640f95f017"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x666d5f1baeef45988548ce174f94a0df", addressList[44], addressList[45], "133229799940657689", "100", "0", "1508564901", "27", "0xe546a0f7009547e4f3f0f4f236f227d02b844a4d1a6a2108aff678fff2dddf44", "0x703819d31bb6d1698ad6a4fd930c670c1eae063069aece19f58b12640f95f017", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508561356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xc82d3f1f6a65046720ccbae845ac4f1671671ad66b62b83aee812150bd49c783"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "238953860059342311" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xd54a0d942c6c45158a4c1246ef6dcec5\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4399934", timeStamp: "1508561603", hash: "0xd13b7942be8208ae12aa5e70a716b867b5df8706b797bb6be51d3e730c143e58", nonce: "0", blockHash: "0xfeb2ecbfb28279df9c2d9383a34a46dada3af7d87ace9028c1b1c70a622b854b", transactionIndex: "95", from: "0x2d6834e076bbb9308aca6db03d34c79d704a58cf", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "2999500000000000000", gas: "75000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67d54a0d942c6c45158a4c1246ef6dcec500000000000000000000000000000000000000000000000000000000dc148e0e2d5584cb51088f1791cba5bb4cc0d1de00000000000000000000000036f005f60d4c2c54c846eef28ca308c01210d4f600000000000000000000000000000000000000000000000029a05d5ba3c8c00000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000001c200000000000000000000000000000000000000000000000000000000059eae0a6000000000000000000000000000000000000000000000000000000000000001b0990268929e9d51c34130f9e62a003439551eee34177447d919365fc9bd402bb0fb57f6083fd323964b2c5e5f0963b5cdcf21ae59cdb9aac78b16b7d75610db2", contractAddress: "", cumulativeGasUsed: "3614808", gasUsed: "69568", confirmations: "3321553"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "2999500000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xd54a0d942c6c45158a4c1246ef6dcec5"}, {type: "address", name: "_seller", value: addressList[47]}, {type: "address", name: "_buyer", value: addressList[48]}, {type: "uint256", name: "_value", value: "2999500000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "7200"}, {type: "uint32", name: "_expiry", value: "1508565158"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x0990268929e9d51c34130f9e62a003439551eee34177447d919365fc9bd402bb"}, {type: "bytes32", name: "_s", value: "0x0fb57f6083fd323964b2c5e5f0963b5cdcf21ae59cdb9aac78b16b7d75610db2"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xd54a0d942c6c45158a4c1246ef6dcec5", addressList[47], addressList[48], "2999500000000000000", "100", "7200", "1508565158", "27", "0x0990268929e9d51c34130f9e62a003439551eee34177447d919365fc9bd402bb", "0x0fb57f6083fd323964b2c5e5f0963b5cdcf21ae59cdb9aac78b16b7d75610db2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508561603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xc92a3d0440e9b66f287f9add00032ad75702346bde90697fda2fbf2fb903da72"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x666d5f1baeef45988548ce174f94a0df\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4399979", timeStamp: "1508562450", hash: "0x4a3d5abdb601edbd4af7469dfb74e365154f21e45a50b203564aec58331db463", nonce: "16", blockHash: "0x6a73bffd24db31c9e75f041c367df73b577ec44dd939ffc81f213ce8660191da", transactionIndex: "21", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250200", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001666d5f1baeef45988548ce174f94a0df000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000aec2e4076448ab6317ea7016c4f6880b4a9d3a1b0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f731b0842685846753c6ad757b67f6c2beb39ea6000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000001d953cc12f5921900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001e2d8613ea04649df5710162c9620585d51756a6be806cdb73b664617e401880400000000000000000000000000000000000000000000000000000000000000010653e1fd16f3e21b60f281e8fcf8736c08532238ca3396fb8d24a137cc461b4000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "1095469", gasUsed: "75348", confirmations: "3321508"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x666d5f1baeef45988548ce174f94a0df"]}, {type: "address[]", name: "_seller", value: [addressList[44]]}, {type: "address[]", name: "_buyer", value: [addressList[45]]}, {type: "uint256[]", name: "_value", value: ["133229799940657689"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0xe2d8613ea04649df5710162c9620585d51756a6be806cdb73b664617e4018804"]}, {type: "bytes32[]", name: "_s", value: ["0x0653e1fd16f3e21b60f281e8fcf8736c08532238ca3396fb8d24a137cc461b40"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x666d5f1baeef45988548ce174f94a0df"], [addressList[44]], [addressList[45]], ["133229799940657689"], ["100"], ["30000000000"], ["28"], ["0xe2d8613ea04649df5710162c9620585d51756a6be806cdb73b664617e4018804"], ["0x0653e1fd16f3e21b60f281e8fcf8736c08532238ca3396fb8d24a137cc461b40"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508562450 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0xc82d3f1f6a65046720ccbae845ac4f1671671ad66b62b83aee812150bd49c783"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x6d46c47bd7314b61acfa23437a1a152f\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400072", timeStamp: "1508563828", hash: "0xfe93a06a88b0146c051850c2e74779f6afb02f5d5ac68d69b1b2aef2ec3c77d3", nonce: "0", blockHash: "0xb3cf00ed7b23b31fb94fbc0d4d180f1dc7800bf1e51c5cdcb879bbab20872c28", transactionIndex: "57", from: "0xd24ed57df2450fd74ba90f1f6c0ab8004b8715af", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "830700000000000000", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d676d46c47bd7314b61acfa23437a1a152f00000000000000000000000000000000000000000000000000000000fedcc13686a73a3a298f757d9616efe8b113091500000000000000000000000055db5180741eb1f65d4c7c0526fa574d2b4f20e10000000000000000000000000000000000000000000000000b873d3faeeac000000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eae95d000000000000000000000000000000000000000000000000000000000000001ce985b702a40efe1ae6dddbcaa1d836ecef8cfb18d477416cfc7a9ee2f77a88ff73a6b68637e473834a73fd60de3a74f1b2a725205ff76f02e56bc17d2319a33a", contractAddress: "", cumulativeGasUsed: "2339295", gasUsed: "69568", confirmations: "3321415"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "830700000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x6d46c47bd7314b61acfa23437a1a152f"}, {type: "address", name: "_seller", value: addressList[50]}, {type: "address", name: "_buyer", value: addressList[51]}, {type: "uint256", name: "_value", value: "830700000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508567389"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xe985b702a40efe1ae6dddbcaa1d836ecef8cfb18d477416cfc7a9ee2f77a88ff"}, {type: "bytes32", name: "_s", value: "0x73a6b68637e473834a73fd60de3a74f1b2a725205ff76f02e56bc17d2319a33a"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x6d46c47bd7314b61acfa23437a1a152f", addressList[50], addressList[51], "830700000000000000", "100", "21600", "1508567389", "28", "0xe985b702a40efe1ae6dddbcaa1d836ecef8cfb18d477416cfc7a9ee2f77a88ff", "0x73a6b68637e473834a73fd60de3a74f1b2a725205ff76f02e56bc17d2319a33a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508563828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x2364f7a93e5cfe0ca821a70d47ffa5c65be572c2e5ec3c66a7622874bc39658d"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x1056b9e0328f492cba222100426aed32\",... )", async function( ) {
		const txOriginal = {blockNumber: "4400192", timeStamp: "1508565412", hash: "0xddce78f34aedb33dc01600382aff9414ec0e7231fda3a9637842774bcd0771d0", nonce: "17", blockHash: "0xbe30ac58b59b5fad91137bbf177a0704fbdace5beab6ee7ad55d52a6ecd02dd9", transactionIndex: "65", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "384033", gasPrice: "14400000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000044000000000000000000000000000000000000000000000000000000000000004c0000000000000000000000000000000000000000000000000000000000000054000000000000000000000000000000000000000000000000000000000000005c000000000000000000000000000000000000000000000000000000000000000031056b9e0328f492cba222100426aed320000000000000000000000000000000045e23a59684c42c79503a47d0e19b768000000000000000000000000000000006d46c47bd7314b61acfa23437a1a152f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000009ecc8724a82b8f197a3823414c2fb13bae429064000000000000000000000000044f778a7a18ab8399528829d023ebf7f3828beb000000000000000000000000fedcc13686a73a3a298f757d9616efe8b1130915000000000000000000000000000000000000000000000000000000000000000300000000000000000000000044c1d404209c64dc5f255d8634e68a6b98b35ab0000000000000000000000000783786b177e0b230871f8803115a34811edcf83500000000000000000000000055db5180741eb1f65d4c7c0526fa574d2b4f20e1000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000515b6dbd5b40000000000000000000000000000000000000000000000000000b873d3faeeac0000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000034b24a267ce5d84e3d1bd76062dc544d795ade771095d955b2ef434d66e3a9aed6383be472f558e59ebc9fd0130c4a7c166ae0f15b8af4095de28615f087b10686307ad4c410ba9cfba3cbaf78b488fc1693dfa3bfca09a49fe1af9c275eaae40000000000000000000000000000000000000000000000000000000000000000347bd675d785913ec86b123addf7acf4d33908c53dc47c2fa91f741a9e880230126d5530ca0dc15e2dbbff388bbe5dba21ff0425832cfe08d8d2fb22192f587e31c4f00b855120331a8498f992fb5ac5705f26fb1456b81ce97bf99ad739decb20000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3021448", gasUsed: "106733", confirmations: "3321295"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x1056b9e0328f492cba222100426aed32","0x45e23a59684c42c79503a47d0e19b768","0x6d46c47bd7314b61acfa23437a1a152f"]}, {type: "address[]", name: "_seller", value: [addressList[28],addressList[42],addressList[50]]}, {type: "address[]", name: "_buyer", value: [addressList[29],addressList[43],addressList[51]]}, {type: "uint256[]", name: "_value", value: ["500000000000000000","22900000000000000","830700000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100","100","100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000","30000000000","30000000000"]}, {type: "uint8[]", name: "_v", value: ["28","27","28"]}, {type: "bytes32[]", name: "_r", value: ["0x4b24a267ce5d84e3d1bd76062dc544d795ade771095d955b2ef434d66e3a9aed","0x6383be472f558e59ebc9fd0130c4a7c166ae0f15b8af4095de28615f087b1068","0x6307ad4c410ba9cfba3cbaf78b488fc1693dfa3bfca09a49fe1af9c275eaae40"]}, {type: "bytes32[]", name: "_s", value: ["0x47bd675d785913ec86b123addf7acf4d33908c53dc47c2fa91f741a9e8802301","0x26d5530ca0dc15e2dbbff388bbe5dba21ff0425832cfe08d8d2fb22192f587e3","0x1c4f00b855120331a8498f992fb5ac5705f26fb1456b81ce97bf99ad739decb2"]}, {type: "uint8[]", name: "_actionByte", value: ["3","1","1"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x1056b9e0328f492cba222100426aed32","0x45e23a59684c42c79503a47d0e19b768","0x6d46c47bd7314b61acfa23437a1a152f"], [addressList[28],addressList[42],addressList[50]], [addressList[29],addressList[43],addressList[51]], ["500000000000000000","22900000000000000","830700000000000000"], ["100","100","100"], ["30000000000","30000000000","30000000000"], ["28","27","28"], ["0x4b24a267ce5d84e3d1bd76062dc544d795ade771095d955b2ef434d66e3a9aed","0x6383be472f558e59ebc9fd0130c4a7c166ae0f15b8af4095de28615f087b1068","0x6307ad4c410ba9cfba3cbaf78b488fc1693dfa3bfca09a49fe1af9c275eaae40"], ["0x47bd675d785913ec86b123addf7acf4d33908c53dc47c2fa91f741a9e8802301","0x26d5530ca0dc15e2dbbff388bbe5dba21ff0425832cfe08d8d2fb22192f587e3","0x1c4f00b855120331a8498f992fb5ac5705f26fb1456b81ce97bf99ad739decb2"], ["3","1","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508565412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledBySeller", events: [{name: "_tradeHash", type: "bytes32", value: "0x0b9df8d9bb24265ea769cc917f0da2b5603a3facceacc16987ff783c363fe836"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x0c0501455f864eaa8e51a4f53fc100ee\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400200", timeStamp: "1508565479", hash: "0x4f5fa5dce69430f9f5aa9d935708eefe946fde0b4d4e22362f26faace03bfffc", nonce: "18", blockHash: "0x6ab09fa749e816513292a16010a29340ca1126336e6089a6b638df730689d2d5", transactionIndex: "5", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249855", gasPrice: "14400000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000010c0501455f864eaa8e51a4f53fc100ee000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a9047e8b75ee500e8fbe14b434ca142e16c8b4b00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000fb7ae564e2eaa0e2398a26ad9f655f1a98a3981900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001ef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf81300000000000000000000000000000000000000000000000000000000000000014e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f0800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "327334", gasUsed: "75210", confirmations: "3321287"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x0c0501455f864eaa8e51a4f53fc100ee"]}, {type: "address[]", name: "_seller", value: [addressList[34]]}, {type: "address[]", name: "_buyer", value: [addressList[35]]}, {type: "uint256[]", name: "_value", value: ["1000000000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf813"]}, {type: "bytes32[]", name: "_s", value: ["0x4e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f08"]}, {type: "uint8[]", name: "_actionByte", value: ["3"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x0c0501455f864eaa8e51a4f53fc100ee"], [addressList[34]], [addressList[35]], ["1000000000000000000"], ["100"], ["30000000000"], ["27"], ["0xef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf813"], ["0x4e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f08"], ["3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508565479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledBySeller", events: [{name: "_tradeHash", type: "bytes32", value: "0xa2bd905f69474a178771ff7389243a509d3a6dfdeb5f38e82a84543bd455f8d6"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x0c0501455f864eaa8e51a4f53fc100ee\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400200", timeStamp: "1508565479", hash: "0x10f6f895cb0036b7ee420176b9ed8968013680b9062a86452c846505401f7f5d", nonce: "19", blockHash: "0x6ab09fa749e816513292a16010a29340ca1126336e6089a6b638df730689d2d5", transactionIndex: "6", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249850", gasPrice: "14400000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000010c0501455f864eaa8e51a4f53fc100ee000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a9047e8b75ee500e8fbe14b434ca142e16c8b4b00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000fb7ae564e2eaa0e2398a26ad9f655f1a98a3981900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001ef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf81300000000000000000000000000000000000000000000000000000000000000014e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f0800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "372802", gasUsed: "45468", confirmations: "3321287"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x0c0501455f864eaa8e51a4f53fc100ee"]}, {type: "address[]", name: "_seller", value: [addressList[34]]}, {type: "address[]", name: "_buyer", value: [addressList[35]]}, {type: "uint256[]", name: "_value", value: ["1000000000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf813"]}, {type: "bytes32[]", name: "_s", value: ["0x4e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f08"]}, {type: "uint8[]", name: "_actionByte", value: ["3"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x0c0501455f864eaa8e51a4f53fc100ee"], [addressList[34]], [addressList[35]], ["1000000000000000000"], ["100"], ["30000000000"], ["27"], ["0xef0016c8952404d86612768401815e988c510f5f9eefb0eebf3263ead39cf813"], ["0x4e314d3d1775fb3497a9d05b7a89e6408468f1e58b526dde8b5857ffb9860f08"], ["3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508565479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0xc7fd134b3b7849bfa406aaf0d06f35e0\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400202", timeStamp: "1508565533", hash: "0xb6d6eb522938404edcabc72f1f5f9492d1807a45aeb848bee4e1c791fb87bfd8", nonce: "20", blockHash: "0xb4ac8dc60bfd0178659bd2f7ae7171a5f5ffc3fbf2ff1393ce74250c883fee0f", transactionIndex: "77", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "134045", gasPrice: "14400000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001c7fd134b3b7849bfa406aaf0d06f35e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000008375f16adfa377e88c240e62c6c2792ea309e5f20000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f1bf45b8d75a4997198033445151c0a5334f19d600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001b05442093781d86544fa07487083beeed92ae24c9a548794c11ef825e9ab52e000000000000000000000000000000000000000000000000000000000000000015134797c0b4977ac000dfb9616e6b04413a1409e33bdaf6d20d9d0fb0d3bc73800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3499123", gasUsed: "75274", confirmations: "3321285"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0xc7fd134b3b7849bfa406aaf0d06f35e0"]}, {type: "address[]", name: "_seller", value: [addressList[39]]}, {type: "address[]", name: "_buyer", value: [addressList[40]]}, {type: "uint256[]", name: "_value", value: ["1000000000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0xb05442093781d86544fa07487083beeed92ae24c9a548794c11ef825e9ab52e0"]}, {type: "bytes32[]", name: "_s", value: ["0x5134797c0b4977ac000dfb9616e6b04413a1409e33bdaf6d20d9d0fb0d3bc738"]}, {type: "uint8[]", name: "_actionByte", value: ["3"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0xc7fd134b3b7849bfa406aaf0d06f35e0"], [addressList[39]], [addressList[40]], ["1000000000000000000"], ["100"], ["30000000000"], ["28"], ["0xb05442093781d86544fa07487083beeed92ae24c9a548794c11ef825e9ab52e0"], ["0x5134797c0b4977ac000dfb9616e6b04413a1409e33bdaf6d20d9d0fb0d3bc738"], ["3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1508565533 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledBySeller", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledBySeller", events: [{name: "_tradeHash", type: "bytes32", value: "0x7497950b9622d7574c098ed240579cdf502d13c6761e849dc92d9ef42c67f1e2"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x3c92c7ed6759476295fccf4c23d63dd9\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400276", timeStamp: "1508566703", hash: "0x0fb9d5f2cf7bfbcb503ca801bd9836f3683b87c4cff8c6f73e45a00a8a7d6da5", nonce: "0", blockHash: "0x33342574de9bf05d4e459ac6b4f931e756fff50530981d899f419e3cc6d17cc6", transactionIndex: "14", from: "0x25e4dc300c09d83ee23cceaacbeeba08558e1035", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "60604912785742694", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d673c92c7ed6759476295fccf4c23d63dd900000000000000000000000000000000000000000000000000000000c004da37499fe78ff3d48d555c7874b1d5d2ee84000000000000000000000000cab3fb089b1c126b57847a8299c252e067c144c800000000000000000000000000000000000000000000000000d74fd8da3cdb66000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eaf4ab000000000000000000000000000000000000000000000000000000000000001b738cfc76440823a908b82c0b68ad453b5e4151dd59de1d944eee68ba875e4be133b35d453f132ce29c45b059c371b059bb5d382d550fce2ca2b48b82cdd3b73e", contractAddress: "", cumulativeGasUsed: "531518", gasUsed: "69568", confirmations: "3321211"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "60604912785742694" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x3c92c7ed6759476295fccf4c23d63dd9"}, {type: "address", name: "_seller", value: addressList[53]}, {type: "address", name: "_buyer", value: addressList[54]}, {type: "uint256", name: "_value", value: "60604912785742694"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508570283"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x738cfc76440823a908b82c0b68ad453b5e4151dd59de1d944eee68ba875e4be1"}, {type: "bytes32", name: "_s", value: "0x33b35d453f132ce29c45b059c371b059bb5d382d550fce2ca2b48b82cdd3b73e"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x3c92c7ed6759476295fccf4c23d63dd9", addressList[53], addressList[54], "60604912785742694", "100", "21600", "1508570283", "27", "0x738cfc76440823a908b82c0b68ad453b5e4151dd59de1d944eee68ba875e4be1", "0x33b35d453f132ce29c45b059c371b059bb5d382d550fce2ca2b48b82cdd3b73e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508566703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x21a63531ff5101dcd208393271f5f1717f494752f2fb64320a28400d9fe44438"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x3c92c7ed6759476295fccf4c23d63dd9\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400286", timeStamp: "1508566765", hash: "0xaa23815ee8ed05b012c243d42c563cf04fd1fab4ffa31c1a3b4622370d433d83", nonce: "21", blockHash: "0x0df380778302f7c131e0ea5553e9bb876fc1aae024c96595d17d28c0f7e29701", transactionIndex: "8", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000013c92c7ed6759476295fccf4c23d63dd9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000c004da37499fe78ff3d48d555c7874b1d5d2ee840000000000000000000000000000000000000000000000000000000000000001000000000000000000000000cab3fb089b1c126b57847a8299c252e067c144c8000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000d74fd8da3cdb6600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000016e6cd862491cb51c73e59d630ebeac69fd707c0302af13c0d72475d2ff2ebbfe00000000000000000000000000000000000000000000000000000000000000011e7406dc990341a1436a1ec9ebf54693bac2d2631c51d5872efc41a5f79b451500000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "427504", gasUsed: "75284", confirmations: "3321201"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x3c92c7ed6759476295fccf4c23d63dd9"]}, {type: "address[]", name: "_seller", value: [addressList[53]]}, {type: "address[]", name: "_buyer", value: [addressList[54]]}, {type: "uint256[]", name: "_value", value: ["60604912785742694"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0x6e6cd862491cb51c73e59d630ebeac69fd707c0302af13c0d72475d2ff2ebbfe"]}, {type: "bytes32[]", name: "_s", value: ["0x1e7406dc990341a1436a1ec9ebf54693bac2d2631c51d5872efc41a5f79b4515"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x3c92c7ed6759476295fccf4c23d63dd9"], [addressList[53]], [addressList[54]], ["60604912785742694"], ["100"], ["30000000000"], ["27"], ["0x6e6cd862491cb51c73e59d630ebeac69fd707c0302af13c0d72475d2ff2ebbfe"], ["0x1e7406dc990341a1436a1ec9ebf54693bac2d2631c51d5872efc41a5f79b4515"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508566765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x21a63531ff5101dcd208393271f5f1717f494752f2fb64320a28400d9fe44438"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x2350bbb59c3b4112b777af5e37ebd1bf\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400360", timeStamp: "1508567735", hash: "0x409b17988cda4a28897e783365de9d5a769136c9abe772e372e6e494a6ea2ae3", nonce: "0", blockHash: "0x6dd1592d6727c32a2b64710c13c8a115655e0bfc18b0cf2bbd1c3a94a321c23d", transactionIndex: "122", from: "0x32ce8483fcb3fad7f5f9bdcf53ca54a62ac03ced", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "954700000000000000", gas: "75000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d672350bbb59c3b4112b777af5e37ebd1bf000000000000000000000000000000000000000000000000000000006a8ba4d48b7ec2fdd4ac59016169dd5cd7b31844000000000000000000000000b599250678e2177578075a3a470946c2237886010000000000000000000000000000000000000000000000000d3fc6977f10c000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eaf8b1000000000000000000000000000000000000000000000000000000000000001c51c16eeff3b8f03452fa6c01630412903e029006a33f5edd604df4ea9f20aaa938ee14ac2aa5e75b64131ba8ef9b3a96afc411316efe7afc9cf0e9a6c7b25f0a", contractAddress: "", cumulativeGasUsed: "4183487", gasUsed: "69425", confirmations: "3321127"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "954700000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x2350bbb59c3b4112b777af5e37ebd1bf"}, {type: "address", name: "_seller", value: addressList[56]}, {type: "address", name: "_buyer", value: addressList[57]}, {type: "uint256", name: "_value", value: "954700000000000000"}, {type: "uint16", name: "_fee", value: "25"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508571313"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x51c16eeff3b8f03452fa6c01630412903e029006a33f5edd604df4ea9f20aaa9"}, {type: "bytes32", name: "_s", value: "0x38ee14ac2aa5e75b64131ba8ef9b3a96afc411316efe7afc9cf0e9a6c7b25f0a"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x2350bbb59c3b4112b777af5e37ebd1bf", addressList[56], addressList[57], "954700000000000000", "25", "0", "1508571313", "28", "0x51c16eeff3b8f03452fa6c01630412903e029006a33f5edd604df4ea9f20aaa9", "0x38ee14ac2aa5e75b64131ba8ef9b3a96afc411316efe7afc9cf0e9a6c7b25f0a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508567735 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x0d0be59301d217379598ea744d402aea85b27b57e116828a7c0c756bf2e893a7"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x6d46c47bd7314b61acfa23437a1a152f\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400405", timeStamp: "1508568346", hash: "0x895b47e37704a65b864743680c89ec4eb80ca53e15bce1485ffaa2d6d2208cb8", nonce: "22", blockHash: "0x3dddcc77df3481ab7b35526104fd62a93fe54f186d44c263e53bae6168e59ea2", transactionIndex: "120", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000016d46c47bd7314b61acfa23437a1a152f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000fedcc13686a73a3a298f757d9616efe8b1130915000000000000000000000000000000000000000000000000000000000000000100000000000000000000000055db5180741eb1f65d4c7c0526fa574d2b4f20e100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000b873d3faeeac00000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001541923188d2c248ac882dfb519ab63d82d9a8d07b67e4b190a05c6b5c2bf52d200000000000000000000000000000000000000000000000000000000000000014c30a7cd6363305b988766bbbce749dd15efcf62d2d315ec016a4676979def9b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "4131481", gasUsed: "75284", confirmations: "3321082"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x6d46c47bd7314b61acfa23437a1a152f"]}, {type: "address[]", name: "_seller", value: [addressList[50]]}, {type: "address[]", name: "_buyer", value: [addressList[51]]}, {type: "uint256[]", name: "_value", value: ["830700000000000000"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x541923188d2c248ac882dfb519ab63d82d9a8d07b67e4b190a05c6b5c2bf52d2"]}, {type: "bytes32[]", name: "_s", value: ["0x4c30a7cd6363305b988766bbbce749dd15efcf62d2d315ec016a4676979def9b"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x6d46c47bd7314b61acfa23437a1a152f"], [addressList[50]], [addressList[51]], ["830700000000000000"], ["100"], ["30000000000"], ["28"], ["0x541923188d2c248ac882dfb519ab63d82d9a8d07b67e4b190a05c6b5c2bf52d2"], ["0x4c30a7cd6363305b988766bbbce749dd15efcf62d2d315ec016a4676979def9b"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508568346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x2364f7a93e5cfe0ca821a70d47ffa5c65be572c2e5ec3c66a7622874bc39658d"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x944cffd590534773a32941368a7859d2\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400405", timeStamp: "1508568346", hash: "0x32814d106b3fdd83536627552c23ebc925ffe5df569f0d636516940926e47533", nonce: "3", blockHash: "0x3dddcc77df3481ab7b35526104fd62a93fe54f186d44c263e53bae6168e59ea2", transactionIndex: "125", from: "0xf28cff7f74680d89aa518d867f18a15aac87fa47", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "26161120685845596", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67944cffd590534773a32941368a7859d20000000000000000000000000000000000000000000000000000000092bc7a63cbdd46fb60933353e01c75a4993359cc0000000000000000000000004ffb84d438fe4f47ffafd49bc777ec7e6e6837aa000000000000000000000000000000000000000000000000005cf1669167ec5c000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eafaec000000000000000000000000000000000000000000000000000000000000001cfebba50730ce8292016690245fac45f748045f6542b18b6b410617d52299ecf87847c1b5de100fc77c563265be2072c26b0fe0d753f5479cff3094a52b8df8e4", contractAddress: "", cumulativeGasUsed: "4401746", gasUsed: "69568", confirmations: "3321082"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "26161120685845596" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x944cffd590534773a32941368a7859d2"}, {type: "address", name: "_seller", value: addressList[58]}, {type: "address", name: "_buyer", value: addressList[59]}, {type: "uint256", name: "_value", value: "26161120685845596"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508571884"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xfebba50730ce8292016690245fac45f748045f6542b18b6b410617d52299ecf8"}, {type: "bytes32", name: "_s", value: "0x7847c1b5de100fc77c563265be2072c26b0fe0d753f5479cff3094a52b8df8e4"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x944cffd590534773a32941368a7859d2", addressList[58], addressList[59], "26161120685845596", "100", "21600", "1508571884", "28", "0xfebba50730ce8292016690245fac45f748045f6542b18b6b410617d52299ecf8", "0x7847c1b5de100fc77c563265be2072c26b0fe0d753f5479cff3094a52b8df8e4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508568346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x323a0acd9dcc73595c2461c6f0f9e757a4079ea2f7f252fe3e0e5f00d71dff0f"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x944cffd590534773a32941368a7859d2\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400417", timeStamp: "1508568503", hash: "0xb0189d6b669b067fc1cfdaef31fb40e98769888295d4656a4176a8a5263d2494", nonce: "23", blockHash: "0xacff61db2c8756d71e7a255f577c2e47d1db070f4e0f290079946cb517140bd6", transactionIndex: "18", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001944cffd590534773a32941368a7859d200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000092bc7a63cbdd46fb60933353e01c75a4993359cc00000000000000000000000000000000000000000000000000000000000000010000000000000000000000004ffb84d438fe4f47ffafd49bc777ec7e6e6837aa0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000005cf1669167ec5c00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000001a05cc22b732dd1720d067e51bc7d9620828efe06b2c15abc63f816948eebbc210000000000000000000000000000000000000000000000000000000000000001042cefd1690e678ae71bfe24f7453eb05784210801d2880821fd502043e1ccd900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "534320", gasUsed: "75284", confirmations: "3321070"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x944cffd590534773a32941368a7859d2"]}, {type: "address[]", name: "_seller", value: [addressList[58]]}, {type: "address[]", name: "_buyer", value: [addressList[59]]}, {type: "uint256[]", name: "_value", value: ["26161120685845596"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0xa05cc22b732dd1720d067e51bc7d9620828efe06b2c15abc63f816948eebbc21"]}, {type: "bytes32[]", name: "_s", value: ["0x042cefd1690e678ae71bfe24f7453eb05784210801d2880821fd502043e1ccd9"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x944cffd590534773a32941368a7859d2"], [addressList[58]], [addressList[59]], ["26161120685845596"], ["100"], ["30000000000"], ["27"], ["0xa05cc22b732dd1720d067e51bc7d9620828efe06b2c15abc63f816948eebbc21"], ["0x042cefd1690e678ae71bfe24f7453eb05784210801d2880821fd502043e1ccd9"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508568503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x323a0acd9dcc73595c2461c6f0f9e757a4079ea2f7f252fe3e0e5f00d71dff0f"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x2e4b98e2bb4c4c6cb015070f7a111297\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400517", timeStamp: "1508569893", hash: "0x3eb70b62b16ab42083ccb23dde54ed426f3712940746fe0ef89bd59b8f260a61", nonce: "1", blockHash: "0xb8d8b3cd2439d8badd3475e8a64aa31886a333a088a0f60d53630fb38c0528af", transactionIndex: "10", from: "0x32ce8483fcb3fad7f5f9bdcf53ca54a62ac03ced", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "291509630499422359", gas: "75000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d672e4b98e2bb4c4c6cb015070f7a11129700000000000000000000000000000000000000000000000000000000b27c7049bdf3b7dfc881b29c951ae12b594594a3000000000000000000000000f46479475790c2f141290e0577baa20b71051098000000000000000000000000000000000000000000000000040ba676e6860097000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eb0118000000000000000000000000000000000000000000000000000000000000001c055e6c1513ea9634d399cafb47b5491a5cbe531c79bc6e7b307e48b1f064ddfc110a09c36905052127df0159a6413e8d589598389afecd3d14aa4070dc46002f", contractAddress: "", cumulativeGasUsed: "342344", gasUsed: "69361", confirmations: "3320970"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "291509630499422359" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x2e4b98e2bb4c4c6cb015070f7a111297"}, {type: "address", name: "_seller", value: addressList[60]}, {type: "address", name: "_buyer", value: addressList[61]}, {type: "uint256", name: "_value", value: "291509630499422359"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508573464"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x055e6c1513ea9634d399cafb47b5491a5cbe531c79bc6e7b307e48b1f064ddfc"}, {type: "bytes32", name: "_s", value: "0x110a09c36905052127df0159a6413e8d589598389afecd3d14aa4070dc46002f"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x2e4b98e2bb4c4c6cb015070f7a111297", addressList[60], addressList[61], "291509630499422359", "100", "0", "1508573464", "28", "0x055e6c1513ea9634d399cafb47b5491a5cbe531c79bc6e7b307e48b1f064ddfc", "0x110a09c36905052127df0159a6413e8d589598389afecd3d14aa4070dc46002f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1508569893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x677d77309c0d65f6e0753bd5532d5a29b93fcb4abc0ce84c1424b69451663cac"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x2e4b98e2bb4c4c6cb015070f7a111297\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400532", timeStamp: "1508570076", hash: "0x1aa05f85905de8b32c0711df540fa4825597e33668500f31d3163e9726bc8808", nonce: "24", blockHash: "0x8d28046df1602cc50359ecb446f058e81cf86b5db013d735fc335d9f3a869980", transactionIndex: "22", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "14400000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000012e4b98e2bb4c4c6cb015070f7a111297000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b27c7049bdf3b7dfc881b29c951ae12b594594a30000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f46479475790c2f141290e0577baa20b710510980000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000040ba676e686009700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000015b8eceed8e968a3118eb9b079dfd38b6eb9e85976e6ef2b951f51aa49aab7b4800000000000000000000000000000000000000000000000000000000000000015f8c0c3d802fac9bb0266742f351ab90915c7c2d23ecd5f44ebf5e5841bfb90c00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "1208320", gasUsed: "75284", confirmations: "3320955"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x2e4b98e2bb4c4c6cb015070f7a111297"]}, {type: "address[]", name: "_seller", value: [addressList[60]]}, {type: "address[]", name: "_buyer", value: [addressList[61]]}, {type: "uint256[]", name: "_value", value: ["291509630499422359"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0x5b8eceed8e968a3118eb9b079dfd38b6eb9e85976e6ef2b951f51aa49aab7b48"]}, {type: "bytes32[]", name: "_s", value: ["0x5f8c0c3d802fac9bb0266742f351ab90915c7c2d23ecd5f44ebf5e5841bfb90c"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x2e4b98e2bb4c4c6cb015070f7a111297"], [addressList[60]], [addressList[61]], ["291509630499422359"], ["100"], ["30000000000"], ["27"], ["0x5b8eceed8e968a3118eb9b079dfd38b6eb9e85976e6ef2b951f51aa49aab7b48"], ["0x5f8c0c3d802fac9bb0266742f351ab90915c7c2d23ecd5f44ebf5e5841bfb90c"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508570076 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x677d77309c0d65f6e0753bd5532d5a29b93fcb4abc0ce84c1424b69451663cac"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0xea4317c5bb164978ada9e3f8222d7b96\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400579", timeStamp: "1508570947", hash: "0x3143824fb0ae3f3217b152160d73635947eefea46f2c7e3e71bb63e734466447", nonce: "2", blockHash: "0x0a3f8b29fe371e67602fbf82764ed37f4245f1fda4b8f767480d432220fa03ef", transactionIndex: "34", from: "0x32ce8483fcb3fad7f5f9bdcf53ca54a62ac03ced", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "466354803886290032", gas: "75000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d67ea4317c5bb164978ada9e3f8222d7b9600000000000000000000000000000000000000000000000000000000da27d307b25dafeca06da45364e0d55a15a59eda000000000000000000000000a1524453c682176dc9a236130a241fe5da2500900000000000000000000000000000000000000000000000000678d33928f07470000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059eb0527000000000000000000000000000000000000000000000000000000000000001c181b7e62a6c763af359d6759a5779cf2f04f609d9e8b3781a30bafc3ddc3ec03317e8e7a62f2b92f5ed905697669c50c711506c3f10ac4bcd5e257873e865f4b", contractAddress: "", cumulativeGasUsed: "1684199", gasUsed: "69425", confirmations: "3320908"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "466354803886290032" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0xea4317c5bb164978ada9e3f8222d7b96"}, {type: "address", name: "_seller", value: addressList[62]}, {type: "address", name: "_buyer", value: addressList[63]}, {type: "uint256", name: "_value", value: "466354803886290032"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "0"}, {type: "uint32", name: "_expiry", value: "1508574503"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x181b7e62a6c763af359d6759a5779cf2f04f609d9e8b3781a30bafc3ddc3ec03"}, {type: "bytes32", name: "_s", value: "0x317e8e7a62f2b92f5ed905697669c50c711506c3f10ac4bcd5e257873e865f4b"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0xea4317c5bb164978ada9e3f8222d7b96", addressList[62], addressList[63], "466354803886290032", "100", "0", "1508574503", "28", "0x181b7e62a6c763af359d6759a5779cf2f04f609d9e8b3781a30bafc3ddc3ec03", "0x317e8e7a62f2b92f5ed905697669c50c711506c3f10ac4bcd5e257873e865f4b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508570947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xb69bb23245e9bc7d0e97753172630862f9a8bb0ff325dd3919050ab81a93615b"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0xea4317c5bb164978ada9e3f8222d7b96\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400593", timeStamp: "1508571122", hash: "0x706de8cd16dd1f46d7da669b72eba745d16bbf13254fa811bccf5029c1f36840", nonce: "25", blockHash: "0xb016daac4d32af04cae864923b2fc888ac68f9eb8bfb4be03046cc59dc116b95", transactionIndex: "6", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000001ea4317c5bb164978ada9e3f8222d7b96000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000da27d307b25dafeca06da45364e0d55a15a59eda0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a1524453c682176dc9a236130a241fe5da25009000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000678d33928f0747000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000016bd0d0d4d14f74af8d59e96f684a248b710680b15bf0561bfddce1d684d2eec50000000000000000000000000000000000000000000000000000000000000001033a80ba129ff14dfbadb52c031535d41de09d5bd5d0b36806d2b93deb1ccfff00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "295205", gasUsed: "75284", confirmations: "3320894"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0xea4317c5bb164978ada9e3f8222d7b96"]}, {type: "address[]", name: "_seller", value: [addressList[62]]}, {type: "address[]", name: "_buyer", value: [addressList[63]]}, {type: "uint256[]", name: "_value", value: ["466354803886290032"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x6bd0d0d4d14f74af8d59e96f684a248b710680b15bf0561bfddce1d684d2eec5"]}, {type: "bytes32[]", name: "_s", value: ["0x033a80ba129ff14dfbadb52c031535d41de09d5bd5d0b36806d2b93deb1ccfff"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0xea4317c5bb164978ada9e3f8222d7b96"], [addressList[62]], [addressList[63]], ["466354803886290032"], ["100"], ["30000000000"], ["28"], ["0x6bd0d0d4d14f74af8d59e96f684a248b710680b15bf0561bfddce1d684d2eec5"], ["0x033a80ba129ff14dfbadb52c031535d41de09d5bd5d0b36806d2b93deb1ccfff"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508571122 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0xb69bb23245e9bc7d0e97753172630862f9a8bb0ff325dd3919050ab81a93615b"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x90ea6ee72b8a4605aa2c38b6beb655ec\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400674", timeStamp: "1508572001", hash: "0xe45502e9eff64c68a9cc29aa693e52635101b0d3d31d581f15f91942673646f4", nonce: "0", blockHash: "0x2cfa6687efdf82a27c7dd6c398e2dcfd024db7b2e537724c94690160bb9faae7", transactionIndex: "36", from: "0xb497cb33362cad354e16328adcf297ccb93f9098", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "2020163759524756475", gas: "75000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d6790ea6ee72b8a4605aa2c38b6beb655ec00000000000000000000000000000000000000000000000000000000469ccdf7e46a40a0b81b2520ec533f2e1fca9d4f00000000000000000000000004162077e231f4de6a9ec432f57353b6d41079750000000000000000000000000000000000000000000000001c09103c6a973bfb000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eb0954000000000000000000000000000000000000000000000000000000000000001c801e12974102adf25f09e8448a7fe0d5c5060aaa38a2b7db3cb9f3c6548606dd59b1530b12dc27d1c8a5a379eceea43df5fdb8845d4acbef5969afabf6c95e1d", contractAddress: "", cumulativeGasUsed: "1042073", gasUsed: "69632", confirmations: "3320813"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[64], to: addressList[2], value: "2020163759524756475" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x90ea6ee72b8a4605aa2c38b6beb655ec"}, {type: "address", name: "_seller", value: addressList[65]}, {type: "address", name: "_buyer", value: addressList[66]}, {type: "uint256", name: "_value", value: "2020163759524756475"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508575572"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x801e12974102adf25f09e8448a7fe0d5c5060aaa38a2b7db3cb9f3c6548606dd"}, {type: "bytes32", name: "_s", value: "0x59b1530b12dc27d1c8a5a379eceea43df5fdb8845d4acbef5969afabf6c95e1d"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x90ea6ee72b8a4605aa2c38b6beb655ec", addressList[65], addressList[66], "2020163759524756475", "100", "21600", "1508575572", "28", "0x801e12974102adf25f09e8448a7fe0d5c5060aaa38a2b7db3cb9f3c6548606dd", "0x59b1530b12dc27d1c8a5a379eceea43df5fdb8845d4acbef5969afabf6c95e1d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508572001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x4d9b510652d7dd955ba85c588ccd986d9b13cf823ab6ca968c8ea0ea4d6ecc3d"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[64], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[64], balance: ( await web3.eth.getBalance( addressList[64], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x90ea6ee72b8a4605aa2c38b6beb655ec\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400776", timeStamp: "1508573373", hash: "0x5b8a18b2f53037c4063141c69dbb8c2e02a6e4e937823d8272f3ffc191052013", nonce: "26", blockHash: "0x7ac6566a816d9bf026869cc0542ade6360fcc7d654d25dd991d454d08d9b268a", transactionIndex: "83", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250200", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000000190ea6ee72b8a4605aa2c38b6beb655ec000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000469ccdf7e46a40a0b81b2520ec533f2e1fca9d4f000000000000000000000000000000000000000000000000000000000000000100000000000000000000000004162077e231f4de6a9ec432f57353b6d410797500000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000001c09103c6a973bfb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000011353698a2d33c7acaaa6951d02910e85840385129ef694f15457a4bd8b8b747f000000000000000000000000000000000000000000000000000000000000000160388eb2d1285347d518011a0734abd0ba78ec808c863bfb185bbcd6a9cf8d7100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3253872", gasUsed: "75348", confirmations: "3320711"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x90ea6ee72b8a4605aa2c38b6beb655ec"]}, {type: "address[]", name: "_seller", value: [addressList[65]]}, {type: "address[]", name: "_buyer", value: [addressList[66]]}, {type: "uint256[]", name: "_value", value: ["2020163759524756475"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["28"]}, {type: "bytes32[]", name: "_r", value: ["0x1353698a2d33c7acaaa6951d02910e85840385129ef694f15457a4bd8b8b747f"]}, {type: "bytes32[]", name: "_s", value: ["0x60388eb2d1285347d518011a0734abd0ba78ec808c863bfb185bbcd6a9cf8d71"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x90ea6ee72b8a4605aa2c38b6beb655ec"], [addressList[65]], [addressList[66]], ["2020163759524756475"], ["100"], ["30000000000"], ["28"], ["0x1353698a2d33c7acaaa6951d02910e85840385129ef694f15457a4bd8b8b747f"], ["0x60388eb2d1285347d518011a0734abd0ba78ec808c863bfb185bbcd6a9cf8d71"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508573373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0x4d9b510652d7dd955ba85c588ccd986d9b13cf823ab6ca968c8ea0ea4d6ecc3d"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x7bdb9fa4584a4a8ab6cf5a950f33563e\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400807", timeStamp: "1508573895", hash: "0x846992fb4e7f6ff6b04243ff8b42127b1ea6a365d064eb90b1dbffb921422931", nonce: "0", blockHash: "0x29b298939f0e8cc109cb3299c6351a20868daaf27aacad6a6b9a97229d7b8a3e", transactionIndex: "103", from: "0x745fa59baf041f227b08de565ce17a147a652445", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "1000000000000000000", gas: "75000", gasPrice: "1200000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d677bdb9fa4584a4a8ab6cf5a950f33563e000000000000000000000000000000000000000000000000000000005376eedac544558758ac4fd6ffaef61284d021de0000000000000000000000000a43472cabf314685f6f3e48e9a46f5f7a6b8c8e0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eb107b000000000000000000000000000000000000000000000000000000000000001cf98df323b0132bb69c8d997e504a97b0d9cc86a79131134af01791bd04e9e3b6086830ea99a3ae52873b580e34361a17501634fab50b390e3adad0b2a5cbc3ad", contractAddress: "", cumulativeGasUsed: "5642074", gasUsed: "69504", confirmations: "3320680"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[67], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x7bdb9fa4584a4a8ab6cf5a950f33563e"}, {type: "address", name: "_seller", value: addressList[68]}, {type: "address", name: "_buyer", value: addressList[69]}, {type: "uint256", name: "_value", value: "1000000000000000000"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508577403"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xf98df323b0132bb69c8d997e504a97b0d9cc86a79131134af01791bd04e9e3b6"}, {type: "bytes32", name: "_s", value: "0x086830ea99a3ae52873b580e34361a17501634fab50b390e3adad0b2a5cbc3ad"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x7bdb9fa4584a4a8ab6cf5a950f33563e", addressList[68], addressList[69], "1000000000000000000", "100", "21600", "1508577403", "28", "0xf98df323b0132bb69c8d997e504a97b0d9cc86a79131134af01791bd04e9e3b6", "0x086830ea99a3ae52873b580e34361a17501634fab50b390e3adad0b2a5cbc3ad", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508573895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0x5dadb1c6bb12d2028dd4cbe6f297a566583ecdd36d181b353c8d6ac317af0646"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[67], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[67], balance: ( await web3.eth.getBalance( addressList[67], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x2350bbb59c3b4112b777af5e37ebd1bf\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400925", timeStamp: "1508575493", hash: "0x029a284187f1fae120108083f94548014020f48d8ee2217f4f14873d656ba9ce", nonce: "27", blockHash: "0xaad51bae8948057bb89948a953ed8d305f93ff6717e25461ced2472cb6a98264", transactionIndex: "117", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "249680", gasPrice: "10800000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000012350bbb59c3b4112b777af5e37ebd1bf0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000006a8ba4d48b7ec2fdd4ac59016169dd5cd7b318440000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b599250678e2177578075a3a470946c22378860100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000d3fc6977f10c00000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000000123c342b78e2f196f8fa1ae4b48ad54d30676488ff952f36f92cd322f672f49f300000000000000000000000000000000000000000000000000000000000000015152de48d3e6910b53b7eaeab47b2d6c5ec520e5c61beb1df23c0dbb40d9972b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4479981", gasUsed: "75140", confirmations: "3320562"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x2350bbb59c3b4112b777af5e37ebd1bf"]}, {type: "address[]", name: "_seller", value: [addressList[56]]}, {type: "address[]", name: "_buyer", value: [addressList[57]]}, {type: "uint256[]", name: "_value", value: ["954700000000000000"]}, {type: "uint16[]", name: "_fee", value: ["25"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0x23c342b78e2f196f8fa1ae4b48ad54d30676488ff952f36f92cd322f672f49f3"]}, {type: "bytes32[]", name: "_s", value: ["0x5152de48d3e6910b53b7eaeab47b2d6c5ec520e5c61beb1df23c0dbb40d9972b"]}, {type: "uint8[]", name: "_actionByte", value: ["2"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x2350bbb59c3b4112b777af5e37ebd1bf"], [addressList[56]], [addressList[57]], ["954700000000000000"], ["25"], ["30000000000"], ["27"], ["0x23c342b78e2f196f8fa1ae4b48ad54d30676488ff952f36f92cd322f672f49f3"], ["0x5152de48d3e6910b53b7eaeab47b2d6c5ec520e5c61beb1df23c0dbb40d9972b"], ["2"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508575493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "CancelledByBuyer", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CancelledByBuyer", events: [{name: "_tradeHash", type: "bytes32", value: "0x0d0be59301d217379598ea744d402aea85b27b57e116828a7c0c756bf2e893a7"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: createEscrow( \"0x1bcd5c2716a4468d9471f6686f3c58ca\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4400937", timeStamp: "1508575664", hash: "0xe2915df696425fb6bf70890ebb1a27c2074fa2a05fc70c56ca1e87439c3a5176", nonce: "1", blockHash: "0xeefa716ca028a8a94988ba6aa13497548a7d30ddccdf9b152c436aa2ecb6be4f", transactionIndex: "18", from: "0x53368611f901ad5622ab7fed08ee959b8fb11251", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "2218442832522111323", gas: "75000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0xf1e03d671bcd5c2716a4468d9471f6686f3c58ca00000000000000000000000000000000000000000000000000000000451b6af880bd6aa8a0274dca38e3d818df572429000000000000000000000000ec0512233a69ae0620f817f62bcc562abbdcc7b00000000000000000000000000000000000000000000000001ec97e009afde95b000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000054600000000000000000000000000000000000000000000000000000000059eb17ae000000000000000000000000000000000000000000000000000000000000001bc15c47dc79188b7faf379ab5f3581d72b15ba74e3caa0c912310b90fa84dae6f4adca58759c431f1216caa3351fa6503788482ac98251582d6d112a216d07dbd", contractAddress: "", cumulativeGasUsed: "1055280", gasUsed: "69568", confirmations: "3320550"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "2218442832522111323" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16", name: "_tradeID", value: "0x1bcd5c2716a4468d9471f6686f3c58ca"}, {type: "address", name: "_seller", value: addressList[70]}, {type: "address", name: "_buyer", value: addressList[71]}, {type: "uint256", name: "_value", value: "2218442832522111323"}, {type: "uint16", name: "_fee", value: "100"}, {type: "uint32", name: "_paymentWindowInSeconds", value: "21600"}, {type: "uint32", name: "_expiry", value: "1508579246"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xc15c47dc79188b7faf379ab5f3581d72b15ba74e3caa0c912310b90fa84dae6f"}, {type: "bytes32", name: "_s", value: "0x4adca58759c431f1216caa3351fa6503788482ac98251582d6d112a216d07dbd"}], name: "createEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createEscrow(bytes16,address,address,uint256,uint16,uint32,uint32,uint8,bytes32,bytes32)" ]( "0x1bcd5c2716a4468d9471f6686f3c58ca", addressList[70], addressList[71], "2218442832522111323", "100", "21600", "1508579246", "27", "0xc15c47dc79188b7faf379ab5f3581d72b15ba74e3caa0c912310b90fa84dae6f", "0x4adca58759c431f1216caa3351fa6503788482ac98251582d6d112a216d07dbd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508575664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Created", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Created", events: [{name: "_tradeHash", type: "bytes32", value: "0xc71ca473f4c36f5c4f21144a9cd2a86f13085f9a0a7c0ef9e0f808e3b980e282"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: batchRelay( [\"0x1bcd5c2716a4468d9471f6686f3c58ca\"]... )", async function( ) {
		const txOriginal = {blockNumber: "4400983", timeStamp: "1508576257", hash: "0xe5026ac2e72f3aee47478afb40b2c73f9969c1b75b8a42a7efb40c10d42703d0", nonce: "28", blockHash: "0x142d238049b927ce170bf2f0a9a467f574e9c7e737fad27565da9a74fdda65b0", transactionIndex: "141", from: "0xa38f728c9431a4248753c63423518faf4de63e18", to: "0x09678741bd50c3e74301f38fbd0136307099ae5d", value: "0", gas: "250040", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8eb4e0ad0000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000011bcd5c2716a4468d9471f6686f3c58ca000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000451b6af880bd6aa8a0274dca38e3d818df5724290000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ec0512233a69ae0620f817f62bcc562abbdcc7b000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000001ec97e009afde95b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000019d5984d290889148f0b59e26196fa15fdf04ddfd20b0e223754a8d5147ed0d0d00000000000000000000000000000000000000000000000000000000000000013670c05ca3c3a3f2bc940f5558074c945b61525a858398076a45dc1b669d1f8700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "5571307", gasUsed: "75284", confirmations: "3320504"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes16[]", name: "_tradeID", value: ["0x1bcd5c2716a4468d9471f6686f3c58ca"]}, {type: "address[]", name: "_seller", value: [addressList[70]]}, {type: "address[]", name: "_buyer", value: [addressList[71]]}, {type: "uint256[]", name: "_value", value: ["2218442832522111323"]}, {type: "uint16[]", name: "_fee", value: ["100"]}, {type: "uint128[]", name: "_maximumGasPrice", value: ["30000000000"]}, {type: "uint8[]", name: "_v", value: ["27"]}, {type: "bytes32[]", name: "_r", value: ["0x9d5984d290889148f0b59e26196fa15fdf04ddfd20b0e223754a8d5147ed0d0d"]}, {type: "bytes32[]", name: "_s", value: ["0x3670c05ca3c3a3f2bc940f5558074c945b61525a858398076a45dc1b669d1f87"]}, {type: "uint8[]", name: "_actionByte", value: ["5"]}], name: "batchRelay", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchRelay(bytes16[],address[],address[],uint256[],uint16[],uint128[],uint8[],bytes32[],bytes32[],uint8[])" ]( ["0x1bcd5c2716a4468d9471f6686f3c58ca"], [addressList[70]], [addressList[71]], ["2218442832522111323"], ["100"], ["30000000000"], ["27"], ["0x9d5984d290889148f0b59e26196fa15fdf04ddfd20b0e223754a8d5147ed0d0d"], ["0x3670c05ca3c3a3f2bc940f5558074c945b61525a858398076a45dc1b669d1f87"], ["5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508576257 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tradeHash", type: "bytes32"}], name: "Released", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Released", events: [{name: "_tradeHash", type: "bytes32", value: "0xc71ca473f4c36f5c4f21144a9cd2a86f13085f9a0a7c0ef9e0f808e3b980e282"}], address: "0x09678741bd50c3e74301f38fbd0136307099ae5d"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "179569966623000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4865935735280000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
