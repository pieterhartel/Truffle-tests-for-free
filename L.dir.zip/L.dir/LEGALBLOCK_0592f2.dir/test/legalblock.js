const LEGALBLOCK = artifacts.require( "./LEGALBLOCK.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "LEGALBLOCK" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xbBc083f213A151A552876b09372A9F98600592F2", "0x5C26E0E054362A294cAf0a791E6491a2b241400E", "0xf57E589B6dbaBb95815D93e69C9138abFb1a86a7", "0x719B956B8b153e61bF89d82d301eF71D4b434CE5", "0xfdA4a4419dfB43e663FB393bC8db428B4340aC5B", "0x7BD5f11db0746103FB35933D34A8637cDE70D93A", "0x3Ab2896AA9502cF1d80f4Cf47117760b021953C0", "0x03bB1b6B40a2C235f19A5446B4126939Bf0EEF8e", "0x4f98fbeE373b5Cc49528fA2E8a33a464280D8Be1", "0xCBe92858fB7eE5B3C5470c840b94751478B7cB62", "0xFceAFd98916e6e61Ad63604648b732d814c1CA0e", "0x8b6c0Cb242d1371CaCc091712733106C0e710266", "0xe5700D60519B4546943748171F70EBb53F003D4E", "0x0d30Fb18eFbBa0aA758156e366113A0029E0371C"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "owners", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockBeforeValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "LOCK_MAX", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMyUnlockValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "unlockAddrs", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "candidateRootMap", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "superOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockTimes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "lockValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ownerList", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "root", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "receiveType", type: "uint8"}], name: "TransferedToLBKDapp", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransferFrom", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKApproval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKMintTo", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnFrom", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnWhenMoveToMainnet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKSellByOtherCoin", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransferToTeam", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransferToPartner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransferToEcosystem", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransferToBounty", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}], name: "SetDelayLockValue", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "Locked", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "SetLockValue", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newRoot", type: "address"}], name: "ChangedRoot", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newSuperOwner", type: "address"}], name: "ChangedSuperOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TransferedToLBKDapp(address,address,address,uint256,uint8)", "LBKTransfer(address,address,uint256,string)", "LBKTransferFrom(address,address,address,uint256,string)", "LBKApproval(address,address,uint256,string)", "LBKMintTo(address,address,uint256,string)", "LBKBurnFrom(address,address,uint256,string)", "LBKBurnWhenMoveToMainnet(address,address,uint256,string)", "LBKSell(address,address,address,uint256,string)", "LBKSellByOtherCoin(address,address,address,uint256,uint256,uint256,string)", "LBKTransferToTeam(address,address,address,uint256,string)", "LBKTransferToPartner(address,address,address,uint256,string)", "LBKTransferToEcosystem(address,address,address,uint256,uint256,uint256,string)", "LBKTransferToBounty(address,address,address,uint256,uint256,uint256,string)", "SetDelayLockValue(address,uint256,uint256)", "Locked(bool,string)", "LockedTo(address,bool,string)", "SetLockValue(address,uint256,string)", "ChangedRoot(address)", "ChangedSuperOwner(address)", "AddedNewOwner(address)", "DeletedOwner(address)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9df0ff3e8a747a2f4b13c576a6d834fa1c89e4996027e5b8516cad45fcf66da4", "0xf72d77fe5fc35130eec6674380320a02f9398663c3d490e5ad8e40bd2dddbec5", "0xf9c19ac2dd83f90259a00db73dd44e7a73df5bb97ee33ed7ec184739088e9876", "0xc42d136c544a0985d54d6099e13e96aaeb0d02385deaa85418ba2dbcef0568b3", "0xd9386d383a90605f77da45e4db61fcfc6b8999c0ffba009c0c1d23c2681f7af9", "0x8eb32cafb0cf26efee30e87cd8fcd4de2aaddc24e246cefa80a822d8b5da2647", "0xb8fc37b8d9ff0bfbde9e59521638f1bff9792af7682c7e5edc93b120d909e200", "0x6694ed3a35939e3a57c2b60c17d8745774d2e58d8b3036947b20879ee236852b", "0xbf46a843eeff7859c7a579aafa44e7d58c0bf5e7406dfeacf5f1938b69bef991", "0xe7d1878c1e2a3b9b8dec382034e21bd5e79bf143c08481ca7dd7c54da9f84f65", "0xbc8b89a32127702fe6ba17414ce86e9cf382fa5e17314f1585f0002ff1e5ee5b", "0x46732c6597d2f271226a30dbf728c12f77fb7dac6f0dbe8d572e5377e3c382cc", "0x843fee6b240ccbe362ec9ff87bbe6066267f432370ecb72826665f566d8c7c0e", "0x29f8b22a98b13376caf4551cf7eb973ad73a6b94bb83780818b808e04bf86af5", "0xc1086893b0a3f1d991fd25e26cd28cad11de174842b04a55cc2423ed178e4382", "0x4bf46282901af80a4309ce07c36d841184ce98297f8735f7769d169497ac7a4c", "0xb19425af6288c6bb0d88f64d6d1cfe5eb7e2d31ee92f1012798df97a9b6b011a", "0x43ddeae7116ae634a7d05c2d1c588bca11b7bbc8cb96fbb2cb9c5b1afdf9ce12", "0x94b17f1a4844062cbed00809347b0f8149fc88c5a3ea720c7aed42c559eed46d", "0x5446d64d957daf41eca8227aa8fa5eb7f92c617adf03fbd9df64e8eb564d824e", "0x1e64d9a491033a9731fa82493f0ab60e9f74294eca27edd93629f1fbaa15d287", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6572176 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6623884 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "LEGALBLOCK", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "owners", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owners(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "INITIAL_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockBeforeValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockBeforeValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "LOCK_MAX", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "LOCK_MAX()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMyUnlockValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMyUnlockValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "unlockAddrs", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "unlockAddrs(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "candidateRootMap", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "candidateRootMap(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "superOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "superOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockTimes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockTimes(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "lockValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "locked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ownerList", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerList(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "root", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "root()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "LEGALBLOCK", function( accounts ) {

	it( "TEST: LEGALBLOCK(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6572176", timeStamp: "1540348318", hash: "0x9ae730a189db2f71df42050762242fd50d0d8a30ffe5fcb349788db0df367466", nonce: "0", blockHash: "0xb802554f9da1e001719e1b583e55c93534a8237bd18ac504d84b793a3c3fd101", transactionIndex: "36", from: "0x5c26e0e054362a294caf0a791e6491a2b241400e", to: 0, value: "0", gas: "5653730", gasPrice: "6600000000", isError: "0", txreceipt_status: "1", input: "0x7863afef", contractAddress: "0xbbc083f213a151a552876b09372a9f98600592f2", cumulativeGasUsed: "7147354", gasUsed: "5653730", confirmations: "1153175"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "LEGALBLOCK", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = LEGALBLOCK.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540348318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = LEGALBLOCK.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[0,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[0,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "value", type: "uint256", value: "15000000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[0,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "62474101000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: changeRoot( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6572212", timeStamp: "1540348829", hash: "0xc500fd0db7e31fcea7f8160642106b39b98fd8166717708407f2b937254a0a67", nonce: "1", blockHash: "0x0ff56d634095fa125bccdc3084271c3c45add35d1724da75eb73527c27d57305", transactionIndex: "287", from: "0x5c26e0e054362a294caf0a791e6491a2b241400e", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "30183", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4a7902d2000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7", contractAddress: "", cumulativeGasUsed: "7935688", gasUsed: "30183", confirmations: "1153139"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newRoot", value: addressList[4]}], name: "changeRoot", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeRoot(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540348829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newRoot", type: "address"}], name: "ChangedRoot", type: "event"} ;
		console.error( "eventCallOriginal[1,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangedRoot", events: [{name: "newRoot", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[1,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "62474101000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: changeSuperOwner( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6615098", timeStamp: "1540955047", hash: "0x9d91e00e55577eb358da8553a72bfb2630c83e18214097906dfb6ea5d6c0d87f", nonce: "1", blockHash: "0x7b505b220dc9cf2ac14d8459a59434c25a29966ecb8fa42d06af5c8adc852a66", transactionIndex: "12", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "29941", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x1044c66b000000000000000000000000719b956b8b153e61bf89d82d301ef71d4b434ce5", contractAddress: "", cumulativeGasUsed: "365232", gasUsed: "29941", confirmations: "1110253"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newSuperOwner", value: addressList[5]}], name: "changeSuperOwner", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeSuperOwner(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540955047 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newSuperOwner", type: "address"}], name: "ChangedSuperOwner", type: "event"} ;
		console.error( "eventCallOriginal[2,18] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangedSuperOwner", events: [{name: "newSuperOwner", type: "address", value: "0x719b956b8b153e61bf89d82d301ef71d4b434ce5"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[2,18] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransfer( addressList[5], \"1\", `test` )", async function( ) {
		const txOriginal = {blockNumber: "6618994", timeStamp: "1541009527", hash: "0x8a7073ed52f044201791e9a7eae3b6e1e53cea59f958f7155e157ef3e0742a8a", nonce: "4", blockHash: "0x6b67af04a58852fbf2fb4547db6344b14e67c9e5c99a5dc6b67045de34b8d3ff", transactionIndex: "58", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x3706cc07000000000000000000000000719b956b8b153e61bf89d82d301ef71d4b434ce50000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4582684", gasUsed: "200000", confirmations: "1106357"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[5]}, {type: "uint256", name: "value", value: "1"}, {type: "string", name: "note", value: `test`}], name: "lbkTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransferFrom( addressList[4], addressList[5], \"1\", `... )", async function( ) {
		const txOriginal = {blockNumber: "6619022", timeStamp: "1541009861", hash: "0xe7ccf35a11cf17ea202058d742f6bf94c88a9b329117488b9432ebb03a681898", nonce: "5", blockHash: "0x79e0ab178cd8ef9bc25a86195b020ba5ffaeda56a9ea2244467d6c2407779fac", transactionIndex: "3", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xbdb74f92000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000719b956b8b153e61bf89d82d301ef71d4b434ce50000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "421552", gasUsed: "200000", confirmations: "1106329"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "to", value: addressList[5]}, {type: "uint256", name: "value", value: "1"}, {type: "string", name: "note", value: `test`}], name: "lbkTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransfer( addressList[5], \"1\", `test` )", async function( ) {
		const txOriginal = {blockNumber: "6619033", timeStamp: "1541009966", hash: "0xcb355e23f1a58c96eb6593896aa01c7a6347e4b784ed2c2f460a4cdd7dd9d130", nonce: "6", blockHash: "0x40e9ee05a95973d54dee1f460a2c3845f1df4a6a418e703dad51a41629e5f191", transactionIndex: "24", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x3706cc07000000000000000000000000719b956b8b153e61bf89d82d301ef71d4b434ce50000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3665936", gasUsed: "200000", confirmations: "1106318"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[5]}, {type: "uint256", name: "value", value: "1"}, {type: "string", name: "note", value: `test`}], name: "lbkTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransfer( addressList[5], \"1\", `test` )", async function( ) {
		const txOriginal = {blockNumber: "6619059", timeStamp: "1541010381", hash: "0x55ecd82e8bc1bdd2190387d5ac6b3f66e7b5ea249b5eeb9f96560e6d055375df", nonce: "7", blockHash: "0x2b720a1633660fac8960af9e268ae18192d081184f3e1c35a589354d55f73c7e", transactionIndex: "13", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x3706cc07000000000000000000000000719b956b8b153e61bf89d82d301ef71d4b434ce50000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "591582", gasUsed: "200000", confirmations: "1106292"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[5]}, {type: "uint256", name: "value", value: "1"}, {type: "string", name: "note", value: `test`}], name: "lbkTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransferFrom( addressList[3], addressList[4], \"150000... )", async function( ) {
		const txOriginal = {blockNumber: "6619156", timeStamp: "1541011663", hash: "0xbc9028b3e3225e9e1fb5fc21b4a616fd76a430330dacb0a5ebc9562d3babd5fb", nonce: "8", blockHash: "0x4d0003da36001b3a4d4c0e1a485418e98cdb2c50e0f6f7b9e3bb620751da3836", transactionIndex: "3", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xbdb74f920000000000000000000000005c26e0e054362a294caf0a791e6491a2b241400e000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000000000000000000000000000000000037e11d600000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "93229", gasUsed: "30229", confirmations: "1106195"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "15000000000"}, {type: "string", name: "note", value: `test`}], name: "lbkTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkTransferFrom(address,address,uint256,string)" ]( addressList[3], addressList[4], "15000000000", `test`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541011663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: changeSuperOwner( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6621329", timeStamp: "1541042986", hash: "0xa4b8b8668d93c02eccd447a99601205e9077c8b5474e705ca4454e68de463f52", nonce: "9", blockHash: "0xf64f93c256c9d5a98ed4c9747620d7618579ca51a718a1f38dbb64746bd1326e", transactionIndex: "147", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0x1044c66b000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7", contractAddress: "", cumulativeGasUsed: "7365159", gasUsed: "29941", confirmations: "1104022"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newSuperOwner", value: addressList[4]}], name: "changeSuperOwner", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeSuperOwner(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541042986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newSuperOwner", type: "address"}], name: "ChangedSuperOwner", type: "event"} ;
		console.error( "eventCallOriginal[8,18] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangedSuperOwner", events: [{name: "newSuperOwner", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[8,18] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6621424", timeStamp: "1541044527", hash: "0x621ef4b556448557e57b1bcd12849775cc7e5bdd1e9e8487349ba1f89b37f0f4", nonce: "10", blockHash: "0x4344a83b8a6877bb565b1d49fe18df4353d93a607e4fc90a7248969476d2ca32", transactionIndex: "42", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7", contractAddress: "", cumulativeGasUsed: "1691203", gasUsed: "71421", confirmations: "1103927"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[4]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541044527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[9,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[9,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: lbkBurnFrom( addressList[3], \"15000000000\", `lbk tr... )", async function( ) {
		const txOriginal = {blockNumber: "6621552", timeStamp: "1541046261", hash: "0xa2d2b485f34a6dd88d444a7ebbb23ed9e316866eeb9e23a27535460adc53c8fe", nonce: "11", blockHash: "0x56a6493665e6894b10b6fa9e136d9fded6bd6b033f1eb6f3f6803c0485472429", transactionIndex: "72", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x2e1cd9d00000000000000000000000005c26e0e054362a294caf0a791e6491a2b241400e000000000000000000000000000000000000000000000000000000037e11d600000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000216c626b207472616e7366657220746f20726f6f742066726f6d2063726561746f7200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4400594", gasUsed: "44687", confirmations: "1103799"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "uint256", name: "value", value: "15000000000"}, {type: "string", name: "note", value: `lbk transfer to root from creator`}], name: "lbkBurnFrom", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkBurnFrom(address,uint256,string)" ]( addressList[3], "15000000000", `lbk transfer to root from creator`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541046261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnFrom", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKBurnFrom", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "from", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "value", type: "uint256", value: "15000000000"}, {name: "note", type: "string", value: "lbk transfer to root from creator"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "15000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[10,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: lbkBurnFrom( addressList[3], \"1499999999999999998500... )", async function( ) {
		const txOriginal = {blockNumber: "6621564", timeStamp: "1541046437", hash: "0x5168008a94119388b0e453c7fcf7a12151481c80a5eab34148144e17c7f9a3a2", nonce: "12", blockHash: "0x14309cb1226d3c7e9ad9ef8bcceeaed56e516edffd946106484c72e8093931ae", transactionIndex: "36", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x2e1cd9d00000000000000000000000005c26e0e054362a294caf0a791e6491a2b241400e00000000000000000000000000000000000000003077b58d5d37838e19ee2a00000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000216c626b207472616e7366657220746f20726f6f742066726f6d2063726561746f7200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2498047", gasUsed: "22568", confirmations: "1103787"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "uint256", name: "value", value: "14999999999999999985000000000"}, {type: "string", name: "note", value: `lbk transfer to root from creator`}], name: "lbkBurnFrom", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkBurnFrom(address,uint256,string)" ]( addressList[3], "14999999999999999985000000000", `lbk transfer to root from creator`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541046437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnFrom", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKBurnFrom", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "from", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "value", type: "uint256", value: "14999999999999999985000000000"}, {name: "note", type: "string", value: "lbk transfer to root from creator"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x5c26e0e054362a294caf0a791e6491a2b241400e"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "14999999999999999985000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[11,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: lbkMintTo( addressList[4], \"1500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6621594", timeStamp: "1541046913", hash: "0x481d75980f9417eb169b647bc1d4fbd9ba065182870e4fa859d2158c3e698ac7", nonce: "13", blockHash: "0x976044cb6673107605dc8515b4cfe4fb1ae874c6b07e8d3c4fcce0515b465446", transactionIndex: "62", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6627048e000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a700000000000000000000000000000000000000003077b58d5d3783919800000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000014726563656976652066726f6d2063726561746f72000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3354398", gasUsed: "73732", confirmations: "1103757"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "amount", value: "15000000000000000000000000000"}, {type: "string", name: "note", value: `receive from creator`}], name: "lbkMintTo", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkMintTo(address,uint256,string)" ]( addressList[4], "15000000000000000000000000000", `receive from creator`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541046913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKMintTo", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKMintTo", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "amount", type: "uint256", value: "15000000000000000000000000000"}, {name: "note", type: "string", value: "receive from creator"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "15000000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[12,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransferFrom( addressList[4], addressList[6], \"225000... )", async function( ) {
		const txOriginal = {blockNumber: "6622129", timeStamp: "1541054169", hash: "0x0ab827c1a51f421d2391669c045b5d56bdc9b36ee55607a1b886506b1c90acad", nonce: "14", blockHash: "0x512e1f484bb110fc8fd33b55a83287a9eb0ec290362f557dc3e3d85ad2ea440e", transactionIndex: "134", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0xbdb74f92000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b000000000000000000000000000000000000000007452808679520890a0000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a636c6f75642073616c6500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6135872", gasUsed: "29267", confirmations: "1103222"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}, {type: "string", name: "note", value: `cloud sale`}], name: "lbkTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkTransferFrom(address,address,uint256,string)" ]( addressList[4], addressList[6], "2250000000000000000000000000", `cloud sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541054169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransferFrom( addressList[4], addressList[6], \"225000... )", async function( ) {
		const txOriginal = {blockNumber: "6622182", timeStamp: "1541054821", hash: "0xf8f24f822cc6aec1926dcc8bd7396dcb6a2084c6a44f1add5def9273cc47b337", nonce: "16", blockHash: "0x2166d7a355e3b0446d01af66b6ebd34a8239e474436fd9fa9ef918e9f31c074c", transactionIndex: "4", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xbdb74f92000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b000000000000000000000000000000000000000007452808679520890a0000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a636c6f75642073616c6500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "126737", gasUsed: "29267", confirmations: "1103169"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}, {type: "string", name: "note", value: `cloud sale`}], name: "lbkTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkTransferFrom(address,address,uint256,string)" ]( addressList[4], addressList[6], "2250000000000000000000000000", `cloud sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541054821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[4], addressList[6], \"225000... )", async function( ) {
		const txOriginal = {blockNumber: "6622349", timeStamp: "1541057086", hash: "0xb1a86f6c980a35dd4f12b2127f600a6d16c8fc00e5fcb11d5cfdacf8b7b05ce7", nonce: "17", blockHash: "0xa9f74ae5025b639b70fe8365ba56cd6b6ad5a51e2a18dd4154e604b8bf34ae10", transactionIndex: "13", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x23b872dd000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b000000000000000000000000000000000000000007452808679520890a000000", contractAddress: "", cumulativeGasUsed: "539487", gasUsed: "27284", confirmations: "1103002"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[4], addressList[6], "2250000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541057086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"2250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622431", timeStamp: "1541058285", hash: "0x5c51c54ca4ca9d99c02ce466eb564e196fa2fc5f1f28cec189232ae3a54aa1a8", nonce: "18", blockHash: "0xaa94ed2949bd60eef8fe93b120ea768d06955274408e59370582cdce6e3fb9a6", transactionIndex: "66", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "30000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b000000000000000000000000000000000000000007452808679520890a000000", contractAddress: "", cumulativeGasUsed: "1431441", gasUsed: "26511", confirmations: "1102920"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "2250000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541058285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6622443", timeStamp: "1541058538", hash: "0x5895387ec6ccf0c9e9d017fd08fa208e5c599290b8e9e48b6ee637e3d93793b3", nonce: "19", blockHash: "0x7d2b6cc5728131ecc199634fe508c5b578d406dbefc55d90428fe92d49c9091b", transactionIndex: "29", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "30000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2614333", gasUsed: "26319", confirmations: "1102908"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541058538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: unlockTo( addressList[4], `\"root\"` )", async function( ) {
		const txOriginal = {blockNumber: "6622495", timeStamp: "1541059345", hash: "0xd3606e037afeb128b47f506fdf2fde3884a5a6ee943150d515cd9f2233881070", nonce: "20", blockHash: "0x3a52127ccd92ab3e145e71ae6c2bd078faa0e37ede13c9b8b39790ee4c3fc011", transactionIndex: "26", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "47608", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x003078b0000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000622726f6f74220000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "721969", gasUsed: "47608", confirmations: "1102856"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[4]}, {type: "string", name: "note", value: `"root"`}], name: "unlockTo", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockTo(address,string)" ]( addressList[4], `"root"`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541059345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[18,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: "\"root\""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[18,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6622501", timeStamp: "1541059440", hash: "0x994aa50f91942bc3d256b6727869f369ae57b051d94819fc6aeb414530f4893e", nonce: "21", blockHash: "0x78ac499c6a66a6fdd8412f852173277b52f693c0556644a2fe10b2061f05d447", transactionIndex: "129", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "58881", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007bd5f11db0746103fb35933d34a8637cde70d93a0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "3011824", gasUsed: "58881", confirmations: "1102850"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[7]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541059440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[19,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransferFrom( addressList[4], addressList[6], \"224999... )", async function( ) {
		const txOriginal = {blockNumber: "6622570", timeStamp: "1541060294", hash: "0x22e5a0765aec21919c086986fbf7e4eb24c522548b909f1af7065c0bcc2a3d76", nonce: "22", blockHash: "0x9bd5869e6de29513e4e84d1246307c2689f9223bd69ee59bb2d28348492bd063", transactionIndex: "134", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5930375000", isError: "1", txreceipt_status: "0", input: "0xbdb74f92000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a7000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b00000000000000000000000000000000000000000745280859b469d5629c00000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a636c6f75642073616c6500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6049985", gasUsed: "30997", confirmations: "1102781"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2249999999000000000000000000"}, {type: "string", name: "note", value: `cloud sale`}], name: "lbkTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkTransferFrom(address,address,uint256,string)" ]( addressList[4], addressList[6], "2249999999000000000000000000", `cloud sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541060294 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"2250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622586", timeStamp: "1541060538", hash: "0x080ff3d48b4df385c8be03ae77c02a58cc4fddad165b84d5a4c38f1a70b3cd2f", nonce: "23", blockHash: "0xa8a6296ae3c06e6ac4537eca3c55d8a38ac04f088749c0f53eebddd5cfc33ac9", transactionIndex: "158", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "59073", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b000000000000000000000000000000000000000007452808679520890a000000", contractAddress: "", cumulativeGasUsed: "3818996", gasUsed: "59073", confirmations: "1102765"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "2250000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541060538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "2250000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "2250000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[21,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1499999999000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622618", timeStamp: "1541060906", hash: "0x5fed0e69e6e9ab3c8ad51c1f0b3a16e9c26cbea47bb8572935983e06acb4d71c", nonce: "24", blockHash: "0x385222918a2dc497b8fbcf2d486d85c1b16d27b95fc49443cbc41859f6f092e3", transactionIndex: "58", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "7920000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003ab2896aa9502cf1d80f4cf47117760b021953c0000000000000000000000000000000000000000004d8c55ae1d809a7b49c0000", contractAddress: "", cumulativeGasUsed: "2172152", gasUsed: "59137", confirmations: "1102733"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[8]}, {type: "uint256", name: "value", value: "1499999999000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "1499999999000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541060906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x3ab2896aa9502cf1d80f4cf47117760b021953c0"}, {name: "value", type: "uint256", value: "1499999999000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x3ab2896aa9502cf1d80f4cf47117760b021953c0"}, {name: "value", type: "uint256", value: "1499999999000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[22,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6622632", timeStamp: "1541061062", hash: "0x2f487c380eab6be986af42c35cfe4e7e666d01b8d31d88abb4ba1894b9891c7f", nonce: "25", blockHash: "0x329e32010de6595e8e9b02e7a5a321bdf688b675babcf180eff38ba00a91ce3c", transactionIndex: "84", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003ab2896aa9502cf1d80f4cf47117760b021953c00000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7115306", gasUsed: "43881", confirmations: "1102719"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[8]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541061062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x3ab2896aa9502cf1d80f4cf47117760b021953c0"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x3ab2896aa9502cf1d80f4cf47117760b021953c0"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[23,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: lbkBurnFrom( addressList[7], \"1000000000\", `buin te... )", async function( ) {
		const txOriginal = {blockNumber: "6622672", timeStamp: "1541061638", hash: "0x40818c9d011584271c0eacfe2a904f8253bf70531889e5a055633b6fe2d2bf91", nonce: "26", blockHash: "0xdbb3ac061c57c8b87569e29dac962a4f74c73317bec4fcf868554505b4149cfa", transactionIndex: "98", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x2e1cd9d00000000000000000000000007bd5f11db0746103fb35933d34a8637cde70d93a000000000000000000000000000000000000000000000000000000003b9aca000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d6275696e20746573742076616c00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5690501", gasUsed: "42883", confirmations: "1102679"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[7]}, {type: "uint256", name: "value", value: "1000000000"}, {type: "string", name: "note", value: `buin test val`}], name: "lbkBurnFrom", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkBurnFrom(address,uint256,string)" ]( addressList[7], "1000000000", `buin test val`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541061638 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnFrom", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKBurnFrom", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "from", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "value", type: "uint256", value: "1000000000"}, {name: "note", type: "string", value: "buin test val"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "1000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[24,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: lbkBurnFrom( addressList[7], \"999999999000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6622687", timeStamp: "1541061936", hash: "0xfe47701929fff536406c3737d01ef91c43387c2cab0d7df02f924a016989fa5e", nonce: "27", blockHash: "0xbf2ea0a7360e2897ac6f7f095cf97aff5bc345005834323a1fb1c6a138c6d7b9", transactionIndex: "119", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x2e1cd9d00000000000000000000000007bd5f11db0746103fb35933d34a8637cde70d93a0000000000000000000000000000000000000000000000000de0b6b36bc936000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d6275696e20746573742076616c00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3375159", gasUsed: "28139", confirmations: "1102664"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[7]}, {type: "uint256", name: "value", value: "999999999000000000"}, {type: "string", name: "note", value: `buin test val`}], name: "lbkBurnFrom", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkBurnFrom(address,uint256,string)" ]( addressList[7], "999999999000000000", `buin test val`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541061936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKBurnFrom", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKBurnFrom", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "from", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "value", type: "uint256", value: "999999999000000000"}, {name: "note", type: "string", value: "buin test val"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x7bd5f11db0746103fb35933d34a8637cde70d93a"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "value", type: "uint256", value: "999999999000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[25,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: lbkBurnFrom( addressList[7], \"999999999000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6622693", timeStamp: "1541062021", hash: "0xb30b88fa1acdbb65d6118e3da44b1387632bdbc0f7e9ad206cba277bcba2d66e", nonce: "28", blockHash: "0xcbbbfec6e4fba03fa60b446ce7b598864f2c7099448d6fb84361b737cb8a29ee", transactionIndex: "94", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x2e1cd9d00000000000000000000000007bd5f11db0746103fb35933d34a8637cde70d93a0000000000000000000000000000000000000000000000000de0b6b36bc936000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d6275696e20746573742076616c00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3876729", gasUsed: "26407", confirmations: "1102658"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[7]}, {type: "uint256", name: "value", value: "999999999000000000"}, {type: "string", name: "note", value: `buin test val`}], name: "lbkBurnFrom", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkBurnFrom(address,uint256,string)" ]( addressList[7], "999999999000000000", `buin test val`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541062021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: lbkMintTo( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6622704", timeStamp: "1541062232", hash: "0x4976549861ec527e9a613ea267f72174c53e8cf79d17b0e1d842c1fe31363c32", nonce: "29", blockHash: "0x4f8048fcd9992eda09f63aea0ed207ac7c6f6ec74c67631c7d165ffde1da821f", transactionIndex: "83", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "8157812500", isError: "0", txreceipt_status: "1", input: "0x6627048e000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d6d696e7420746573742076616c00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4368413", gasUsed: "43092", confirmations: "1102647"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "amount", value: "1000000000000000000"}, {type: "string", name: "note", value: `mint test val`}], name: "lbkMintTo", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkMintTo(address,uint256,string)" ]( addressList[4], "1000000000000000000", `mint test val`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541062232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKMintTo", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKMintTo", events: [{name: "controller", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: "mint test val"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[27,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"2250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622718", timeStamp: "1541062468", hash: "0xede0b6cae8bdfbdd38016137691ea604c86ed3e547305541ebb7b86b31fe0417", nonce: "30", blockHash: "0xcf701bb513f00e0bf061d4ddfdce073892f4f6dfa69a2d42c97e456393766275", transactionIndex: "155", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "8157812500", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000003bb1b6b40a2c235f19a5446b4126939bf0eef8e000000000000000000000000000000000000000007452808679520890a000000", contractAddress: "", cumulativeGasUsed: "7545391", gasUsed: "59073", confirmations: "1102633"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "uint256", name: "value", value: "2250000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "2250000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541062468 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x03bb1b6b40a2c235f19a5446b4126939bf0eef8e"}, {name: "value", type: "uint256", value: "2250000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x03bb1b6b40a2c235f19a5446b4126939bf0eef8e"}, {name: "value", type: "uint256", value: "2250000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[28,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622760", timeStamp: "1541063071", hash: "0x40cc1459bb583d9483c73816dd83a7105ea0463edc9c23d15aef5674965c72c3", nonce: "31", blockHash: "0xb69dcc57f56cb3a35bde06b9348a143f6b79cc598030e255b75d64b13219fe07", transactionIndex: "133", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000004f98fbee373b5cc49528fa2e8a33a464280d8be1000000000000000000000000000000000000000009b18ab5df7180b6b8000000", contractAddress: "", cumulativeGasUsed: "6663773", gasUsed: "59073", confirmations: "1102591"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[10]}, {type: "uint256", name: "value", value: "3000000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "3000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541063071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x4f98fbee373b5cc49528fa2e8a33a464280d8be1"}, {name: "value", type: "uint256", value: "3000000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x4f98fbee373b5cc49528fa2e8a33a464280d8be1"}, {name: "value", type: "uint256", value: "3000000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[29,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623041", timeStamp: "1541067104", hash: "0x05959b101420c0a10ef1e869413d93b2967a4e317111a915eca2daea3aa83fc0", nonce: "32", blockHash: "0x6d903ef0bb39a050a14e5252fcc8d67007b83964dfa9832f6d215da6fa13f329", transactionIndex: "137", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5300000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000cbe92858fb7ee5b3c5470c840b94751478b7cb62000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "5977381", gasUsed: "59073", confirmations: "1102310"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[11]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "1500000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541067104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xcbe92858fb7ee5b3c5470c840b94751478b7cb62"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xcbe92858fb7ee5b3c5470c840b94751478b7cb62"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[30,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623047", timeStamp: "1541067210", hash: "0x5f644a4d25aa357792a802ef4838b83a7514fbacb7ac36d0c9329198e6ab2e6f", nonce: "33", blockHash: "0x78cb6c5e90f2b1d03d129dde8313b22ff8ebcf96aef4bc87472f9343f2549615", transactionIndex: "92", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5300000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fceafd98916e6e61ad63604648b732d814c1ca0e000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "4624684", gasUsed: "59073", confirmations: "1102304"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[12]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "1500000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541067210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfceafd98916e6e61ad63604648b732d814c1ca0e"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfceafd98916e6e61ad63604648b732d814c1ca0e"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[31,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623050", timeStamp: "1541067261", hash: "0xe356429621ebcf40c4490ecbe60cc8b1f1398adaab9f1b1ae043cdb83948a3d0", nonce: "34", blockHash: "0x42a5bbe2293c56687245a6885318c5821be414f13081a2ca85dd066a94e76da4", transactionIndex: "74", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "5300000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008b6c0cb242d1371cacc091712733106c0e710266000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "5600336", gasUsed: "59073", confirmations: "1102301"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[13]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "1500000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541067261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x8b6c0cb242d1371cacc091712733106c0e710266"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0x8b6c0cb242d1371cacc091712733106c0e710266"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[32,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623052", timeStamp: "1541067271", hash: "0x6878afc023b9fec61690d6ebd2510674aed5558ae0df80d9346c8b50a4493bb9", nonce: "35", blockHash: "0x5581971eedc7d4b17504a5e4a731925c5715ba1a745106854f90a04feb3a671b", transactionIndex: "7", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000cbe92858fb7ee5b3c5470c840b94751478b7cb62000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "284953", gasUsed: "29073", confirmations: "1102299"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[11]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "1500000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541067271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xcbe92858fb7ee5b3c5470c840b94751478b7cb62"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xcbe92858fb7ee5b3c5470c840b94751478b7cb62"}, {name: "value", type: "uint256", value: "1500000000000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[33,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623052", timeStamp: "1541067271", hash: "0x1efc73f1770f647d464aca3d81ba29e793ea2970f4bf976361706ccfe96e762d", nonce: "36", blockHash: "0x5581971eedc7d4b17504a5e4a731925c5715ba1a745106854f90a04feb3a671b", transactionIndex: "11", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000fceafd98916e6e61ad63604648b732d814c1ca0e000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "739213", gasUsed: "200000", confirmations: "1102299"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[12]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623052", timeStamp: "1541067271", hash: "0x17e8f5a3b00718848988603a730ace4b3ad61f58d1e8afa84f17a4f92abcb9bd", nonce: "37", blockHash: "0x5581971eedc7d4b17504a5e4a731925c5715ba1a745106854f90a04feb3a671b", transactionIndex: "14", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000008b6c0cb242d1371cacc091712733106c0e710266000000000000000000000000000000000000000004d8c55aefb8c05b5c000000", contractAddress: "", cumulativeGasUsed: "1112450", gasUsed: "200000", confirmations: "1102299"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[13]}, {type: "uint256", name: "value", value: "1500000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623054", timeStamp: "1541067296", hash: "0xebbb0341c4608de57bcf67ce9664b7f92e3c30bc70c8932a3a46358ba7c8622c", nonce: "38", blockHash: "0x30587874447f7f33bf4453a6edc494eb258936a8e692153c988c12d53405cb1c", transactionIndex: "70", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000e5700d60519b4546943748171f70ebb53f003d4e0000000000000000000000000000000000000000026c62ad77dc602dae000000", contractAddress: "", cumulativeGasUsed: "4178129", gasUsed: "200000", confirmations: "1102297"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[14]}, {type: "uint256", name: "value", value: "750000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623054", timeStamp: "1541067296", hash: "0xe77c4b756edeb2335053a18d186a990f6c0598fa28e46f84b2d1049114e5013c", nonce: "39", blockHash: "0x30587874447f7f33bf4453a6edc494eb258936a8e692153c988c12d53405cb1c", transactionIndex: "81", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000000d30fb18efbba0aa758156e366113a0029e0371c0000000000000000000000000000000000000000026c62ad77dc602dae000000", contractAddress: "", cumulativeGasUsed: "5606146", gasUsed: "200000", confirmations: "1102297"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "value", value: "750000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623564", timeStamp: "1541074530", hash: "0xed63ec877f860718ea0ce9cf65afec8b8e129d3ae67796c91415c0768a9cb5ad", nonce: "0", blockHash: "0xb478534148faf3264c4c5bb2c15c81177aaed43180797665b7ad881d58bb55bd", transactionIndex: "16", from: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "30000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "507833", gasUsed: "26319", confirmations: "1101787"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541074530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "899508000000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: unlockTo( addressList[6], `cloud account` )", async function( ) {
		const txOriginal = {blockNumber: "6623689", timeStamp: "1541076558", hash: "0x7497373a0aeb4368a0aa0defe30434df0e6c0abb856375cc49e6ec282db50cb4", nonce: "40", blockHash: "0x86f64aff3b06645be63e55b2806fc28634d67b8912c672ae3bc1bffcf804f357", transactionIndex: "42", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "48056", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x003078b0000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000d636c6f7564206163636f756e7400000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2171747", gasUsed: "48056", confirmations: "1101662"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[6]}, {type: "string", name: "note", value: `cloud account`}], name: "unlockTo", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockTo(address,string)" ]( addressList[6], `cloud account`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541076558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[39,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: "cloud account"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[39,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: unlockTo( addressList[14], `bounty account` )", async function( ) {
		const txOriginal = {blockNumber: "6623696", timeStamp: "1541076636", hash: "0x7e493b93f8a281a2eea27e19150aca351cdceea246d4cf194e4098f4d60dc1e6", nonce: "41", blockHash: "0x0fde13acef4dc96aa422ba1b007188a388a0227a6b7ad9088a2d3e5d3370c809", transactionIndex: "2", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "48056", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x003078b0000000000000000000000000e5700d60519b4546943748171f70ebb53f003d4e0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000e626f756e7479206163636f756e74000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "125427", gasUsed: "48056", confirmations: "1101655"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[14]}, {type: "string", name: "note", value: `bounty account`}], name: "unlockTo", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockTo(address,string)" ]( addressList[14], `bounty account`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541076636 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[40,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0xe5700d60519b4546943748171f70ebb53f003d4e"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: "bounty account"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[40,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623707", timeStamp: "1541076748", hash: "0x0eeb5a7c6204887fd8d59664d34c1fd73811141fc633781badfcadfea1749a0a", nonce: "1", blockHash: "0x4db5ec4f48974ec439b9071d0e914aa0cd4efa093aa2bcda731f31202631aeaf", transactionIndex: "18", from: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "58881", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1009479", gasUsed: "58881", confirmations: "1101644"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541076748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[41,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "899508000000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623716", timeStamp: "1541076892", hash: "0x25f6bf8d3a91da062814948241c60224b3cf69b653911cb42a6d7632cbcbf36e", nonce: "42", blockHash: "0x2292e47ac3805705625a67751aa240d6300709340532af1e1d73483c65805a4f", transactionIndex: "5", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "43881", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "321808", gasUsed: "28881", confirmations: "1101635"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541076892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "to", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[42,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: lbkTransfer( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6623751", timeStamp: "1541077300", hash: "0xf5d799e53cde539838592de16994be8d867faa44b325717fad91b36e25428658", nonce: "2", blockHash: "0x9a81c47601fdfde616c31acf31a258b56cb98521c34d28b82f8d86da883a2010", transactionIndex: "4", from: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "59672", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x3706cc07000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000047465737400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "438387", gasUsed: "59672", confirmations: "1101600"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "1000000000000000000"}, {type: "string", name: "note", value: `test`}], name: "lbkTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lbkTransfer(address,uint256,string)" ]( addressList[4], "1000000000000000000", `test`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541077300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "LBKTransfer", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LBKTransfer", events: [{name: "from", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "note", type: "string", value: "test"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "to", type: "address", value: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[43,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "899508000000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setLockValue( addressList[6], \"2249999998000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623798", timeStamp: "1541078059", hash: "0x6aa5134de85a0082d3a67a7d9cc17fbf6020d0eeaa09a615783c0257e6ae0b3c", nonce: "44", blockHash: "0xbe91c7526e399c3270fe8d3ba6025b93b33235091d59fa220426ba5530e10bf3", transactionIndex: "36", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "49029", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xd712800f000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b0000000000000000000000000000000000000000074528084bd3b321bb380000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000096c6f636b20746573740000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6374287", gasUsed: "49029", confirmations: "1101553"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[6]}, {type: "uint256", name: "value", value: "2249999998000000000000000000"}, {type: "string", name: "note", value: `lock test`}], name: "setLockValue", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setLockValue(address,uint256,string)" ]( addressList[6], "2249999998000000000000000000", `lock test`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541078059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "SetLockValue", type: "event"} ;
		console.error( "eventCallOriginal[44,16] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetLockValue", events: [{name: "addr", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "2249999998000000000000000000"}, {name: "note", type: "string", value: "lock test"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[44,16] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623811", timeStamp: "1541078262", hash: "0x6142255d03b0d0d26f77caf214935c83431c696bde38229702fac3d1f5dee233", nonce: "4", blockHash: "0x049cde5419d242d343f9768465eb66fb2b45f7569ba742ae6f0e8cf316c4bcb9", transactionIndex: "23", from: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "25000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "642808", gasUsed: "25000", confirmations: "1101540"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "10000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "899508000000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623817", timeStamp: "1541078366", hash: "0x53a005985dea0bbc1dfb02d57d2b8fb20570ddf4be9d8cb1fcb0cd453f633da5", nonce: "5", blockHash: "0x81b0b6bc4b23cdd2246ad8d6abbd30cd7f5537fd7a220091b1d7953b8b4569a5", transactionIndex: "31", from: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "200000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000f57e589b6dbabb95815d93e69c9138abfb1a86a70000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "858044", gasUsed: "27049", confirmations: "1101534"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "uint256", name: "value", value: "10000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541078366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "899508000000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setLockValue( addressList[6], \"0\", `lock test` )", async function( ) {
		const txOriginal = {blockNumber: "6623837", timeStamp: "1541078681", hash: "0x0b9e96747d3a6153b4dd0d48c79745fde531e5a48cb29e67be95eb3bec839e76", nonce: "45", blockHash: "0x2506622a024345cc281d7909e4cebb2ef15735c0b8f9fa559e4d7c487aae7239", transactionIndex: "14", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "33389", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xd712800f000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000096c6f636b20746573740000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "409581", gasUsed: "18389", confirmations: "1101514"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[6]}, {type: "uint256", name: "value", value: "0"}, {type: "string", name: "note", value: `lock test`}], name: "setLockValue", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setLockValue(address,uint256,string)" ]( addressList[6], "0", `lock test`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541078681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "SetLockValue", type: "event"} ;
		console.error( "eventCallOriginal[47,16] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetLockValue", events: [{name: "addr", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: "lock test"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[47,16] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6623882", timeStamp: "1541079242", hash: "0x36db722c73ca83069659dd6c2ec164d0a70ae829d2b4cad8158bfd73407f8da7", nonce: "46", blockHash: "0x682c15f765650bd24bb71935ea3ed6b681c2e205140754e4687cb9363eeba9a5", transactionIndex: "0", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "71421", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000fda4a4419dfb43e663fb393bc8db428b4340ac5b", contractAddress: "", cumulativeGasUsed: "71421", gasUsed: "71421", confirmations: "1101469"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[6]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541079242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[48,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xfda4a4419dfb43e663fb393bc8db428b4340ac5b"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[48,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6623884", timeStamp: "1541079283", hash: "0x4a6e40dfb26ee5943ed0b97f276982029500f63281b0c2e075b91775e1550c7f", nonce: "47", blockHash: "0x11f2dc7949ce4db2c02374813fb5f21f6e0392e44f8c1148718f3427eeca25cc", transactionIndex: "21", from: "0xf57e589b6dbabb95815d93e69c9138abfb1a86a7", to: "0xbbc083f213a151a552876b09372a9f98600592f2", value: "0", gas: "71357", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000e5700d60519b4546943748171f70ebb53f003d4e", contractAddress: "", cumulativeGasUsed: "601526", gasUsed: "71357", confirmations: "1101467"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[14]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541079283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[49,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xe5700d60519b4546943748171f70ebb53f003d4e"}], address: "0xbbc083f213a151a552876b09372a9f98600592f2"}] ;
		console.error( "eventResultOriginal[49,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "186103228000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
