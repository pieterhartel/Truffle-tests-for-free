const Lotthereum = artifacts.require( "./Lotthereum.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Lotthereum" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5a2a454675C1b659caa58B5675ee759b992b84b1", "0x50caB9A73A7A4A787A5B74230B5ADC59BE499698", "0x21FBFf7DC33330A2d9E8BaC4C28Dc626E504F67a", "0x168c73Ba8f3C0f4e034Ef7249571E3A8ba50875a", "0xdb2AC0b1028b71C649e78aa6E3d8a9302b728CBD", "0x67b80E003e2B2dd0022d16CCD926989aeAa9F230"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_a", type: "bytes32"}], name: "getNumber", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}], name: "getGameRoundOpen", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}], name: "getRoundPointer", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numberOfClosedGames", outputs: [{name: "numberOfClosedGames", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getGameMinAmountByBet", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}], name: "getRoundNumberOfBets", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}, {name: "betId", type: "uint256"}], name: "getRoundBetOrigin", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getGames", outputs: [{name: "ids", type: "uint256[]"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}], name: "getRoundNumber", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getGameCurrentRoundId", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}, {name: "betId", type: "uint256"}], name: "getRoundBetNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getGameMaxNumberOfBets", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getPointer", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getGamePrize", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "i", type: "uint256"}], name: "getBlockHash", outputs: [{name: "blockHash", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "roundId", type: "uint256"}, {name: "betId", type: "uint256"}], name: "getRoundBetAmount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: false, name: "number", type: "uint8"}], name: "RoundClose", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "maxNumberOfBets", type: "uint256"}], name: "MaxNumberOfBetsChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "minAmountByBet", type: "uint256"}], name: "MinAmountByBetChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "winnerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RoundWinner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}], name: "GameOpened", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}], name: "GameClosed", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RoundOpen(uint256,uint256)", "RoundClose(uint256,uint256,uint8)", "MaxNumberOfBetsChanged(uint256)", "MinAmountByBetChanged(uint256)", "BetPlaced(uint256,uint256,address,uint256)", "RoundWinner(uint256,uint256,address,uint256)", "GameOpened(uint256)", "GameClosed(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xd3db0eb7a3ce838b416d5946a8e3a24a3d490b8d70895551df735f49a61d7f41", "0x3cf46fee4a08f281c4350a9bbb4aaeadb7c80ff5ef61a56ffb43b79d212ae41f", "0x40c3a6db7e366b19bd3a11f3bfcbe973319c26c42b3fbbe017205f9fd55940a5", "0xe4b503ecdd365467c074299d55ed5df93486fad07398b2352bf41a20d1c59939", "0xfdd8ed02332acacb3420e7345a9adadb30877075eade2bcde9fe778e8bb71e42", "0x0f12d8f8fd831e0019cea15f4d3d3d6fbb9929f044d3ff3c528fac91dce47d48", "0xc882ef929f6977685bbc272ef610963c15fdbefb6e09e0cce9b34e809a3031e4", "0x71f4c9aec1b2c51302bcaf09a3f4985709759853536445493905081899603a21"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4063433 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4067356 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Lotthereum", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_a", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getNumber", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumber(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}], name: "getGameRoundOpen", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGameRoundOpen(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}], name: "getRoundPointer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundPointer(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numberOfClosedGames", outputs: [{name: "numberOfClosedGames", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numberOfClosedGames()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getGameMinAmountByBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGameMinAmountByBet(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}], name: "getRoundNumberOfBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundNumberOfBets(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}, {type: "uint256", name: "betId", value: random.range( maxRandom )}], name: "getRoundBetOrigin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundBetOrigin(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getGames", outputs: [{name: "ids", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGames()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}], name: "getRoundNumber", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundNumber(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getGameCurrentRoundId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGameCurrentRoundId(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}, {type: "uint256", name: "betId", value: random.range( maxRandom )}], name: "getRoundBetNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundBetNumber(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getGameMaxNumberOfBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGameMaxNumberOfBets(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getPointer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPointer(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getGamePrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGamePrize(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "i", value: random.range( maxRandom )}], name: "getBlockHash", outputs: [{name: "blockHash", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBlockHash(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "uint256", name: "roundId", value: random.range( maxRandom )}, {type: "uint256", name: "betId", value: random.range( maxRandom )}], name: "getRoundBetAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRoundBetAmount(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Lotthereum", function( accounts ) {

	it( "TEST: Lotthereum(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4063433", blockHash: "0xcf5b44e6d78da7839c9dd0a626b254c4092e38c20f4ea0d82ed57709fdb1004a", timeStamp: "1500833806", hash: "0x7c8c2ac3d20ea19247072ea84c1266ed4e0f959b09bd1e38e0f89b075bc5b2ec", nonce: "73", transactionIndex: "31", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: 0, value: "0", gas: "2303465", gasPrice: "21000000000", input: "0xe966d01a", contractAddress: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", cumulativeGasUsed: "3411847", txreceipt_status: "", gasUsed: "2303465", confirmations: "3619550", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Lotthereum", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Lotthereum.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1500833806 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Lotthereum.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"1\", \"10\", \"1000000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4063436", blockHash: "0x1195a3a829c140e484bf74eb4acd7fc59c256870c54485151f21e5b0d5dd954f", timeStamp: "1500833905", hash: "0x009e1e7d7b8b5155d8ae1666821895400a90b407cd36a6189fb912d72ca70ddc", nonce: "74", transactionIndex: "5", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "206128", gasPrice: "21000000000", input: "0xbdaae1e70000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "499736", txreceipt_status: "", gasUsed: "206128", confirmations: "3619547", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pointer", value: "1"}, {type: "uint256", name: "maxNumberOfBets", value: "10"}, {type: "uint256", name: "minAmountByBet", value: "1000000000000000000"}, {type: "uint256", name: "prize", value: "10000000000000000000"}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(uint256,uint256,uint256,uint256)" ]( "1", "10", "1000000000000000000", "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1500833905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "0"}, {name: "roundId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"1\", \"10\", \"100000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4063440", blockHash: "0xac99e60e2bbe5d099afe2affb7a200f49974fd9909677c45a0c5e5ccee878045", timeStamp: "1500833946", hash: "0xd735b1c6ff614bf458a4067ab131c14c0dd7d26dd21b724d6002acc40238ca8b", nonce: "75", transactionIndex: "4", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "206128", gasPrice: "21000000000", input: "0xbdaae1e70000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "306239", txreceipt_status: "", gasUsed: "206128", confirmations: "3619543", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pointer", value: "1"}, {type: "uint256", name: "maxNumberOfBets", value: "10"}, {type: "uint256", name: "minAmountByBet", value: "100000000000000000"}, {type: "uint256", name: "prize", value: "1000000000000000000"}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(uint256,uint256,uint256,uint256)" ]( "1", "10", "100000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1500833946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "1"}, {name: "roundId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"1\", \"10\", \"10000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "4063444", blockHash: "0x4d80d8a19609168f98430999a2301b355ba53a0655a7e077dc3d35cfa550672c", timeStamp: "1500834022", hash: "0xccf762bb1abf7ec69c6ef2043c1fd403956484410da6fb9674a71598aacbacc0", nonce: "76", transactionIndex: "2", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "206064", gasPrice: "21000000000", input: "0xbdaae1e70000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "414002", txreceipt_status: "", gasUsed: "206064", confirmations: "3619539", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pointer", value: "1"}, {type: "uint256", name: "maxNumberOfBets", value: "10"}, {type: "uint256", name: "minAmountByBet", value: "10000000000000000"}, {type: "uint256", name: "prize", value: "100000000000000000"}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(uint256,uint256,uint256,uint256)" ]( "1", "10", "10000000000000000", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1500834022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "2"}, {name: "roundId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: createGame( \"1\", \"10\", \"1000000000000000\", \"1... )", async function( ) {
		const txOriginal = {blockNumber: "4063447", blockHash: "0xe79444424389985b9ae800896c777c0a0b9b490b3c1b7c9fe064e6ccf767a40a", timeStamp: "1500834080", hash: "0x2a97a547a309c3bcd9b45ff7e726d8c6025b0b6066d68bcd494b2f42558354c6", nonce: "77", transactionIndex: "19", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "206064", gasPrice: "21000000000", input: "0xbdaae1e70000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "870273", txreceipt_status: "", gasUsed: "206064", confirmations: "3619536", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "pointer", value: "1"}, {type: "uint256", name: "maxNumberOfBets", value: "10"}, {type: "uint256", name: "minAmountByBet", value: "1000000000000000"}, {type: "uint256", name: "prize", value: "10000000000000000"}], name: "createGame", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGame(uint256,uint256,uint256,uint256)" ]( "1", "10", "1000000000000000", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1500834080 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063484", blockHash: "0xee19b10ec21c43166b0bd446af4c0a3a42d2af9704b95f900f66ac64f745c6bd", timeStamp: "1500834727", hash: "0x4a316c1cc61e89b0f24debc53a208150d480d704b9ec75a874858751ba853522", nonce: "78", transactionIndex: "6", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "100000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "305240", txreceipt_status: "", gasUsed: "118194", confirmations: "3619499", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "1"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "1", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1500834727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "1"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063485", blockHash: "0x8b35fe89faa7d6784b704d4264c2557742ced565c946d2170ef88c433dc50611", timeStamp: "1500834729", hash: "0x035bbb72dccc83c9235ce4806e9196b25f98b62bd2678d2b2fd7503828b7b3df", nonce: "79", transactionIndex: "2", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "10000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "178706", txreceipt_status: "", gasUsed: "118194", confirmations: "3619498", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "2", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1500834729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "2"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063486", blockHash: "0xf39f6cf7c38433aa2195fc40da742e6ba1b1cce680f19d3ac2ddf488ed0baaa1", timeStamp: "1500834742", hash: "0x09cfe6556e4a967e62d81c3eed5bd1dd5f0043a7189b506b2d71e339e8d2acb2", nonce: "80", transactionIndex: "2", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "160194", txreceipt_status: "", gasUsed: "118194", confirmations: "3619497", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1500834742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"0\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063491", blockHash: "0x5806b93724a1ddea6e2857e7af0258859d22f82329c53e1583c078e69f70dad4", timeStamp: "1500834856", hash: "0x8be78c080995298771868425daa37fbf9adbd4ab02f2f65192e7c8ca556b4fc3", nonce: "81", transactionIndex: "8", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "365260", txreceipt_status: "", gasUsed: "118130", confirmations: "3619492", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "0"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "0", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1500834856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "0"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063500", blockHash: "0x5069e2d2c20444414f9f5de47225d5c33e035c2ba6bc0fb466e30f882bd6a47f", timeStamp: "1500835083", hash: "0xae442004b57f77ed385f4ac5d6cbaf371cb900724a61156fc0d36189f2b08780", nonce: "139", transactionIndex: "26", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "10000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1160724", txreceipt_status: "", gasUsed: "133258", confirmations: "3619483", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1500835083 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "2"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063507", blockHash: "0xc543eef456919c91e8270d5926d8930d523d9a33682910206c893b21251fcc4b", timeStamp: "1500835202", hash: "0xb44fda27d0c4e8fa526f783e2f7f650fb2e7681ec08dd243280dbcd68344da58", nonce: "381", transactionIndex: "57", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3182011", txreceipt_status: "", gasUsed: "133258", confirmations: "3619476", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1500835202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4063507", blockHash: "0xc543eef456919c91e8270d5926d8930d523d9a33682910206c893b21251fcc4b", timeStamp: "1500835202", hash: "0x4e9e9b9da7704e9c7c7746367b2609755c368bd86bf9b27cc03c0c2d5b098fcc", nonce: "382", transactionIndex: "64", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4460922", txreceipt_status: "", gasUsed: "133258", confirmations: "3619476", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1500835202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4063509", blockHash: "0x90d6d86f2c0502922441fa730aaa9b509f1255e3d037e92ab2f0e0d8e0ca0b6f", timeStamp: "1500835239", hash: "0x7e92b3dcdc0c337e2de3fcb9eeb1b7d850792ac7f6323dd9b97e4fbf08021b51", nonce: "140", transactionIndex: "8", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "454543", txreceipt_status: "", gasUsed: "133258", confirmations: "3619474", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1500835239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4063510", blockHash: "0xc117e7358f5403a4b594f0a0af01565ada5944c6bbb840534598ec71b26fe7a9", timeStamp: "1500835241", hash: "0xb272a215b93e0965ba506a2996763875af07bece7b8c3bd38895046d82bb80d5", nonce: "141", transactionIndex: "1", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "154258", txreceipt_status: "", gasUsed: "133258", confirmations: "3619473", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "4"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1500835241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "4"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4063514", blockHash: "0x5c92c465b74b076c10178020ea48f23431a4c47557e77f7120cb83055007e8b3", timeStamp: "1500835293", hash: "0x2a6abe1ab41d36c0e5d699f661924e4743db438e10d6720ace791d6216ee4ed9", nonce: "142", transactionIndex: "2", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "210037", txreceipt_status: "", gasUsed: "133258", confirmations: "3619469", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "5"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1500835293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "5"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4063516", blockHash: "0x0b5544ea53882311b984ddd1d963b46a2a9bf05f95268c17ea495fe969c60106", timeStamp: "1500835319", hash: "0x2a62be9fca1eeaedf93177c174fdb1af7809d7ec351eae67ffd654be8adb5172", nonce: "8", transactionIndex: "5", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "258165", txreceipt_status: "", gasUsed: "133258", confirmations: "3619467", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "6"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1500835319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "6"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4063518", blockHash: "0xe85246e1bb2300d656a70a4c3546345cfbf1533b7e9da0cbc3fea5171ad6a66f", timeStamp: "1500835384", hash: "0x2e264c363781bc6488932a273c2f36744246ba4a531100ed5a573f04a1e5f96b", nonce: "82", transactionIndex: "3", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "196258", txreceipt_status: "", gasUsed: "133258", confirmations: "3619465", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "8"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1500835384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "7"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4063518", blockHash: "0xe85246e1bb2300d656a70a4c3546345cfbf1533b7e9da0cbc3fea5171ad6a66f", timeStamp: "1500835384", hash: "0x727012c2f1a8c23e1e649eb847287a049a34d227a5be34a3303b5892dbf928cd", nonce: "9", transactionIndex: "6", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "371516", txreceipt_status: "", gasUsed: "133258", confirmations: "3619465", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "7"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1500835384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "8"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4063519", blockHash: "0xd048265a1c6baa6340c0cb538993644fc181e7bb87fde28973707b773aba90ec", timeStamp: "1500835395", hash: "0x0be2e662a5f4640d2e75739e6acc33605ef18edd1f9226357bbacc0cc07cb0a8", nonce: "83", transactionIndex: "23", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "5855890", txreceipt_status: "", gasUsed: "360043", confirmations: "3619464", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "9"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1500835395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: false, name: "number", type: "uint8"}], name: "RoundClose", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundClose", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "number", type: "uint8", value: "4"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "9"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "winnerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RoundWinner", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundWinner", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "0"}, {name: "winnerAddress", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4063524", blockHash: "0x68160f50da635c8c4b5af0b955d8b71ca6f5645bdee9bb3444817c6d4c9ddbab", timeStamp: "1500835462", hash: "0xe09788bb993f307a1036c5779601a7e9aa66b0205086d337655a689a493a0cba", nonce: "143", transactionIndex: "8", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "500000", gasPrice: "21000000000", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "686010", txreceipt_status: "", gasUsed: "20942", confirmations: "3619459", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1500835462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4063527", blockHash: "0xf40026da83f4273f1b4545d0f0e81841cbfe00a9a29daf751f252e661405a491", timeStamp: "1500835551", hash: "0xbc7b429c2af3af88ebefe1e46d56eef7a32bd3ab01ce69116b18352b0146d299", nonce: "84", transactionIndex: "5", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "354496", txreceipt_status: "", gasUsed: "148258", confirmations: "3619456", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1500835551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063527", blockHash: "0xf40026da83f4273f1b4545d0f0e81841cbfe00a9a29daf751f252e661405a491", timeStamp: "1500835551", hash: "0x1277f40442f6f05d382be60e1403e75744323803e3b2cf8921414adc3f01564d", nonce: "144", transactionIndex: "10", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "699252", txreceipt_status: "", gasUsed: "133194", confirmations: "3619456", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1500835551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063527", blockHash: "0xf40026da83f4273f1b4545d0f0e81841cbfe00a9a29daf751f252e661405a491", timeStamp: "1500835551", hash: "0xdb6c5eb78a396d49aede3f39073887f83a7ef2d3d82d4638e271429c25a0a0b0", nonce: "145", transactionIndex: "11", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "847510", txreceipt_status: "", gasUsed: "148258", confirmations: "3619456", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1500835551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4063531", blockHash: "0xbf9e504596d00b09758f8835924ede50f52ceb6dcf921fe4eb1da196169a857e", timeStamp: "1500835604", hash: "0x2d7e78c0835dcc42aefcab3fe457569d5b5bbea54849e714f2bca6472ffd8b9d", nonce: "383", transactionIndex: "27", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1233968", txreceipt_status: "", gasUsed: "148258", confirmations: "3619452", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1500835604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4063534", blockHash: "0x0487f722245d9bb742c3bea3f7b8f3f222179cec2d694d077803e91127854c6d", timeStamp: "1500835657", hash: "0xa86176b1030716ab69f81978bec9b7cad9eeff405757917c09bd9a15099ceb7a", nonce: "384", transactionIndex: "6", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "10000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "329516", txreceipt_status: "", gasUsed: "133258", confirmations: "3619449", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "bet", value: "2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "2", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1500835657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "2"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063537", blockHash: "0x56c9e7b5b608abecf3cbbe5c3e9a9e64cc328083e37255fcae8f202a162ade8c", timeStamp: "1500835688", hash: "0xc3e461d0037327b33eef459904e57aa05b8c58f8e123188420ed5c6dc484cb92", nonce: "385", transactionIndex: "17", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "100000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2019863", txreceipt_status: "", gasUsed: "133258", confirmations: "3619446", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "1"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1500835688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "1"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4063541", blockHash: "0x5f26772d3b3bae8725b9882cf718c04057cd03e18845a2352b73479a5bf84faf", timeStamp: "1500835797", hash: "0x89ecf63fc2a551c77e9dc837a5c682a73c534f883b5f00bf18554b002e6acb9a", nonce: "85", transactionIndex: "35", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "10000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1795945", txreceipt_status: "", gasUsed: "133258", confirmations: "3619442", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "2"}, {type: "uint8", name: "bet", value: "3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1500835797 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "2"}, {name: "roundId", type: "uint256", value: "0"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4063547", blockHash: "0x51c113a6a5c1079668d40d398658598739863112ea28e9fab4726ce5899015de", timeStamp: "1500836012", hash: "0xc8cddf744fe686ddda16d369f49ea2a4fd9d5f61223d533d96b9dd1ea28a073e", nonce: "2", transactionIndex: "62", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "2448626", txreceipt_status: "", gasUsed: "148258", confirmations: "3619436", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "6"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1500836012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "4"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4063547", blockHash: "0x51c113a6a5c1079668d40d398658598739863112ea28e9fab4726ce5899015de", timeStamp: "1500836012", hash: "0xe5a63fd56c3d20f4ea24a7f08a2da4fae08583d79f78e7a7cbd021ebd07f2a78", nonce: "146", transactionIndex: "74", from: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "2908123", txreceipt_status: "", gasUsed: "148258", confirmations: "3619436", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "4"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1500836012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x21fbff7dc33330a2d9e8bac4c28dc626e504f67a"}, {name: "betId", type: "uint256", value: "5"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "95627859056967" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4063548", blockHash: "0xb8d5a2f7cf2ab22da3d0f4a2ec56e4d0dcfdbf427b27d838e8c90cb65a3b01be", timeStamp: "1500836015", hash: "0xe4ee304281a50ac9f6be116a8e4703b10f75b0dd71486f0e153948836f9c0f93", nonce: "3", transactionIndex: "18", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "761707", txreceipt_status: "", gasUsed: "148258", confirmations: "3619435", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "7"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1500836015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "6"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4063548", blockHash: "0xb8d5a2f7cf2ab22da3d0f4a2ec56e4d0dcfdbf427b27d838e8c90cb65a3b01be", timeStamp: "1500836015", hash: "0x561703e06195842da5fb9e5b5ce5d0e64c93d79354b4af074a2e72ebc28b5b5b", nonce: "4", transactionIndex: "19", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "909965", txreceipt_status: "", gasUsed: "148258", confirmations: "3619435", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "8"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1500836015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "7"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4063550", blockHash: "0x93717a8aa1b394b1cd25ebb1cc818353d17765d8e7f6f6ff0642e1ff0db6fc6d", timeStamp: "1500836043", hash: "0x29724e368cd81b616ca16d56fc43eac9e64074feffcb3ba77f7ab87b4802a28e", nonce: "5", transactionIndex: "6", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "325310", txreceipt_status: "", gasUsed: "148258", confirmations: "3619433", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "9"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1500836043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "8"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063550", blockHash: "0x93717a8aa1b394b1cd25ebb1cc818353d17765d8e7f6f6ff0642e1ff0db6fc6d", timeStamp: "1500836043", hash: "0x4acfbb84c16c4df3b6f3010a352d2da426ab66d41c00be3fdb63f6c2a3a23603", nonce: "6", transactionIndex: "28", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1654346", txreceipt_status: "", gasUsed: "274435", confirmations: "3619433", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1500836043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: false, name: "number", type: "uint8"}], name: "RoundClose", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundClose", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "number", type: "uint8", value: "5"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "1"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "9"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063581", blockHash: "0x8e6d56595179bf0dd5c5e445aa97d0c61bb33e560cca819693c864913f7bf8bd", timeStamp: "1500836544", hash: "0xcc22b692141b9699736019ac374de54b519609b1875e07e7a0abcca7903a9074", nonce: "386", transactionIndex: "16", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "653456", txreceipt_status: "", gasUsed: "148258", confirmations: "3619402", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1500836544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063581", blockHash: "0x8e6d56595179bf0dd5c5e445aa97d0c61bb33e560cca819693c864913f7bf8bd", timeStamp: "1500836544", hash: "0x193743d81608640b383684cf48c892cfa80aa1dc77b1368392fec0f0e2e40112", nonce: "7", transactionIndex: "32", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "2000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1866313", txreceipt_status: "", gasUsed: "133194", confirmations: "3619402", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1500836544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4063583", blockHash: "0x35d2d035f7be8331e725816dc67e91d4567a57e3eaefb6b34df9ceecddfa2f33", timeStamp: "1500836618", hash: "0x8d6a4f00e655bb7a4e3793ec1506880d0080dbac8b4aadd4cae6ad8852c35791", nonce: "387", transactionIndex: "71", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2063396", txreceipt_status: "", gasUsed: "148258", confirmations: "3619400", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1500836618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4063585", blockHash: "0x2faaf8f8b7a9d452069652bbf8e173a951f98951d896cdcf006624e3347304b6", timeStamp: "1500836659", hash: "0x7d1b3b84182285403a59c1226ca337d87bb0d60e2aa0e0e0b5a202e40cb7a4d5", nonce: "388", transactionIndex: "51", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1867557", txreceipt_status: "", gasUsed: "148258", confirmations: "3619398", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1500836659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4063591", blockHash: "0xfde794c06ab134500c5bd06b1b07a77577bbd88e268d17f7fa1ad7b9ff9180d8", timeStamp: "1500836761", hash: "0xce1d599d7bdbf18b49218db2a98a51ad29a2e73a4596cb1af39faf911dfcec2b", nonce: "10", transactionIndex: "23", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "986464", txreceipt_status: "", gasUsed: "148258", confirmations: "3619392", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "9"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1500836761 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "4"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4063598", blockHash: "0xb708587b4c635b8c8d098155a61245446468629c1c8ba3692576aa6344be1109", timeStamp: "1500836953", hash: "0x4d16c5a92e78766c2682485d12887e714e8c4cd2ab351e37fd337831cfc976e7", nonce: "8", transactionIndex: "57", from: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2941345", txreceipt_status: "", gasUsed: "148258", confirmations: "3619385", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "7"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1500836953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x67b80e003e2b2dd0022d16ccd926989aeaa9f230"}, {name: "betId", type: "uint256", value: "5"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "18053000000004" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4063598", blockHash: "0xb708587b4c635b8c8d098155a61245446468629c1c8ba3692576aa6344be1109", timeStamp: "1500836953", hash: "0x7898fab325a3d57f1ac53b40c4cc397287cb50e42ea7c080b94bb36a507365fd", nonce: "86", transactionIndex: "58", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3089603", txreceipt_status: "", gasUsed: "148258", confirmations: "3619385", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "6"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1500836953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "6"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4063598", blockHash: "0xb708587b4c635b8c8d098155a61245446468629c1c8ba3692576aa6344be1109", timeStamp: "1500836953", hash: "0xc1a537c2886436203cadbcb9baec7fe49150ad5821f9fe549dd24620b69f76af", nonce: "11", transactionIndex: "59", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "3237861", txreceipt_status: "", gasUsed: "148258", confirmations: "3619385", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "8"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1500836953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "7"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4063610", blockHash: "0x11fc4f2d836d296c485ceb0a302b522cd5d3708d444491fe53f53d6b774900b1", timeStamp: "1500837187", hash: "0x2e1fea405abccd939dc5b69960cce3d660e9c94f38f80c230b07dca2786fbd7b", nonce: "87", transactionIndex: "57", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2242788", txreceipt_status: "", gasUsed: "148258", confirmations: "3619373", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "5"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1500837187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "8"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063617", blockHash: "0x59e2728740147d4520e5fe278bd57e1f2e69c9ba27aacf68d71badf39bfc9c12", timeStamp: "1500837236", hash: "0x56634e6598b0ff992e796e4217f5cef97e250c18d771c50620bf706ccd1db97d", nonce: "88", transactionIndex: "12", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "797141", txreceipt_status: "", gasUsed: "337042", confirmations: "3619366", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1500837236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}], name: "RoundOpen", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundOpen", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: false, name: "number", type: "uint8"}], name: "RoundClose", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundClose", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "number", type: "uint8", value: "9"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "9"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "winnerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RoundWinner", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundWinner", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "2"}, {name: "winnerAddress", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "amount", type: "uint256", value: "10000000000000000"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "4063631", blockHash: "0x0563e4969e34c230a89df0bd3d38787a09a373f6c5e7981d3039e6ff1a6c9082", timeStamp: "1500837567", hash: "0xe26cd3db6dbe9d92f5ec0be61b3a0505523f4dd6989bba80f243af057cbe42a4", nonce: "12", transactionIndex: "44", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "0", gas: "500000", gasPrice: "5000000000", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2112044", txreceipt_status: "", gasUsed: "20942", confirmations: "3619352", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1500837567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4063667", blockHash: "0xf4904b597909227ec09ed55b20a4d83aa00bd199e49bf23cd689bdc4b22ada4d", timeStamp: "1500838310", hash: "0x74320228a02ea402e7b8644c61b1037642c90a0e0100746466b610911e1ba868", nonce: "89", transactionIndex: "49", from: "0x50cab9a73a7a4a787a5b74230b5adc59be499698", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2055417", txreceipt_status: "", gasUsed: "133194", confirmations: "3619316", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1500838310 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0x50cab9a73a7a4a787a5b74230b5adc59be499698"}, {name: "betId", type: "uint256", value: "0"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "701047494195378" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4063718", blockHash: "0xfddcb9a53d135685c2a0b66dc768ab90a547cd6dfecd91358d5a5fe036c31aa1", timeStamp: "1500839236", hash: "0x317e62c7b3857d8649e1a974fbca1f027ecac0d1df88042fb8f046a4f3619755", nonce: "389", transactionIndex: "8", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "5000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "378733", txreceipt_status: "", gasUsed: "148258", confirmations: "3619265", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "1"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1500839236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "1"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4063724", blockHash: "0x8b9d0fafd2085b64ccc806c2a616a4776b658c82da50769e4558275c8a69bede", timeStamp: "1500839412", hash: "0xdb0d311c375bf797b8df6293f3fe453ca46efc2638c9a7a0766caad955dd9f24", nonce: "390", transactionIndex: "29", from: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "21000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2030238", txreceipt_status: "", gasUsed: "148258", confirmations: "3619259", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1500839412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0x168c73ba8f3c0f4e034ef7249571e3a8ba50875a"}, {name: "betId", type: "uint256", value: "2"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "190407056291329777" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4067262", blockHash: "0x0aa58123ea042fbc632e22c26e77f38f1acb15b96187760d21893661fb2f183d", timeStamp: "1500905481", hash: "0x20cf915dd920a09274ace416bce0568deea1c0a70f3263fb199b413097b8c47d", nonce: "13", transactionIndex: "7", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "20000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "389218", txreceipt_status: "", gasUsed: "148258", confirmations: "3615721", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1500905481 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "3"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4067348", blockHash: "0x5e409385222202e5f77784c60be6fb3e2175f884c952bf91f1f087b8f5819240", timeStamp: "1500906979", hash: "0x28e9c419866f6714d2d7a4e616474fac0e8fdf79fbb32830320d67552d3b4e3e", nonce: "14", transactionIndex: "86", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "20000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4748600", txreceipt_status: "", gasUsed: "148258", confirmations: "3615635", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "4"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1500906979 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "4"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"3\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4067356", blockHash: "0xf23b60dc00b72f9139757a6b92840ff9be910a613b64c52f0fccd4da3e6af9f2", timeStamp: "1500907161", hash: "0xd12f945d9789857ede05f5caa421f4ffd74e1ec256b046df1086a9cdb2ac67bc", nonce: "15", transactionIndex: "74", from: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd", to: "0x5a2a454675c1b659caa58b5675ee759b992b84b1", value: "1000000000000000", gas: "500000", gasPrice: "20000000000", input: "0x03edf91400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2669739", txreceipt_status: "", gasUsed: "148258", confirmations: "3615627", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "3"}, {type: "uint8", name: "bet", value: "5"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint8)" ]( "3", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1500907161 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "roundId", type: "uint256"}, {indexed: true, name: "origin", type: "address"}, {indexed: false, name: "betId", type: "uint256"}], name: "BetPlaced", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BetPlaced", events: [{name: "gameId", type: "uint256", value: "3"}, {name: "roundId", type: "uint256", value: "3"}, {name: "origin", type: "address", value: "0xdb2ac0b1028b71c649e78aa6e3d8a9302b728cbd"}, {name: "betId", type: "uint256", value: "5"}], address: "0x5a2a454675c1b659caa58b5675ee759b992b84b1"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "295302868406978" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
