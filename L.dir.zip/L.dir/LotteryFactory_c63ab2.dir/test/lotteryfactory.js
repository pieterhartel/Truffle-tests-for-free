const LotteryFactory = artifacts.require( "./LotteryFactory.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "LotteryFactory" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6851A80b7655e36e1F04E383b5946dafE9c63ab2", "0x344A7C6cA361157D506C54E9F5c3DF19D3354EC3", "0x8437424573FADdeCFAd4ED55f93CB2A096fe64d2", "0x827A7D44ad8dF073FcaD9969B7Cd50Ea99988cc6", "0x08966DBcF722eA3AE7047202968AF09a0ED5b9ad", "0xcab5f8c4830938aD3040863E668FA071e1F9c5dC", "0x7d08212f2a022B3bBC6e9085b7687745C7eb0829", "0xE123D167f03f70fB3B62b06f71534142ECd46cc6", "0x83b3AB5f410e82aAED0E49Bb8FAEcD862775d70B", "0xae6bB0CeAC079E48f8a9ddCb7Ca561f33A54Ea54", "0x3Ef6E4C4Ad4f0013B9913e066179b38e1aAf8b50", "0x0ED7CEE6F0f7Ab73389c34d6dA368A4d6df0F73D", "0xfAB47fF562e0209EBf2fDFd9Ef7A03A610d568e5", "0xaa65A32C3FB57385d811877002Afe54506806a31", "0x7407C31fcA614b217E6ACA80DCB6eF177c4bCF99", "0x36aC9E87721D9A5fE07ca6B9aABc6205644Bb5Fe", "0xd6D1fc43BD2fCD734b2a447773400eCf5C71b69C", "0xa7d89A2B12AF49E0f89889fa59a8f0d5E1475775", "0xd8b760fC78a69b651Da9eD4F28898277364e18D6", "0xf510ba5977DB118df1e10D61e278B4023A71AAfa", "0x74C03BF5746BD6DaE3df7530b2c079d58b66dE28", "0x940131019f29248dbD522e4D9bA1E5D1B043e13C", "0xceAd4e4d74e6a19F16D3602e495fF0f9943919e2", "0x13aF60631686E79599d214Db2fe5e5a16184ce5D", "0xc3a55C07dd52627789bC1f1dE3Cb4340AbB48C63", "0xb78760A3Db76A5aCD2BA396e9a2E2B6FBeBB0D46", "0xF76C73Fd2f79DC2499b14d6E476FF3620B57364f", "0xaf6CBAa814b9772A231f0d956CaC4EC689f980b6", "0x8d79bD07B587288F97541508dAae3Fb6E0d02D4C", "0x59685d654a6bfd6E10Aa273c8709FF1d00cc42F7", "0xcc9204edF789796bDc62543F4153489d5EA215E2", "0x7647FbA07431782A8329F0AB25DDC1f2896b9C2D", "0x62836B27EDD124280eA2891Be24f31BF3AE4fBBd", "0x7197e2B447Db607034834aAD089C4a1cC507F538"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "checkRole", outputs: [], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "lotteries", outputs: [{name: "betAmount", type: "uint32"}, {name: "dividend", type: "uint32"}, {name: "refund", type: "uint32"}, {name: "date", type: "uint32"}, {name: "race", type: "uint8"}, {name: "isPaid", type: "bool"}, {name: "betline", type: "string"}, {name: "place", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ROLE_WHITELISTED", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "hasRole", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_playerAddress", type: "address"}], name: "getBalanceOfPlayer", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "getLotteriesByOwner", outputs: [{name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "players", outputs: [{name: "isFreezed", type: "bool"}, {name: "isExist", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "lotteryToOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: false, name: "_dividend", type: "uint32"}], name: "Dividend", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: false, name: "_refund", type: "uint32"}], name: "Refund", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BuyLottery(uint32,address,string,string,uint32,uint32,uint8)", "Dividend(uint32,uint32)", "Refund(uint32,uint32)", "NewPlayer(address)", "RoleAdded(address,string)", "RoleRemoved(address,string)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc3bc8cc6238cfa4d5605573949d0190bdec10759f44769bd297b31b4f85295f0", "0xe0e5db7a0d2ca5a295daf5a0026fffa40f1a5fdd2ce343c69a573927f8a02346", "0x221b3ce8956df4b9cf69a447a1ad515f7228bb251da32a3de4c752fdf5dc82f5", "0x52e92d4898337244a39bd42674ac561eadfd3959e947deec1c0ab82dd58b5a75", "0xbfec83d64eaa953f2708271a023ab9ee82057f8f3578d548c1a4ba0b5b700489", "0xd211483f91fc6eff862467f8de606587a30c8fc9981056f051b897a418df803a", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6617004 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6636225 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "LotteryFactory", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "checkRole", outputs: [], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "lotteries", outputs: [{name: "betAmount", type: "uint32"}, {name: "dividend", type: "uint32"}, {name: "refund", type: "uint32"}, {name: "date", type: "uint32"}, {name: "race", type: "uint8"}, {name: "isPaid", type: "bool"}, {name: "betline", type: "string"}, {name: "place", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lotteries(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ROLE_WHITELISTED", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ROLE_WHITELISTED()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "hasRole", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getBalanceOfPlayer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBalanceOfPlayer(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getLotteriesByOwner", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLotteriesByOwner(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "players", outputs: [{name: "isFreezed", type: "bool"}, {name: "isExist", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "players(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "lotteryToOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lotteryToOwner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "LotteryFactory", function( accounts ) {

	it( "TEST: LotteryFactory(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6617004", timeStamp: "1540980933", hash: "0x91536435bfe644fb06932d248dcfbfc22b2bd9ddc29c4c552616c72894468f20", nonce: "635", blockHash: "0x27068f165d2a09479e4a99ceb4ac4ff7faa804a970dbd8d44cb0b7eb7ccd2665", transactionIndex: "20", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: 0, value: "0", gas: "4000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x8f8fcb6b", contractAddress: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", cumulativeGasUsed: "4891696", gasUsed: "3355686", confirmations: "1109007"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "LotteryFactory", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = LotteryFactory.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540980933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = LotteryFactory.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoleAdded", events: [{name: "operator", type: "address", value: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3"}, {name: "role", type: "string", value: "whitelist"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setHKHcoinAddress( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6620866", timeStamp: "1541036318", hash: "0xe9f8868ab23c5c313fc719690612d9f991a4c4376fc3f54f709215ff13743fdd", nonce: "678", blockHash: "0xcc23566f07fd28e18c166386f7898bdc513af1861e42991791e55e37f86c4162", transactionIndex: "44", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "4000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xeea6e7230000000000000000000000008437424573faddecfad4ed55f93cb2a096fe64d2", contractAddress: "", cumulativeGasUsed: "3368768", gasUsed: "44499", confirmations: "1105145"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[4]}], name: "setHKHcoinAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setHKHcoinAddress(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541036318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6621450", timeStamp: "1541044913", hash: "0x05652bce39f96b03de918303f1e6ff4df237fa78b9628a3f6869c508e65c4901", nonce: "680", blockHash: "0xe0bd5198cd72b5e0c45e30e44ff92081d65607f2bb4d15a1c5005d0db2e64fe6", transactionIndex: "66", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000827a7d44ad8df073fcad9969b7cd50ea99988cc6", contractAddress: "", cumulativeGasUsed: "6934228", gasUsed: "76527", confirmations: "1104561"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[5]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541044913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x827a7d44ad8df073fcad9969b7cd50ea99988cc6"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6621936", timeStamp: "1541051554", hash: "0x50557f0bd23a3b282675e778d2a19fcdd1e192fafdc298ded979e792b76e4f44", nonce: "681", blockHash: "0x3171778572a72c6c08e565053b0a8aae413646bc044cd020f6b3cd4f23488a81", transactionIndex: "90", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000008966dbcf722ea3ae7047202968af09a0ed5b9ad", contractAddress: "", cumulativeGasUsed: "3528180", gasUsed: "76527", confirmations: "1104075"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[6]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541051554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x08966dbcf722ea3ae7047202968af09a0ed5b9ad"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6621984", timeStamp: "1541052267", hash: "0x0ed25d3eb4e7b75f03b04d0509a4886b1e5caf8266161fa3f8d6487d32014666", nonce: "682", blockHash: "0xdfa52627cb644a59fdd505c6af26ff2ff0633bcf1391ab30b10c5bd935a2c473", transactionIndex: "129", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000cab5f8c4830938ad3040863e668fa071e1f9c5dc", contractAddress: "", cumulativeGasUsed: "5828464", gasUsed: "76527", confirmations: "1104027"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[7]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541052267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xcab5f8c4830938ad3040863e668fa071e1f9c5dc"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6622090", timeStamp: "1541053650", hash: "0x5f15a19b420939d53bf812b13992d3e886075d03f2158e4e88c64c2fbd3fe0ef", nonce: "683", blockHash: "0x5631f7f3e8a89b90f661574cdb45e66f849bc4b29650cc21f978d62120e86822", transactionIndex: "98", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "4281250000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000007d08212f2a022b3bbc6e9085b7687745c7eb0829", contractAddress: "", cumulativeGasUsed: "6257874", gasUsed: "76527", confirmations: "1103921"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[8]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541053650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x7d08212f2a022b3bbc6e9085b7687745c7eb0829"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6622210", timeStamp: "1541055266", hash: "0x05590daa7f33817a58774671cfb4c79972382e6562f420720d1d4cfa1d402f3b", nonce: "684", blockHash: "0x57fb218e92ee4e0265004f3bbc63b2cab7129d2526c675ef3d0f7863ee0d5e5f", transactionIndex: "67", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5687500000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000e123d167f03f70fb3b62b06f71534142ecd46cc6", contractAddress: "", cumulativeGasUsed: "3924808", gasUsed: "76527", confirmations: "1103801"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[9]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541055266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xe123d167f03f70fb3b62b06f71534142ecd46cc6"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6622299", timeStamp: "1541056413", hash: "0xd56c801d14f3eca4ca290f216252f5edc31724f14f044d18558aaa4096e9d9ea", nonce: "685", blockHash: "0x10b0bc58216577032ba5bc812180e9dd0b3e467c564a6b86eccafc1593321c45", transactionIndex: "44", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "6612500001", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000083b3ab5f410e82aaed0e49bb8faecd862775d70b", contractAddress: "", cumulativeGasUsed: "5215256", gasUsed: "76527", confirmations: "1103712"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[10]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541056413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x83b3ab5f410e82aaed0e49bb8faecd862775d70b"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6622467", timeStamp: "1541058896", hash: "0x0e58a903a5260336334fd956981a9d0b539ad025ac22cc57bc1f3d36db3a4be4", nonce: "686", blockHash: "0x49e130e09dd17603914b783b6bf4bb29680872c9cb9a5dae12c104566fcf4fbb", transactionIndex: "163", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "7093750000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000ae6bb0ceac079e48f8a9ddcb7ca561f33a54ea54", contractAddress: "", cumulativeGasUsed: "5008388", gasUsed: "76527", confirmations: "1103544"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[11]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541058896 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xae6bb0ceac079e48f8a9ddcb7ca561f33a54ea54"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6622467", timeStamp: "1541058896", hash: "0x5d6a22ccf4b2cebd3f6c3dc175210f90bd6a2cf8d89aff8438a0a3ebdcc34439", nonce: "687", blockHash: "0x49e130e09dd17603914b783b6bf4bb29680872c9cb9a5dae12c104566fcf4fbb", transactionIndex: "164", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "7093750000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b50", contractAddress: "", cumulativeGasUsed: "5084851", gasUsed: "76463", confirmations: "1103544"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541058896 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6622999", timeStamp: "1541066607", hash: "0x6b710968ad4fcd677b88db03df459bf37898643d240bb3243c770f6ea86f9669", nonce: "688", blockHash: "0x74a16b9973994920c5c85abdcdb368ef053af627792e0f2c1ead3ac2ae66354e", transactionIndex: "85", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9600000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000000ed7cee6f0f7ab73389c34d6da368a4d6df0f73d", contractAddress: "", cumulativeGasUsed: "2996896", gasUsed: "76527", confirmations: "1103012"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[13]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541066607 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x0ed7cee6f0f7ab73389c34d6da368a4d6df0f73d"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6623010", timeStamp: "1541066730", hash: "0xb34e04f74ce689fe009e6d62a23233619058ec2f6d0e1928e820e5744f7adc55", nonce: "689", blockHash: "0xfab2586f608e0b79a3b9b1819bb4b77c625934470daa895519043994c6a94526", transactionIndex: "87", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000fab47ff562e0209ebf2fdfd9ef7a03a610d568e5", contractAddress: "", cumulativeGasUsed: "3787307", gasUsed: "76527", confirmations: "1103001"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[14]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541066730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xfab47ff562e0209ebf2fdfd9ef7a03a610d568e5"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6623469", timeStamp: "1541072994", hash: "0x273b6c62cd164f24f4f1dc694a4a0a1d33537ee6c962b56c08ec9f9c55fec83e", nonce: "690", blockHash: "0x54e8becb683efcf3f10677bbad485f8a02ebf38a81d544885c0f3c045930244f", transactionIndex: "117", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000aa65a32c3fb57385d811877002afe54506806a31", contractAddress: "", cumulativeGasUsed: "4402534", gasUsed: "76527", confirmations: "1102542"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[15]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541072994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xaa65a32c3fb57385d811877002afe54506806a31"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6623737", timeStamp: "1541077098", hash: "0x4fbec72d5c8edccbc4c1596aa0ae8b2da15b0adb8c5d658aa56755ad92d648cc", nonce: "691", blockHash: "0x3e1938e511ae5d37ece7af17da96450fe54773c6a0bc23bace963e4e1bbe6561", transactionIndex: "18", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "12250000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000007407c31fca614b217e6aca80dcb6ef177c4bcf99", contractAddress: "", cumulativeGasUsed: "1321353", gasUsed: "76527", confirmations: "1102274"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[16]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541077098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x7407c31fca614b217e6aca80dcb6ef177c4bcf99"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6624357", timeStamp: "1541085843", hash: "0x0841792376c06e07e0231f9a11974fe101906d6b4b12c4db187d5c36695e83c6", nonce: "692", blockHash: "0x63e4a023763b375d64c14f724593bf4bff07a4a65e1bb07f0777e363ce5f05cd", transactionIndex: "76", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000036ac9e87721d9a5fe07ca6b9aabc6205644bb5fe", contractAddress: "", cumulativeGasUsed: "5020476", gasUsed: "76527", confirmations: "1101654"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[17]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541085843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x36ac9e87721d9a5fe07ca6b9aabc6205644bb5fe"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[18] )", async function( ) {
		const txOriginal = {blockNumber: "6624614", timeStamp: "1541089378", hash: "0x3ae213bcff1ad6af2b219ebbb4d42b4c26aa9f484507e38bbf48069dc9dd7cd4", nonce: "693", blockHash: "0x388f1b6c9f2de7d1315739eae0c28d31168749d33949e2bbb7dd85bfd6354aed", transactionIndex: "105", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000d6d1fc43bd2fcd734b2a447773400ecf5c71b69c", contractAddress: "", cumulativeGasUsed: "7711127", gasUsed: "76527", confirmations: "1101397"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[18]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541089378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xd6d1fc43bd2fcd734b2a447773400ecf5c71b69c"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[19] )", async function( ) {
		const txOriginal = {blockNumber: "6624662", timeStamp: "1541090039", hash: "0x7152f87fcfbd0afa2ea95bdcf6d68b1d3c6ea7bf3cb1f53ef997281cac000af7", nonce: "694", blockHash: "0x44d16a052e12a6d1a8c8ab0d999b6dd2dc2113eb4ea41b3dbb053d641c8dadcb", transactionIndex: "57", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000a7d89a2b12af49e0f89889fa59a8f0d5e1475775", contractAddress: "", cumulativeGasUsed: "3090006", gasUsed: "76527", confirmations: "1101349"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[19]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541090039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xa7d89a2b12af49e0f89889fa59a8f0d5e1475775"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[20] )", async function( ) {
		const txOriginal = {blockNumber: "6626064", timeStamp: "1541109858", hash: "0x3a1c4291cbc2788d711974f2e20d0d8b642736945b876db13c07f3f6c12bb7ec", nonce: "695", blockHash: "0x85558f2584712e36a5d05fa9dad21390352de895114c3e4127c7983dc55006a6", transactionIndex: "15", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000d8b760fc78a69b651da9ed4f28898277364e18d6", contractAddress: "", cumulativeGasUsed: "7549690", gasUsed: "76527", confirmations: "1099947"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[20]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541109858 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xd8b760fc78a69b651da9ed4f28898277364e18d6"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6627399", timeStamp: "1541129527", hash: "0xfdb215a6e4b3a695718db148df13e1095c5e127030e9532348340614c925fe2b", nonce: "696", blockHash: "0x8254eb71475a2f13be410cf3bf2e52eeeb1b53d2a648a46eba4c0a87d15b2635", transactionIndex: "85", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000f510ba5977db118df1e10d61e278b4023a71aafa", contractAddress: "", cumulativeGasUsed: "7344219", gasUsed: "76527", confirmations: "1098612"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[21]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541129527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xf510ba5977db118df1e10d61e278b4023a71aafa"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6627468", timeStamp: "1541130604", hash: "0xe96bf2a39f0c996fb38c107e052dc4bf8c5d983556a6cdb111ede516e645beda", nonce: "697", blockHash: "0xba9fac834bc00492fe7c7458fb0f0fc900d8777d3d5de716c1fddf6b75ecb0aa", transactionIndex: "69", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000074c03bf5746bd6dae3df7530b2c079d58b66de28", contractAddress: "", cumulativeGasUsed: "6246376", gasUsed: "76527", confirmations: "1098543"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[22]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541130604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x74c03bf5746bd6dae3df7530b2c079d58b66de28"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[23] )", async function( ) {
		const txOriginal = {blockNumber: "6628298", timeStamp: "1541142532", hash: "0xbe90b42cfc7f93951b1a2310a723c7bb141ffe591c398895b354aaf7b7aad297", nonce: "698", blockHash: "0x8d5ef151a404f88a83f09b7a9cc4ccd3187895f1b393b09da2acdd92bf7118df", transactionIndex: "125", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000940131019f29248dbd522e4d9ba1e5d1b043e13c", contractAddress: "", cumulativeGasUsed: "7544654", gasUsed: "76527", confirmations: "1097713"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[23]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[23], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541142532 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x940131019f29248dbd522e4d9ba1e5d1b043e13c"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[24] )", async function( ) {
		const txOriginal = {blockNumber: "6628437", timeStamp: "1541144669", hash: "0xb41a73c8733d259ac710db6d7f8edb107acb001c062ba35d3d74bd6d69f05856", nonce: "699", blockHash: "0xcd06686197a2340126d2a408749aab8220803977f92325f1f8e63ca2d9d4c216", transactionIndex: "42", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000cead4e4d74e6a19f16d3602e495ff0f9943919e2", contractAddress: "", cumulativeGasUsed: "5211756", gasUsed: "76527", confirmations: "1097574"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[24]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[24], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541144669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xcead4e4d74e6a19f16d3602e495ff0f9943919e2"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[25] )", async function( ) {
		const txOriginal = {blockNumber: "6628480", timeStamp: "1541145332", hash: "0x0c594bba650e1a93095f7f4c981d2dc597b469e7bdfc39307d6b0a263c6781f4", nonce: "700", blockHash: "0xc88fcf0f3e5fbf37c3327c0b9654ebfb79427a004bc510cbb69509077284f657", transactionIndex: "168", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000013af60631686e79599d214db2fe5e5a16184ce5d", contractAddress: "", cumulativeGasUsed: "6991444", gasUsed: "76527", confirmations: "1097531"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[25]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[25], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541145332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x13af60631686e79599d214db2fe5e5a16184ce5d"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6628497", timeStamp: "1541145539", hash: "0x1b8f6ee4e61696c1cabf06d86cd0b9a62e62fa3717ff1b82ef182d8c40952b7f", nonce: "701", blockHash: "0xb46da2416cd6b019290f3fe3682ce69fadd7e0caf3618727fa32cd55b7b9d414", transactionIndex: "38", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000c3a55c07dd52627789bc1f1de3cb4340abb48c63", contractAddress: "", cumulativeGasUsed: "1616162", gasUsed: "76527", confirmations: "1097514"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[26]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541145539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xc3a55c07dd52627789bc1f1de3cb4340abb48c63"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[27] )", async function( ) {
		const txOriginal = {blockNumber: "6628558", timeStamp: "1541146555", hash: "0x55baecca8ab616717dda86bc1a329419423da3e941510d3a2e8122b5a6d37bea", nonce: "702", blockHash: "0xd312d6b1c1ca375889889fd9c12be61b037cc0bba0005576355ebeb9bd4e9dcc", transactionIndex: "28", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000b78760a3db76a5acd2ba396e9a2e2b6fbebb0d46", contractAddress: "", cumulativeGasUsed: "6935754", gasUsed: "76527", confirmations: "1097453"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[27]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[27], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541146555 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xb78760a3db76a5acd2ba396e9a2e2b6fbebb0d46"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[11], `W-P 7*8`, `ST`, \"200\... )", async function( ) {
		const txOriginal = {blockNumber: "6628598", timeStamp: "1541147099", hash: "0xe867949429a2f121aa8b54c8b069e0b475be58c6050489058042b371db177bec", nonce: "703", blockHash: "0xf450faeb49078c8e04d234adadcf27bf834346ebfa998ca369c02c58d35d74d0", transactionIndex: "37", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "9100000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb6000000000000000000000000ae6bb0ceac079e48f8a9ddcb7ca561f33a54ea5400000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000c8000000000000000000000000000000000000000000000000000000005bddc60000000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000007572d5020372a380000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6516900", gasUsed: "191448", confirmations: "1097413"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[11]}, {type: "string", name: "_betline", value: `W-P 7*8`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "7"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[11], `W-P 7*8`, `ST`, "200", "1541260800", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541147099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [0]}}, {name: "_playerAddress", type: "address", value: "0xae6bb0ceac079e48f8a9ddcb7ca561f33a54ea54"}, {name: "_betline", type: "string", value: "W-P 7*8"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "7"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `W-P 1*1+2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628773", timeStamp: "1541149498", hash: "0x1904aaa8be61fe0e765a9076c5a5a62e5c14d7444942cbbcb0b865eedb95afc3", nonce: "704", blockHash: "0xaa8b597021d447e8e0235a01a0201d095d079efe074f70141036ee7cd27c14cd", transactionIndex: "48", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000005bddc60000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000020572d5020312a312b322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3366476", gasUsed: "198354", confirmations: "1097238"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `W-P 1*1+2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "2400"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `W-P 1*1+2+3+4+5+6+7+8+9+10+11+12`, `ST`, "2400", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541149498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "W-P 1*1+2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [2400]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `WIN 1*1+2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0xa4765876be9ade97a525bc131c6ac6a1180b5da0b3d7e98d056ac346cb01ee13", nonce: "705", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "145", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004b0000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002057494e20312a312b322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6589317", gasUsed: "183354", confirmations: "1097233"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `WIN 1*1+2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `WIN 1*1+2+3+4+5+6+7+8+9+10+11+12`, `ST`, "1200", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "WIN 1*1+2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `PLA 1*1+2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0x179ac2b7fdcd75b2caad4ef237378f67ba59a0f4fcdce133d038832576361e45", nonce: "706", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "146", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004b0000000000000000000000000000000000000000000000000000000005bddc60000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000020504c4120312a312b322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6772671", gasUsed: "183354", confirmations: "1097233"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `PLA 1*1+2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `PLA 1*1+2+3+4+5+6+7+8+9+10+11+12`, `ST`, "1200", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "PLA 1*1+2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `WIN 1*1`, `ST`, \"100\... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0x8786d4d3cf7e13f607f3254596fddb823eec1ade7816a3f3b422967510e2c3cb", nonce: "707", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "147", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000757494e20312a310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6934055", gasUsed: "161384", confirmations: "1097233"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `WIN 1*1`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `WIN 1*1`, `ST`, "100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "WIN 1*1"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `PLA 1*12`, `ST`, \"100... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0xd084b0923237ba6a7024d3eed74be55c039aa230e95f59260381b1089eadb206", nonce: "708", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "148", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000005bddc60000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000008504c4120312a313200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7095511", gasUsed: "161456", confirmations: "1097233"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `PLA 1*12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `PLA 1*12`, `ST`, "100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "PLA 1*12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `WIN 1*1`, `ST`, \"100\... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0x84ddeab445a60242cfb45cb84e62e0468b793604226af336d5ca8db8ca2c44bd", nonce: "709", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "149", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000757494e20312a310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7256895", gasUsed: "161384", confirmations: "1097233"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `WIN 1*1`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `WIN 1*1`, `ST`, "100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "WIN 1*1"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QIN 1*1+2`, `ST`, \"10... )", async function( ) {
		const txOriginal = {blockNumber: "6628778", timeStamp: "1541149577", hash: "0xf614d82fad453148481e7b8eb73e6a2747d04bcddd532af316698947b7f55598", nonce: "710", blockHash: "0x235e16f1af90845d8880976c2dbdd8a17531a1f0037bfbc67548f09f7de2988b", transactionIndex: "150", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000951494e20312a312b32000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7418423", gasUsed: "161528", confirmations: "1097233"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QIN 1*1+2`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QIN 1*1+2`, `ST`, "100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541149577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [7]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QIN 1*1+2"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QIN 1*1+2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628781", timeStamp: "1541149645", hash: "0x2cf74a42ac2a954a98c6479eb903edf7ccfe215388cac6c9a027ed725926ada9", nonce: "711", blockHash: "0xdd99d797086411712e8d3ccab6774662763e7301219e4154ee2b6f1953fd6950", transactionIndex: "49", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000019c8000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051494e20312a312b322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6428971", gasUsed: "183354", confirmations: "1097230"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QIN 1*1+2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "6600"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QIN 1*1+2+3+4+5+6+7+8+9+10+11+12`, `ST`, "6600", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541149645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [8]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QIN 1*1+2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [6600]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QIN 1*1>2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628781", timeStamp: "1541149645", hash: "0xd0fc66326b8c88ef6bb9be63244cdddcbd10339eb0c2b151114ec948814d064e", nonce: "712", blockHash: "0xdd99d797086411712e8d3ccab6774662763e7301219e4154ee2b6f1953fd6950", transactionIndex: "50", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000044c000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051494e20312a313e322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6612325", gasUsed: "183354", confirmations: "1097230"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QIN 1*1>2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QIN 1*1>2+3+4+5+6+7+8+9+10+11+12`, `ST`, "1100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541149645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 0, c: [9]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QIN 1*1>2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QPL 1*2>1+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628832", timeStamp: "1541150153", hash: "0x76ce9f2b6103f21ad51566ef282f7cdac06c6e20318d6e2b9073fe402c547e16", nonce: "713", blockHash: "0xacd25d7bd77a71ed922792c108d4799d6595f019d2613a0706c6a8a4e91e8cdc", transactionIndex: "38", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000044c000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051504c20312a323e312b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3121846", gasUsed: "183354", confirmations: "1097179"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QPL 1*2>1+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QPL 1*2>1+3+4+5+6+7+8+9+10+11+12`, `ST`, "1100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541150153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [10]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QPL 1*2>1+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QPL 1*12>1+2+3+4+5+6+7... )", async function( ) {
		const txOriginal = {blockNumber: "6628836", timeStamp: "1541150221", hash: "0x805c2a3bb80cc578afba0ce11a3c6f554f312582ffd77d1a713616796f0f316b", nonce: "714", blockHash: "0xf66a5ed536f0611efb61aa5ed828cecf5b60299f51d15668af7a534da46dd7a6", transactionIndex: "17", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000044c000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051504c20312a31323e312b322b332b342b352b362b372b382b392b31302b313100000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "953217", gasUsed: "183354", confirmations: "1097175"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QPL 1*12>1+2+3+4+5+6+7+8+9+10+11`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1100"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QPL 1*12>1+2+3+4+5+6+7+8+9+10+11`, `ST`, "1100", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541150221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [11]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QPL 1*12>1+2+3+4+5+6+7+8+9+10+11"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1100]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QQP 1*1>2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628836", timeStamp: "1541150221", hash: "0xcb8bfdeb857f0e80b3ec20aa9e0fcb3cdec3bbe9aa6aa81134d8cf88e38199c9", nonce: "715", blockHash: "0xf66a5ed536f0611efb61aa5ed828cecf5b60299f51d15668af7a534da46dd7a6", transactionIndex: "42", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000898000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051515020312a313e322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4856595", gasUsed: "183354", confirmations: "1097175"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QQP 1*1>2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "2200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QQP 1*1>2+3+4+5+6+7+8+9+10+11+12`, `ST`, "2200", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541150221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [12]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QQP 1*1>2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [2200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[12], `QQP 1*1+2+3+4+5+6+7+8+... )", async function( ) {
		const txOriginal = {blockNumber: "6628838", timeStamp: "1541150235", hash: "0x73b55f8720ef78c95e9a405a4a2f424db547b5f991ceb6e4d922dd43c1538bac", nonce: "716", blockHash: "0x0154fc7b5aa07da4ef3edd11738ec103a55a20de3e4755555a0630b335d9f8fb", transactionIndex: "18", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb60000000000000000000000003ef6e4c4ad4f0013b9913e066179b38e1aaf8b5000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000003390000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002051515020312a312b322b332b342b352b362b372b382b392b31302b31312b313200000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "886069", gasUsed: "183354", confirmations: "1097173"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[12]}, {type: "string", name: "_betline", value: `QQP 1*1+2+3+4+5+6+7+8+9+10+11+12`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "13200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[12], `QQP 1*1+2+3+4+5+6+7+8+9+10+11+12`, `ST`, "13200", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541150235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [13]}}, {name: "_playerAddress", type: "address", value: "0x3ef6e4c4ad4f0013b9913e066179b38e1aaf8b50"}, {name: "_betline", type: "string", value: "QQP 1*1+2+3+4+5+6+7+8+9+10+11+12"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 4, c: [13200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[25], `W-P 1*1`, `ST`, \"200\... )", async function( ) {
		const txOriginal = {blockNumber: "6628838", timeStamp: "1541150235", hash: "0x2b7a84fc02cf3db5eaca858069ba5589677ce1e7356238435ca402d490bb06c2", nonce: "717", blockHash: "0x0154fc7b5aa07da4ef3edd11738ec103a55a20de3e4755555a0630b335d9f8fb", transactionIndex: "21", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb600000000000000000000000013af60631686e79599d214db2fe5e5a16184ce5d00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000c8000000000000000000000000000000000000000000000000000000005bddc60000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000007572d5020312a310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1211609", gasUsed: "176448", confirmations: "1097173"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[25]}, {type: "string", name: "_betline", value: `W-P 1*1`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "200"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[25], `W-P 1*1`, `ST`, "200", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541150235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [14]}}, {name: "_playerAddress", type: "address", value: "0x13af60631686e79599d214db2fe5e5a16184ce5d"}, {name: "_betline", type: "string", value: "W-P 1*1"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 2, c: [200]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[28] )", async function( ) {
		const txOriginal = {blockNumber: "6628923", timeStamp: "1541151693", hash: "0x87493824c61b26b5436c4ca9d1470040d8f73e987826ce4658dd4912068f88aa", nonce: "718", blockHash: "0x6a90b1271c3c39abd20e80be0491021975aae9435d17b92595b59af7aaace6b2", transactionIndex: "77", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9100000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000f76c73fd2f79dc2499b14d6e476ff3620b57364f", contractAddress: "", cumulativeGasUsed: "6228941", gasUsed: "76527", confirmations: "1097088"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[28]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[28], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541151693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xf76c73fd2f79dc2499b14d6e476ff3620b57364f"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[29] )", async function( ) {
		const txOriginal = {blockNumber: "6628991", timeStamp: "1541152600", hash: "0x74667300bf26f679d783533dcf9ef80db4883b95866b9cbd2c664393a2745891", nonce: "719", blockHash: "0x80545d4e511ec8a9f2d443d22b6c1d3289d8e1cd507c93a471192bfc7df24e9b", transactionIndex: "97", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000af6cbaa814b9772a231f0d956cac4ec689f980b6", contractAddress: "", cumulativeGasUsed: "6693170", gasUsed: "76527", confirmations: "1097020"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[29]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[29], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541152600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xaf6cbaa814b9772a231f0d956cac4ec689f980b6"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[30] )", async function( ) {
		const txOriginal = {blockNumber: "6628991", timeStamp: "1541152600", hash: "0x1b3599bea60278b73eb2a4f2373de33d58743956d421285c8c73b63b3b79d8ef", nonce: "720", blockHash: "0x80545d4e511ec8a9f2d443d22b6c1d3289d8e1cd507c93a471192bfc7df24e9b", transactionIndex: "98", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000008d79bd07b587288f97541508daae3fb6e0d02d4c", contractAddress: "", cumulativeGasUsed: "6769697", gasUsed: "76527", confirmations: "1097020"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[30]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541152600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x8d79bd07b587288f97541508daae3fb6e0d02d4c"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[23], `QQP 1*1+6`, `ST`, \"10... )", async function( ) {
		const txOriginal = {blockNumber: "6633680", timeStamp: "1541218765", hash: "0x96b214fc09625dffad25693be7558d37a918a01c6802e81570599771a0c0236a", nonce: "721", blockHash: "0x331037f2ff6ae56da0450a035fd9a770e262528f9db4aa611aeeed0f53b5fbcf", transactionIndex: "72", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb6000000000000000000000000940131019f29248dbd522e4d9ba1e5d1b043e13c00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000951515020312a312b36000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5653947", gasUsed: "176656", confirmations: "1092331"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[23]}, {type: "string", name: "_betline", value: `QQP 1*1+6`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "1000"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "1"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[23], `QQP 1*1+6`, `ST`, "1000", "1541260800", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541218765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [15]}}, {name: "_playerAddress", type: "address", value: "0x940131019f29248dbd522e4d9ba1e5d1b043e13c"}, {name: "_betline", type: "string", value: "QQP 1*1+6"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [1000]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "1"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: createLottery( addressList[23], `QQP 2*2+6`, `ST`, \"20... )", async function( ) {
		const txOriginal = {blockNumber: "6633691", timeStamp: "1541218887", hash: "0xde14eaf6016c16b5694f9e7fed20bda7fb44a54c2a74f14a4c1bf1aa2ad811d0", nonce: "722", blockHash: "0x4b72729e0c88c0da92e9bec63984b05a86589d5874a30cdbe619eb56140edf4d", transactionIndex: "18", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x840d7fb6000000000000000000000000940131019f29248dbd522e4d9ba1e5d1b043e13c00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000007d0000000000000000000000000000000000000000000000000000000005bddc6000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000951515020322a322b36000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025354000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1866049", gasUsed: "161656", confirmations: "1092320"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[23]}, {type: "string", name: "_betline", value: `QQP 2*2+6`}, {type: "string", name: "_place", value: `ST`}, {type: "uint32", name: "_betAmount", value: "2000"}, {type: "uint32", name: "_date", value: "1541260800"}, {type: "uint8", name: "_race", value: "2"}], name: "createLottery", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLottery(address,string,string,uint32,uint32,uint8)" ]( addressList[23], `QQP 2*2+6`, `ST`, "2000", "1541260800", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541218887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint32"}, {indexed: true, name: "_playerAddress", type: "address"}, {indexed: false, name: "_betline", type: "string"}, {indexed: false, name: "_place", type: "string"}, {indexed: false, name: "_betAmount", type: "uint32"}, {indexed: true, name: "_date", type: "uint32"}, {indexed: true, name: "_race", type: "uint8"}], name: "BuyLottery", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyLottery", events: [{name: "_id", type: "uint32", value: {s: 1, e: 1, c: [16]}}, {name: "_playerAddress", type: "address", value: "0x940131019f29248dbd522e4d9ba1e5d1b043e13c"}, {name: "_betline", type: "string", value: "QQP 2*2+6"}, {name: "_place", type: "string", value: "ST"}, {name: "_betAmount", type: "uint32", value: {s: 1, e: 3, c: [2000]}}, {name: "_date", type: "uint32", value: "0x000000000000000000000000000000000000000000000000000000005bddc600"}, {name: "_race", type: "uint8", value: "2"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[31] )", async function( ) {
		const txOriginal = {blockNumber: "6634147", timeStamp: "1541225649", hash: "0x6bdf9d1731af1746e1be1c0ba6859bf03825274701fac2c051c7e31219a5b27a", nonce: "723", blockHash: "0x36f22e7784fffaa8d5a6afc9869d7949309f8b4791192b126ed4dc252305de72", transactionIndex: "102", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000059685d654a6bfd6e10aa273c8709ff1d00cc42f7", contractAddress: "", cumulativeGasUsed: "7101994", gasUsed: "76463", confirmations: "1091864"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[31]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[31], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541225649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x59685d654a6bfd6e10aa273c8709ff1d00cc42f7"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[32] )", async function( ) {
		const txOriginal = {blockNumber: "6635904", timeStamp: "1541249827", hash: "0xc347da115a5f329e196644b5567ac259479f020e198554934d98c777a098c1e3", nonce: "724", blockHash: "0x96de1fdb8c8372830a6a0037f27ad4e5180320e32fe141ac4c150c9a719c5e31", transactionIndex: "142", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b000000000000000000000000cc9204edf789796bdc62543f4153489d5ea215e2", contractAddress: "", cumulativeGasUsed: "7248238", gasUsed: "76527", confirmations: "1090107"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[32]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[32], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541249827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0xcc9204edf789796bdc62543f4153489d5ea215e2"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[33] )", async function( ) {
		const txOriginal = {blockNumber: "6635904", timeStamp: "1541249827", hash: "0x43ce1e6730589a201871fc93d1053bb89fa47e646e22ba3a9e07e0c867e5fd1e", nonce: "725", blockHash: "0x96de1fdb8c8372830a6a0037f27ad4e5180320e32fe141ac4c150c9a719c5e31", transactionIndex: "143", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000007647fba07431782a8329f0ab25ddc1f2896b9c2d", contractAddress: "", cumulativeGasUsed: "7324765", gasUsed: "76527", confirmations: "1090107"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[33]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[33], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541249827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x7647fba07431782a8329f0ab25ddc1f2896b9c2d"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[34] )", async function( ) {
		const txOriginal = {blockNumber: "6636005", timeStamp: "1541251234", hash: "0xfa615321eb63a4ebeb8213fdce6115c2830c49c09ed63a39030bd0907b9f4b27", nonce: "726", blockHash: "0x14fe8e9645f5968aae5108041b01d60ced448e6a84052255bf095d0734b3f75a", transactionIndex: "195", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b00000000000000000000000062836b27edd124280ea2891be24f31bf3ae4fbbd", contractAddress: "", cumulativeGasUsed: "6242287", gasUsed: "76527", confirmations: "1090006"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[34]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[34], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541251234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x62836b27edd124280ea2891be24f31bf3ae4fbbd"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: joinClub( addressList[35] )", async function( ) {
		const txOriginal = {blockNumber: "6636225", timeStamp: "1541254149", hash: "0x309784c41cf57ae75ff0ade47c5972b65f63ca58b8f95adf28be25a2e44e0ade", nonce: "727", blockHash: "0x39c176720c6ddb826878364ebacf89634a05dab55bdf6003e8b73e97fb114e3a", transactionIndex: "103", from: "0x344a7c6ca361157d506c54e9f5c3df19d3354ec3", to: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2", value: "0", gas: "90000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1b49d82b0000000000000000000000007197e2b447db607034834aad089c4a1cc507f538", contractAddress: "", cumulativeGasUsed: "5376735", gasUsed: "76527", confirmations: "1089786"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_playerAddress", value: addressList[35]}], name: "joinClub", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinClub(address)" ]( addressList[35], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541254149 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_playerAddress", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_playerAddress", type: "address", value: "0x7197e2b447db607034834aad089c4a1cc507f538"}], address: "0x6851a80b7655e36e1f04e383b5946dafe9c63ab2"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3250500264471615616" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
