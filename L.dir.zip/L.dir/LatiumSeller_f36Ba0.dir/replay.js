var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "LatiumSeller"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x0174312e4Aef436606ffdEb4D05d22fB68f36Ba0","0xBb31037f997553BEc50510a635d231A35F8EC640","0xd2B8f17fA226992Bf5BCC36e3BE6f47f319fFAdd","0x937aB460b94655531073EADb9413874C343dA64E","0x47260348Ba90c56c9C058d3c42Db471cd585Ca7b","0x38043226EF8E8145555B46F763758824A70157c7","0x7172a45f7BdeA63Ba057f2AF5DE9CF2cD2ad2Bd9","0xEC050E9441A195b2c92eFbE517a560B085f740D2","0xC1D9c3ce04B1a3b8ED675464287A0E54770E402F","0x0B1a5768Cf12C5c4D1f007dec7020A1685179bAB","0xd68Fc6f433E170A92bf60d91e4A29286cd1B8Dd3","0x7e7ebf25E2Bc2f87d9bF9f19c2a719C8a8FE1efd","0x0Ed1e93dADDa274f066c7Acc92808887e91c7549","0xfA7301fC8Ec9A58190e81776dBd0763C9E07cB8E","0x34FB7c454750E72D0a127a5421b0cAb5297c5BAA","0x6850224A4993Eb927E4BE10c4134296737fee322","0xD11ffdBF62926f573237C47866c6eC36fb83DCE9","0xcD40D14786693Cf325279E8B18dCaCd2eAE293B5","0x44bc46350444bFAC4ae5162B81609Bc7E62d74B6","0xBBe82def1da2D334db09ea31c1781775a37797d1","0xA300E3aa8e5C53A93E598BA6E685a84A9cD1059c","0x374EFD41C9607f39B45beB7cA4dd9779EF58D211","0xADbb8611e35990d8A8490F4285DC9f82680997fF","0x03E7D38A76D478c6a9EDC2386FcD7e2983309b6C","0xb07374E0B2596ADA615A2d6823AA0dcCdA019D97","0x3F0B5A1b76447c9Af77a803De62B5216F5C8A517","0x365a44B5375DA308b9DCCcD078515369e0Abb587","0x80Fa3656cD2A3602896e492d6DbB3eac9A68BAcF","0x30b6eEAC8D12C5652bD5AA048f7C90B46F6f50aa","0x9386b171119ca01d1B39e24830AdB5152F72E924","0x16F5c45290f9ebC5496ea00613f38FAb8f246068","0x0ba1361eE9159FCfd3b81F0699892546184a2Bf1","0x05ea864f2401c5f7Cc746c433f0d70a2aA999cD5","0xf29c93ac59C4CAf5d24d6e1c779f9b35c4090Dd6","0xa206CDd62497eE6BB9F873b3e5bF38038f57C2fe","0xd1f032C30029791ebF369Aedcc7A1a7704bf2fD6","0x713B6a35bAA56aC1a53C3711d51fba812410D3D2","0xb7054F807dB12b1a778F7DCe988450BEBe3DD34f","0x2Fd5dB715292cbfd55828c31f815A72dB8E4138E"]
addressListOriginal.length = 41
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"tokenPrice","outputs":[{"name":"tokenPrice","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"minimumPurchase","outputs":[{"name":"minimumPurchase","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = []
eventSignatureListOriginal = []
topicListOriginal = []
nBlocksOriginal = 50
fromBlockOriginal = 4144576
toBlockOriginal = 4231103
constructorPrototypeOriginal = {"inputs":[],"name":"LatiumSeller","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4144576","blockHash":"0xbd83f49df548fb76feba3e08d9e1bd61d25d223ab52372f4088e246ae6522b30","timeStamp":"1502458883","hash":"0xd2801b715ab1e1cf80d1db363f97808e477eeea0ee9c2478a2b721cf315a8822","nonce":"0","transactionIndex":"93","from":"0xd2b8f17fa226992bf5bcc36e3be6f47f319ffadd","to":0,"value":"0","gas":"524241","gasPrice":"1000000000","input":"0xeb88e84d","contractAddress":"0x0174312e4aef436606ffdeb4d05d22fb68f36ba0","cumulativeGasUsed":"3640266","txreceipt_status":"","gasUsed":"424240","confirmations":"3556784","isError":"0"}
txOptions[0] = {"from":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"LatiumSeller","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
