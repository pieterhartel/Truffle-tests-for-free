const LunarToken = artifacts.require( "./LunarToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "LunarToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x43fb95c7afA1Ac1E721F33C695b2A0A94C7ddAb2", "0xdD9d7dc506A8F362df016fE67b95B18365bF0c16", "0x845E730a70aCA88595C2c2558bCDC04C56b9f986", "0x798435374D8615B6De18c87fE3efd9eC20600D45", "0x307c3Bab49b368a5eA321E34037E2a0A26d560aA", "0xf15e4c935c53115952d1712542d087935EbB23c6", "0x9C1430e6174b33c7460DD4AD808662b54a6083D5", "0x980F937Ad2Eaf2a35fE8bB55690378E4B65a4ae4", "0xC3cF18A57B5AD5b3916CBF4D986DA6D5C48a6b2B", "0x7cd15E2994192899cE9FbFc64C0a61Dc4f2329fF", "0x000450d853CB49099f10E02d0b92a4325461cbA1", "0x0031Fe1B496d4DFbda777a3E2270de73192008EA", "0x79D8FB221a4D4377E1Cad316Cf8348EC31e2f1ED", "0xcAA0D483d0D7f2EAaAc94D67b83672ae1d83D839", "0x0041EF94612F97fd37a31278C8879feBd40A25CE", "0x913C1bE1953ad441777a6C1534D7c2bFb0dE90d6", "0x35A80237Af795C23c5fa53464dA5e2a95dE4Be38"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numPlots", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalOwned", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "initialPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}, {name: "idx", type: "uint256"}], name: "tokensOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tradingEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalPurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plots", outputs: [{name: "owner", type: "address"}, {name: "price", type: "uint256"}, {name: "forSale", type: "bool"}, {name: "metadata", type: "string"}, {name: "disabled", type: "bool"}, {name: "subdivision", type: "uint8"}, {name: "parentID", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "subdivisionEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feePercentage", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "plotsOwned", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxSubdivisions", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "isUnowned", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "PriceChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newData", type: "string"}], name: "MetadataUpdated", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Purchase(address,uint256,uint256)", "PriceChanged(address,uint256,uint256)", "MetadataUpdated(address,uint256,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x12cb4648cf3058b17ceeb33e579f8b0bc269fe0843f3900b8e24b6c54871703c", "0x4d624906ce6fd4e4b8b649463516ff505029a1903a8cc34bd82b4ca0f9a479de", "0x09e9976d8c3e4d232147efa3e62e4af75ea58a39b0cdbc3f351d96fec3ed07d5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4395031 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4399000 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "_numPlots", value: "400"}, {type: "uint256", name: "_initialPriceInWei", value: "10000000000000000"}, {type: "uint8", name: "_feePercentage", value: "10"}, {type: "bool", name: "_tradingEnabled", value: true}, {type: "bool", name: "_subdivisionEnabled", value: false}, {type: "uint8", name: "_maxSubdivisions", value: "0"}], name: "LunarToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numPlots", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numPlots()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalOwned", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalOwned()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "initialPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "initialPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "idx", value: random.range( maxRandom )}], name: "tokensOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tradingEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tradingEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalPurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plots", outputs: [{name: "owner", type: "address"}, {name: "price", type: "uint256"}, {name: "forSale", type: "bool"}, {name: "metadata", type: "string"}, {name: "disabled", type: "bool"}, {name: "subdivision", type: "uint8"}, {name: "parentID", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plots(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "subdivisionEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "subdivisionEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feePercentage", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feePercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "plotsOwned", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plotsOwned(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxSubdivisions", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxSubdivisions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "isUnowned", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isUnowned(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "LunarToken", function( accounts ) {

	it( "TEST: LunarToken( \"400\", \"10000000000000000\", \"10\", ... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4395031", timeStamp: "1508494417", hash: "0xd00fc314a7877b2ee06195382f725e58447d5cfaa379db1572eb8a40e40d59d5", nonce: "3", blockHash: "0xedfc1614bb91fd93a67954ca9715a665961238f77fe6728d7cb31d29c77b0d90", transactionIndex: "44", from: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16", to: 0, value: "0", gas: "2625445", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x210cb4280000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", cumulativeGasUsed: "4854177", gasUsed: "2625445", confirmations: "3325822"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_numPlots", value: "400"}, {type: "uint256", name: "_initialPriceInWei", value: "10000000000000000"}, {type: "uint8", name: "_feePercentage", value: "10"}, {type: "bool", name: "_tradingEnabled", value: true}, {type: "bool", name: "_subdivisionEnabled", value: false}, {type: "uint8", name: "_maxSubdivisions", value: "0"}], name: "LunarToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = LunarToken.new( "400", "10000000000000000", "10", true, false, "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508494417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = LunarToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1624629984493076663" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"186\", ``, true, \"30000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396137", timeStamp: "1508509562", hash: "0xd90c3207507275017a7aad6032729225306a7348a29711d5662b16f564028818", nonce: "4", blockHash: "0xe7fac0ddd06cd84c54286979760a13644fb4915e91ed1f8e5e957f98dd03f149", transactionIndex: "157", from: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "253440", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000ba00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000006a94d74f4300000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5648279", gasUsed: "168960", confirmations: "3324716"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "186"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "30000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "186", ``, true, "30000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508509562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16"}, {name: "id", type: "uint256", value: "186"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1624629984493076663" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"113\", ``, true, \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396199", timeStamp: "1508510452", hash: "0x56c825bdda792deb1754227d55c063b9fdac760707fdf78bccfd80cfe3f52b8b", nonce: "5", blockHash: "0x8a438a4094e7f45c8b4f372d750f02d76a45f8837cae531e961becd58c9266c8", transactionIndex: "60", from: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000710000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2567800", gasUsed: "123960", confirmations: "3324654"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "113"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "50000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "113", ``, true, "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508510452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16"}, {name: "id", type: "uint256", value: "113"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1624629984493076663" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"134\", ``, true, \"40000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396378", timeStamp: "1508513442", hash: "0xd4d3b716b647275103720131d0cf7cb0808e0b66961182b6d07e4ac220e6512b", nonce: "0", blockHash: "0x7cf073730092cb0a087bad8c8f781fb09eb17a776830aa71626c43ae5d24deaf", transactionIndex: "140", from: "0x845e730a70aca88595c2c2558bcdc04c56b9f986", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208440", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000008600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000008e1bc9bf0400000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5557787", gasUsed: "138960", confirmations: "3324475"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "134"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "40000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "134", ``, true, "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508513442 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x845e730a70aca88595c2c2558bcdc04c56b9f986"}, {name: "id", type: "uint256", value: "134"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "39610400000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"215\", ``, true, \"20000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396545", timeStamp: "1508515639", hash: "0x74ef0203bc42f35fc4af790cd1689cdbb6c47beb075fee03b582411ba8fc83c4", nonce: "7", blockHash: "0x154df5f6acf19ceb8f6a5f6c49aa2d6467d647fecdec10e87e11c25e30ddd937", transactionIndex: "155", from: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000d70000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6581322", gasUsed: "123960", confirmations: "3324308"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "215"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "20000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "215", ``, true, "20000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508515639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16"}, {name: "id", type: "uint256", value: "215"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1624629984493076663" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"215\", addressList[5], `` )", async function( ) {
		const txOriginal = {blockNumber: "4396555", timeStamp: "1508515768", hash: "0x5651c8315885b30385c9d7109a8f33e3b7a451a86b3a38b32bdd1e2141c5ab7d", nonce: "8", blockHash: "0x93e01c637df200cd8a55dc339448a003bd5a7f145bc3a325ca51faff16188447", transactionIndex: "100", from: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "148059", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000d7000000000000000000000000798435374d8615b6de18c87fe3efd9ec20600d4500000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4180671", gasUsed: "83706", confirmations: "3324298"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "215"}, {type: "address", name: "newOwner", value: addressList[5]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "215", addressList[5], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508515768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdd9d7dc506a8f362df016fe67b95b18365bf0c16"}, {name: "_to", type: "address", value: "0x798435374d8615b6de18c87fe3efd9ec20600d45"}, {name: "id", type: "uint256", value: "215"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1624629984493076663" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", ``, true, \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396923", timeStamp: "1508520868", hash: "0xd784bbe114df845fba88a913519fc0706392dea741a630b4a27ef8bc82bb1961", nonce: "0", blockHash: "0x3051528e5152ee9eb905a9fe3e96d4b6349fde0ae7759cb74facde6538ecac5f", transactionIndex: "18", from: "0x307c3bab49b368a5ea321e34037e2a0a26d560aa", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185844", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1803951", gasUsed: "123896", confirmations: "3323930"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "50000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "0", ``, true, "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508520868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x307c3bab49b368a5ea321e34037e2a0a26d560aa"}, {name: "id", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1033761040000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396927", timeStamp: "1508520902", hash: "0xf603d0f3d283fe729b08c8d4a9656da4b7baed95e005538ce818e30aafbe054d", nonce: "0", blockHash: "0x1d1962cfbdffb6f3b97bfe827172185aeda5082da2a053027789d26b6bc6a62b", transactionIndex: "47", from: "0xf15e4c935c53115952d1712542d087935ebb23c6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208440", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1597382", gasUsed: "138960", confirmations: "3323926"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "1", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508520902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xf15e4c935c53115952d1712542d087935ebb23c6"}, {name: "id", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "494553739510034028" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396938", timeStamp: "1508521033", hash: "0xedc6e1d280ec97d05fe70abf238c9aca19ddd93179bc16a33eb791de5f17646c", nonce: "1", blockHash: "0xd63052ff54ce7b13874ccc21c041276bc57bad27dc3be328043999560303338d", transactionIndex: "29", from: "0xf15e4c935c53115952d1712542d087935ebb23c6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1157386", gasUsed: "123960", confirmations: "3323915"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "2", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508521033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xf15e4c935c53115952d1712542d087935ebb23c6"}, {name: "id", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "494553739510034028" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"188\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4396946", timeStamp: "1508521112", hash: "0xe108b243ac979419c9101b39b4ca8148723c03e5bee6564145919f8621f5f492", nonce: "2", blockHash: "0x12590661afb7d146012e368f218ed24efe538eb0291a4cccb2d5b7795d108c2b", transactionIndex: "25", from: "0xf15e4c935c53115952d1712542d087935ebb23c6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000bc00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "791804", gasUsed: "123960", confirmations: "3323907"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "188"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "188", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508521112 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xf15e4c935c53115952d1712542d087935ebb23c6"}, {name: "id", type: "uint256", value: "188"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "494553739510034028" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"208\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4397124", timeStamp: "1508523552", hash: "0x27509e4030847ca1527986062167b17c023d82b55c9b045abf334f449c852c18", nonce: "0", blockHash: "0x2d78762cf2e7521be16d156670d160f96ca366985681c98d31736969003d200f", transactionIndex: "96", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208440", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4139849", gasUsed: "138960", confirmations: "3323729"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "208"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "208", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508523552 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "id", type: "uint256", value: "208"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"208\", addressList[9], `` )", async function( ) {
		const txOriginal = {blockNumber: "4397140", timeStamp: "1508523699", hash: "0x703b4540ea0a9853339c5b078cbcd65009dfc63e11d0742b2da480b8dbb7d709", nonce: "1", blockHash: "0xac682e621ae46c5ebba8eff679aec7060a0829a83265e64c6ec34e7214bd08c0", transactionIndex: "42", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "146040", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000980f937ad2eaf2a35fe8bb55690378e4b65a4ae400000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1702118", gasUsed: "67360", confirmations: "3323713"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "208"}, {type: "address", name: "newOwner", value: addressList[9]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "208", addressList[9], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508523699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "_to", type: "address", value: "0x980f937ad2eaf2a35fe8bb55690378e4b65a4ae4"}, {name: "id", type: "uint256", value: "208"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"260\", ``, true, \"20000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4397172", timeStamp: "1508524104", hash: "0x878691bf01a1eb6a9670295a0a45025b2630990122968f6b2141cffbead2020b", nonce: "2", blockHash: "0xe57d8ed771b58556fa4192a377e50f06a4f419f76aa808cbe24ea7715f553dc7", transactionIndex: "159", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208536", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000001040000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5685644", gasUsed: "139024", confirmations: "3323681"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "260"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "20000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "260", ``, true, "20000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508524104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "id", type: "uint256", value: "260"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"260\", addressList[10], `` )", async function( ) {
		const txOriginal = {blockNumber: "4397181", timeStamp: "1508524217", hash: "0x9881954d192cd3c41d070c7cc8dce0cf714296a71011c2312cc947dac61f8258", nonce: "3", blockHash: "0x7fbe6f858d3bd4f6a5bda17063b433a86512aa6ca4ed5146f8d2edc052989236", transactionIndex: "148", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "146136", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe47459700000000000000000000000000000000000000000000000000000000000000104000000000000000000000000c3cf18a57b5ad5b3916cbf4d986da6d5c48a6b2b00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5049527", gasUsed: "67424", confirmations: "3323672"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "260"}, {type: "address", name: "newOwner", value: addressList[10]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "260", addressList[10], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508524217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "_to", type: "address", value: "0xc3cf18a57b5ad5b3916cbf4d986da6d5c48a6b2b"}, {name: "id", type: "uint256", value: "260"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"157\", ``, true, \"25000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4397187", timeStamp: "1508524302", hash: "0xc868314fda29ed0f60d5d275bdeb2e8adb0b581578c825c890f4a23007682e03", nonce: "4", blockHash: "0xb090537f7db4c93658c1e0b521f85f6cf98259eed04539f29a425e077cd29a3b", transactionIndex: "32", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208536", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000009d000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1256712", gasUsed: "139024", confirmations: "3323666"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "157"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "25000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "157", ``, true, "25000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508524302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "id", type: "uint256", value: "157"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"157\", addressList[11], `` )", async function( ) {
		const txOriginal = {blockNumber: "4397218", timeStamp: "1508524741", hash: "0x2185d7a9ad8a55b3f0f3b863a0d18e62e77c1397bc841b447eca5a68cad928b3", nonce: "5", blockHash: "0xdc3f2c6ecafb3adf1f260bb98c18609e0d1bf9bd911807786b90894cc8d26979", transactionIndex: "23", from: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "146040", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe4745970000000000000000000000000000000000000000000000000000000000000009d0000000000000000000000007cd15e2994192899ce9fbfc64c0a61dc4f2329ff00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1060576", gasUsed: "67360", confirmations: "3323635"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "157"}, {type: "address", name: "newOwner", value: addressList[11]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "157", addressList[11], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508524741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x9c1430e6174b33c7460dd4ad808662b54a6083d5"}, {name: "_to", type: "address", value: "0x7cd15e2994192899ce9fbfc64c0a61dc4f2329ff"}, {name: "id", type: "uint256", value: "157"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "65025648000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"163\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398723", timeStamp: "1508545029", hash: "0x14175c21400bb7a70971cf575fb7cbf6800819c50c1a752623e1bf346abcdfc0", nonce: "123", blockHash: "0xfc7e022653719834697c2face1d952530f7d1ed9db7bb22fdc3a76aae10445b2", transactionIndex: "48", from: "0x000450d853cb49099f10e02d0b92a4325461cba1", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208440", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000a300000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1692165", gasUsed: "138960", confirmations: "3322130"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "163"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "163", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508545029 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x000450d853cb49099f10e02d0b92a4325461cba1"}, {name: "id", type: "uint256", value: "163"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "316000000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setPrice( \"163\", true, \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398732", timeStamp: "1508545182", hash: "0xecdff57ba5e1b8e979acae731bc95847814375e0f998563d8b554e2b84a609fd", nonce: "124", blockHash: "0xaae02a89452d59872fd24abef6d076b2c63e39b8064074a9b2c51fd7851ca9c9", transactionIndex: "25", from: "0x000450d853cb49099f10e02d0b92a4325461cba1", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "154814", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb0c1adac00000000000000000000000000000000000000000000000000000000000000a300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "1277575", gasUsed: "36543", confirmations: "3322121"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "163"}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000000"}], name: "setPrice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPrice(uint256,bool,uint256)" ]( "163", true, "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508545182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PriceChanged", events: [{name: "_from", type: "address", value: "0x000450d853cb49099f10e02d0b92a4325461cba1"}, {name: "id", type: "uint256", value: "163"}, {name: "newPrice", type: "uint256", value: "10000000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "316000000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"261\", ``, true, \"1002000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398799", timeStamp: "1508546052", hash: "0xb3d771a4effb13afeeb2f7a7794f5f37cedd483d8e7620592a824b1632a5d198", nonce: "10", blockHash: "0x555bd63e1691f80e1455fd2679c763f094eff4ed598223a103a9619a4aa229a3", transactionIndex: "43", from: "0x0031fe1b496d4dfbda777a3e2270de73192008ea", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x07d525980000000000000000000000000000000000000000000000000000000000000105000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000056e8de91e1e2400000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2519355", gasUsed: "139152", confirmations: "3322054"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "261"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "100200000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "261", ``, true, "100200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508546052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0031fe1b496d4dfbda777a3e2270de73192008ea"}, {name: "id", type: "uint256", value: "261"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "141230328538378401" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"286\", ``, true, \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4398867", timeStamp: "1508546944", hash: "0x284a10d2bc60b7089996e1e4053065bd7f59bed4c87bb44ebd136222792e3769", nonce: "11", blockHash: "0x613ab639f872745882cdac7e87be0b5dc79595866272a0b1ad5dee5fe5aa56bd", transactionIndex: "16", from: "0x0031fe1b496d4dfbda777a3e2270de73192008ea", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000011e0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "939999", gasUsed: "108704", confirmations: "3321986"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "286"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "0"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "286", ``, true, "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508546944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0031fe1b496d4dfbda777a3e2270de73192008ea"}, {name: "id", type: "uint256", value: "286"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "141230328538378401" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"164\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398867", timeStamp: "1508546944", hash: "0xd666f2e7f4c244fb96ff7be8c55a8b386edc260e32ac36ec67dba44f0ccab588", nonce: "19", blockHash: "0x613ab639f872745882cdac7e87be0b5dc79595866272a0b1ad5dee5fe5aa56bd", transactionIndex: "24", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208536", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000a400000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1559706", gasUsed: "139024", confirmations: "3321986"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "164"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "164", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508546944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "164"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"165\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398875", timeStamp: "1508547067", hash: "0xe15f9ccec5677279f93de7ceae704167cc618a5dac690dd4eea039aa0dfc5838", nonce: "20", blockHash: "0xa49f55aaf59075a2f03bad7bea01fa77e9ea838d0f49fd27a517fb221ea7022d", transactionIndex: "33", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186036", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000a500000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "966494", gasUsed: "124024", confirmations: "3321978"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "165"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "165", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508547067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "165"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"165\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398875", timeStamp: "1508547067", hash: "0xfeb7ecadb0af228677dee8986e54548d0e2c963291f229ede54110abd1fd15de", nonce: "21", blockHash: "0xa49f55aaf59075a2f03bad7bea01fa77e9ea838d0f49fd27a517fb221ea7022d", transactionIndex: "69", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186036", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000a500000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3177020", gasUsed: "25364", confirmations: "3321978"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "165"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "165", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508547067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"189\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398880", timeStamp: "1508547136", hash: "0x55c69ec700bf6a24a7c7292cc34095e14f9b42b2d23e53b72f7c100fdd6ba519", nonce: "22", blockHash: "0x868b1c4e6c9e091b5043cf03745bd0a55491e1cae0e3833274603c20641d9a46", transactionIndex: "16", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186036", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000bd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1087737", gasUsed: "124024", confirmations: "3321973"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "189"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "189", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508547136 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "189"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"190\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398884", timeStamp: "1508547233", hash: "0xe94b42411515dd391bf81f1d3cf76900ab0f3da81c38f2f66121f1e1c950fea5", nonce: "23", blockHash: "0x9ffd94f5ba8cfb875c55d8852a6c0e269e3e3b5cd3ccb47e1159ebe8bf50f7aa", transactionIndex: "66", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186036", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000be00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5745782", gasUsed: "124024", confirmations: "3321969"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "190"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "190", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508547233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "190"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"166\", ``, true, \"2000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398890", timeStamp: "1508547318", hash: "0x2bf660b3f8a1e51cc47783906f7469d8184894fdfda546884f6ef8d7d059adc4", nonce: "24", blockHash: "0x5b7e6491f9a9b661ab7196a3bedf4322a039ee52adbef01eba7eca24e9f96838", transactionIndex: "78", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186132", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000a600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5135185", gasUsed: "124088", confirmations: "3321963"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "166"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "20000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "166", ``, true, "20000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508547318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "166"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"286\", ``, true, \"5000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398896", timeStamp: "1508547454", hash: "0xb8ee0b1afedf50439a5913a31dde733f64eff9e427268e49c389e0f7f6776023", nonce: "25", blockHash: "0x1171784304b9cb32343bbab626896f8f037bd305fbdaad51535d77cc91c5fca3", transactionIndex: "50", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "172471", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000011e000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1846531", gasUsed: "99981", confirmations: "3321957"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "286"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "5000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "286", ``, true, "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508547454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "286"}, {name: "price", type: "uint256", value: "0"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398905", timeStamp: "1508547551", hash: "0x02d79edfca471dc611e195b4eeac885d9541a16e016884223bb2eb49c5b6e741", nonce: "15", blockHash: "0x0a205a3128063015df6c69123b4bbeb753db9e5b2770d6b48cad7756058b8de3", transactionIndex: "37", from: "0xcaa0d483d0d7f2eaaac94d67b83672ae1d83d839", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "181320", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1440014", gasUsed: "105880", confirmations: "3321948"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "1", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508547551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xcaa0d483d0d7f2eaaac94d67b83672ae1d83d839"}, {name: "id", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"214\", ``, true, \"1500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398905", timeStamp: "1508547551", hash: "0x25c6fbd79bc22d67db2b35ce3e8b23bd3f868bedfa9483f64dddfc9e78d47859", nonce: "26", blockHash: "0x0a205a3128063015df6c69123b4bbeb753db9e5b2770d6b48cad7756058b8de3", transactionIndex: "44", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "186036", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x07d5259800000000000000000000000000000000000000000000000000000000000000d600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1882481", gasUsed: "124024", confirmations: "3321948"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "214"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "15000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "214", ``, true, "15000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508547551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "id", type: "uint256", value: "214"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398905", timeStamp: "1508547551", hash: "0x37c1c7673a91e79b2c4032e4099b0965a772eb4e3f784ca7cca3abd36e2aa8b8", nonce: "16", blockHash: "0x0a205a3128063015df6c69123b4bbeb753db9e5b2770d6b48cad7756058b8de3", transactionIndex: "55", from: "0xcaa0d483d0d7f2eaaac94d67b83672ae1d83d839", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "181320", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2520175", gasUsed: "90880", confirmations: "3321948"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "1", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508547551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0xcaa0d483d0d7f2eaaac94d67b83672ae1d83d839"}, {name: "id", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"24\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398927", timeStamp: "1508547852", hash: "0xa0518286d8504d3adb366c7e1df3ad309533162e12b99f3a6c34ccdf01d07ba9", nonce: "63", blockHash: "0x74ffe1d07ab3bd5da2ff06094a8a72cc9dc4d55b521b7167302573ea8c8577b1", transactionIndex: "33", from: "0x0041ef94612f97fd37a31278c8879febd40a25ce", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1676991", gasUsed: "138960", confirmations: "3321926"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "24"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "24", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508547852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0041ef94612f97fd37a31278c8879febd40a25ce"}, {name: "id", type: "uint256", value: "24"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1083519553932815049" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"24\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398927", timeStamp: "1508547852", hash: "0x5050d5e173dc72707bc7430fd0d30733b63b87c7dad202d5c70088b0f44cc6ec", nonce: "64", blockHash: "0x74ffe1d07ab3bd5da2ff06094a8a72cc9dc4d55b521b7167302573ea8c8577b1", transactionIndex: "34", from: "0x0041ef94612f97fd37a31278c8879febd40a25ce", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1767871", gasUsed: "90880", confirmations: "3321926"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "24"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "24", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508547852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0041ef94612f97fd37a31278c8879febd40a25ce"}, {name: "id", type: "uint256", value: "24"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1083519553932815049" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"24\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398929", timeStamp: "1508547870", hash: "0xe50f3f473dd3d160fb8db66c84d9e48f71476edf74bde900645d8b596017218c", nonce: "65", blockHash: "0x7a0971bd748d867129a13ba9e0c672776fb3d9d3c7aca703a21ab67c481e6192", transactionIndex: "28", from: "0x0041ef94612f97fd37a31278c8879febd40a25ce", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1335699", gasUsed: "90880", confirmations: "3321924"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "24"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "24", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508547870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0041ef94612f97fd37a31278c8879febd40a25ce"}, {name: "id", type: "uint256", value: "24"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1083519553932815049" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"13\", ``, true, \"10000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398933", timeStamp: "1508547962", hash: "0x17dd7162d1c1efe784a03706a565c8eb48d62bd1b4fbf17ae86fa9f681589636", nonce: "12", blockHash: "0x83de565cb412eebb411c726c71bb4a87f70a142e48f6adebd365b9f065c23990", transactionIndex: "40", from: "0x0031fe1b496d4dfbda777a3e2270de73192008ea", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4692021", gasUsed: "124088", confirmations: "3321920"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "13"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "100000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "13", ``, true, "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1508547962 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0031fe1b496d4dfbda777a3e2270de73192008ea"}, {name: "id", type: "uint256", value: "13"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "141230328538378401" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"300\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398942", timeStamp: "1508548037", hash: "0x5679da925b9d4c9c1d2d1b9acf2e9b815dbdb7dc5b9a317aeed6558e829fbf9c", nonce: "0", blockHash: "0x6a2f496ecf01a90f55eb3b49c205c8c2c8f4a6f63945f58b674720de6d72b5b0", transactionIndex: "14", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208536", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000012c00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "826928", gasUsed: "139024", confirmations: "3321911"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "300"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "300", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508548037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "300"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"300\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398943", timeStamp: "1508548049", hash: "0x11d18f6136f0897eb56301e683374b3ff91e13ddbb9f5d9fbf74b7641ed18d46", nonce: "1", blockHash: "0xf2a16dcc334dd2e0501f5b5ee0cc66dc1f264baf6616822d3b6e18cd15896eac", transactionIndex: "23", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "208536", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000012c00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2314286", gasUsed: "90944", confirmations: "3321910"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "300"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "300", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508548049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "300"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"45\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398947", timeStamp: "1508548074", hash: "0xf784d30b183fdff390d25a45de267da27f249df7a49500ea10b00df8b93cdc7f", nonce: "2", blockHash: "0x404650eb17ae9919f2d47916adb66facbd14b6cc8f9cd1e17e20835cccc96d70", transactionIndex: "16", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000002d00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1023574", gasUsed: "123960", confirmations: "3321906"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "45"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "45", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508548074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "45"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"166\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4398947", timeStamp: "1508548074", hash: "0xbb3a75c15606b46fc737e3d689421415487462453e238784b1f30649c4e53958", nonce: "27", blockHash: "0x404650eb17ae9919f2d47916adb66facbd14b6cc8f9cd1e17e20835cccc96d70", transactionIndex: "17", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "150078", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000a600000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1108626", gasUsed: "85052", confirmations: "3321906"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "166"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "166", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508548074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "166"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"52\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398947", timeStamp: "1508548074", hash: "0xc830bd2019856af60aa4ab634e2c5c4bd8127474aaf600b2fe00db8acec36f7a", nonce: "3", blockHash: "0x404650eb17ae9919f2d47916adb66facbd14b6cc8f9cd1e17e20835cccc96d70", transactionIndex: "19", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1325700", gasUsed: "123960", confirmations: "3321906"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "52"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "52", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508548074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "52"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"88\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398950", timeStamp: "1508548135", hash: "0x2404f4f3e6fc2d8073202366a7fbe4c167490b4e74e5ef2fd2f265ccc8535eb6", nonce: "4", blockHash: "0x19fa109b7a4c163de00809b78d2b8cc2fae5c40b06b72afb9ecb4ca7010b4f5d", transactionIndex: "44", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "185940", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000005800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4172810", gasUsed: "123960", confirmations: "3321903"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "88"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "88", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508548135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "88"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"262\", ``, true, \"1000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4398961", timeStamp: "1508548194", hash: "0x3b2b637690d468f8130819eb9932d23f69c7c271b4870564df99881ac45360de", nonce: "13", blockHash: "0x06fb0bccfa8e529df5dcca2686901a7cf445d1a8b5a0f473ab2ccaf0e2470f5e", transactionIndex: "9", from: "0x0031fe1b496d4dfbda777a3e2270de73192008ea", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "940000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07d525980000000000000000000000000000000000000000000000000000000000000106000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "652649", gasUsed: "124152", confirmations: "3321892"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "262"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "100000000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "262", ``, true, "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1508548194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Purchase", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Purchase", events: [{name: "_from", type: "address", value: "0x0031fe1b496d4dfbda777a3e2270de73192008ea"}, {name: "id", type: "uint256", value: "262"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "141230328538378401" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"888\", ``, true, \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398965", timeStamp: "1508548237", hash: "0x56089f3df92e54e85fa0ef26e2a0e316bdce9a2c0db1d8a3b1bbcbbd4dcd9276", nonce: "5", blockHash: "0x5e7147dc01b1b9652965cd927ead3d6bcb8417c8aa07f30571439b545056b903", transactionIndex: "110", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "10000000000000000", gas: "150000", gasPrice: "5000000000", isError: "0", txreceipt_status: "0", input: "0x07d52598000000000000000000000000000000000000000000000000000000000000037800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3398535", gasUsed: "23144", confirmations: "3321888"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "888"}, {type: "string", name: "metadata", value: ``}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "10000000000000000"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,string,bool,uint256)" ]( "888", ``, true, "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508548237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"164\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4398974", timeStamp: "1508548320", hash: "0x507d7b9d2d8dcb321c55c4d31b38362f0e67c0f4ae9edeb5d5efaf7b1c027f3d", nonce: "28", blockHash: "0x367b6f5f13a63fc15cbca4756887d1d75ba2ed6aaa5037838ccffae024801b2b", transactionIndex: "34", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "123540", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000a400000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1228395", gasUsed: "67360", confirmations: "3321879"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "164"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "164", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508548320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "164"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setPrice( \"52\", true, \"200000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398976", timeStamp: "1508548363", hash: "0xf5e13e05a5135fa8cb92975c40692238a4baf7eef4f3bb62c53a6a13dafca399", nonce: "6", blockHash: "0x71a3d37de8a5503539994a539eb2b7222864209658e138b73744626977d458d4", transactionIndex: "25", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "54910", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb0c1adac0000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000ad78ebc5ac6200000", contractAddress: "", cumulativeGasUsed: "1157246", gasUsed: "36607", confirmations: "3321877"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "52"}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "200000000000000000000"}], name: "setPrice", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPrice(uint256,bool,uint256)" ]( "52", true, "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508548363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PriceChanged", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "52"}, {name: "newPrice", type: "uint256", value: "200000000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"165\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4398977", timeStamp: "1508548390", hash: "0x54ebd2c43268bcaf0e4595366f0cb9d2589ad07be48127af71712e40b8776295", nonce: "29", blockHash: "0xe6dbffdae0b68de639f0a510a2510b700f13cb2b0b23b84902c08667ae2c6837", transactionIndex: "36", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "124549", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000a500000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1014787", gasUsed: "68033", confirmations: "3321876"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "165"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "165", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508548390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "165"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setPrice( \"52\", true, \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398978", timeStamp: "1508548396", hash: "0x20d7034e8ef806ac5d4293e28a490bff134ece1c2a2e47973b868772e1d925ab", nonce: "7", blockHash: "0x2a88cf7925a7ae8fde124ed61854056707570c657c6721632c78b06328227e23", transactionIndex: "10", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "54910", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb0c1adac00000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "421519", gasUsed: "36607", confirmations: "3321875"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "52"}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "50000000000000000000"}], name: "setPrice", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPrice(uint256,bool,uint256)" ]( "52", true, "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508548396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PriceChanged", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "52"}, {name: "newPrice", type: "uint256", value: "50000000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"190\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4398984", timeStamp: "1508548459", hash: "0xce9b6b51c28099e8c520a20dda117f05cbca1428f0706d900769c3361cf17022", nonce: "30", blockHash: "0xecd2bed5e14e8cbda1d498ad489afec47e2c0bf25025a35b89f312e3f1640e0b", transactionIndex: "35", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "126568", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000be00000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1968691", gasUsed: "69379", confirmations: "3321869"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "190"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "190", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508548459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "190"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"189\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4398990", timeStamp: "1508548515", hash: "0x5e7f557180b968042023b089af14e2f158751bac8cec90608ab8572b8707bd32", nonce: "31", blockHash: "0x4b7cfe722a24a383422ce018175fbfe5b4cf3b9f71570efaadb07f928a7d8868", transactionIndex: "43", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "125559", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000bd00000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3010801", gasUsed: "68706", confirmations: "3321863"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "189"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "189", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508548515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "189"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setPrice( \"88\", true, \"88000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4398990", timeStamp: "1508548515", hash: "0xa02885e27fec6a179c065f80faf727a03dd3f07eb9546f808210fd88f951b474", nonce: "8", blockHash: "0x4b7cfe722a24a383422ce018175fbfe5b4cf3b9f71570efaadb07f928a7d8868", transactionIndex: "50", from: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "54910", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb0c1adac00000000000000000000000000000000000000000000000000000000000000580000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000004c53ecdc18a600000", contractAddress: "", cumulativeGasUsed: "3201322", gasUsed: "36607", confirmations: "3321863"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "88"}, {type: "bool", name: "forSale", value: true}, {type: "uint256", name: "newPrice", value: "88000000000000000000"}], name: "setPrice", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPrice(uint256,bool,uint256)" ]( "88", true, "88000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508548515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PriceChanged", events: [{name: "_from", type: "address", value: "0x913c1be1953ad441777a6c1534d7c2bfb0de90d6"}, {name: "id", type: "uint256", value: "88"}, {name: "newPrice", type: "uint256", value: "88000000000000000000"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3526097979206026" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( \"214\", addressList[18], `` )", async function( ) {
		const txOriginal = {blockNumber: "4399000", timeStamp: "1508548610", hash: "0xfe9ecc8ec27bc8c1c266b51d23bb43876b94daa4cc964413705fa475070d6fc6", nonce: "32", blockHash: "0x00481b6cec060cc12074179e8e85d045b7c71473f340e784f1ef917e2c7d4dbd", transactionIndex: "31", from: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed", to: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2", value: "0", gas: "124549", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe474597000000000000000000000000000000000000000000000000000000000000000d600000000000000000000000035a80237af795c23c5fa53464da5e2a95de4be3800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "917772", gasUsed: "68033", confirmations: "3321853"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "214"}, {type: "address", name: "newOwner", value: addressList[18]}, {type: "string", name: "newData", value: ``}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(uint256,address,string)" ]( "214", addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508548610 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "id", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79d8fb221a4d4377e1cad316cf8348ec31e2f1ed"}, {name: "_to", type: "address", value: "0x35a80237af795c23c5fa53464da5e2a95de4be38"}, {name: "id", type: "uint256", value: "214"}], address: "0x43fb95c7afa1ac1e721f33c695b2a0a94c7ddab2"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
