const Luckyblock = artifacts.require( "./Luckyblock.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Luckyblock" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x448E0209610A9064C776Ae0255AD71ef49D58d0A", "0x35d415bF0E6bbf8e10ebA814e10325c46a2CF009", "0x56bA2703c08986BA42F4758A9C4A335a8fF3C95d", "0x7ca121b093e2FbD4bB9A894bD5Ff487d16f1F83b", "0x533A99a1292C7ddB74621BF288F50fa34D42C79E", "0xEb3C8aAD671d0244FE9cF2CC668685342dA82ca9", "0xEAccFf287f8E596070e3178B4d280693D40eCC4B", "0xD14454406601Ef37C9f1e3b5e9386204aB572eE6", "0xbCDa642138D621c07902F08cB61C8f765bAA51be", "0x7f755135B92355182f6796014De9669e141A9252", "0x84733f3Ed69B6200f2225bFf43A0494F90DeA3b1", "0xf8f4C79dA4b700F905F70DccdaCbb02fB38ecdd9", "0x41c93A11f3B688d286e4FF5159d9667fc3238F76", "0x349B4A1eDa8361Ff7B93c1cDb467dc00067438ca", "0x43Be2D9455D1aBd6e981E4fb4c70645FE72310E1", "0x53AD9B8acC73e90e371C4A4B46464D12E5dd4536", "0xb51694051d0294EccDa91b62B05c7637B5bF348B", "0xC5594619ef50c77735cF08AE5Df37F15d98C3597", "0x992ac25E30dcf717602068cb6c3eFA8Ce0e575E9"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getLuckyblockIds", outputs: [{name: "", type: "bytes32[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "checkRole", outputs: [], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "luckyblockId", type: "bytes32"}], name: "getLuckyblockSpend", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "luckyblockIds", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "hasRole", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "luckyblockId", type: "bytes32"}], name: "getLuckyblockEarn", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "int256[]"}, {name: "", type: "uint256"}, {name: "", type: "int256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "isSuperuser", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "luckyblockId", type: "bytes32"}], name: "getLuckyblockBase", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ROLE_SUPERUSER", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "contractAddress", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "count", type: "uint256"}], name: "WithdrawToken", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "to", type: "address"}, {indexed: false, name: "count", type: "uint256"}], name: "WithdrawEth", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Pay", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Play(bytes32,address,uint8)", "WithdrawToken(address,address,uint256)", "WithdrawEth(address,uint256)", "Pay(address,uint256)", "Pause()", "Unpause()", "RoleAdded(address,string)", "RoleRemoved(address,string)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1009100be547b15253a834b07028268987e77a9111d95d8c973ffdc19a374604", "0x037238854fe57fbf51f09946f854fc3916fe83938d6521f09bd05463839f1304", "0xccbd99ba6da8f29b2a4f65e474e3c3973564d356c162c08d45f3dc7f0cb5b3aa", "0x357b676c439b9e49b4410f8eb8680bee4223724802d8e3fd422e1756f87b475f", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0xbfec83d64eaa953f2708271a023ab9ee82057f8f3578d548c1a4ba0b5b700489", "0xd211483f91fc6eff862467f8de606587a30c8fc9981056f051b897a418df803a", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6973112 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6973726 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Luckyblock", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getLuckyblockIds", outputs: [{name: "", type: "bytes32[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLuckyblockIds()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "checkRole", outputs: [], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getLuckyblockSpend", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLuckyblockSpend(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "luckyblockIds", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "luckyblockIds(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "hasRole", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getLuckyblockEarn", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "int256[]"}, {name: "", type: "uint256"}, {name: "", type: "int256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLuckyblockEarn(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isSuperuser", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isSuperuser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getLuckyblockBase", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLuckyblockBase(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ROLE_SUPERUSER", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ROLE_SUPERUSER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Luckyblock", function( accounts ) {

	it( "TEST: Luckyblock(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6973112", timeStamp: "1546075101", hash: "0xa5294c95847deb5dc73c958ba83480061c0ff56d2442a82c686d5c66f710ea0b", nonce: "143", blockHash: "0xb66d5b6ae44a85721dbdb39da13c890cf37c218943b14fbe667d13b54f3d8259", transactionIndex: "28", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: 0, value: "0", gas: "2430444", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2eac12dc", contractAddress: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", cumulativeGasUsed: "3413024", gasUsed: "2430444", confirmations: "700651"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Luckyblock", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Luckyblock.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1546075101 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Luckyblock.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoleAdded", events: [{name: "operator", type: "address", value: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009"}, {name: "role", type: "string", value: "superuser"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[0,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addLuckyblock( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6973127", timeStamp: "1546075344", hash: "0xed8ad57ddb18c0def7d4b9e9bf2cd62245ee6064eaa5fb56bd237b8c645506d9", nonce: "144", blockHash: "0x92206c75d9379eb7b8abccb99a2d7f5e8da26b64101b365a9ac7caebfcbfebed", transactionIndex: "104", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "68591", gasPrice: "4001000000", isError: "0", txreceipt_status: "1", input: "0xbd7173dd0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7709435", gasUsed: "68591", confirmations: "700636"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seed", value: "1"}], name: "addLuckyblock", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addLuckyblock(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1546075344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockSpend( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973140", timeStamp: "1546075565", hash: "0xfea43c53e75061b9922b0963dc8bfc8e16df2bea36792def273d37af507800ba", nonce: "145", blockHash: "0xd37e0eb59ee7d806a61ee8394d972b93472a3c21c6d07bd5b799ca16f677bd5f", transactionIndex: "41", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "77444", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x5b7dc56a51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7057736", gasUsed: "77444", confirmations: "700623"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {type: "address[]", name: "spendTokenAddresses", value: [addressList[0]]}, {type: "uint256[]", name: "spendTokenCount", value: []}, {type: "uint256", name: "spendEtherCount", value: "50000000000000000"}], name: "updateLuckyblockSpend", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockSpend(bytes32,address[],uint256[],uint256)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", [addressList[0]], [], "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1546075565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockEarn( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973145", timeStamp: "1546075695", hash: "0x6cc125b9be777c087ea50483621bdac36323ca9d53017e72314a4dd01225a886", nonce: "146", blockHash: "0x7da78bb39831a80e1e3dbfae5bcb4eacb08a98d16175f1f9ceb3c9dee544a243", transactionIndex: "144", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "191099", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccd09af51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000100000000000000000000000056ba2703c08986ba42f4758a9c4a335a8ff3c95d000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "7999888", gasUsed: "191099", confirmations: "700618"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {type: "address[]", name: "earnTokenAddresses", value: [addressList[4]]}, {type: "uint256[]", name: "earnTokenCount", value: ["2000000000000000000000"]}, {type: "int256[]", name: "earnTokenProbability", value: ["100"]}, {type: "uint256", name: "earnEtherCount", value: "50000000000000000"}, {type: "int256", name: "earnEtherProbability", value: "50"}], name: "updateLuckyblockEarn", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockEarn(bytes32,address[],uint256[],int256[],uint256,int256)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", [addressList[4]], ["2000000000000000000000"], ["100"], "50000000000000000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1546075695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addLuckyblock( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6973236", timeStamp: "1546076840", hash: "0xbe00dc606da6ee8bc6c7edc6812a868f2539fa05451d52fb54ef6cc8196c89e2", nonce: "147", blockHash: "0xc4858978c175c3b9e8120b80a290aa0c8b04f1ac1b1917219f2a77065b4b59ca", transactionIndex: "170", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "53591", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xbd7173dd0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6655833", gasUsed: "53591", confirmations: "700527"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seed", value: "2"}], name: "addLuckyblock", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addLuckyblock(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1546076840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6973238", timeStamp: "1546076872", hash: "0x07bf7ce9424bb6ccb8561f46309117e05b49529b4c9691b7098a22d9353825d4", nonce: "148", blockHash: "0xcf53fb92f141dc0dfa32903e9ed82828b3c219f7272004aaba599bffccbf42a8", transactionIndex: "72", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "2000000000000000000", gas: "33567", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4553424", gasUsed: "22378", confirmations: "700525"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1546076872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Pay", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Pay", events: [{name: "from", type: "address", value: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009"}, {name: "value", type: "uint256", value: "2000000000000000000"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockEarn( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973253", timeStamp: "1546077170", hash: "0x8e772af1b019db469b0a889081a2cb4d8ddba1e930a52e778714604a6f62ff13", nonce: "149", blockHash: "0x9571859b55f655472a24cc2e6430f6f2a903ee3844d6a8f1f74061c2b13111f7", transactionIndex: "52", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "71099", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccd09af51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000010000000000000000000000007ca121b093e2fbd4bb9a894bd5ff487d16f1f83b000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "2930882", gasUsed: "71099", confirmations: "700510"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {type: "address[]", name: "earnTokenAddresses", value: [addressList[5]]}, {type: "uint256[]", name: "earnTokenCount", value: ["2000000000000000000000"]}, {type: "int256[]", name: "earnTokenProbability", value: ["100"]}, {type: "uint256", name: "earnEtherCount", value: "50000000000000000"}, {type: "int256", name: "earnEtherProbability", value: "50"}], name: "updateLuckyblockEarn", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockEarn(bytes32,address[],uint256[],int256[],uint256,int256)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", [addressList[5]], ["2000000000000000000000"], ["100"], "50000000000000000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1546077170 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockSpend( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973315", timeStamp: "1546078141", hash: "0x0960b5b19fee5acb6144397b9d2f4433bc4481950a972f0f022e49efb056d078", nonce: "150", blockHash: "0xc02d4a99eca140916508cfbfeffaac2d80ec0d439f621b7ccd1274fa5707e11c", transactionIndex: "119", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "129483", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x5b7dc56ae09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000001ff973cafa800000000000000000000000000000000000000000000000000000000000000000010000000000000000000000007ca121b093e2fbd4bb9a894bd5ff487d16f1f83b000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000001043561a8829300000", contractAddress: "", cumulativeGasUsed: "6834514", gasUsed: "129483", confirmations: "700448"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {type: "address[]", name: "spendTokenAddresses", value: [addressList[5]]}, {type: "uint256[]", name: "spendTokenCount", value: ["300000000000000000000"]}, {type: "uint256", name: "spendEtherCount", value: "9000000000000000"}], name: "updateLuckyblockSpend", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockSpend(bytes32,address[],uint256[],uint256)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", [addressList[5]], ["300000000000000000000"], "9000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1546078141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockEarn( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973318", timeStamp: "1546078159", hash: "0xd2f80e20efd4179f03ba83965cec53fba739dc3c64e61350c83963b9dd4a107f", nonce: "151", blockHash: "0xb0929b06b99d46416d2e065fea73d1f97927fdaf8bde19bc970aa6d8412bda7a", transactionIndex: "119", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "103621", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccd09afe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b37100000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000006a94d74f430000000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4885069", gasUsed: "103621", confirmations: "700445"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {type: "address[]", name: "earnTokenAddresses", value: [addressList[0]]}, {type: "uint256[]", name: "earnTokenCount", value: []}, {type: "int256[]", name: "earnTokenProbability", value: []}, {type: "uint256", name: "earnEtherCount", value: "30000000000000000"}, {type: "int256", name: "earnEtherProbability", value: "30"}], name: "updateLuckyblockEarn", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockEarn(bytes32,address[],uint256[],int256[],uint256,int256)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", [addressList[0]], [], [], "30000000000000000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1546078159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addLuckyblock( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6973322", timeStamp: "1546078234", hash: "0x38125d34028a047ce09fb7c1b5d7f50bd1a10e508f71e16e6c8e88b1daeaaf1b", nonce: "152", blockHash: "0x121d62aca3f680941df0e3313d1580597ed91f5e99f750c59393e79b147000b6", transactionIndex: "70", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "53591", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xbd7173dd0000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3158098", gasUsed: "53591", confirmations: "700441"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seed", value: "3"}], name: "addLuckyblock", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addLuckyblock(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1546078234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockSpend( \"0x373d9d0e67c4b14cc422edaa728d93287b0b... )", async function( ) {
		const txOriginal = {blockNumber: "6973327", timeStamp: "1546078313", hash: "0x6ab97fe4db1db9e23b9f77d5ce6dc13abd39db154bf89fd631ca4734f16d139f", nonce: "153", blockHash: "0x9a310cb80ba60eba50d12c190e3b8eeb77d7cf452f15a41067b903dbf633cdc7", transactionIndex: "47", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "129547", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x5b7dc56a373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000001ff973cafa800000000000000000000000000000000000000000000000000000000000000000010000000000000000000000007ca121b093e2fbd4bb9a894bd5ff487d16f1f83b000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5405460", gasUsed: "129547", confirmations: "700436"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}, {type: "address[]", name: "spendTokenAddresses", value: [addressList[5]]}, {type: "uint256[]", name: "spendTokenCount", value: ["1000000000000000000000"]}, {type: "uint256", name: "spendEtherCount", value: "9000000000000000"}], name: "updateLuckyblockSpend", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockSpend(bytes32,address[],uint256[],uint256)" ]( "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", [addressList[5]], ["1000000000000000000000"], "9000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1546078313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: updateLuckyblockEarn( \"0x373d9d0e67c4b14cc422edaa728d93287b0b... )", async function( ) {
		const txOriginal = {blockNumber: "6973331", timeStamp: "1546078374", hash: "0xaaa6ac64ddeaba54d167aca3f0e10ec20fd1102c4118fdc0e39c74663fdac167", nonce: "154", blockHash: "0xebf26530e653667e1b1cf63a134d3f561dd159adb9517cb98d2e28c5fc28e04d", transactionIndex: "83", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "103685", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccd09af373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000b1a2bc2ec5000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4602860", gasUsed: "103685", confirmations: "700432"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}, {type: "address[]", name: "earnTokenAddresses", value: [addressList[0]]}, {type: "uint256[]", name: "earnTokenCount", value: []}, {type: "int256[]", name: "earnTokenProbability", value: []}, {type: "uint256", name: "earnEtherCount", value: "50000000000000000"}, {type: "int256", name: "earnEtherProbability", value: "22"}], name: "updateLuckyblockEarn", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateLuckyblockEarn(bytes32,address[],uint256[],int256[],uint256,int256)" ]( "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", [addressList[0]], [], [], "50000000000000000", "22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1546078374 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973370", timeStamp: "1546078993", hash: "0x89df329eba6503d6fe696cc8606fafb963657d755f5021a1606008ef5eb0fd07", nonce: "155", blockHash: "0x181b3d8515d19d40bf0983560a66b45af192c982f9a28ea28fa1c9a35a192b87", transactionIndex: "145", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "51622", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7916266", gasUsed: "51622", confirmations: "700393"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973376", timeStamp: "1546079116", hash: "0x24c34d78cc3b01c57193614cd0cab74736701fe57d5bd5c5b8b823b6bc83a365", nonce: "156", blockHash: "0x3dd6eb739a4374c5ad3650e05a8ab2069f7bd50d87df47e02c588ae09c5a506f", transactionIndex: "58", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "0", gas: "3000000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4727966", gasUsed: "25194", confirmations: "700387"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1546079116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973381", timeStamp: "1546079186", hash: "0x44785de65c85acac398c4827bc9697582a807788b9109f51f3640b63b3f1a47a", nonce: "157", blockHash: "0x252089d7e271718bdb0416f129530e41464333fedef1df365b60c4e95231e361", transactionIndex: "33", from: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "159929", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "1821573", gasUsed: "51622", confirmations: "700382"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1546079186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x35d415bf0e6bbf8e10eba814e10325c46a2cf009"}, {name: "random", type: "uint8", value: "32"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3626837182151420362" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973517", timeStamp: "1546081104", hash: "0xda2a3e5a9626366ac0fcbce79a2cfb96996d8958463ca75705a1aa3e16df14f2", nonce: "134", blockHash: "0xdbd9d551d914fb07aef7b7d0aec9b225fad6e058fcfc7bfec94622696be572ba", transactionIndex: "55", from: "0x533a99a1292c7ddb74621bf288f50fa34d42c79e", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4231738", gasUsed: "59419", confirmations: "700246"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1546081104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x533a99a1292c7ddb74621bf288f50fa34d42c79e"}, {name: "random", type: "uint8", value: "60"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "10028251614033318596" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973528", timeStamp: "1546081270", hash: "0xf34f7f9b72757667ad8c6d3dc3ca8ae762f253221b9bcc9be5061e69137064a4", nonce: "136", blockHash: "0x20a2f8cb7483bdf4f0a9daedaf1793976d81dc105435995ee61d61dcaa3406f2", transactionIndex: "101", from: "0x533a99a1292c7ddb74621bf288f50fa34d42c79e", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7569517", gasUsed: "60820", confirmations: "700235"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1546081270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x533a99a1292c7ddb74621bf288f50fa34d42c79e"}, {name: "random", type: "uint8", value: "25"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "10028251614033318596" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x373d9d0e67c4b14cc422edaa728d93287b0b... )", async function( ) {
		const txOriginal = {blockNumber: "6973545", timeStamp: "1546081550", hash: "0xaaad5bdc56c7ee22503e2c2bc8659a667e45713a7867f244b0e34d8384525542", nonce: "6", blockHash: "0xe4052df52540ca541f5fed4471fbe19be695b93e2145dd2f8ec97b41bf9a99ef", transactionIndex: "133", from: "0xeb3c8aad671d0244fe9cf2cc668685342da82ca9", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", contractAddress: "", cumulativeGasUsed: "3589581", gasUsed: "60884", confirmations: "700218"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1546081550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}, {name: "user", type: "address", value: "0xeb3c8aad671d0244fe9cf2cc668685342da82ca9"}, {name: "random", type: "uint8", value: "21"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "4520833335296000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973574", timeStamp: "1546081963", hash: "0x139f67add724d3a62e5b080e9414c019c387aa441b405630f9c4266a92a403f6", nonce: "38", blockHash: "0xcf46202ae3380091f239f303cecaba5d9f88b659a21d5a37e7b10951ce7b1477", transactionIndex: "53", from: "0xeaccff287f8e596070e3178b4d280693d40ecc4b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "6509119", gasUsed: "59419", confirmations: "700189"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1546081963 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0xeaccff287f8e596070e3178b4d280693d40ecc4b"}, {name: "random", type: "uint8", value: "92"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "6770987207757199" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973594", timeStamp: "1546082298", hash: "0x22bab100b2545b28b4c22afc55e9e643a5a652b55b9d9cc4649d10b8deaf76ff", nonce: "40", blockHash: "0x42a65506b268b5c8e1ae7936d7c1c5baefc96f5330def44bd64827c44065bb88", transactionIndex: "55", from: "0xd14454406601ef37c9f1e3b5e9386204ab572ee6", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4153798", gasUsed: "59419", confirmations: "700169"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1546082298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0xd14454406601ef37c9f1e3b5e9386204ab572ee6"}, {name: "random", type: "uint8", value: "96"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "4391070478635536" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973615", timeStamp: "1546082596", hash: "0x6994b5807f3ad7c7f3b776dcd8bb72bfae5484c8d64a96acc4395da460b42f04", nonce: "14", blockHash: "0x59bb798af7b1a06a9fcf74504197053af72b25916cd81ad2cc4d08c3af433d21", transactionIndex: "79", from: "0xbcda642138d621c07902f08cb61c8f765baa51be", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "4650203", gasUsed: "60820", confirmations: "700148"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1546082596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xbcda642138d621c07902f08cb61c8f765baa51be"}, {name: "random", type: "uint8", value: "13"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "48755661354891767" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973616", timeStamp: "1546082625", hash: "0x6451668241c21592870c86f2287f4e113685db84d852f124505948177f084e18", nonce: "22", blockHash: "0x796816af87d0d8c0b834774a246a7ef12c6583e33c0d0278305cbd6a20e90933", transactionIndex: "126", from: "0x7f755135b92355182f6796014de9669e141a9252", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7830543", gasUsed: "51622", confirmations: "700147"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1546082625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x7f755135b92355182f6796014de9669e141a9252"}, {name: "random", type: "uint8", value: "2"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "75636028292733184" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973640", timeStamp: "1546082938", hash: "0x3b6c13c6bf8b04bcbfe40f20f9c06df86e066346afd8d8086bdad83095e19eb5", nonce: "3", blockHash: "0x0308662cfd5e2a74d13d495d6b8d1ea80ddff81b5980a715350d3a4e3ed565a8", transactionIndex: "141", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "6075136", gasUsed: "59419", confirmations: "700123"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1546082938 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "90"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973656", timeStamp: "1546083266", hash: "0x31ebb9405487636ec4887d8c09ee96be044c268c78b7796acc7cb80dbb5c0dc6", nonce: "22", blockHash: "0x9a988202c4c0403f667e7966244389571799b0c1eea0235a5133aa84ac180caa", transactionIndex: "199", from: "0xf8f4c79da4b700f905f70dccdacbb02fb38ecdd9", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7798164", gasUsed: "60820", confirmations: "700107"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1546083266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xf8f4c79da4b700f905f70dccdacbb02fb38ecdd9"}, {name: "random", type: "uint8", value: "3"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x373d9d0e67c4b14cc422edaa728d93287b0b... )", async function( ) {
		const txOriginal = {blockNumber: "6973656", timeStamp: "1546083266", hash: "0x2dba0ebe614ea07caa899f278b29757e4dbee40e4314aada2c35f54b125a0fc7", nonce: "290", blockHash: "0x9a988202c4c0403f667e7966244389571799b0c1eea0235a5133aa84ac180caa", transactionIndex: "201", from: "0x41c93a11f3b688d286e4ff5159d9667fc3238f76", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", contractAddress: "", cumulativeGasUsed: "7910744", gasUsed: "60884", confirmations: "700107"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1546083266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}, {name: "user", type: "address", value: "0x41c93a11f3b688d286e4ff5159d9667fc3238f76"}, {name: "random", type: "uint8", value: "3"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2091005920769664" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973659", timeStamp: "1546083344", hash: "0x9c8cc751dbf838db67f806e2cfe82bdc6622aaee5f4ed8ac19f3de93f871f674", nonce: "57", blockHash: "0x03733d4a89ce574a83de5fa6f60b9bce1648fa37bad28e7979e37bbbd5f909dc", transactionIndex: "149", from: "0x349b4a1eda8361ff7b93c1cdb467dc00067438ca", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2020000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7324923", gasUsed: "60820", confirmations: "700104"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1546083344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x349b4a1eda8361ff7b93c1cdb467dc00067438ca"}, {name: "random", type: "uint8", value: "35"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "3487445002623537" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973663", timeStamp: "1546083392", hash: "0xb138cc9138aa3913928afbead00c54e130d7a5954763282d7cb8dd47bf687b39", nonce: "291", blockHash: "0xbe9c2e2ea645de7ba1f582d0226881aed0a33319cda8132d077aacb7b0e02111", transactionIndex: "136", from: "0x41c93a11f3b688d286e4ff5159d9667fc3238f76", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7204483", gasUsed: "29312", confirmations: "700100"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1546083392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2091005920769664" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973663", timeStamp: "1546083392", hash: "0x1703ecc964853c5dcc24aa8e5e277706c99b175f4d04131d04777d10aa55afad", nonce: "4", blockHash: "0xbe9c2e2ea645de7ba1f582d0226881aed0a33319cda8132d077aacb7b0e02111", transactionIndex: "140", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7468528", gasUsed: "51622", confirmations: "700100"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1546083392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "22"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973663", timeStamp: "1546083392", hash: "0xbdfc75b0c679531a0fef0777f6635ed51d05b1de7ae67b63e52c32e7fafff995", nonce: "292", blockHash: "0xbe9c2e2ea645de7ba1f582d0226881aed0a33319cda8132d077aacb7b0e02111", transactionIndex: "141", from: "0x41c93a11f3b688d286e4ff5159d9667fc3238f76", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7520150", gasUsed: "51622", confirmations: "700100"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1546083392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x41c93a11f3b688d286e4ff5159d9667fc3238f76"}, {name: "random", type: "uint8", value: "22"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2091005920769664" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973671", timeStamp: "1546083472", hash: "0x2d583d640cdc50c954eb93e1ef65f055fa7367e983b099de2bb72b6703479826", nonce: "5", blockHash: "0x62925c932d99bdb5dbf8c85cce7999a55332d282de85867f67284796b9379c67", transactionIndex: "17", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "6051741", gasUsed: "59419", confirmations: "700092"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1546083472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "73"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x373d9d0e67c4b14cc422edaa728d93287b0b... )", async function( ) {
		const txOriginal = {blockNumber: "6973687", timeStamp: "1546083756", hash: "0xdbe45f1098306dccf7eadba9420b4829c0c17b4a5d8dd12853532fcaa675b527", nonce: "23", blockHash: "0x33417f7c3ce5aefd74c591f183122c13d87c46f62ce5fc4c23a833db95c32e42", transactionIndex: "49", from: "0xf8f4c79da4b700f905f70dccdacbb02fb38ecdd9", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", contractAddress: "", cumulativeGasUsed: "2313891", gasUsed: "60884", confirmations: "700076"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1546083756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x373d9d0e67c4b14cc422edaa728d93287b0b2bbfed2e4673666f6da128b589bd"}, {name: "user", type: "address", value: "0xf8f4c79da4b700f905f70dccdacbb02fb38ecdd9"}, {name: "random", type: "uint8", value: "57"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973688", timeStamp: "1546083769", hash: "0x00f2647fbc5351b0c392cd4912af8c1d1a85f9739f2dfea3b11a679d188364a7", nonce: "6", blockHash: "0x43d95dc08b27f96e6017b8b55df86e65f47bb64c900832e5550d3280aeea78f2", transactionIndex: "83", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "5279368", gasUsed: "51622", confirmations: "700075"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1546083769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "10"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973688", timeStamp: "1546083769", hash: "0x06531af0fb14d08da61ab245027b5f4c616bcba9303bea4fae3d13b7830a061b", nonce: "7", blockHash: "0x43d95dc08b27f96e6017b8b55df86e65f47bb64c900832e5550d3280aeea78f2", transactionIndex: "142", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7845717", gasUsed: "51622", confirmations: "700075"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1546083769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "10"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973696", timeStamp: "1546083894", hash: "0x486129d91dd4042f11becc24393b9070374a62d3a3deb54f44b134401c763dfb", nonce: "43", blockHash: "0x2f77573a098d69938c0080a1189ef463e3861dbfb5072b17146d6f6bb1fb2603", transactionIndex: "106", from: "0x43be2d9455d1abd6e981e4fb4c70645fe72310e1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7862283", gasUsed: "51622", confirmations: "700067"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1546083894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x43be2d9455d1abd6e981e4fb4c70645fe72310e1"}, {name: "random", type: "uint8", value: "42"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "137915822633791982" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973698", timeStamp: "1546083929", hash: "0x2bb357c698c989532dcdeef358a435272c7beb9455b325ffdf47cfbe4e770f1b", nonce: "4", blockHash: "0x4566dd2e221401de205ee9550c302c57d5cddc0c2f758f2bf2897497592d527f", transactionIndex: "157", from: "0x53ad9b8acc73e90e371c4a4b46464d12e5dd4536", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7715640", gasUsed: "60820", confirmations: "700065"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1546083929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x53ad9b8acc73e90e371c4a4b46464d12e5dd4536"}, {name: "random", type: "uint8", value: "35"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "795256407528448" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973700", timeStamp: "1546083956", hash: "0x37d588d55435fac0abc5dea881e46f5baadbf18e4cea36cc712c2777d303023c", nonce: "379", blockHash: "0x0acafe8e8fc5c3c093a1227834c16bc358bc3eab88b618b306c7d02cd320b71f", transactionIndex: "134", from: "0xb51694051d0294eccda91b62b05c7637b5bf348b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "4539580", gasUsed: "68617", confirmations: "700063"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1546083956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xb51694051d0294eccda91b62b05c7637b5bf348b"}, {name: "random", type: "uint8", value: "70"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4767562179910862" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973704", timeStamp: "1546083993", hash: "0x8c02627874a8e73535ec71a4639beff019c05ed0c744f0a4fad11ff2b92a514b", nonce: "8", blockHash: "0x72f3f3dd8f0af3744b94461efbf53814b9166bae67c38b66aa6b63fc2e5dba15", transactionIndex: "139", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "6553721", gasUsed: "51622", confirmations: "700059"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1546083993 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "1"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973706", timeStamp: "1546084017", hash: "0xc57924079bbbe1677db18826057611e73519b22c0de8c9a489fa3456615dbe77", nonce: "9", blockHash: "0x354b36ec4f296b6aa056eefdf2362dda42814b474a421251fce89c905aa77eed", transactionIndex: "94", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4041641", gasUsed: "51622", confirmations: "700057"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1546084017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "37"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973707", timeStamp: "1546084038", hash: "0xd7c54ae57c1c9c4c9153dfaab089aece8f5e716c0ef044aec6c77d1bd4527ac5", nonce: "103", blockHash: "0x993428ceaa70b268971c13d214b6c5de9e3d9fc5799385ec9a2e1a6b6ffbf2b1", transactionIndex: "104", from: "0xc5594619ef50c77735cf08ae5df37f15d98c3597", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "5138146", gasUsed: "60820", confirmations: "700056"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1546084038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xc5594619ef50c77735cf08ae5df37f15d98c3597"}, {name: "random", type: "uint8", value: "20"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "93144107713738" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973709", timeStamp: "1546084084", hash: "0x0342ce4ee243ebc919e65bab4c78aea32cc02c2b36da2bde536a6404f4bc12fd", nonce: "104", blockHash: "0xd2b1bfdc5fff7be604247a408ab1f74c40622a6d9e0cdbf3880516a2b43b9b48", transactionIndex: "76", from: "0x992ac25e30dcf717602068cb6c3efa8ce0e575e9", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "3180422", gasUsed: "68617", confirmations: "700054"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1546084084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x992ac25e30dcf717602068cb6c3efa8ce0e575e9"}, {name: "random", type: "uint8", value: "77"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "24909395598414397" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973709", timeStamp: "1546084084", hash: "0xe2806e1191116582a717825eb47d5a2b31cb5ce179e43b321fedf79102584cff", nonce: "380", blockHash: "0xd2b1bfdc5fff7be604247a408ab1f74c40622a6d9e0cdbf3880516a2b43b9b48", transactionIndex: "150", from: "0xb51694051d0294eccda91b62b05c7637b5bf348b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7181986", gasUsed: "68617", confirmations: "700054"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1546084084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xb51694051d0294eccda91b62b05c7637b5bf348b"}, {name: "random", type: "uint8", value: "77"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4767562179910862" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973710", timeStamp: "1546084089", hash: "0x95fff09d88c4a098a4825eb8846bef75e96cd7074d1bbff50ad3185f17443c3b", nonce: "381", blockHash: "0x7f6d85ed448521036cc156577303d82a5dc57e289dc8f6e901325c0e7bd3f5c4", transactionIndex: "69", from: "0xb51694051d0294eccda91b62b05c7637b5bf348b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7750772", gasUsed: "68617", confirmations: "700053"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1546084089 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0xb51694051d0294eccda91b62b05c7637b5bf348b"}, {name: "random", type: "uint8", value: "91"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4767562179910862" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973712", timeStamp: "1546084114", hash: "0x1a42f66c6fed7fe4a4a98f6adea0d2e487cb9d4833965a7cadd7299ce60ad810", nonce: "5", blockHash: "0xbd66c70ca8ab4f101073f720877858b08ed18811e3c1f4fb4a518681a1858a71", transactionIndex: "67", from: "0x53ad9b8acc73e90e371c4a4b46464d12e5dd4536", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "3309548", gasUsed: "60820", confirmations: "700051"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1546084114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x53ad9b8acc73e90e371c4a4b46464d12e5dd4536"}, {name: "random", type: "uint8", value: "31"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "795256407528448" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973712", timeStamp: "1546084114", hash: "0x3bf02d2d36e905b1f29b2439b5753029e24cec9a3761a28375c8f28a90d30e2a", nonce: "10", blockHash: "0xbd66c70ca8ab4f101073f720877858b08ed18811e3c1f4fb4a518681a1858a71", transactionIndex: "127", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "5980355", gasUsed: "51622", confirmations: "700051"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1546084114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "31"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973712", timeStamp: "1546084114", hash: "0xfcda136d79354614e3ea3ec669e9c87bfe2dca479088c85a80269bf355bc93b5", nonce: "44", blockHash: "0xbd66c70ca8ab4f101073f720877858b08ed18811e3c1f4fb4a518681a1858a71", transactionIndex: "134", from: "0x43be2d9455d1abd6e981e4fb4c70645fe72310e1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "7080950", gasUsed: "60820", confirmations: "700051"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1546084114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x43be2d9455d1abd6e981e4fb4c70645fe72310e1"}, {name: "random", type: "uint8", value: "31"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "137915822633791982" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0xe09de4bca130cfa57702f65069de3b996680... )", async function( ) {
		const txOriginal = {blockNumber: "6973714", timeStamp: "1546084137", hash: "0x88450b8a847d647bb7bc9184b8fd40c5e57d6ce4a49b59bfc9e7a9e66cef8a47", nonce: "105", blockHash: "0x6e32cc813c9325e0a25b03834dba550f42afdef50de9f04b0a6e5788f6b66f5c", transactionIndex: "117", from: "0x992ac25e30dcf717602068cb6c3efa8ce0e575e9", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "9000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865be09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", contractAddress: "", cumulativeGasUsed: "4811956", gasUsed: "60820", confirmations: "700049"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "9000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1546084137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0xe09de4bca130cfa57702f65069de3b996680c59565977c0092b27a5f8ea3b371"}, {name: "user", type: "address", value: "0x992ac25e30dcf717602068cb6c3efa8ce0e575e9"}, {name: "random", type: "uint8", value: "25"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "24909395598414397" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973714", timeStamp: "1546084137", hash: "0x4e82c2548d480e8836b0dd25c92053d37baa4ac56ea74cf0a279ee6c9e986f64", nonce: "11", blockHash: "0x6e32cc813c9325e0a25b03834dba550f42afdef50de9f04b0a6e5788f6b66f5c", transactionIndex: "119", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4915094", gasUsed: "51622", confirmations: "700049"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1546084137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "25"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973718", timeStamp: "1546084179", hash: "0xafd3b75afd6a5aa3036a095791301ae699ee0d13c9c4dddb3c1bca5085a2e319", nonce: "12", blockHash: "0xa89f0f82fd68888bb7e4ed1774e11162fb8da1547b08cb5c0f5faf030fe4fdb4", transactionIndex: "126", from: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4616898", gasUsed: "59419", confirmations: "700045"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1546084179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0x84733f3ed69b6200f2225bff43a0494f90dea3b1"}, {name: "random", type: "uint8", value: "58"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "21596585243100009" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973718", timeStamp: "1546084179", hash: "0x08e6ff85fe632e8898b4a053784522ad0dac8d0e2777608e1669163b6b517e8f", nonce: "382", blockHash: "0xa89f0f82fd68888bb7e4ed1774e11162fb8da1547b08cb5c0f5faf030fe4fdb4", transactionIndex: "127", from: "0xb51694051d0294eccda91b62b05c7637b5bf348b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "4676317", gasUsed: "59419", confirmations: "700045"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1546084179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0xb51694051d0294eccda91b62b05c7637b5bf348b"}, {name: "random", type: "uint8", value: "58"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4767562179910862" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"0x51582105545ee275f426635555f6690899a8... )", async function( ) {
		const txOriginal = {blockNumber: "6973726", timeStamp: "1546084342", hash: "0x612d94de2160d7c8773404ca2dd3ca4bd4016bc8d7984d5ef6babea69b5f2258", nonce: "383", blockHash: "0x946108f5fb7b34f0bf03ecb7ad6fb94ada991fe1af0aef4e9e530ce4f16731c2", transactionIndex: "300", from: "0xb51694051d0294eccda91b62b05c7637b5bf348b", to: "0x448e0209610a9064c776ae0255ad71ef49d58d0a", value: "50000000000000000", gas: "139999", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0xc7a1865b51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", contractAddress: "", cumulativeGasUsed: "7432429", gasUsed: "51622", confirmations: "700037"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "luckyblockId", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(bytes32)" ]( "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1546084342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "luckyblockId", type: "bytes32"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "random", type: "uint8"}], name: "Play", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Play", events: [{name: "luckyblockId", type: "bytes32", value: "0x51582105545ee275f426635555f6690899a826cd5694bf413fd3374836a4039f"}, {name: "user", type: "address", value: "0xb51694051d0294eccda91b62b05c7637b5bf348b"}, {name: "random", type: "uint8", value: "27"}], address: "0x448e0209610a9064c776ae0255ad71ef49d58d0a"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4767562179910862" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
