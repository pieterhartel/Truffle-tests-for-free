const LuckyoneGuess = artifacts.require( "./LuckyoneGuess.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "LuckyoneGuess" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x79BDe2574D61f2Bdbfe4C333A594FbBA3C99E122", "0xCBb490F8034d0A4591c677865863dD50A89014Ed"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "guessType", type: "uint256"}, {name: "period", type: "uint256"}], name: "getResult", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "master", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = [] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = [] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6487122 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6492412 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "LuckyoneGuess", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "guessType", value: random.range( maxRandom )}, {type: "uint256", name: "period", value: random.range( maxRandom )}], name: "getResult", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getResult(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "master", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "master()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "LuckyoneGuess", function( accounts ) {

	it( "TEST: LuckyoneGuess(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6487122", timeStamp: "1539150008", hash: "0x9975564ce6d0972c12b096dbaebd257b92f19d6cbf12d4fb914cf47fafa2424c", nonce: "0", blockHash: "0x8c657cea8e7d86d628c1613e7eaa9f87057a324fc65d403c78c0a5f6135bb250", transactionIndex: "203", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: 0, value: "0", gas: "453529", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x090a5936", contractAddress: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", cumulativeGasUsed: "7533438", gasUsed: "353529", confirmations: "1254308"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "LuckyoneGuess", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = LuckyoneGuess.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1539150008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = LuckyoneGuess.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"1\", \"723700557733226221397318... )", async function( ) {
		const txOriginal = {blockNumber: "6487541", timeStamp: "1539155800", hash: "0x20b480ce73ff4c0b60b2e135ff2b9b069195448c28ea9669ed7fcabe67003e3d", nonce: "1", blockHash: "0x1f8b3c6d84d7f4251f0b02939bc6a55bd2db3717aeab5c8f66ad31d08c8895d0", transactionIndex: "58", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "44463", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "2377972", gasUsed: "44079", confirmations: "1253889"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "1"}, {type: "uint256", name: "seed", value: "7237005577332262213973186563042994240829374041602535252466099000494570602497"}, {type: "uint256", name: "maxNumber", value: "100"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "1", "7237005577332262213973186563042994240829374041602535252466099000494570602497", "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1539155800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000001\", \"9048147\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489465", timeStamp: "1539182887", hash: "0x2c62c78e70efe834a430c651114c33235cf882c23f40c6fe3f16d5595da93b90", nonce: "2", blockHash: "0x09010153157e4e81d6e79b5cb7744ff1cd319b2693a45ffe90c69fb87f2b3851", transactionIndex: "77", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144100000000000000000000000000000000000000000000000000000000008a10530000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3576987", gasUsed: "44463", confirmations: "1251965"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000001"}, {type: "uint256", name: "seed", value: "9048147"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000001", "9048147", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1539182887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000001\", \"4671266\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489465", timeStamp: "1539182887", hash: "0x89dd1a52cbf9b5aabacbf5a6b7061447e9e29d74159049196353653994b57fc5", nonce: "3", blockHash: "0x09010153157e4e81d6e79b5cb7744ff1cd319b2693a45ffe90c69fb87f2b3851", transactionIndex: "78", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4100000000000000000000000000000000000000000000000000000000004747220000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3621450", gasUsed: "44463", confirmations: "1251965"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000001"}, {type: "uint256", name: "seed", value: "4671266"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000001", "4671266", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1539182887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101010000001\", \"9726435\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489465", timeStamp: "1539182887", hash: "0xa854a334c0595f937450f054772947deb30331ed138ee28e8d3af2c486e71fa8", nonce: "4", blockHash: "0x09010153157e4e81d6e79b5cb7744ff1cd319b2693a45ffe90c69fb87f2b3851", transactionIndex: "79", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767845688100000000000000000000000000000000000000000000000000000000009469e30000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3665913", gasUsed: "44463", confirmations: "1251965"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101010000001"}, {type: "uint256", name: "seed", value: "9726435"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101010000001", "9726435", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1539182887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000002\", \"1540507\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489477", timeStamp: "1539183100", hash: "0xaf28311325af1f5d8cef2df17a1bdbd59360b59f96e251fc27565022a0f33fea", nonce: "5", blockHash: "0x404bcf1347946743b376c02fc7017924532a588b12bbcd9271d728fcd82623f7", transactionIndex: "19", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12748237772", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc1442000000000000000000000000000000000000000000000000000000000017819b0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "841784", gasUsed: "44463", confirmations: "1251953"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000002"}, {type: "uint256", name: "seed", value: "1540507"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000002", "1540507", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1539183100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000002\", \"7238882\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489480", timeStamp: "1539183186", hash: "0x4401bf7748e9c42ead8c1eea194ebbf3b4a94d0ca51d15166cf1483dc63c0719", nonce: "6", blockHash: "0xbed1ce72822e8b20b92e5d2f7065acb02773cf36d1098afec82a77a482770613", transactionIndex: "102", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4200000000000000000000000000000000000000000000000000000000006e74e20000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3912293", gasUsed: "44463", confirmations: "1251950"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000002"}, {type: "uint256", name: "seed", value: "7238882"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000002", "7238882", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1539183186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"20\", \"18101020000001\", \"2873113\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489483", timeStamp: "1539183213", hash: "0x011e10f9b52854663c6e3d80f3ac0e81e533ed368ce0378b836c402897b0f92a", nonce: "7", blockHash: "0x0e438cd3d73f79599c0eaf8a6f3ed6c4da4c4ff0123e08d2e2769dfba15edceb", transactionIndex: "33", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000107678ddff0100000000000000000000000000000000000000000000000000000000002bd7190000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2055812", gasUsed: "44463", confirmations: "1251947"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "20"}, {type: "uint256", name: "period", value: "18101020000001"}, {type: "uint256", name: "seed", value: "2873113"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "20", "18101020000001", "2873113", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1539183213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000003\", \"7098738\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489486", timeStamp: "1539183245", hash: "0x003bce2475fdcf2b5e3765191b9a2e373db7b8f9ebe3dd96af7a7fcb720f46ea", nonce: "8", blockHash: "0xf66a584c473baeb74bfecfdf6af24fab650952459a2fc1cbd659019d7b95d6fa", transactionIndex: "52", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144300000000000000000000000000000000000000000000000000000000006c51720000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2617968", gasUsed: "44463", confirmations: "1251944"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000003"}, {type: "uint256", name: "seed", value: "7098738"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000003", "7098738", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1539183245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000004\", \"9745489\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489497", timeStamp: "1539183458", hash: "0x00da056b8590488d8f67567fff5bfd9ff51187bb18d5823d719cf3107ee78063", nonce: "9", blockHash: "0xee166024d9343980ffce8346c9ec64afb0d30fce7c59eab9607dc34a676550e7", transactionIndex: "104", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc1444000000000000000000000000000000000000000000000000000000000094b4510000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "5058343", gasUsed: "44463", confirmations: "1251933"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000004"}, {type: "uint256", name: "seed", value: "9745489"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000004", "9745489", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1539183458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101010000002\", \"9056737\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489499", timeStamp: "1539183498", hash: "0x802d515c70ea9076f8c86dd60bd73ab8909400049ec5ec0b0994bcbf2a6abc42", nonce: "10", blockHash: "0xc9fb6e371b3cca073be0564345b64ed18a78a62f4dcd69a4824451cc179584c6", transactionIndex: "21", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767845688200000000000000000000000000000000000000000000000000000000008a31e10000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "980814", gasUsed: "44463", confirmations: "1251931"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101010000002"}, {type: "uint256", name: "seed", value: "9056737"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101010000002", "9056737", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1539183498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000003\", \"4003033\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489499", timeStamp: "1539183498", hash: "0xc113186b9852b1e33ea90669ad1fd5f284056c08094ff40edf4d6a27caf49702", nonce: "11", blockHash: "0xc9fb6e371b3cca073be0564345b64ed18a78a62f4dcd69a4824451cc179584c6", transactionIndex: "22", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4300000000000000000000000000000000000000000000000000000000003d14d90000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1025277", gasUsed: "44463", confirmations: "1251931"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000003"}, {type: "uint256", name: "seed", value: "4003033"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000003", "4003033", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1539183498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000005\", \"1440222\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489504", timeStamp: "1539183608", hash: "0xd45b29167a4615763ab2d2bf277ef5481f3af96ac0c8d3ddcd461ac99a1b9e8a", nonce: "12", blockHash: "0xaf4ab1415d9761a18519b0e9feaef97c986ddf9b1883d7bd0db3b5336fc0043c", transactionIndex: "128", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc1445000000000000000000000000000000000000000000000000000000000015f9de0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3474731", gasUsed: "44463", confirmations: "1251926"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000005"}, {type: "uint256", name: "seed", value: "1440222"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000005", "1440222", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1539183608 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000006\", \"6293170\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489515", timeStamp: "1539183802", hash: "0x23f1f3642b3fe4075a1235671a2d4658a0b5141f0abe9c56a71e1e5c41135918", nonce: "13", blockHash: "0x0bf35ddd394a71ca74cdf0c8e783b87cf1602ff9c76163dce4ad2236456206df", transactionIndex: "45", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144600000000000000000000000000000000000000000000000000000000006006b20000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2128550", gasUsed: "44463", confirmations: "1251915"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000006"}, {type: "uint256", name: "seed", value: "6293170"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000006", "6293170", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1539183802 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000004\", \"1954763\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489515", timeStamp: "1539183802", hash: "0xf2285c2116b748d0785d41684fc1ad2d5b91a8a86b9b7cf6e6c8156e0f334804", nonce: "14", blockHash: "0x0bf35ddd394a71ca74cdf0c8e783b87cf1602ff9c76163dce4ad2236456206df", transactionIndex: "102", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4400000000000000000000000000000000000000000000000000000000001dd3cb0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "7547645", gasUsed: "44463", confirmations: "1251915"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000004"}, {type: "uint256", name: "seed", value: "1954763"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000004", "1954763", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1539183802 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"50\", \"18101050000001\", \"869443\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489518", timeStamp: "1539183827", hash: "0x823e563e0a0a81cf66078a12c51a9a0f537c4300c4270ba9e762f56f5e15e31c", nonce: "15", blockHash: "0x9a1de9705812b65d2ccbf5a0bea778f6ae6ede05b5e7ce0d9a1468232e1fce4f", transactionIndex: "38", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000010767aa7c28100000000000000000000000000000000000000000000000000000000000d44430000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2013207", gasUsed: "44463", confirmations: "1251912"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "50"}, {type: "uint256", name: "period", value: "18101050000001"}, {type: "uint256", name: "seed", value: "869443"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "50", "18101050000001", "869443", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1539183827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000007\", \"1150091\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489529", timeStamp: "1539183969", hash: "0x4c167ece38a96a7bf4d7a7cc62bfaf4ee5481fad1fc79709f79540678cf71405", nonce: "16", blockHash: "0x4d5848959a026397f9d6f0d78142944ea804ce0ccccd695f91b572b9febcdad1", transactionIndex: "36", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc14470000000000000000000000000000000000000000000000000000000000118c8b0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "1370890", gasUsed: "44463", confirmations: "1251901"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000007"}, {type: "uint256", name: "seed", value: "1150091"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000007", "1150091", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1539183969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101010000003\", \"4065357\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489540", timeStamp: "1539184093", hash: "0xb2cc8aeed4efab041098f3fdbb90e7d9a1ea7ad1399f86d8b5b6e306fb65bbc2", nonce: "17", blockHash: "0xc04239a53f6b9a3819a45d7a5a17128df6e2f6b78bc9e59c5b2fb0493ed26557", transactionIndex: "77", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767845688300000000000000000000000000000000000000000000000000000000003e084d0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3409940", gasUsed: "44463", confirmations: "1251890"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101010000003"}, {type: "uint256", name: "seed", value: "4065357"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101010000003", "4065357", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1539184093 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000005\", \"8055455\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489540", timeStamp: "1539184093", hash: "0xb626e0adfa724884182dd7d5b45187a4efde945dbd624a0de1e8d3b592c7f022", nonce: "18", blockHash: "0xc04239a53f6b9a3819a45d7a5a17128df6e2f6b78bc9e59c5b2fb0493ed26557", transactionIndex: "78", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4500000000000000000000000000000000000000000000000000000000007aea9f0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3454403", gasUsed: "44463", confirmations: "1251890"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000005"}, {type: "uint256", name: "seed", value: "8055455"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000005", "8055455", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1539184093 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000008\", \"1888459\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489547", timeStamp: "1539184190", hash: "0x33bfc0722222c87e94880b2448cb88dd89170cb38156ab0eac41d77983460c66", nonce: "19", blockHash: "0xd4d2f6dd70ea8d36dea57929aaa5eb32f05044abaf5295113e59c96e021265fe", transactionIndex: "59", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144800000000000000000000000000000000000000000000000000000000001cd0cb0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3298118", gasUsed: "44463", confirmations: "1251883"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000008"}, {type: "uint256", name: "seed", value: "1888459"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000008", "1888459", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1539184190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000009\", \"5810104\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489559", timeStamp: "1539184380", hash: "0x8c3d64f6f3fa334689bf59d379898eed17d4e51a07d375d14f8e65dd84683e7a", nonce: "20", blockHash: "0x0ca952f4218b001387ff6b142b32a92ecfcb4aad466991ad83b833d86cf02c65", transactionIndex: "79", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "17100000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc1449000000000000000000000000000000000000000000000000000000000058a7b80000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4407940", gasUsed: "44463", confirmations: "1251871"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000009"}, {type: "uint256", name: "seed", value: "5810104"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000009", "5810104", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1539184380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000006\", \"4605423\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489561", timeStamp: "1539184428", hash: "0x593fcda6abef2545c3d75f91a95f70f9d2cfbb5185ecd4d20584c02303de972c", nonce: "21", blockHash: "0xfbcf02ec714e18cab57a1800351ea66a80c0635286626a63a9fa5bed6a82ba8d", transactionIndex: "42", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4600000000000000000000000000000000000000000000000000000000004645ef0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1866974", gasUsed: "44463", confirmations: "1251869"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000006"}, {type: "uint256", name: "seed", value: "4605423"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000006", "4605423", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1539184428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"20\", \"18101020000002\", \"1352896\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489561", timeStamp: "1539184428", hash: "0xeb1b48e794c1f32ef2a9d41529395ba92e9ab67e0b75adf5dd1f9d9fe48d1afb", nonce: "22", blockHash: "0xfbcf02ec714e18cab57a1800351ea66a80c0635286626a63a9fa5bed6a82ba8d", transactionIndex: "43", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000107678ddff02000000000000000000000000000000000000000000000000000000000014a4c00000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1911437", gasUsed: "44463", confirmations: "1251869"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "20"}, {type: "uint256", name: "period", value: "18101020000002"}, {type: "uint256", name: "seed", value: "1352896"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "20", "18101020000002", "1352896", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1539184428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000010\", \"9119168\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489573", timeStamp: "1539184513", hash: "0xd460aa641d93d5e9513c0af0156e4a2fb15174fb9aea76d027f578f115167a3f", nonce: "23", blockHash: "0x01954baf8a7f0ebd3d24fb8d89b8183907e743ca99db3560844f0c13bd76a8f5", transactionIndex: "21", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "36000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144a00000000000000000000000000000000000000000000000000000000008b25c00000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "593492", gasUsed: "44463", confirmations: "1251857"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000010"}, {type: "uint256", name: "seed", value: "9119168"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000010", "9119168", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1539184513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101010000004\", \"2822590\",... )", async function( ) {
		const txOriginal = {blockNumber: "6489588", timeStamp: "1539184722", hash: "0x986dda0076cc3024d83be410f8e9281b1e4c3f6d5a18c12baba7cabba1eebc02", nonce: "24", blockHash: "0xb7ecd3777a87c137288aa75ef3ea681d5ab45db78f95ed435a7b55d29ee82329", transactionIndex: "25", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "36000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767845688400000000000000000000000000000000000000000000000000000000002b11be0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "795937", gasUsed: "44463", confirmations: "1251842"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101010000004"}, {type: "uint256", name: "seed", value: "2822590"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101010000004", "2822590", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1539184722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000011\", \"2702048\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6489590", timeStamp: "1539184779", hash: "0x707b4ab81ad1789c7e9168519c85391cd479539740897400dd4892153aa8918f", nonce: "25", blockHash: "0xac807c72b48c649077c1349967fa74fb1d76f14ea00bfecaac26ef1d00ddbd05", transactionIndex: "155", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12320000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144b0000000000000000000000000000000000000000000000000000000000293ae00000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "7834648", gasUsed: "44463", confirmations: "1251840"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000011"}, {type: "uint256", name: "seed", value: "2702048"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000011", "2702048", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1539184779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000007\", \"846837\", \... )", async function( ) {
		const txOriginal = {blockNumber: "6489590", timeStamp: "1539184779", hash: "0x5481d465be83fb620db5a2134d61c08c8b02d38e88f828d553e1e1b034f03372", nonce: "26", blockHash: "0xac807c72b48c649077c1349967fa74fb1d76f14ea00bfecaac26ef1d00ddbd05", transactionIndex: "156", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12320000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4700000000000000000000000000000000000000000000000000000000000cebf50000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "7879111", gasUsed: "44463", confirmations: "1251840"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000007"}, {type: "uint256", name: "seed", value: "846837"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000007", "846837", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1539184779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"50\", \"18101050000002\", \"2870890\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492267", timeStamp: "1539222158", hash: "0x77dfaa0573234ee6dbc9eae9b60655d6e7d2514da11c33f4096e651f02c58049", nonce: "27", blockHash: "0xd5ee5768829dea068d790e7f689e7cc0a11727e5bd01e238da4d299bf4ad9638", transactionIndex: "75", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000010767aa7c28200000000000000000000000000000000000000000000000000000000002bce6a0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3472331", gasUsed: "44463", confirmations: "1249163"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "50"}, {type: "uint256", name: "period", value: "18101050000002"}, {type: "uint256", name: "seed", value: "2870890"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "50", "18101050000002", "2870890", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1539222158 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"20\", \"18101020000003\", \"7444126\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492269", timeStamp: "1539222194", hash: "0xfc123cf5ed6f229fb8bf88dc0e682ca28c2ef658cf998d633b235e1fe6885174", nonce: "28", blockHash: "0x700d21cf59e3d0acc858f6fb3882b743e59b65b53b1225cd69b22f455ce90e41", transactionIndex: "29", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000107678ddff03000000000000000000000000000000000000000000000000000000000071969e0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1840764", gasUsed: "44463", confirmations: "1249161"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "20"}, {type: "uint256", name: "period", value: "18101020000003"}, {type: "uint256", name: "seed", value: "7444126"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "20", "18101020000003", "7444126", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1539222194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101010000005\", \"6733623\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492269", timeStamp: "1539222194", hash: "0x30b606f9b11b4e89accdcf3886517dc7a5bf2f1878df023ef44e8f226b2af57f", nonce: "29", blockHash: "0x700d21cf59e3d0acc858f6fb3882b743e59b65b53b1225cd69b22f455ce90e41", transactionIndex: "30", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000107678456885000000000000000000000000000000000000000000000000000000000066bf370000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1885227", gasUsed: "44463", confirmations: "1249161"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101010000005"}, {type: "uint256", name: "seed", value: "6733623"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101010000005", "6733623", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1539222194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101001000012\", \"170422\", \... )", async function( ) {
		const txOriginal = {blockNumber: "6492269", timeStamp: "1539222194", hash: "0x8ad8d61ede5234e08ac4efceee92a1051ea9f857cbb667c0d286f78e00319889", nonce: "30", blockHash: "0x700d21cf59e3d0acc858f6fb3882b743e59b65b53b1225cd69b22f455ce90e41", transactionIndex: "31", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000107677bc144c00000000000000000000000000000000000000000000000000000000000299b60000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "1929690", gasUsed: "44463", confirmations: "1249161"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101001000012"}, {type: "uint256", name: "seed", value: "170422"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101001000012", "170422", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1539222194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101005000008\", \"8267125\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492269", timeStamp: "1539222194", hash: "0x9c6397cb70f65c0da5f260852b703052acb78d0631cf0c817dd63e654eb40d8a", nonce: "31", blockHash: "0x700d21cf59e3d0acc858f6fb3882b743e59b65b53b1225cd69b22f455ce90e41", transactionIndex: "32", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000107677f91d4800000000000000000000000000000000000000000000000000000000007e25750000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1974153", gasUsed: "44463", confirmations: "1249161"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101005000008"}, {type: "uint256", name: "seed", value: "8267125"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101005000008", "8267125", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1539222194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100000\", \"5809210\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492288", timeStamp: "1539222367", hash: "0xec101812e9eec0823ae6f0a890dd69b65d3d0b560044c4317098de6f95742e1a", nonce: "32", blockHash: "0x32b90a27053f7824aec5cf76d9258d6e5da43ce7233930c0a4010303e35126f4", transactionIndex: "40", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "14280000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a0000000000000000000000000000000000000000000000000000000000058a43a0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4837144", gasUsed: "44463", confirmations: "1249142"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100000"}, {type: "uint256", name: "seed", value: "5809210"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100000", "5809210", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1539222367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101100500000\", \"661975\", \... )", async function( ) {
		const txOriginal = {blockNumber: "6492299", timeStamp: "1539222490", hash: "0x4ddc5a5948d73a400e667a7ed1f0277342d31d01e579adde2e161ab7bdf5fa03", nonce: "33", blockHash: "0x89228c54b93b1b63efb22aa3b2eedcfaa85474dac08fe7408062b84b35c6f735", transactionIndex: "44", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000010767daa542000000000000000000000000000000000000000000000000000000000000a19d70000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4236960", gasUsed: "44463", confirmations: "1249131"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101100500000"}, {type: "uint256", name: "seed", value: "661975"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101100500000", "661975", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1539222490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100001\", \"3304756\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492306", timeStamp: "1539222554", hash: "0x0d6c1a0337be15531daa3e166cbbe952c1433970ff241059ca674be2b95cd618", nonce: "34", blockHash: "0x5600e2b76ffcd984e554ba416f0ffa5a8a909fcf36e066605349553c9eb5c595", transactionIndex: "94", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a10000000000000000000000000000000000000000000000000000000000326d340000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4685940", gasUsed: "44463", confirmations: "1249124"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100001"}, {type: "uint256", name: "seed", value: "3304756"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100001", "3304756", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1539222554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100002\", \"2030467\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492321", timeStamp: "1539222756", hash: "0x1c43fdccf573706bbb0182965933399404437d9f34ec2cdc9faaeee64f58ee38", nonce: "35", blockHash: "0x07f334d5393bc1262c81bd10b177a9f7e07934282983e3605bfca79760bfaef7", transactionIndex: "25", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "58926", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a200000000000000000000000000000000000000000000000000000000001efb830000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "1384663", gasUsed: "44463", confirmations: "1249109"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100002"}, {type: "uint256", name: "seed", value: "2030467"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100002", "2030467", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1539222756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101101000000\", \"2768589\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492325", timeStamp: "1539222831", hash: "0xf984d4b9f40de15210e1b8a0aa95be4262082a50a86280ceb58b8e336c25c755", nonce: "36", blockHash: "0xbe012e6bf7e9f54b3bc58d59d50e9f4b77410162e1f4505434296cecf180240e", transactionIndex: "52", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767db1f54000000000000000000000000000000000000000000000000000000000002a3ecd0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3237691", gasUsed: "44463", confirmations: "1249105"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101101000000"}, {type: "uint256", name: "seed", value: "2768589"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101101000000", "2768589", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1539222831 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101100500001\", \"6080367\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492328", timeStamp: "1539222868", hash: "0xbaa10906a670bcc4461146b44d591e471ff99bfa38362caa8c147899727f2d5f", nonce: "37", blockHash: "0xfff9bdcf7b24c5b541ad28021a283775e674c2075549135b2e01507e445ffff4", transactionIndex: "20", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000010767daa542100000000000000000000000000000000000000000000000000000000005cc76f0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "892733", gasUsed: "44463", confirmations: "1249102"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101100500001"}, {type: "uint256", name: "seed", value: "6080367"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101100500001", "6080367", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1539222868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100003\", \"8840560\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492333", timeStamp: "1539222927", hash: "0x90e0b2de18bd2b09c18e070b0c60589f198252d206adcc7d8cdef77a6348f3c9", nonce: "38", blockHash: "0xf79d18dc6e994bbb2bee5d28a3e94979921c431c117afb5286ccfec74ed438c0", transactionIndex: "174", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a3000000000000000000000000000000000000000000000000000000000086e5700000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "5572737", gasUsed: "44463", confirmations: "1249097"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100003"}, {type: "uint256", name: "seed", value: "8840560"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100003", "8840560", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1539222927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101100500002\", \"2375029\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492348", timeStamp: "1539223091", hash: "0xf91af648bf5b07b8a01180363f0771a6c6f3078c889be3812b31966bd1da0c8d", nonce: "39", blockHash: "0x45ec56fc979619b395a66235021cda9ca4a8fc2045c8cde887d189f9b0bd5689", transactionIndex: "76", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12919403520", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000010767daa54220000000000000000000000000000000000000000000000000000000000243d750000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4296282", gasUsed: "44463", confirmations: "1249082"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101100500002"}, {type: "uint256", name: "seed", value: "2375029"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101100500002", "2375029", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1539223091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100004\", \"6370153\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492350", timeStamp: "1539223117", hash: "0xe7e4293b337eb4571b9061121fe8b3d4c5a0df5482eefe6624ba37fdf529589b", nonce: "40", blockHash: "0x5298735200350ef1459218853dc02d7ec23ff1f549e4f84adcd38c8b4df08cfd", transactionIndex: "38", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12919403520", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a400000000000000000000000000000000000000000000000000000000006133690000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3384970", gasUsed: "44463", confirmations: "1249080"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100004"}, {type: "uint256", name: "seed", value: "6370153"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100004", "6370153", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1539223117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100005\", \"4967654\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492361", timeStamp: "1539223282", hash: "0xacc1b2d72110a4677d70fd29ad7602fc461161ba30c4655fef23f4900e3df6df", nonce: "41", blockHash: "0xc4bbb8526735af7f5b19c18d39339d8c8523690efef8625fa271a1a0015275c6", transactionIndex: "59", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "12919403520", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a500000000000000000000000000000000000000000000000000000000004bcce60000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2216703", gasUsed: "44463", confirmations: "1249069"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100005"}, {type: "uint256", name: "seed", value: "4967654"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100005", "4967654", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1539223282 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"20\", \"18101102000000\", \"1359402\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492368", timeStamp: "1539223390", hash: "0x029c0d9777291a51595ddb801d3e3f1746f03978ef4a6afe6773b66bfc3e302a", nonce: "42", blockHash: "0x170137ff953f97c68bcba7be969ea3d8559dedabd87859a928f0b2311517334f", transactionIndex: "25", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "15385074688", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000010767dc13780000000000000000000000000000000000000000000000000000000000014be2a0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1222422", gasUsed: "44463", confirmations: "1249062"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "20"}, {type: "uint256", name: "period", value: "18101102000000"}, {type: "uint256", name: "seed", value: "1359402"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "20", "18101102000000", "1359402", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1539223390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"10\", \"18101101000001\", \"1497376\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492368", timeStamp: "1539223390", hash: "0x0209e5e5a5f8d79d762d41182807f2ae49feef6bfb97e0e6ce198f9a8412f761", nonce: "43", blockHash: "0x170137ff953f97c68bcba7be969ea3d8559dedabd87859a928f0b2311517334f", transactionIndex: "26", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "15385074688", isError: "0", txreceipt_status: "1", input: "0x9732b33a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000010767db1f541000000000000000000000000000000000000000000000000000000000016d9200000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1266885", gasUsed: "44463", confirmations: "1249062"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "10"}, {type: "uint256", name: "period", value: "18101101000001"}, {type: "uint256", name: "seed", value: "1497376"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "10", "18101101000001", "1497376", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1539223390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101100500003\", \"3165287\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492369", timeStamp: "1539223458", hash: "0x7ebdd5bea2f94276d6bb85028391711c3cbb053b1492ebd56f5062717cb476ae", nonce: "44", blockHash: "0x223ab998ef0ba78358c987cd11e1d203f2ab987dcd39d208c0b715a93073169b", transactionIndex: "79", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000010767daa54230000000000000000000000000000000000000000000000000000000000304c670000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3768766", gasUsed: "44463", confirmations: "1249061"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101100500003"}, {type: "uint256", name: "seed", value: "3165287"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101100500003", "3165287", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1539223458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100006\", \"6216618\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492369", timeStamp: "1539223458", hash: "0x621ab0ac30ac8fea9d36dbb099ad148f2e01dd32586267fd8b22d04da7b97cb5", nonce: "45", blockHash: "0x223ab998ef0ba78358c987cd11e1d203f2ab987dcd39d208c0b715a93073169b", transactionIndex: "80", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a600000000000000000000000000000000000000000000000000000000005edbaa0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3813229", gasUsed: "44463", confirmations: "1249061"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100006"}, {type: "uint256", name: "seed", value: "6216618"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100006", "6216618", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1539223458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100007\", \"8339996\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492380", timeStamp: "1539223646", hash: "0x76f7100949f3bc2ac17e17805bfbfd80878e293b479fc4046907e3236e6fa49c", nonce: "46", blockHash: "0x4cd2e4fd6a3e980a57023260237bc37343f7fd665c4b750346c7661e59233a6e", transactionIndex: "33", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a700000000000000000000000000000000000000000000000000000000007f421c0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "1898540", gasUsed: "44463", confirmations: "1249050"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100007"}, {type: "uint256", name: "seed", value: "8339996"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100007", "8339996", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1539223646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"5\", \"18101100500004\", \"3757472\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492383", timeStamp: "1539223695", hash: "0x21a59a6cfa6d424ca7e4b272400295dced665702797ecad602c9774f0053650f", nonce: "47", blockHash: "0x54ee47c221c63f9d66149c43ab07f22b0983cb0425727d9d20ef1943b7616549", transactionIndex: "38", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000010767daa542400000000000000000000000000000000000000000000000000000000003955a00000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2234956", gasUsed: "44463", confirmations: "1249047"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "5"}, {type: "uint256", name: "period", value: "18101100500004"}, {type: "uint256", name: "seed", value: "3757472"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "5", "18101100500004", "3757472", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1539223695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"1\", \"18101100100008\", \"4518777\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6492393", timeStamp: "1539223827", hash: "0x745f3da2f462ee2e46f62adc2a424831c6cd4b2615fb0866fc89c487a3294277", nonce: "48", blockHash: "0x40d9eb084f216999dc5658885c09d641c45597bd0d7225441577e1056199576d", transactionIndex: "22", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000010767da439a8000000000000000000000000000000000000000000000000000000000044f3790000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "989331", gasUsed: "44463", confirmations: "1249037"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "1"}, {type: "uint256", name: "period", value: "18101100100008"}, {type: "uint256", name: "seed", value: "4518777"}, {type: "uint256", name: "maxNumber", value: "20"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "1", "18101100100008", "4518777", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1539223827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: makeRandomResult( \"50\", \"18101105000000\", \"6214072\",... )", async function( ) {
		const txOriginal = {blockNumber: "6492412", timeStamp: "1539223997", hash: "0x794899e53055e6d7b3b085f48df2d7cbc5707fc1dc58d58083a0514cffaa5ef3", nonce: "49", blockHash: "0xfebe5585841862b0dc41037fd37f6aa7d44d71b600193fbcda2675218d9ed541", transactionIndex: "70", from: "0xcbb490f8034d0a4591c677865863dd50a89014ed", to: "0x79bde2574d61f2bdbfe4c333a594fbba3c99e122", value: "0", gas: "88926", gasPrice: "28800000000", isError: "0", txreceipt_status: "1", input: "0x9732b33a0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000010767deefe4000000000000000000000000000000000000000000000000000000000005ed1b80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2827558", gasUsed: "44463", confirmations: "1249018"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "guessType", value: "50"}, {type: "uint256", name: "period", value: "18101105000000"}, {type: "uint256", name: "seed", value: "6214072"}, {type: "uint256", name: "maxNumber", value: "50"}], name: "makeRandomResult", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeRandomResult(uint256,uint256,uint256,uint256)" ]( "50", "18101105000000", "6214072", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1539223997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17909902216514451371" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
