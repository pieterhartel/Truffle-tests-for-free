const ERC721dAppCaps = artifacts.require( "./ERC721dAppCaps.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ERC721dAppCaps" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x0C15D535F8c21d6f3A03dd46ae23A07e5d897C80", "0x00e4f5F746242E4d115bD65aaC7C08fE5D38FB21", "0x75264379A14D7FFF69455a23d37Fcf51196b2F24", "0xaC8239EDBE33ABAC951F15209bC8623C1b126cD0"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contact", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "exists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "company", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "viewTokenMeta", outputs: [{name: "tokenType_", type: "uint256"}, {name: "specialQuality_", type: "string"}, {name: "tokenTitle_", type: "string"}, {name: "tokenDescription_", type: "string"}, {name: "iptcKeyword_", type: "string"}, {name: "tokenClass_", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "author", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentPrice", outputs: [{name: "price", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_approved", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BoughtToken(address,uint256)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x75424253909c2f4460f8a59099700e980f5b484608c4fdd79f600f5162ac88a5", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6573255 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6585486 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "string", name: "_name", value: "dAppCaps"}, {type: "string", name: "_symbol", value: "CAPS"}], name: "ERC721dAppCaps", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "_interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "InterfaceId_ERC165()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contact", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contact()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "exists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "company", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "company()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "viewTokenMeta", outputs: [{name: "tokenType_", type: "uint256"}, {name: "specialQuality_", type: "string"}, {name: "tokenTitle_", type: "string"}, {name: "tokenDescription_", type: "string"}, {name: "iptcKeyword_", type: "string"}, {name: "tokenClass_", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "viewTokenMeta(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "author", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "author()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentPrice", outputs: [{name: "price", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ERC721dAppCaps", function( accounts ) {

	it( "TEST: ERC721dAppCaps( `dAppCaps`, `CAPS` )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6573255", timeStamp: "1540363455", hash: "0x2078dda0edda28ca26dca85f449156d6f489318581b7f45ad7e2b7b5d6241dc5", nonce: "48", blockHash: "0xcf521547cf4f6ed34399fed402e6883881d68e11731117ef7b170f603cf9de95", transactionIndex: "28", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: 0, value: "0", gas: "4433693", gasPrice: "9912660001", isError: "0", txreceipt_status: "1", input: "0x58382fc9000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000008644170704361707300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044341505300000000000000000000000000000000000000000000000000000000", contractAddress: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", cumulativeGasUsed: "4923029", gasUsed: "3694744", confirmations: "1163615"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_name", value: `dAppCaps`}, {type: "string", name: "_symbol", value: `CAPS`}], name: "ERC721dAppCaps", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ERC721dAppCaps.new( `dAppCaps`, `CAPS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540363455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ERC721dAppCaps.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6573284", timeStamp: "1540363905", hash: "0xf1e5c85c9204767c363123ad3679a7d4a30b7571c6ec24bd41daf5dcbff7ac2f", nonce: "49", blockHash: "0x8e01c4744c9a91ac802457fca1feb8ba5ec890e32950a5543cea5105a774af80", transactionIndex: "87", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "425275", gasPrice: "7796410001", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3481913", gasUsed: "354396", confirmations: "1163586"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540363905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "1"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "1"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Spider Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6573295", timeStamp: "1540364109", hash: "0x51cc18509c801dd206c8f674285b460fca4b28a2fb7a04ba6f7e5002fb4721a9", nonce: "50", blockHash: "0x97d00bb196276e80f5ca9f7600485521ee2aa7e2912187e073e923ada2077a74", transactionIndex: "138", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c53706964657220536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000556656e6f6d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7413982", gasUsed: "339396", confirmations: "1163575"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Spider Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Venom`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Spider Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Venom`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540364109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "2"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Ninja, Sawblade`, `Did you know ... )", async function( ) {
		const txOriginal = {blockNumber: "6573316", timeStamp: "1540364390", hash: "0x06cea72ce2ce158bd9c2801228d38bdc691a276a663187b5371be23425d35e26", nonce: "51", blockHash: "0x3ac8441dd8621755ee584869fbb9ced0410b001cac12670f339c42b9efc52842", transactionIndex: "156", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407352", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000f4e696e6a612c20536177626c6164650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000034368690000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7302028", gasUsed: "339460", confirmations: "1163554"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Ninja, Sawblade`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Chi`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Ninja, Sawblade`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Chi`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540364390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "3"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "3"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"1\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6573352", timeStamp: "1540364991", hash: "0x0908e030a1c1698c98fdb95b62915c6aea471e75e8b79f5d89d363670e3c25b8", nonce: "52", blockHash: "0x1a218bb84cd555ff964ce24427e816c03388758dd7c6e8e7628c238337d66327", transactionIndex: "87", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "34182", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f310000000000000000000000", contractAddress: "", cumulativeGasUsed: "2962662", gasUsed: "34182", confirmations: "1163518"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/1`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"2\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6573355", timeStamp: "1540365023", hash: "0xf6552f283468d3a5beef1a9751fe89e2ae5371a7f9ef7818966a0d7dbfe335ff", nonce: "53", blockHash: "0xcd700a417e6c96b233ab63bf25fc18174cb9f52737a6ae86b1e04284c130c36c", transactionIndex: "132", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f320000000000000000000000", contractAddress: "", cumulativeGasUsed: "5190941", gasUsed: "109631", confirmations: "1163515"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/2`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "2", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/2`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540365023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"3\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6573357", timeStamp: "1540365049", hash: "0x5a8e00b3ecfd4b1ab722c4c575e0cf7e6afcedaa0589ca09fe36164c92971021", nonce: "54", blockHash: "0xdc8b43bc3f4b8a848c7ccc953a7847e44622828a15c540084b6bec7c7a33f5d6", transactionIndex: "118", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "8400000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f330000000000000000000000", contractAddress: "", cumulativeGasUsed: "5256099", gasUsed: "109631", confirmations: "1163513"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/3`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "3", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540365049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"1\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6573369", timeStamp: "1540365218", hash: "0x92e3bb945a0371e0707418e09234303a33750726329ec036ceaafa4edb128170", nonce: "55", blockHash: "0xed85f56e9046076ee4c3514d2234414cba58875a26fd3b644c26415163454423", transactionIndex: "133", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f310000000000000000000000", contractAddress: "", cumulativeGasUsed: "5479355", gasUsed: "109631", confirmations: "1163501"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/1`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "1", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540365218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setApprovalForAll( addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6573399", timeStamp: "1540365645", hash: "0x4a9099b537e53eec3104306701ad17c1f8a144321eca5bd8bd675508111a9553", nonce: "56", blockHash: "0x5bda2c4464776a91d5ad5784c7e439781a9be8ec4b02f8eee798978dc0b3b553", transactionIndex: "56", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "68950", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa22cb46500000000000000000000000075264379a14d7fff69455a23d37fcf51196b2f240000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2814415", gasUsed: "45967", confirmations: "1163471"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "bool", name: "_approved", value: true}], name: "setApprovalForAll", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setApprovalForAll(address,bool)" ]( addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540365645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovalForAll", events: [{name: "_owner", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_operator", type: "address", value: "0x75264379a14d7fff69455a23d37fcf51196b2f24"}, {name: "_approved", type: "bool", value: true}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582831", timeStamp: "1540498256", hash: "0xc76268cd82d0f213808c5c1c96b513d490612eb71c1e49190ff9b5f60ad25ae2", nonce: "57", blockHash: "0x4a15dffc91009fa96fd73dec7cc010480cfff41a6b7420695eb4e323149f46fa", transactionIndex: "73", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5003324", gasUsed: "517861", confirmations: "1154039"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540498256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "4"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "4"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582835", timeStamp: "1540498320", hash: "0x6fc4db9baa2d9b495766ed8ef88fcf531dd78abb6ac4e078b75c7baad1e0afb0", nonce: "58", blockHash: "0x389d9c4ad61fd033f6bb6d429a64b90e38660d817762ae54a32212474ddebdc0", transactionIndex: "17", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1760844", gasUsed: "517861", confirmations: "1154035"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540498320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "5"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "5"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582837", timeStamp: "1540498344", hash: "0x8bd1f1ffc6d2efc713d118e20c855f087132be8ff2541e8ede1904aff2ea0681", nonce: "59", blockHash: "0x5610e92df645ca03683eeec8d2ed68fb9cc0abfa01098bfe543ce5dbe1bafa02", transactionIndex: "10", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "602504", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1182077", gasUsed: "517861", confirmations: "1154033"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540498344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "6"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "6"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582837", timeStamp: "1540498344", hash: "0x05cf5c4bc1549c4b422c0b8fa4e97b5e60ae5b1e85577a9f59f980c55db88f74", nonce: "60", blockHash: "0x5610e92df645ca03683eeec8d2ed68fb9cc0abfa01098bfe543ce5dbe1bafa02", transactionIndex: "11", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1699938", gasUsed: "517861", confirmations: "1154033"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540498344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "7"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "7"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582842", timeStamp: "1540498424", hash: "0x62bc10fc9c5c7d02384445c1023515d7d02a809c598f1315846d848d90886351", nonce: "61", blockHash: "0xa8d52b1f81fb4883d8bc810d0dc27bef84a17d652ffb0fce83e8610ad77c6067", transactionIndex: "9", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2079012", gasUsed: "517861", confirmations: "1154028"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540498424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "8"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "8"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582844", timeStamp: "1540498452", hash: "0x12d0d9686de54d48e4e2edc51f53200704e49b1dc3a44c436ea437a42f9c9f8a", nonce: "62", blockHash: "0x24e735f5cbdf38afe45feea1180145e7bfb5b4af39b5245d52e1d705e3364a77", transactionIndex: "55", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6156593", gasUsed: "517861", confirmations: "1154026"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540498452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "9"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582844", timeStamp: "1540498452", hash: "0x531fc9516966c8ce968503d364e800707c1294124d498a59f04cef4442a3cb0d", nonce: "63", blockHash: "0x24e735f5cbdf38afe45feea1180145e7bfb5b4af39b5245d52e1d705e3364a77", transactionIndex: "56", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6674454", gasUsed: "517861", confirmations: "1154026"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540498452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "10"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "10"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582888", timeStamp: "1540498991", hash: "0xb639be633608e0dfd4d259510732d6ad2604935e3e20776c28901e34fd82169f", nonce: "64", blockHash: "0xd28665e587c681000ad7a4179568f8c48e5e97f68e092f555ce4e3ea6c303d12", transactionIndex: "79", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "583038", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5433025", gasUsed: "517861", confirmations: "1153982"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540498991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "11"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "11"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Silver Haze`, `The first seed st... )", async function( ) {
		const txOriginal = {blockNumber: "6582891", timeStamp: "1540499050", hash: "0xcc613de0c38fc132d73ca13d822b054afd175372b2a58458ce386061a56082fc", nonce: "65", blockHash: "0x6bba85e9824f95cf5e3df4bd0aba7ca7b88cb3a6eb226cdd8a241588d7174eea", transactionIndex: "10", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "621433", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000b53696c7665722048617a65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a54686520666972737420736565642073747261696e20746f2064656c69766572207468652066756c6c2d737472656e6774682048617a6520657870657269656e636520696e2061206661747465722c206661737465722c206d6f726520636f6d7061637420666f726d2e2043726f7373696e672048617a6520776974682061206e6f6e2d646f6d696e616e7420696e64696361204e6f72746865726e204c69676874732c2053696c7665722048617a65206d61696e7461696e73207374726f6e672062757420636c6561722d6865616465642073617469766120656666656374732e20496e74726f64756365642062792053656e73692053656564732c207468652053696c7665722048617a65206765747320697473206e616d652066726f6d20746865206d61737369766520616d6f756e74206f66207368696e792054484320676c616e647320636f766572696e672074686520627564732e00000000000000000000000000000000000000000000000000000000000000000000000000065361746976610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1173338", gasUsed: "517861", confirmations: "1153979"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Silver Haze`}, {type: "string", name: "_description", value: `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`}, {type: "string", name: "_specialQuality", value: `Sativa`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Silver Haze`, `The first seed strain to deliver the full-strength Haze experience in a fatter, faster, more compact form. Crossing Haze with a non-dominant indica Northern Lights, Silver Haze maintains strong but clear-headed sativa effects. Introduced by Sensi Seeds, the Silver Haze gets its name from the massive amount of shiny THC glands covering the buds.`, `Sativa`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540499050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "12"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "12"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"4\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582894", timeStamp: "1540499090", hash: "0xa579c235652dd2298da7f305dcf7467cd815def3ea93a0d27e49cd8d4691ed20", nonce: "66", blockHash: "0x29d598b5b9f5bba59773a53f20330a3f9ccde9ecf694777a27f74ce009e3dca1", transactionIndex: "50", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f340000000000000000000000", contractAddress: "", cumulativeGasUsed: "3444216", gasUsed: "109631", confirmations: "1153976"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/4`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "4", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/4`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540499090 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"5\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582895", timeStamp: "1540499108", hash: "0xa0c98db210c60a6fd933403c314f722ad3e381e6b0cfadcac39c0f77f5418aad", nonce: "67", blockHash: "0xa0ce65061062662d6b516189d3f2b950f486987bd8ec17d02fbfae37d2a64a0a", transactionIndex: "50", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f350000000000000000000000", contractAddress: "", cumulativeGasUsed: "7962456", gasUsed: "109631", confirmations: "1153975"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/5`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "5", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540499108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"6\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582899", timeStamp: "1540499132", hash: "0x9f32cfc1494f49b674063e1a5cb2457617384757a0d9c562ddba5048c04e6942", nonce: "68", blockHash: "0x5a756f82755325f8a276938ea3107479932b6b74af6f5eb5dfad00955be94264", transactionIndex: "81", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f360000000000000000000000", contractAddress: "", cumulativeGasUsed: "2654274", gasUsed: "109631", confirmations: "1153971"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "6"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/6`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "6", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540499132 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"7\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582915", timeStamp: "1540499348", hash: "0x0194762fead2dbc53fa794101ca1b6061d3078e4adcfeb824a945281e2df6f7f", nonce: "69", blockHash: "0x7e9a0c233f29b09ecba6b0907d4f6956e61c3acafa2b60a2a5d67d509783a394", transactionIndex: "119", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f370000000000000000000000", contractAddress: "", cumulativeGasUsed: "5498020", gasUsed: "109631", confirmations: "1153955"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "7"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/7`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "7", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540499348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"8\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582915", timeStamp: "1540499348", hash: "0x54825d55d3e645e9c0e8398fd1eef8810629cf3b30680fc5d9bc4e03acccbe21", nonce: "70", blockHash: "0x7e9a0c233f29b09ecba6b0907d4f6956e61c3acafa2b60a2a5d67d509783a394", transactionIndex: "120", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f380000000000000000000000", contractAddress: "", cumulativeGasUsed: "5607651", gasUsed: "109631", confirmations: "1153955"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "8"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/8`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "8", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/8`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540499348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"9\", `https://raw.githubusercontent.co... )", async function( ) {
		const txOriginal = {blockNumber: "6582915", timeStamp: "1540499348", hash: "0x9442de6cc8e460dd01189802d6007c15b6cd3c70992386115049a46245c796d8", nonce: "71", blockHash: "0x7e9a0c233f29b09ecba6b0907d4f6956e61c3acafa2b60a2a5d67d509783a394", transactionIndex: "145", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131557", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005568747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f390000000000000000000000", contractAddress: "", cumulativeGasUsed: "6485522", gasUsed: "109631", confirmations: "1153955"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "9"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/9`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "9", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540499348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"10\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6582915", timeStamp: "1540499348", hash: "0x911f535f2ccc86436ec361e1db66f15ab8d87a06afb52a84ad3840f447fdf0e5", nonce: "72", blockHash: "0x7e9a0c233f29b09ecba6b0907d4f6956e61c3acafa2b60a2a5d67d509783a394", transactionIndex: "146", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313000000000000000000000", contractAddress: "", cumulativeGasUsed: "6595217", gasUsed: "109695", confirmations: "1153955"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "10"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/10`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "10", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/10`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540499348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"12\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6582915", timeStamp: "1540499348", hash: "0x3f6422f86bf1a6320fbe87703200efa9b4a7bb7eb476311fc03d1122c0d99ad2", nonce: "73", blockHash: "0x7e9a0c233f29b09ecba6b0907d4f6956e61c3acafa2b60a2a5d67d509783a394", transactionIndex: "147", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313200000000000000000000", contractAddress: "", cumulativeGasUsed: "6704912", gasUsed: "109695", confirmations: "1153955"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "12"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/12`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "12", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/12`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540499348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"11\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6582923", timeStamp: "1540499468", hash: "0xe72bfdbcb3a1469cbbf4a6304af2adcdb7ddc6904b6f1f14d7aa89c6bf86e7e4", nonce: "74", blockHash: "0x6b20d559c7f688e9fd37d27a6c5719a14408afb0164cdfd0a60e66bd50af9a69", transactionIndex: "108", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313100000000000000000000", contractAddress: "", cumulativeGasUsed: "5167211", gasUsed: "109695", confirmations: "1153947"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "11"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/11`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "11", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/11`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540499468 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583729", timeStamp: "1540511005", hash: "0x7aff4dae7f066420cd72418bbe3f2059636d65895ad3d3b7b6731f1f2788d3f4", nonce: "75", blockHash: "0x9fcac284b8c53287ec4c0855aac8108e3e8c89b9e42752f3f80a469a9369a97b", transactionIndex: "30", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1469438", gasUsed: "339396", confirmations: "1153141"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540511005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "13"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "13"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583733", timeStamp: "1540511067", hash: "0x4053efcd31f69d7f7fbd5c015373e4eb9d5d33a0bce2ad9c85787fe9ba5061cb", nonce: "76", blockHash: "0xaaec7d6b828dea618bbc268a78d9643596e22cbc284e320fee5b7922ab690962", transactionIndex: "48", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2620951", gasUsed: "339396", confirmations: "1153137"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540511067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "14"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "14"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison`, `Did you know that I ha... )", async function( ) {
		const txOriginal = {blockNumber: "6583735", timeStamp: "1540511109", hash: "0xf257adfbce6f9b5e643dfc1c0bf5e6c654f5ec3645bd79432a605d528296aa63", nonce: "77", blockHash: "0x4cea34f88c0eaea66710e5dee7e3570235fa62c8d5461efbdf5d17f34ebda5a5", transactionIndex: "92", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "406814", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000006506f69736f6e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2894483", gasUsed: "339012", confirmations: "1153135"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540511109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "15"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "15"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583738", timeStamp: "1540511206", hash: "0x2c2224d259de64de6c8b8a750fd5992c1018bc30e6239fc0184ffe822619544b", nonce: "78", blockHash: "0x1bfaaf92c01fee3c50e04aae6271ea0ab167e99266806c882a95d1c4bbcda84f", transactionIndex: "70", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6169176", gasUsed: "339396", confirmations: "1153132"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540511206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "16"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "16"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583740", timeStamp: "1540511244", hash: "0x4613fd42dab2c78017b47db7e3e53f80a6e33197f8d4ae2bf71a94cfb9f9ecaf", nonce: "79", blockHash: "0xec68772000c57eaa2209e61475a9d51a007b4ad6961eec2e12bf05d6ce076e80", transactionIndex: "63", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7082381", gasUsed: "339396", confirmations: "1153130"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540511244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "17"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "17"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583742", timeStamp: "1540511258", hash: "0x656193c1ab3a04fcf986d825d6375b739493601f6e7d7ea6c03a56c2249a2e1e", nonce: "80", blockHash: "0xe0c2677943617494ea9b32ff19103d1252f0c334dd9530bdec7c5deb9c706de9", transactionIndex: "38", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4102118", gasUsed: "339396", confirmations: "1153128"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540511258 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "18"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "18"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583747", timeStamp: "1540511317", hash: "0xdde8fa35df575adc9e57fd16991e777615b0d02d0e9c9048537d5b6ff2454115", nonce: "81", blockHash: "0x9b0ad94f3bbe953aa7afa57a7d29d026d111a9edfb190f0531c05cc84bab0041", transactionIndex: "45", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2253806", gasUsed: "339396", confirmations: "1153123"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540511317 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "19"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "19"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583755", timeStamp: "1540511422", hash: "0x2e5eae312f857ece7364ac45100eda382e887bcf16e63631743b4fa893fc8a85", nonce: "82", blockHash: "0xdc9350485078508645df6a193b6aa04d6b559ab425ee78a9116c7da42e4fab3a", transactionIndex: "44", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2541013", gasUsed: "339396", confirmations: "1153115"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540511422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "20"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "20"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Poison Skull`, `Did you know tha... )", async function( ) {
		const txOriginal = {blockNumber: "6583755", timeStamp: "1540511422", hash: "0x064e5eb3b6226afd59eb80b402fdbe23875d48f75a80a09ffcf887f0c945ff72", nonce: "83", blockHash: "0xdc9350485078508645df6a193b6aa04d6b559ab425ee78a9116c7da42e4fab3a", transactionIndex: "45", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407275", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000c506f69736f6e20536b756c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005444696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572653f2056697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000054465617468000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2880409", gasUsed: "339396", confirmations: "1153115"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Poison Skull`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Death`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Poison Skull`, `Did you know that I have a physical copy somewhere? Visit qwoyn.io to find out more.`, `Death`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540511422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "21"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"13\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583776", timeStamp: "1540511618", hash: "0x9599f0de3fdc3e1b8ec477454bf0d02870317907cab91aa51913508699c6022f", nonce: "84", blockHash: "0x9a768ea6fef7dcbd6fb8780f9ce46dce83640127dcb37922f15574f7b8c99cf0", transactionIndex: "45", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313300000000000000000000", contractAddress: "", cumulativeGasUsed: "5558176", gasUsed: "109695", confirmations: "1153094"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "13"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/13`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "13", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/13`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540511618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"14\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583779", timeStamp: "1540511677", hash: "0xd816ac473c06918d67b96c32d95a119b8f36e64cd43a64e0d58852d040b554e9", nonce: "85", blockHash: "0x3733af20e2b327921843982958159e0c2ceee7bb7af7c4771d1cce9c5c6cc9a5", transactionIndex: "23", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313400000000000000000000", contractAddress: "", cumulativeGasUsed: "6004389", gasUsed: "109695", confirmations: "1153091"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "14"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/14`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "14", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/14`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540511677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"15\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583779", timeStamp: "1540511677", hash: "0x52d69f5e741652915d0280ec897c340635d78d0723a1aecad82fe1fa5eea41b3", nonce: "86", blockHash: "0x3733af20e2b327921843982958159e0c2ceee7bb7af7c4771d1cce9c5c6cc9a5", transactionIndex: "27", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x01538868000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313500000000000000000000", contractAddress: "", cumulativeGasUsed: "6193968", gasUsed: "109695", confirmations: "1153091"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "15"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/15`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "15", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/15`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540511677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"16\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583783", timeStamp: "1540511715", hash: "0x6683bcc9e0582ecbdc7986392180040ebaa0fd2d399a02840f24edd3c8af110d", nonce: "87", blockHash: "0x1169cd0ffaf34c6a466d36c359a4146a546ab893125b72441b74fc3c6ee47961", transactionIndex: "84", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313600000000000000000000", contractAddress: "", cumulativeGasUsed: "6467567", gasUsed: "109695", confirmations: "1153087"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "16"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/16`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "16", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/16`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540511715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"17\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583783", timeStamp: "1540511715", hash: "0xe3dc345c326e3812aecda135a8f39d0851c204781c1ff1fe4c9e08aaf6531cde", nonce: "88", blockHash: "0x1169cd0ffaf34c6a466d36c359a4146a546ab893125b72441b74fc3c6ee47961", transactionIndex: "85", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313700000000000000000000", contractAddress: "", cumulativeGasUsed: "6577262", gasUsed: "109695", confirmations: "1153087"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "17"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/17`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "17", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/17`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540511715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"18\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583790", timeStamp: "1540511765", hash: "0x25000722de96d65f13f8b1cfab64d7ee14b9587e15b402f139d6c163489b3dec", nonce: "89", blockHash: "0x7df3c5451024cb3fd2d7b6365fef1dc747c0ce70f46e697042311796e34f49ac", transactionIndex: "17", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313800000000000000000000", contractAddress: "", cumulativeGasUsed: "1856706", gasUsed: "109695", confirmations: "1153080"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "18"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/18`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "18", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/18`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540511765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"19\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583793", timeStamp: "1540511807", hash: "0xaa8703cdfa7543a88d6a55a178c1d31c6cd0100b89389060e453a0feef31cee5", nonce: "90", blockHash: "0x83d5e3e1a398b07b593dcaebb96334b7f627182c5d3fbf6c36e2c816a7499c23", transactionIndex: "58", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f313900000000000000000000", contractAddress: "", cumulativeGasUsed: "2497102", gasUsed: "109695", confirmations: "1153077"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "19"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/19`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "19", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/19`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540511807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"20\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583793", timeStamp: "1540511807", hash: "0xaf9d51105ee3a3599565af78c615414515186ba7c17899ee584396246117ce04", nonce: "91", blockHash: "0x83d5e3e1a398b07b593dcaebb96334b7f627182c5d3fbf6c36e2c816a7499c23", transactionIndex: "80", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f323000000000000000000000", contractAddress: "", cumulativeGasUsed: "3547950", gasUsed: "109695", confirmations: "1153077"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "20"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/20`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "20", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/20`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540511807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"21\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6583799", timeStamp: "1540511891", hash: "0xe778ecb25dca3676e72215b59eec1cff7462125b88ce4b37b5630c41f3c84d9a", nonce: "92", blockHash: "0x3fd05c7e34bcc21f8002365ca47b2ebe84e4c6f2a3fa6bc1424245eb63a98018", transactionIndex: "86", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f323100000000000000000000", contractAddress: "", cumulativeGasUsed: "5387214", gasUsed: "109695", confirmations: "1153071"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "21"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/21`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "21", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/21`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540511891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[3], addressList[5], \"21\" )", async function( ) {
		const txOriginal = {blockNumber: "6584045", timeStamp: "1540515297", hash: "0xdfd0d040fceb5ee4500c1ec8df333d332c2640ed1f36e7ee9bf2ce99ff8bad2c", nonce: "93", blockHash: "0x242de616799a0aeeb2043b3bc74f08387d0ec121ed41595b5729f02326943bf7", transactionIndex: "43", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "261891", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd00000000000000000000000000e4f5f746242e4d115bd65aac7c08fe5d38fb21000000000000000000000000ac8239edbe33abac951f15209bc8623c1b126cd00000000000000000000000000000000000000000000000000000000000000015", contractAddress: "", cumulativeGasUsed: "2297881", gasUsed: "114594", confirmations: "1152825"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[3]}, {type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_tokenId", value: "21"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[3], addressList[5], "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540515297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_to", type: "address", value: "0xac8239edbe33abac951f15209bc8623c1b126cd0"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Ninja, Sawblade`, `Did you know ... )", async function( ) {
		const txOriginal = {blockNumber: "6585028", timeStamp: "1540528865", hash: "0x21283e4c58f750a6d1f6262fc6bf4136b46d2cc2b7da90a9368cd3e771eaa5ce", nonce: "94", blockHash: "0x165cfbdf1eb07257aba49dcc98cf4a41448b945c490d6e9676eec2559894a800", transactionIndex: "182", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "388500", gasPrice: "9550000000", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000f4e696e6a612c20536177626c6164650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005544696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572655c6e2076697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e000000000000000000000000000000000000000000000000000000000000000000000000000000000000034368690000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7927675", gasUsed: "339524", confirmations: "1151842"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Ninja, Sawblade`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere\n visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Chi`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Ninja, Sawblade`, `Did you know that I have a physical copy somewhere\n visit qwoyn.io to find out more.`, `Chi`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540528865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "22"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyToken( \"1\", `Ninja, Sawblade`, `Did you know ... )", async function( ) {
		const txOriginal = {blockNumber: "6585032", timeStamp: "1540528907", hash: "0x0a601dd867def6c08ddece69941efa2d9b8426024525528f850a76e22de46012", nonce: "95", blockHash: "0xd217e32affc9832199076cb41d32fe09ad340bd26449ea05b2b3992de478a449", transactionIndex: "87", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "407429", gasPrice: "9835992700", isError: "0", txreceipt_status: "1", input: "0x228197c9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000f4e696e6a612c20536177626c6164650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005544696420796f75206b6e6f77207468617420492068617665206120706879736963616c20636f707920736f6d6577686572655c6e2076697369742071776f796e2e696f20746f2066696e64206f7574206d6f72652e000000000000000000000000000000000000000000000000000000000000000000000000000000000000034368690000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001171776f796e5f696f2064617070636170730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009746f6b656e4f6e6c790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4895761", gasUsed: "339524", confirmations: "1151838"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_type", value: "1"}, {type: "string", name: "_title", value: `Ninja, Sawblade`}, {type: "string", name: "_description", value: `Did you know that I have a physical copy somewhere\n visit qwoyn.io to find out more.`}, {type: "string", name: "_specialQuality", value: `Chi`}, {type: "string", name: "_iptcKeyword", value: `qwoyn_io dappcaps`}, {type: "string", name: "_tokenClass", value: `tokenOnly`}], name: "buyToken", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyToken(uint256,string,string,string,string,string)" ]( "1", `Ninja, Sawblade`, `Did you know that I have a physical copy somewhere\n visit qwoyn.io to find out more.`, `Chi`, `qwoyn_io dappcaps`, `tokenOnly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540528907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "BoughtToken", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BoughtToken", events: [{name: "buyer", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "tokenId", type: "uint256", value: "23"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21"}, {name: "_tokenId", type: "uint256", value: "23"}], address: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"22\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6585484", timeStamp: "1540535628", hash: "0xf41fc3c40a48490d0092c5500a653e10edce56951788df5f79da8eaeaca63fd8", nonce: "98", blockHash: "0x0016dc2db8e4e89ddb07e5c63f109c2ecbb1550e0b93c22d16e4be1186f19df5", transactionIndex: "81", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f323200000000000000000000", contractAddress: "", cumulativeGasUsed: "2761521", gasUsed: "109695", confirmations: "1151386"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "22"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/22`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "22", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/22`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540535628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: _setTokenURI( \"23\", `https://raw.githubusercontent.c... )", async function( ) {
		const txOriginal = {blockNumber: "6585486", timeStamp: "1540535669", hash: "0xd860d417b90242969463610d4d6b1d9320c901a2b3313fd7f0d4ce6e2ed1bcea", nonce: "99", blockHash: "0x75e9358a2d61c49efb2587cdb17475c6a3998248d7aa62f2d5474db33d0b8f8f", transactionIndex: "63", from: "0x00e4f5f746242e4d115bd65aac7c08fe5d38fb21", to: "0x0c15d535f8c21d6f3a03dd46ae23a07e5d897c80", value: "0", gas: "131634", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x0153886800000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005668747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f51776f796e2f64417070436170732f6d61737465722f546f6b656e2532304a534f4e2f56657273696f6e253230312e37372f323300000000000000000000", contractAddress: "", cumulativeGasUsed: "2748037", gasUsed: "109695", confirmations: "1151384"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "23"}, {type: "string", name: "_uri", value: `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/23`}], name: "_setTokenURI", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_setTokenURI(uint256,string)" ]( "23", `https://raw.githubusercontent.com/Qwoyn/dAppCaps/master/Token%20JSON/Version%201.77/23`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540535669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "210500000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
