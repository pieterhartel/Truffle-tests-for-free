const Extend = artifacts.require( "./Extend.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Extend" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x690508422D576eDb99D676320ea251036d164062", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x6c259ea1fCa0D1883e3FFFdDeb8a0719E1D7265f", "0x72eF77B170E76719FE1844f876FcAB529c70Cc18", "0x53206dc09B9594B8d961f0b8C8623f87757760Ae", "0x3e7489A60951132040E86E4E7C86B78c356Be14C", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0xBbB8A05873ae02be3a6E8D45a9047d9D20b3c93A", "0xdE71B2bb918D167AC27109C05A9E387dC35d4F1e", "0x4b20Bee98F360d4c5bf7F04A094e779862d0A866", "0x919F7D0bFE66188D5F26d896851Fc43cE5153A1e", "0xC834b38ba4470b43537169cd404FffB4d5615f12", "0xC26bf0FA0413d9a81470353589a50d4fb3f92a30", "0x1D1Fa9b986b2510A41f9b07329E9E3b1515E1F9e", "0xe07caB35275C4f0Be90D6F4900639EC301Fc9b69", "0xe18a73290BFd400Edf1a123C3d87E1504D592Ff4", "0x69CC780Bf4F63380c4bC745Ee338CB678752301a"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "checkAddressVerified", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_username", type: "bytes32"}], name: "checkIfRefundAvailable", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}], name: "getUsernameForAddress", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getOraclizePrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_username", type: "bytes32"}], name: "checkUsernameVerified", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "checkBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getDataAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getEventAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_username", type: "bytes32"}], name: "getAddressFromUsername", outputs: [{name: "userAddress", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = [] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = [] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4569214 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4589342 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_data", value: 11}, {type: "address", name: "_events", value: 12}], name: "Extend", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "checkAddressVerified", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkAddressVerified()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_username", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "checkIfRefundAvailable", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkIfRefundAvailable(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getUsernameForAddress", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getUsernameForAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getOraclizePrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOraclizePrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_username", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "checkUsernameVerified", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkUsernameVerified(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "checkBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getDataAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDataAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getEventAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEventAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_username", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getAddressFromUsername", outputs: [{name: "userAddress", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAddressFromUsername(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Extend", function( accounts ) {

	it( "TEST: Extend( addressList[11], addressList[12] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4569214", timeStamp: "1510915826", hash: "0xefaea719e7cb1b3880eabd3b476d0bca4087e5cff1b41251dcbc17fa1f057180", nonce: "2", blockHash: "0x6753038267812a7d7978d3be11f480d05ac39c9534e738865fb8414f0964015d", transactionIndex: "33", from: "0x6c259ea1fca0d1883e3fffddeb8a0719e1d7265f", to: 0, value: "0", gas: "4024823", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xaee0438a00000000000000000000000072ef77b170e76719fe1844f876fcab529c70cc1800000000000000000000000053206dc09b9594b8d961f0b8c8623f87757760ae", contractAddress: "0x690508422d576edb99d676320ea251036d164062", cumulativeGasUsed: "4863318", gasUsed: "4024823", confirmations: "3173256"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_data", value: addressList[11]}, {type: "address", name: "_events", value: addressList[12]}], name: "Extend", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Extend.new( addressList[11], addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510915826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Extend.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4577010", timeStamp: "1511024623", hash: "0x756e1d850f9485be5996939fa24f2d6a90e8f00bb5091e48323295331b2200fb", nonce: "0", blockHash: "0x0ca20d6ce84107bbf9652265defcbbbe72c7bb04967013015894bc7d1454267e", transactionIndex: "46", from: "0x3e7489a60951132040e86e4e7c86b78c356be14c", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "288298", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd646a6f6e65795f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000904246352f4d6778326b2b71637a42556457504d56702f644b7959457138666f4c6931584934367979686346714c2f376868687130516159552b367472682b59392f6e67674e694e5347617054656f334675493955345a617a4d38333974596d654e53513637436467457a507666624c706e545552392f634e74755057664d45683674306b583631364b6e66596273427600000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2361254", gasUsed: "262089", confirmations: "3165460"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BF5/Mgx2k+qczBUdWPMVp/dKyYEq8foLi1XI46yyhcFqL/7hhhq0QaYU+6trh+Y9/nggNiNSGapTeo3FuI9U4ZazM839tYmeNSQ67CdgEzPvfbLpnTUR9/cNtuPWfMEh6t0kX616KnfYbsBv`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", `BF5/Mgx2k+qczBUdWPMVp/dKyYEq8foLi1XI46yyhcFqL/7hhhq0QaYU+6trh+Y9/nggNiNSGapTeo3FuI9U4ZazM839tYmeNSQ67CdgEzPvfbLpnTUR9/cNtuPWfMEh6t0kX616KnfYbsBv`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1511024623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "256546000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8bead267212989708377d2bc2b6c6b2ee5c4... )", async function( ) {
		const txOriginal = {blockNumber: "4577021", timeStamp: "1511024762", hash: "0x9410bf4b9893637c5e479b3faaeb413b96fec434ed0fce45d91bf9325e4719f8", nonce: "335744", blockHash: "0xf985cb65d0309935b1cee5d1cd3e849275387c720dd12d38e83e19d40e88f784", transactionIndex: "31", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e8bead267212989708377d2bc2b6c6b2ee5c4319b968d60d1fc9f904e7131fa5000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000007646a6f6e65795f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1425112", gasUsed: "98228", confirmations: "3165449"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x8bead267212989708377d2bc2b6c6b2ee5c4319b968d60d1fc9f904e7131fa50"}, {type: "string", name: "_result", value: `djoney_`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x8bead267212989708377d2bc2b6c6b2ee5c4319b968d60d1fc9f904e7131fa50", `djoney_`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1511024762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4577042", timeStamp: "1511025012", hash: "0x3461669143af0aa5a839840af1111576c5e2286d060de8bd2e414f3d2cdd2c67", nonce: "1", blockHash: "0xd7c64e945d045e5bb7e2a92aa6a5d4cf1c64d0f91ddc1ca537286dabafbd3445", transactionIndex: "74", from: "0x3e7489a60951132040e86e4e7c86b78c356be14c", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "102417", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2780127", gasUsed: "93106", confirmations: "3165428"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1511025012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "256546000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4577121", timeStamp: "1511026056", hash: "0xfa1994f962689d3cf136cc56b48594d11eb6b734737838230e2b487bda68279e", nonce: "0", blockHash: "0x6bc2f9a849c2469a977b3129e4f9a4c1c84c4e75822a5d4d106c8d2d508e024e", transactionIndex: "30", from: "0xbbb8a05873ae02be3a6e8d45a9047d9d20b3c93a", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219166", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd646a6f6e65795f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000009042447055364a38432f4259556a5152366e762f43452f31464c78544250666d6f6a7265315936322f44374e475578464c72776c65785142536251722b3450436879376b6e3365597a65476775344b3044596d2b775250352f7a71494e2b6439454f53336a302b616b735550636e47426d575550714173556a68796a542f37556b797643507656534847495748454d384e00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1126640", gasUsed: "199242", confirmations: "3165349"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BDpU6J8C/BYUjQR6nv/CE/1FLxTBPfmojre1Y62/D7NGUxFLrwlexQBSbQr+4PChy7kn3eYzeGgu4K0DYm+wRP5/zqIN+d9EOS3j0+aksUPcnGBmWUPqAsUjhyjT/7UkyvCPvVSHGIWHEM8N`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", `BDpU6J8C/BYUjQR6nv/CE/1FLxTBPfmojre1Y62/D7NGUxFLrwlexQBSbQr+4PChy7kn3eYzeGgu4K0DYm+wRP5/zqIN+d9EOS3j0+aksUPcnGBmWUPqAsUjhyjT/7UkyvCPvVSHGIWHEM8N`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1511026056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "4137186956843500" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2b6acb41b9883be6fdb91d13dacf73093987... )", async function( ) {
		const txOriginal = {blockNumber: "4577131", timeStamp: "1511026202", hash: "0x1e6ca994f02173350ff677b74c580821f7c7e076c54f7a749baa07b0edcacf29", nonce: "335773", blockHash: "0x8d4cd5ad079d23cd035f951af3a466a850bb89bec1d6b25d0571f9ec72ae3706", transactionIndex: "36", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e2b6acb41b9883be6fdb91d13dacf730939879f23f2744ce51cde33e214caf10a00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000007646a6f6e65795f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1281406", gasUsed: "83228", confirmations: "3165339"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x2b6acb41b9883be6fdb91d13dacf730939879f23f2744ce51cde33e214caf10a"}, {type: "string", name: "_result", value: `djoney_`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x2b6acb41b9883be6fdb91d13dacf730939879f23f2744ce51cde33e214caf10a", `djoney_`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1511026202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588531", timeStamp: "1511183237", hash: "0x8e1ebf23fc170f39207d595bbc56249726db86952c6f2cfd2d55e837e44e6fc9", nonce: "0", blockHash: "0x873bce6e8d3cfe9a0165d049f9231f681182825ebad281cc0481e79190435e4d", transactionIndex: "48", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219096", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd656c6930747a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000009042465855496d457467717347773636316a774a75615a36447277365a7835416163455164395742496434486e66684e366b304e624c397635792f7a6c6b4f6341714c41776c537a6f594f746b335342457667616c6f715141526776474c2b36455652454168556a6b4a434867534e6b4563395674766f6b6b754656356d516f794a6c65764a58666e3031513765374c6500000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1475061", gasUsed: "199178", confirmations: "3153939"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BFXUImEtgqsGw661jwJuaZ6Drw6Zx5AacEQd9WBId4HnfhN6k0NbL9v5y/zlkOcAqLAwlSzoYOtk3SBEvgaloqQARgvGL+6EVREAhUjkJCHgSNkEc9VtvokkuFV5mQoyJlevJXfn01Q7e7Le`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", `BFXUImEtgqsGw661jwJuaZ6Drw6Zx5AacEQd9WBId4HnfhN6k0NbL9v5y/zlkOcAqLAwlSzoYOtk3SBEvgaloqQARgvGL+6EVREAhUjkJCHgSNkEc9VtvokkuFV5mQoyJlevJXfn01Q7e7Le`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1511183237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588535", timeStamp: "1511183291", hash: "0x1108b5589eb4e4043793d18756d2ef19ec1c7cdfa2dde1f92f6cd71892876aba", nonce: "1", blockHash: "0x9b2b96558cf43469442279787d78c77f1f23f06ee8e050946bf061e02363b1cf", transactionIndex: "105", from: "0x4b20bee98f360d4c5bf7f04a094e779862d0a866", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219166", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd646a6f6e65795f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000090425076594666486f79744a496e5768734d7747773169384e6f30504349433673784c6c31466f6448536e39696f7449696a70645a71684c5831322f7179456b4a706b5333645062516a6f75796a613946464a5341684a784a6e7a506c325978673865705952356e50304f5358544f794f4543716d5a4b79785053555468453335673679532f307768485a4e4b3271413700000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5017274", gasUsed: "199242", confirmations: "3153935"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BPvYFfHoytJInWhsMwGw1i8No0PCIC6sxLl1FodHSn9iotIijpdZqhLX12/qyEkJpkS3dPbQjouyja9FFJSAhJxJnzPl2Yxg8epYR5nP0OSXTOyOECqmZKyxPSUThE35g6yS/0whHZNK2qA7`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", `BPvYFfHoytJInWhsMwGw1i8No0PCIC6sxLl1FodHSn9iotIijpdZqhLX12/qyEkJpkS3dPbQjouyja9FFJSAhJxJnzPl2Yxg8epYR5nP0OSXTOyOECqmZKyxPSUThE35g6yS/0whHZNK2qA7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1511183291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "46838431582500" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x736f6d655f72616e646f6d5f757365725f30... )", async function( ) {
		const txOriginal = {blockNumber: "4588540", timeStamp: "1511183358", hash: "0xb9edbaf6a66bcae2939f276f9729d1a1b7015443d9ace20c615de59bd656b3d7", nonce: "0", blockHash: "0xa561386b6f8b8b356600e0641e4b1d45d0542e21530830837737e5675e75f800", transactionIndex: "64", from: "0x919f7d0bfe66188d5f26d896851fc43ce5153a1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219941", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd736f6d655f72616e646f6d5f757365725f3000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000009042456f447046654c78373938305a2f317444583142583477744c647469485a733430583465584a787430613045636e6e386f71584f555a73586f73447a2f312b45596a2b4c7475627a517750365a37372b4e4978554770414f75544b65784a35347a763036736e395265384e304d53764f745649636b713255456b486e553563764234707034624e6c4b63386943575900000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3166123", gasUsed: "199946", confirmations: "3153930"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x736f6d655f72616e646f6d5f757365725f300000000000000000000000000000"}, {type: "string", name: "_token", value: `BEoDpFeLx7980Z/1tDX1BX4wtLdtiHZs40X4eXJxt0a0Ecnn8oqXOUZsXosDz/1+EYj+LtubzQwP6Z77+NIxUGpAOuTKexJ54zv06sn9Re8N0MSvOtVIckq2UEkHnU5cvB4pp4bNlKc8iCWY`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x736f6d655f72616e646f6d5f757365725f300000000000000000000000000000", `BEoDpFeLx7980Z/1tDX1BX4wtLdtiHZs40X4eXJxt0a0Ecnn8oqXOUZsXosDz/1+EYj+LtubzQwP6Z77+NIxUGpAOuTKexJ54zv06sn9Re8N0MSvOtVIckq2UEkHnU5cvB4pp4bNlKc8iCWY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1511183358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "684228936843500" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x03144a361cf3afbc5fae91d5fbda055b4c26... )", async function( ) {
		const txOriginal = {blockNumber: "4588541", timeStamp: "1511183375", hash: "0xc03a566a96278e4fea08677787900fb2e07ec91a5e1b36b2b0694fbd70e1dbf8", nonce: "338085", blockHash: "0x7191cdb8fb11e973aaade296233b14b8368591a0e1cca72ad7a93fd14d194799", transactionIndex: "62", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e03144a361cf3afbc5fae91d5fbda055b4c26f4f0cd044237a29269bf1a5deb4f00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000006656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2151487", gasUsed: "98219", confirmations: "3153929"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x03144a361cf3afbc5fae91d5fbda055b4c26f4f0cd044237a29269bf1a5deb4f"}, {type: "string", name: "_result", value: `eli0tz`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x03144a361cf3afbc5fae91d5fbda055b4c26f4f0cd044237a29269bf1a5deb4f", `eli0tz`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1511183375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x6265736f6973696e6f766900000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588543", timeStamp: "1511183400", hash: "0x5acc7730792de81f6ca823a8cb34a8dff508f6b8eae12d319dd54b0985283af1", nonce: "0", blockHash: "0xa21f150c574b9aee9c9b1f5fab7d02879c401368e748ee3862c5c2b540a229ac", transactionIndex: "40", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219448", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd6265736f6973696e6f7669000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000904243574a50435059625279576b2b6f6b58576239395a377067726846474a6c73727a4a62634379393835516b796556746a5954372f754a5362666d32696d742b674d7934576b714746517136567041365230483850673662593871714d7047597a5143615646492b3573334748414d4c684b37684a435a73734d70464c77394d51383165332f2f526c63515a4f4a505000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1479857", gasUsed: "199498", confirmations: "3153927"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6265736f6973696e6f7669000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BCWJPCPYbRyWk+okXWb99Z7pgrhFGJlsrzJbcCy985QkyeVtjYT7/uJSbfm2imt+gMy4WkqGFQq6VpA6R0H8Pg6bY8qqMpGYzQCaVFI+5s3GHAMLhK7hJCZssMpFLw9MQ81e3//RlcQZOJPP`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x6265736f6973696e6f7669000000000000000000000000000000000000000000", `BCWJPCPYbRyWk+okXWb99Z7pgrhFGJlsrzJbcCy985QkyeVtjYT7/uJSbfm2imt+gMy4WkqGFQq6VpA6R0H8Pg6bY8qqMpGYzQCaVFI+5s3GHAMLhK7hJCZssMpFLw9MQ81e3//RlcQZOJPP`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1511183400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x4d61746b6f39350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588543", timeStamp: "1511183400", hash: "0xb83b7f9608c0b003532dfb96576e81dae067821d0edb3dfc012e4cebb3e6adbd", nonce: "0", blockHash: "0xa21f150c574b9aee9c9b1f5fab7d02879c401368e748ee3862c5c2b540a229ac", transactionIndex: "52", from: "0xc26bf0fa0413d9a81470353589a50d4fb3f92a30", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219166", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd4d61746b6f39350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000090424643694d44366a4e796a735954344666656b7564555032364d5965465465506537387070797a78556b46336174534843747347577a4972324556764837427a38613948317770613573545a6e4a4e38505248467a33305073636d356772634a5a3065716b6273664e6c7846446f3273434f634e6e306c4e63374d4d733464333353575350705a41714752444939497600000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2200697", gasUsed: "199242", confirmations: "3153927"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x4d61746b6f393500000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BFCiMD6jNyjsYT4FfekudUP26MYeFTePe78ppyzxUkF3atSHCtsGWzIr2EVvH7Bz8a9H1wpa5sTZnJN8PRHFz30Pscm5grcJZ0eqkbsfNlxFDo2sCOcNn0lNc7MMs4d33SWSPpZAqGRDI9Iv`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x4d61746b6f393500000000000000000000000000000000000000000000000000", `BFCiMD6jNyjsYT4FfekudUP26MYeFTePe78ppyzxUkF3atSHCtsGWzIr2EVvH7Bz8a9H1wpa5sTZnJN8PRHFz30Pscm5grcJZ0eqkbsfNlxFDo2sCOcNn0lNc7MMs4d33SWSPpZAqGRDI9Iv`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1511183400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "49745956733500" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xba92a16ffed9bbe1949fd7a879423185e1f0... )", async function( ) {
		const txOriginal = {blockNumber: "4588548", timeStamp: "1511183462", hash: "0xc0dee8b58ee405862a274c7c2ab301b1ba88f1f834b969242e5edc7b5631fca8", nonce: "338087", blockHash: "0xdebf76e27290030ae045282bfb8a2d8310f1fd727c00206c7e2e2c8f1b507d0c", transactionIndex: "104", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297eba92a16ffed9bbe1949fd7a879423185e1f078121d24605c9c14ff83d53f038800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000007646a6f6e65795f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3432759", gasUsed: "83228", confirmations: "3153922"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0xba92a16ffed9bbe1949fd7a879423185e1f078121d24605c9c14ff83d53f0388"}, {type: "string", name: "_result", value: `djoney_`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xba92a16ffed9bbe1949fd7a879423185e1f078121d24605c9c14ff83d53f0388", `djoney_`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1511183462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x76610d1dcdef67e57521ac205c9ab2a7d993... )", async function( ) {
		const txOriginal = {blockNumber: "4588554", timeStamp: "1511183525", hash: "0x5e9b7b93ee952f2b6bbd6a6b402cb2cc17b7d28a0bdc99bfc98063fb387a8d4c", nonce: "338090", blockHash: "0xfb51e9bb2c247b32337375c9d46483dff54913aac5a1381fd0079dc221192d49", transactionIndex: "100", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e76610d1dcdef67e57521ac205c9ab2a7d993efe501123cd2e12f15cfbac1c5aa00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000012736f6d655f72616e646f6d5f757365725f300000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3341736", gasUsed: "98932", confirmations: "3153916"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x76610d1dcdef67e57521ac205c9ab2a7d993efe501123cd2e12f15cfbac1c5aa"}, {type: "string", name: "_result", value: `some_random_user_0`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x76610d1dcdef67e57521ac205c9ab2a7d993efe501123cd2e12f15cfbac1c5aa", `some_random_user_0`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1511183525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe149661b923333d3be2e282bb011865ad506... )", async function( ) {
		const txOriginal = {blockNumber: "4588555", timeStamp: "1511183571", hash: "0xc6f38cb2db5a74fb6f1556ee2bbbc94ffb1167dc3105352dd828345d6b0299f3", nonce: "338091", blockHash: "0x8fc9d324ce98597d8bf9a230591352b98cf79aff39f16dec853a35891b6d070f", transactionIndex: "101", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ee149661b923333d3be2e282bb011865ad5069703e3bbdf109d039cd5372b8710000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000074d61746b6f393500000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3513056", gasUsed: "98228", confirmations: "3153915"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0xe149661b923333d3be2e282bb011865ad5069703e3bbdf109d039cd5372b8710"}, {type: "string", name: "_result", value: `Matko95`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xe149661b923333d3be2e282bb011865ad5069703e3bbdf109d039cd5372b8710", `Matko95`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1511183571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd22a1b0e788b3747cf3c3ba64f3ac8eb57bf... )", async function( ) {
		const txOriginal = {blockNumber: "4588556", timeStamp: "1511183587", hash: "0xa72413ef25608f204c5d34fd86eacd5fb4dab9c53af72cb67d24a2cf2893bd1b", nonce: "338092", blockHash: "0xed0a0b9118c62130629bc11160c58f5a36e45c68c0b3f743d37bc56fe0af3809", transactionIndex: "33", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ed22a1b0e788b3747cf3c3ba64f3ac8eb57bf588cf739bdbf0c4cdb051e57d8eb0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000b6265736f6973696e6f7669000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1049870", gasUsed: "98484", confirmations: "3153914"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0xd22a1b0e788b3747cf3c3ba64f3ac8eb57bf588cf739bdbf0c4cdb051e57d8eb"}, {type: "string", name: "_result", value: `besoisinovi`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xd22a1b0e788b3747cf3c3ba64f3ac8eb57bf588cf739bdbf0c4cdb051e57d8eb", `besoisinovi`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1511183587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588561", timeStamp: "1511183653", hash: "0xf5f618962ca25c0a4860cfb43b41df19c838bdd4e685300c53d54a534899fd21", nonce: "1", blockHash: "0x838a6c1d243c7235dd5febe66cd9d19018959a3b5b6f7e649472fe1b7d18d1a2", transactionIndex: "37", from: "0x919f7d0bfe66188d5f26d896851fc43ce5153a1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000", gas: "121455", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1400694", gasUsed: "93172", confirmations: "3153909"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1511183653 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "684228936843500" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588564", timeStamp: "1511183694", hash: "0xaea7f884f0c389ec34d985c457a135d0d50d9e5075432e70fb1a6a7aea5af77f", nonce: "1", blockHash: "0x6742500a23e3b5bee5468b2b0574d859861561a6cba02e5d54b7644b452c469b", transactionIndex: "128", from: "0xc26bf0fa0413d9a81470353589a50d4fb3f92a30", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "121455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6292261", gasUsed: "93172", confirmations: "3153906"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511183694 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "49745956733500" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6265736f6973696e6f766900000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588566", timeStamp: "1511183746", hash: "0x21ae35dd610ba9c3b8013bb38a544747f54925e59b93192c8e2d4110378fec23", nonce: "2", blockHash: "0x3f5d1a6342ba814627a6527b515c25d5bff09c9f839fa3dd431b2ca2899be373", transactionIndex: "89", from: "0x919f7d0bfe66188d5f26d896851fc43ce5153a1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000", gas: "121807", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6265736f6973696e6f7669000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4096075", gasUsed: "93492", confirmations: "3153904"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6265736f6973696e6f7669000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6265736f6973696e6f7669000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1511183746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "684228936843500" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588569", timeStamp: "1511183776", hash: "0xb64090c462d5c3be721573846fb75085a25359ab41e324b8c62231e1fb1e4234", nonce: "1", blockHash: "0xf323f651d637009b391b9f53e6543c8a5d95e688c89dcaf82304ee646ba751e9", transactionIndex: "48", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000000", gas: "137922", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2217574", gasUsed: "93172", confirmations: "3153901"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511183776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588578", timeStamp: "1511183875", hash: "0xf464a0e175aa600b4ebd88c060edd4b1df0f1c3468ccabb09ee73c5ca20c9b93", nonce: "1", blockHash: "0x0203ed43b33202785ce3994cafdf671335c188abf42c21b1bfafe1b648ba004e", transactionIndex: "149", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000", gas: "121455", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3780374", gasUsed: "93172", confirmations: "3153892"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511183875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyGold( \"0x6265736f6973696e6f766900000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588585", timeStamp: "1511183968", hash: "0x7ff9b50c133150eda00ca4596ed986bb6a6f608d62b9912eb2d43db50f7a909e", nonce: "2", blockHash: "0x260feea8da26b8aa029bfb78925f50d53696282f590461a4500bd3f4a6d394bc", transactionIndex: "71", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "11160167989897000", gas: "114200", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xbf907def6265736f6973696e6f766900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004332e393900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a74315f6470707438786f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a323030363738313935310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ac4c49374b5458636b5248546a46337a484f626f736961466a6e565273653841492f317059726e45454247346354524938366c4d5a36642f6c6c516b4a47594b774b626374736c4f343436774f4f70617a75776f314d355667556a6d326c356a512b4e4f397055697075435555526e732b6e31704656734f6939755a4e34704a472b39615a71746c757833636c476a593754795456462b347376503856724e30733370676e4f365357682f5764774249476c3058376b54514c43695a4b38565272426d77396c7a65624e48506f76594a4d69526769576f57565a39414a744c79646f4869722f50333335424866684d4d5448384341567844574c4e454555697170717432344777704b537166453746704175555563696b4a61744b42306f587068396f2b6f5a6b51543851716d617576315046652f2f696a6b54564b416545416474674847572b6d58737550316453474d6c674c7264577a7979353077486e2b686d665068683269316b32366255624c6f334c5447636c7348394f5574787750384b482b4e5344397479794342386c4154343559785973566c55316c47756e55414174537138314c36314f5a4d53705044456a6b38492f6e31394e4669684f5a6548445978596849686e5a7a67784c38583978614e517a78714d41343672596d694c6254396539315152366c34726f5144697234476777334f356f4d56526341467a72336a66303871327852754f616f724c35303447724d4666445765577437527374415968583758552b4a4261586d636333596b42764461356b6c586b6e58665836765573554b6f52387665546b635a547a44305541693954463169596f61447a65736b696a493137586f754a764648654a6d745968725933577848466c6b6d68417746445a576e5a345541634e7170734c4b33695337686e446e47324f456c4d2b54502b355657434b553d0000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2248832", gasUsed: "103610", confirmations: "3153885"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "11160167989897000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_to", value: "0x6265736f6973696e6f7669000000000000000000000000000000000000000000"}, {type: "string", name: "_months", value: `1`}, {type: "string", name: "_priceUsd", value: `3.99`}, {type: "string", name: "_commentId", value: `t1_dppt8xo`}, {type: "string", name: "_nonce", value: `2006781951`}, {type: "string", name: "_signature", value: `LI7KTXckRHTjF3zHObosiaFjnVRse8AI/1pYrnEEBG4cTRI86lMZ6d/llQkJGYKwKbctslO446wOOpazuwo1M5VgUjm2l5jQ+NO9pUipuCUURns+n1pFVsOi9uZN4pJG+9aZqtlux3clGjY7TyTVF+4svP8VrN0s3pgnO6SWh/WdwBIGl0X7kTQLCiZK8VRrBmw9lzebNHPovYJMiRgiWoWVZ9AJtLydoHir/P335BHfhMMTH8CAVxDWLNEEUiqpqt24GwpKSqfE7FpAuUUcikJatKB0oXph9o+oZkQT8Qqmauv1PFe//ijkTVKAeEAdtgHGW+mXsuP1dSGMlgLrdWzyy50wHn+hmfPhh2i1k26bUbLo3LTGclsH9OUtxwP8KH+NSD9tyyCB8lAT45YxYsVlU1lGunUAAtSq81L61OZMSpPDEjk8I/n19NFihOZeHDYxYhIhnZzgxL8X9xaNQzxqMA46rYmiLbT9e91QR6l4roQDir4Ggw3O5oMVRcAFzr3jf08q2xRuOaorL504GrMFfDWeWt7RstAYhX7XU+JBaXmcc3YkBvDa5klXknXfX6vUsUKoR8veTkcZTzD0UAi9TF1iYoaDzeskijI17XouJvFHeJmtYhrY3WxHFlkmhAwFDZWnZ4UAcNqpsLK3iS7hnDnG2OElM+TP+5VWCKU=`}], name: "buyGold", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGold(bytes32,string,string,string,string,string)" ]( "0x6265736f6973696e6f7669000000000000000000000000000000000000000000", `1`, `3.99`, `t1_dppt8xo`, `2006781951`, `LI7KTXckRHTjF3zHObosiaFjnVRse8AI/1pYrnEEBG4cTRI86lMZ6d/llQkJGYKwKbctslO446wOOpazuwo1M5VgUjm2l5jQ+NO9pUipuCUURns+n1pFVsOi9uZN4pJG+9aZqtlux3clGjY7TyTVF+4svP8VrN0s3pgnO6SWh/WdwBIGl0X7kTQLCiZK8VRrBmw9lzebNHPovYJMiRgiWoWVZ9AJtLydoHir/P335BHfhMMTH8CAVxDWLNEEUiqpqt24GwpKSqfE7FpAuUUcikJatKB0oXph9o+oZkQT8Qqmauv1PFe//ijkTVKAeEAdtgHGW+mXsuP1dSGMlgLrdWzyy50wHn+hmfPhh2i1k26bUbLo3LTGclsH9OUtxwP8KH+NSD9tyyCB8lAT45YxYsVlU1lGunUAAtSq81L61OZMSpPDEjk8I/n19NFihOZeHDYxYhIhnZzgxL8X9xaNQzxqMA46rYmiLbT9e91QR6l4roQDir4Ggw3O5oMVRcAFzr3jf08q2xRuOaorL504GrMFfDWeWt7RstAYhX7XU+JBaXmcc3YkBvDa5klXknXfX6vUsUKoR8veTkcZTzD0UAi9TF1iYoaDzeskijI17XouJvFHeJmtYhrY3WxHFlkmhAwFDZWnZ4UAcNqpsLK3iS7hnDnG2OElM+TP+5VWCKU=`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511183968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588594", timeStamp: "1511184062", hash: "0xa2f9f0b0745964f4d6b28b4f1278f56fb92bc07e68c0ff22896ec2b3438aef84", nonce: "3", blockHash: "0x8b2635466f86ebeb2341c713a277c01efa962053a65d666a2bed0b407f4b597b", transactionIndex: "37", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000000000", gas: "121526", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x158952da646a6f6e65795f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1250266", gasUsed: "93236", confirmations: "3153876"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511184062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588609", timeStamp: "1511184229", hash: "0xbc0bb927427b4cdb299f13714233f95dd426370261b0e8ab3abd9c8f3af833c1", nonce: "2", blockHash: "0xa0c15114b6d592ae106521d0ce430fb06201001ed4ab97c344b27ad650300652", transactionIndex: "38", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2758335", gasUsed: "63172", confirmations: "3153861"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511184229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588615", timeStamp: "1511184293", hash: "0x567ff314054d447aadbc5811c91668f78cfd15ba539b0658926465df418ab2e1", nonce: "3", blockHash: "0xa4cdf6e930b9907b8943531d95b8cd2c481fa325c6a6854918cef82464bc2553", transactionIndex: "109", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "300000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4351105", gasUsed: "63172", confirmations: "3153855"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "300000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511184293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588651", timeStamp: "1511184701", hash: "0x556faa7c1b77195494636f275c2ed40f983a2adb9cf2db01b8dd222d96807a48", nonce: "5", blockHash: "0x9378d03c56cbdd3ca57ca433e780b1aa4e69ece106a2156ef5119df013e805b9", transactionIndex: "109", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000", gas: "85987", gasPrice: "5000000000", isError: "0", txreceipt_status: "0", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4148280", gasUsed: "85042", confirmations: "3153819"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511184701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588651", timeStamp: "1511184701", hash: "0xf5845355722e25321d9391b3de030e506d327bf69abf6e2c296d43b7c74d8ee4", nonce: "2", blockHash: "0x9378d03c56cbdd3ca57ca433e780b1aa4e69ece106a2156ef5119df013e805b9", transactionIndex: "126", from: "0x4b20bee98f360d4c5bf7f04a094e779862d0a866", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000000", gas: "102487", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5352097", gasUsed: "93170", confirmations: "3153819"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511184701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "46838431582500" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588659", timeStamp: "1511184826", hash: "0x24090623b97aaf5af0b5777b95837bf95fa447139a3196331fa574f394bc7daf", nonce: "3", blockHash: "0xdb4e47b057faa8698aebb1c8045a5b4e5cf437766884e25b9983abb61aa06ae1", transactionIndex: "74", from: "0xc26bf0fa0413d9a81470353589a50d4fb3f92a30", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000", gas: "85987", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5083899", gasUsed: "78170", confirmations: "3153811"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "100000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511184826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "49745956733500" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588660", timeStamp: "1511184879", hash: "0x576c1e8cd186480068352bd4addda8125f6c0822add55af8a3ae94bef25d34f2", nonce: "4", blockHash: "0x81d73b545ef75b88edc7dceee52899dd0f32a5fb8bb004e19edf20088c072d4a", transactionIndex: "153", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3785008", gasUsed: "63172", confirmations: "3153810"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511184879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588668", timeStamp: "1511184991", hash: "0xc040898da48cd3e33eddc02fb698bdb9b4282f404f5923002fc827e099674697", nonce: "6", blockHash: "0xbfada2ffe66d7201a2aadd418bb20433c896b0fa27a940a340090778a14e9258", transactionIndex: "64", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000", gas: "85987", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6336089", gasUsed: "78170", confirmations: "3153802"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511184991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588668", timeStamp: "1511184991", hash: "0x665e5e231011bea359ae15ebab1eb0c1c08520d69069f12a0ba05d62508b48e5", nonce: "3", blockHash: "0xbfada2ffe66d7201a2aadd418bb20433c896b0fa27a940a340090778a14e9258", transactionIndex: "65", from: "0x4b20bee98f360d4c5bf7f04a094e779862d0a866", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "52987", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6384259", gasUsed: "48170", confirmations: "3153802"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511184991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "46838431582500" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x6e656275726f320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588683", timeStamp: "1511185210", hash: "0xd907a891f5c827b9da76979f3cba08b2f98740e3ff0240926a81d2b990b6f313", nonce: "4", blockHash: "0x6cc1ca99021fae0f394799519608f3800cbd2888c7ddd2ed68a4222e16e8cf7f", transactionIndex: "102", from: "0x4b20bee98f360d4c5bf7f04a094e779862d0a866", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000000", gas: "52987", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da6e656275726f3200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4496719", gasUsed: "48170", confirmations: "3153787"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x6e656275726f3200000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x6e656275726f3200000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511185210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "46838431582500" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588702", timeStamp: "1511185470", hash: "0x0a374845fd53dff0d51d00876178e2e7358fe72890475d20ae553ec8ac67aea0", nonce: "5", blockHash: "0x20e02bd78b7177a0dd04bd3df027d45eabb0073fcabf93356291a902a216b5b1", transactionIndex: "50", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1300557", gasUsed: "63172", confirmations: "3153768"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511185470 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588713", timeStamp: "1511185630", hash: "0xb6cce438fe708f110d59f45c97da4d5f2d1469336d343356e452fb76e74885a8", nonce: "6", blockHash: "0xfdda66214122978f70f0ac62cb09b2a59f84799d59f69d16ec79f6f725613c5c", transactionIndex: "54", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "100000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1340938", gasUsed: "63172", confirmations: "3153757"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511185630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588732", timeStamp: "1511185782", hash: "0xcc563bd27a78af92fda0de9d37c0ef85bc3a98eb993af28418206f819122263c", nonce: "7", blockHash: "0x35d3a9445995588820ae8b42fa4d08414555f70cb00f98fddbf4058c011e43b0", transactionIndex: "54", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1916615", gasUsed: "63172", confirmations: "3153738"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511185782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588744", timeStamp: "1511185966", hash: "0x80454f2fb3234dc54a29cdf45ec0e7746e6315575755502fa0237ecceca9dba7", nonce: "8", blockHash: "0xd4603182eb324ee98530f20790b46b60e6ee6fd0ae1f2c0e8ed2cffa55399dba", transactionIndex: "51", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000000", gas: "88455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1250981", gasUsed: "63172", confirmations: "3153726"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511185966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyGold( \"0x4d61746b6f39350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588756", timeStamp: "1511186113", hash: "0x380a33c1e985326c6fc66e93d6db365a61918f345cc9150998f8c6c39db8b760", nonce: "7", blockHash: "0x4218af7b463a8ffb90965a1d67bfef99eee691b8eda3e78d121dcba37c989cac", transactionIndex: "171", from: "0xde71b2bb918d167ac27109c05a9e387dc35d4f1e", to: "0x690508422d576edb99d676320ea251036d164062", value: "11154728761634000", gas: "113858", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xbf907def4d61746b6f39350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004332e393900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a74315f646f757861376f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009393332333730383634000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ac7a48734f427969575646386a69515967616d387055756f4750476244386a6a2f4d3948522f3149447831623472723552627a34644a31446a71636e7a6e304e3673676258794d673734494d4b585a303235673657664a565739484c4b6634335a776f524a674b764e6b6f3734493152577565382b302b306636624739716b3544747362687a6131673370544e583674435656613561486649706a6d4967717764345565707771466f4b67344d544c4b4e72672b764f34515159356d33543272797a624d425864326c4a614754644a654b4a6b58327263564a42636646426d5856366b75504d3348776e64534e334b6a596132777452625a624f666b2f7661526853416161427356535448656c4d6e46724d596b4a4b596b6446412f62762f5262793670654e516b2b4f78733236324a7452506b37496f72564475454146643845677775626934657a413276433956793678744739374f4e66736b4a33547653794a44485562424c74363537683370452b4e4279586231724f3754617850776b712b507265586e6230586b4a765a7246396e732f4e3745726b4b57336e30526a57497a2b596a4e71326a73507438574b486d414d576e5a75497365666e5856743758384579326a626a49335571452b794e5032507437574271356541397362695754744c655a5166496b495879374c722f347a65476e324c5678374e48463274424b76334558556435706a3741464976495754664e6c4541714c445043782f3158434d3642655538796a555546694c734e324752505943344a696a3973752f697135476f6c447753683347325550414f7a6a636869744d2b354132476f722f6e347046587a777a394444335547655a41702b765a723076573655774f354750536b674d423067343558615934623456625169426d31594b355061546351664163525a7036544e744d454d306b3d0000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5317585", gasUsed: "103290", confirmations: "3153714"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "11154728761634000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_to", value: "0x4d61746b6f393500000000000000000000000000000000000000000000000000"}, {type: "string", name: "_months", value: `1`}, {type: "string", name: "_priceUsd", value: `3.99`}, {type: "string", name: "_commentId", value: `t1_douxa7o`}, {type: "string", name: "_nonce", value: `932370864`}, {type: "string", name: "_signature", value: `zHsOByiWVF8jiQYgam8pUuoGPGbD8jj/M9HR/1IDx1b4rr5Rbz4dJ1Djqcnzn0N6sgbXyMg74IMKXZ025g6WfJVW9HLKf43ZwoRJgKvNko74I1RWue8+0+0f6bG9qk5Dtsbhza1g3pTNX6tCVVa5aHfIpjmIgqwd4UepwqFoKg4MTLKNrg+vO4QQY5m3T2ryzbMBXd2lJaGTdJeKJkX2rcVJBcfFBmXV6kuPM3HwndSN3KjYa2wtRbZbOfk/vaRhSAaaBsVSTHelMnFrMYkJKYkdFA/bv/Rby6peNQk+Oxs262JtRPk7IorVDuEAFd8Egwubi4ezA2vC9Vy6xtG97ONfskJ3TvSyJDHUbBLt657h3pE+NByXb1rO7TaxPwkq+PreXnb0XkJvZrF9ns/N7ErkKW3n0RjWIz+YjNq2jsPt8WKHmAMWnZuIsefnXVt7X8Ey2jbjI3UqE+yNP2Pt7WBq5eA9sbiWTtLeZQfIkIXy7Lr/4zeGn2LVx7NHF2tBKv3EXUd5pj7AFIvIWTfNlEAqLDPCx/1XCM6BeU8yjUUFiLsN2GRPYC4Jij9su/iq5GolDwSh3G2UPAOzjchitM+5A2Gor/n4pFXzwz9DD3UGeZAp+vZr0vW6UwO5GPSkgMB0g45XaY4b4VbQiBm1YK5PaTcQfAcRZp6TNtMEM0k=`}], name: "buyGold", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGold(bytes32,string,string,string,string,string)" ]( "0x4d61746b6f393500000000000000000000000000000000000000000000000000", `1`, `3.99`, `t1_douxa7o`, `932370864`, `zHsOByiWVF8jiQYgam8pUuoGPGbD8jj/M9HR/1IDx1b4rr5Rbz4dJ1Djqcnzn0N6sgbXyMg74IMKXZ025g6WfJVW9HLKf43ZwoRJgKvNko74I1RWue8+0+0f6bG9qk5Dtsbhza1g3pTNX6tCVVa5aHfIpjmIgqwd4UepwqFoKg4MTLKNrg+vO4QQY5m3T2ryzbMBXd2lJaGTdJeKJkX2rcVJBcfFBmXV6kuPM3HwndSN3KjYa2wtRbZbOfk/vaRhSAaaBsVSTHelMnFrMYkJKYkdFA/bv/Rby6peNQk+Oxs262JtRPk7IorVDuEAFd8Egwubi4ezA2vC9Vy6xtG97ONfskJ3TvSyJDHUbBLt657h3pE+NByXb1rO7TaxPwkq+PreXnb0XkJvZrF9ns/N7ErkKW3n0RjWIz+YjNq2jsPt8WKHmAMWnZuIsefnXVt7X8Ey2jbjI3UqE+yNP2Pt7WBq5eA9sbiWTtLeZQfIkIXy7Lr/4zeGn2LVx7NHF2tBKv3EXUd5pj7AFIvIWTfNlEAqLDPCx/1XCM6BeU8yjUUFiLsN2GRPYC4Jij9su/iq5GolDwSh3G2UPAOzjchitM+5A2Gor/n4pFXzwz9DD3UGeZAp+vZr0vW6UwO5GPSkgMB0g45XaY4b4VbQiBm1YK5PaTcQfAcRZp6TNtMEM0k=`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511186113 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7069422215312500" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyGold( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588814", timeStamp: "1511186803", hash: "0xa5f872b8d0b33240919777b90fbc84c4d5f4b74131d69e17e7b000bafb010c08", nonce: "5", blockHash: "0xcf6a1f746a9e2fa8cfe4f093937fcc8ad20dd658c679ee9721d84dff1680797e", transactionIndex: "96", from: "0x4b20bee98f360d4c5bf7f04a094e779862d0a866", to: "0x690508422d576edb99d676320ea251036d164062", value: "11165612525261000", gas: "113777", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf907def646a6f6e65795f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004332e393900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000974335f37627471697800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009323131323739323331000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ac6657633832736f2f652f616841394c70343239314c33356f4f6b36525270777879487a342f334f4e7279326e456b38582f4a4b694b50455936697165694f7a55654d65707172385144386d53746563747455664b6b2f7768374176534c4853587236312b327858654e504a4342594b6349543932304130744b61437a584b6756396b384949627a556e5177653161742b6b7676525752766b55514f57654c39563755746e58766d4c594d71666b75472b724a3068787a7a357179566678614b537264594234316e6e38525353314c38722f534f703354534a35732b317a7956386f72617a73547748436130494562736b5762724f476345714952467836352b61597942713461484257684d4f5843596b31434b7134457446363746767930346562545752547965726e537839764c4a5878423632636e2b314e416a56444d53584f6d79465a486e6830674f37616e56664d39512f4637456879444e38656b6332524b4b42636b684c5958687674616a5748476d58514f4d2b4357526e436e4a7854614e374d5137614741456b355a344f5456316f68626e47366931757a2b5a67426c553064494834696e66396d664f356b57776b4155744c554737634f773861575854746f4341562f39334b546b3367756b344f486b53354a726547423170376a6a4568574d4f74645033573048694b5a79576a68456247554843454537393555384732436f6c712b6a41677a42416a41684c696d324e7662436569642b4e565a7a3657456168476133695436453962764c56497863534d4867666747474e416a574b4b4175764d516464342b6a6e6d4953685054796e585862415845486b774b7959632b625a2b4c694d5456626a4c44643836317a4e5566542f486e6746785a676a3977727558504b6e695754565966652b514e64455567725a4573612f74632f2b46724433777465413d0000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5421733", gasUsed: "103226", confirmations: "3153656"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "11165612525261000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_to", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}, {type: "string", name: "_months", value: `1`}, {type: "string", name: "_priceUsd", value: `3.99`}, {type: "string", name: "_commentId", value: `t3_7btqix`}, {type: "string", name: "_nonce", value: `211279231`}, {type: "string", name: "_signature", value: `fWc82so/e/ahA9Lp4291L35oOk6RRpwxyHz4/3ONry2nEk8X/JKiKPEY6iqeiOzUeMepqr8QD8mStecttUfKk/wh7AvSLHSXr61+2xXeNPJCBYKcIT920A0tKaCzXKgV9k8IIbzUnQwe1at+kvvRWRvkUQOWeL9V7UtnXvmLYMqfkuG+rJ0hxzz5qyVfxaKSrdYB41nn8RSS1L8r/SOp3TSJ5s+1zyV8orazsTwHCa0IEbskWbrOGcEqIRFx65+aYyBq4aHBWhMOXCYk1CKq4EtF67Fvy04ebTWRTyernSx9vLJXxB62cn+1NAjVDMSXOmyFZHnh0gO7anVfM9Q/F7EhyDN8ekc2RKKBckhLYXhvtajWHGmXQOM+CWRnCnJxTaN7MQ7aGAEk5Z4OTV1ohbnG6i1uz+ZgBlU0dIH4inf9mfO5kWwkAUtLUG7cOw8aWXTtoCAV/93KTk3guk4OHkS5JreGB1p7jjEhWMOtdP3W0HiKZyWjhEbGUHCEE795U8G2Colq+jAgzBAjAhLim2NvbCeid+NVZz6WEahGa3iT6E9bvLVIxcSMHgfgGGNAjWKKAuvMQdd4+jnmIShPTynXXbAXEHkwKyYc+bZ+LiMTVbjLDd861zNUfT/HngFxZgj9wruXPKniWTVYfe+QNdEUgrZEsa/tc/+FrD3wteA=`}], name: "buyGold", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGold(bytes32,string,string,string,string,string)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", `1`, `3.99`, `t3_7btqix`, `211279231`, `fWc82so/e/ahA9Lp4291L35oOk6RRpwxyHz4/3ONry2nEk8X/JKiKPEY6iqeiOzUeMepqr8QD8mStecttUfKk/wh7AvSLHSXr61+2xXeNPJCBYKcIT920A0tKaCzXKgV9k8IIbzUnQwe1at+kvvRWRvkUQOWeL9V7UtnXvmLYMqfkuG+rJ0hxzz5qyVfxaKSrdYB41nn8RSS1L8r/SOp3TSJ5s+1zyV8orazsTwHCa0IEbskWbrOGcEqIRFx65+aYyBq4aHBWhMOXCYk1CKq4EtF67Fvy04ebTWRTyernSx9vLJXxB62cn+1NAjVDMSXOmyFZHnh0gO7anVfM9Q/F7EhyDN8ekc2RKKBckhLYXhvtajWHGmXQOM+CWRnCnJxTaN7MQ7aGAEk5Z4OTV1ohbnG6i1uz+ZgBlU0dIH4inf9mfO5kWwkAUtLUG7cOw8aWXTtoCAV/93KTk3guk4OHkS5JreGB1p7jjEhWMOtdP3W0HiKZyWjhEbGUHCEE795U8G2Colq+jAgzBAjAhLim2NvbCeid+NVZz6WEahGa3iT6E9bvLVIxcSMHgfgGGNAjWKKAuvMQdd4+jnmIShPTynXXbAXEHkwKyYc+bZ+LiMTVbjLDd861zNUfT/HngFxZgj9wruXPKniWTVYfe+QNdEUgrZEsa/tc/+FrD3wteA=`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511186803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "46838431582500" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x656c6930747a000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588996", timeStamp: "1511189769", hash: "0xced5fec2e9602f898963f70a746e7a198e49f9d978a82420d83fee21101e2127", nonce: "0", blockHash: "0xa8b8f99a196ccaba645480fda66e752de0438babaefcd5b78cfda9f0f0ad21a3", transactionIndex: "97", from: "0x1d1fa9b986b2510a41f9b07329e9e3b1515e1f9e", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219096", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd656c6930747a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000090424241612b47567579724b4f444e47422b586e337759614f3979307935387777305658787833763765307053787377437a6b6f4c576e69486d5142716f4a6163733675574e4b555473327a717a6f6a54313230335a77415948416d35686165347472656437585578654a48355a4a4f485639334e3875416d524a6642557737476b444458482f65555a7857585243504e00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3944099", gasUsed: "199178", confirmations: "3153474"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x656c6930747a0000000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BBAa+GVuyrKODNGB+Xn3wYaO9y0y58ww0VXxx3v7e0pSxswCzkoLWniHmQBqoJacs6uWNKUTs2zqzojT1203ZwAYHAm5hae4tred7XUxeJH5ZJOHV93N8uAmRJfBUw7GkDDXH/eUZxWXRCPN`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x656c6930747a0000000000000000000000000000000000000000000000000000", `BBAa+GVuyrKODNGB+Xn3wYaO9y0y58ww0VXxx3v7e0pSxswCzkoLWniHmQBqoJacs6uWNKUTs2zqzojT1203ZwAYHAm5hae4tred7XUxeJH5ZJOHV93N8uAmRJfBUw7GkDDXH/eUZxWXRCPN`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511189769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "50575634957843500" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x00739d596736d86056d36d48071fe1d66963... )", async function( ) {
		const txOriginal = {blockNumber: "4589003", timeStamp: "1511189918", hash: "0x5d25ada18b8df924bedec8cd67d5e6c3a37f109ca99357e3b40e09aa3a2a9ca1", nonce: "338134", blockHash: "0xf5db8e3a849065c1bf8b623c0748b997c7edacc89af78b3dc7bc45bc77bec060", transactionIndex: "143", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e00739d596736d86056d36d48071fe1d669632e81a5b442e68604ff88a804568d00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000006656c6930747a0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4657355", gasUsed: "83100", confirmations: "3153467"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x00739d596736d86056d36d48071fe1d669632e81a5b442e68604ff88a804568d"}, {type: "string", name: "_result", value: `eli0tz`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x00739d596736d86056d36d48071fe1d669632e81a5b442e68604ff88a804568d", `eli0tz`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511189918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x537465724c75000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589098", timeStamp: "1511191141", hash: "0xfa28796adc7491a801249b0b9de9f323d72690a2d62814d5adacc21550786bed", nonce: "0", blockHash: "0xc78ae9c35963463ffe841dd51a17fb7f53bcbd82805936538d26502cf5270b78", transactionIndex: "56", from: "0xe07cab35275c4f0be90d6f4900639ec301fc9b69", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219096", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd537465724c75000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000090424c624d2b3961693776526b50477179374837725262367179424c755a7934652b54757243366543706c73496c6770496c34582f777154732b66566c4e556779756f7567416d5072564866317257634e49456e7135424f66634f6b39414c49487679445550456751474e636e452f72516c352b683651306e513930694f5950676e50616c6a6642414167707a6b7a5a3300000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3216993", gasUsed: "199178", confirmations: "3153372"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x537465724c750000000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BLbM+9ai7vRkPGqy7H7rRb6qyBLuZy4e+TurC6eCplsIlgpIl4X/wqTs+fVlNUgyuougAmPrVHf1rWcNIEnq5BOfcOk9ALIHvyDUPEgQGNcnE/rQl5+h6Q0nQ90iOYPgnPaljfBAAgpzkzZ3`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x537465724c750000000000000000000000000000000000000000000000000000", `BLbM+9ai7vRkPGqy7H7rRb6qyBLuZy4e+TurC6eCplsIlgpIl4X/wqTs+fVlNUgyuougAmPrVHf1rWcNIEnq5BOfcOk9ALIHvyDUPEgQGNcnE/rQl5+h6Q0nQ90iOYPgnPaljfBAAgpzkzZ3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511191141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "2044914956843500" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x646a6f6e65795f0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589099", timeStamp: "1511191153", hash: "0x3cd1a4dd7a4e060cd03ec376fd3b663853a9da39f18e78ea3a8dad82d8ee870e", nonce: "0", blockHash: "0x4e8315918d8573e345a9741d7501c80d6b0a245dcde7ba77b1c6d2cb0b8a0bca", transactionIndex: "69", from: "0xe18a73290bfd400edf1a123c3d87e1504d592ff4", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "223908", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd646a6f6e65795f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000009042485853676955312f444f3768574a62455141696a5575305335584f6d5765325777616170393142454248576b6c72466e393832425930723342723331634464414f354b314275446c645244774b316e7a51324b526a2b55677259594143664963736e6f5671324135324e68656b624276374f447870746e363051334f34693231466e63795779683138795a6e31477500000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4596762", gasUsed: "199242", confirmations: "3153371"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x646a6f6e65795f00000000000000000000000000000000000000000000000000"}, {type: "string", name: "_token", value: `BHXSgiU1/DO7hWJbEQAijUu0S5XOmWe2Wwaap91BEBHWklrFn982BY0r3Br31cDdAO5K1BuDldRDwK1nzQ2KRj+UgrYYACfIcsnoVq2A52NhekbBv7ODxptn60Q3O4i21FncyWyh18yZn1Gu`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x646a6f6e65795f00000000000000000000000000000000000000000000000000", `BHXSgiU1/DO7hWJbEQAijUu0S5XOmWe2Wwaap91BEBHWklrFn982BY0r3Br31cDdAO5K1BuDldRDwK1nzQ2KRj+UgrYYACfIcsnoVq2A52NhekbBv7ODxptn60Q3O4i21FncyWyh18yZn1Gu`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511191153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "157364420390500" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyGold( \"0x537465724c75000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589104", timeStamp: "1511191235", hash: "0x5d00d99e8ae9a528f77d037727c7cf1636b3f261159b907309d08c54c11ac487", nonce: "1", blockHash: "0x6b579d46b376a0ab290e4948d4624a5eec7c78b90953375477dfa5d3b68b3bd1", transactionIndex: "77", from: "0xe18a73290bfd400edf1a123c3d87e1504d592ff4", to: "0x690508422d576edb99d676320ea251036d164062", value: "11070039036453000", gas: "113848", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf907def537465724c75000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004332e393900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a74315f646f757835333100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a313136303537323434350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ac6a55707465334f70543346714b4e72574c516e30575637426f566169326950324438772b58415a7968424b506f695564656f664854497535586239776f667671716973756433505a677a697250515035425264663475484a396b475858776d64477158624371727052795650504f66644a4f38332b38625631456f6968762f67375038396e62516d456566502b377a5a6f3834454b6b6b4a6977774e6d644a4e564149324d31647a533973786e3133493063615370384c62795274554b4e7731726b526c6f2b4e43314d76445833427144396c6c503246757a76524174715a6c4e506f7463567945574a584c43694b313736726670422f75514530516c6276666b784f69573332654352594e792b34352b69317056734738733469692b61693667584c6c796d354d73467a6c564d6c3845555a456633423979412f5a6e4b3932644a726c59546d346d5175463973486f302f7370794d526b48697a47724658463879486152696552623641484a746538633756626f664a6f4357376c79576d626854526a31466263734b37326f37452f734a6c2b367976784971685a7973466834673634364f35485736623642387a6146506f2b6935476662635145614f6a37666830434a2b5777383364335732356c63503056335533424d6767664f363064694864565945637933734d46366b56673349566b3676715758516f34683952445a357661534e57467a37793677382b6b77424746715a553857347a4b333937396e71665341472f7836695a366d344a794f2b70574e7a76626c756976587862595458656e493737737049597057787a5868484e6d336d624358463973336c6d534338494d4a613547556159344b66707a43706d77796c714661526c48534c4d3161454573596a533565775961586b676f707a486459436d4677554c465138666b64576a2b784566425a64773d0000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3267023", gasUsed: "103290", confirmations: "3153366"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "11070039036453000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_to", value: "0x537465724c750000000000000000000000000000000000000000000000000000"}, {type: "string", name: "_months", value: `1`}, {type: "string", name: "_priceUsd", value: `3.99`}, {type: "string", name: "_commentId", value: `t1_doux531`}, {type: "string", name: "_nonce", value: `1160572445`}, {type: "string", name: "_signature", value: `jUpte3OpT3FqKNrWLQn0WV7BoVai2iP2D8w+XAZyhBKPoiUdeofHTIu5Xb9wofvqqisud3PZgzirPQP5BRdf4uHJ9kGXXwmdGqXbCqrpRyVPPOfdJO83+8bV1Eoihv/g7P89nbQmEefP+7zZo84EKkkJiwwNmdJNVAI2M1dzS9sxn13I0caSp8LbyRtUKNw1rkRlo+NC1MvDX3BqD9llP2FuzvRAtqZlNPotcVyEWJXLCiK176rfpB/uQE0QlbvfkxOiW32eCRYNy+45+i1pVsG8s4ii+ai6gXLlym5MsFzlVMl8EUZEf3B9yA/ZnK92dJrlYTm4mQuF9sHo0/spyMRkHizGrFXF8yHaRieRb6AHJte8c7VbofJoCW7lyWmbhTRj1FbcsK72o7E/sJl+6yvxIqhZysFh4g646O5HW6b6B8zaFPo+i5GfbcQEaOj7fh0CJ+Ww83d3W25lcP0V3U3BMggfO60diHdVYEcy3sMF6kVg3IVk6vqWXQo4h9RDZ5vaSNWFz7y6w8+kwBGFqZU8W4zK3979nqfSAG/x6iZ6m4JyO+pWNzvbluivXxbYTXenI77spIYpWxzXhHNm3mbCXF9s3lmSC8IMJa5GUaY4KfpzCpmwylqFaRlHSLM1aEEsYjS5ewYaXkgopzHdYCmFwULFQ8fkdWj+xEfBZdw=`}], name: "buyGold", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGold(bytes32,string,string,string,string,string)" ]( "0x537465724c750000000000000000000000000000000000000000000000000000", `1`, `3.99`, `t1_doux531`, `1160572445`, `jUpte3OpT3FqKNrWLQn0WV7BoVai2iP2D8w+XAZyhBKPoiUdeofHTIu5Xb9wofvqqisud3PZgzirPQP5BRdf4uHJ9kGXXwmdGqXbCqrpRyVPPOfdJO83+8bV1Eoihv/g7P89nbQmEefP+7zZo84EKkkJiwwNmdJNVAI2M1dzS9sxn13I0caSp8LbyRtUKNw1rkRlo+NC1MvDX3BqD9llP2FuzvRAtqZlNPotcVyEWJXLCiK176rfpB/uQE0QlbvfkxOiW32eCRYNy+45+i1pVsG8s4ii+ai6gXLlym5MsFzlVMl8EUZEf3B9yA/ZnK92dJrlYTm4mQuF9sHo0/spyMRkHizGrFXF8yHaRieRb6AHJte8c7VbofJoCW7lyWmbhTRj1FbcsK72o7E/sJl+6yvxIqhZysFh4g646O5HW6b6B8zaFPo+i5GfbcQEaOj7fh0CJ+Ww83d3W25lcP0V3U3BMggfO60diHdVYEcy3sMF6kVg3IVk6vqWXQo4h9RDZ5vaSNWFz7y6w8+kwBGFqZU8W4zK3979nqfSAG/x6iZ6m4JyO+pWNzvbluivXxbYTXenI77spIYpWxzXhHNm3mbCXF9s3lmSC8IMJa5GUaY4KfpzCpmwylqFaRlHSLM1aEEsYjS5ewYaXkgopzHdYCmFwULFQ8fkdWj+xEfBZdw=`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511191235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "157364420390500" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd92003c1cc27c5a277a28e05af496d61148d... )", async function( ) {
		const txOriginal = {blockNumber: "4589108", timeStamp: "1511191283", hash: "0xaa781e6b385c5a72595f60cb03f1969359f9f8b87fcc46a887ec3d9989442627", nonce: "338148", blockHash: "0xb614777cda999603bca704c9d2fe2658fcab693505b8c16c946712985caedec5", transactionIndex: "19", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297ed92003c1cc27c5a277a28e05af496d61148d12014473c796bc785bc3077dede600000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000006537465724c750000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "925625", gasUsed: "98164", confirmations: "3153362"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0xd92003c1cc27c5a277a28e05af496d61148d12014473c796bc785bc3077dede6"}, {type: "string", name: "_result", value: `SterLu`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xd92003c1cc27c5a277a28e05af496d61148d12014473c796bc785bc3077dede6", `SterLu`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511191283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xb0b25ae39e144bb521b91edf9cb036032891... )", async function( ) {
		const txOriginal = {blockNumber: "4589108", timeStamp: "1511191283", hash: "0xf07420e92be8edc027312a870f0e2a468c272133d8b8318a0ff9bd38b7618c62", nonce: "338149", blockHash: "0xb614777cda999603bca704c9d2fe2658fcab693505b8c16c946712985caedec5", transactionIndex: "20", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297eb0b25ae39e144bb521b91edf9cb036032891045e642087fa3e22def0a860963700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000007646a6f6e65795f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1008853", gasUsed: "83228", confirmations: "3153362"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0xb0b25ae39e144bb521b91edf9cb036032891045e642087fa3e22def0a8609637"}, {type: "string", name: "_result", value: `djoney_`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xb0b25ae39e144bb521b91edf9cb036032891045e642087fa3e22def0a8609637", `djoney_`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511191283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x537465724c75000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589110", timeStamp: "1511191326", hash: "0x2f944c15cf13bbf958b81c37aea875622508dfd8dab42cbad1c232eef09e5765", nonce: "9", blockHash: "0x608ca455e2e525cf59faf16330a0bdbdd83612fa335c3ba135b0cd802246ce98", transactionIndex: "109", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "1000000000000", gas: "121455", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da537465724c750000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2878046", gasUsed: "93172", confirmations: "3153360"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x537465724c750000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x537465724c750000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511191326 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: createUser( \"0x736f6d655f72616e646f6d5f757365725f30... )", async function( ) {
		const txOriginal = {blockNumber: "4589119", timeStamp: "1511191454", hash: "0x12bc54e6a4b3458ca1f3e3a7c4c4bdc9b13151669e5e4a1815ad66bddf313dd7", nonce: "0", blockHash: "0xba49b252d2577083b810b417326c1c8e01c55bcb1aa5ffcfeb2a9b1539eb878e", transactionIndex: "48", from: "0x69cc780bf4f63380c4bc745ee338cb678752301a", to: "0x690508422d576edb99d676320ea251036d164062", value: "5663571043156500", gas: "219941", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x097b36dd736f6d655f72616e646f6d5f757365725f300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000904241424c4472414268522b737364466e397a306e6873395176667572525068636f7a656d747779535554534b584737664f6273736f6a41757834433276442b37565465373355646372507a4c784b756a79497941615172667a6e615177496c5049794c62386b534d5248686b37374c70775a456d54736f6d42446d3967396d4b7761526a39484f75343132422f2b635a00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2914271", gasUsed: "199946", confirmations: "3153351"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "5663571043156500" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x736f6d655f72616e646f6d5f757365725f300000000000000000000000000000"}, {type: "string", name: "_token", value: `BABLDrABhR+ssdFn9z0nhs9QvfurRPhcozemtwySUTSKXG7fObssojAux4C2vD+7VTe73UdcrPzLxKujyIyAaQrfznaQwIlPIyLb8kSMRHhk77LpwZEmTsomBDm9g9mKwaRj9HOu412B/+cZ`}], name: "createUser", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createUser(bytes32,string)" ]( "0x736f6d655f72616e646f6d5f757365725f300000000000000000000000000000", `BABLDrABhR+ssdFn9z0nhs9QvfurRPhcozemtwySUTSKXG7fObssojAux4C2vD+7VTe73UdcrPzLxKujyIyAaQrfznaQwIlPIyLb8kSMRHhk77LpwZEmTsomBDm9g9mKwaRj9HOu412B/+cZ`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511191454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "72089954843500" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8778db9fd968a9e3b4ea6d61930ff6c7aa69... )", async function( ) {
		const txOriginal = {blockNumber: "4589133", timeStamp: "1511191595", hash: "0xa3e4c7fef6df41f6ec9685972a8d5bc61b0348ce0a41dfda218d114036edd17b", nonce: "338157", blockHash: "0x9a032c49c8fb9dd6fe79a24634b03e16033bc9be84e3c69cd039cce8d8d53468", transactionIndex: "21", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x690508422d576edb99d676320ea251036d164062", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x27dc297e8778db9fd968a9e3b4ea6d61930ff6c7aa69d090d3d635f82586a50b072ce41700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000012736f6d655f72616e646f6d5f757365725f300000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "890992", gasUsed: "83932", confirmations: "3153337"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_myid", value: "0x8778db9fd968a9e3b4ea6d61930ff6c7aa69d090d3d635f82586a50b072ce417"}, {type: "string", name: "_result", value: `some_random_user_0`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x8778db9fd968a9e3b4ea6d61930ff6c7aa69d090d3d635f82586a50b072ce417", `some_random_user_0`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511191595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x626f62616e6d000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589289", timeStamp: "1511193632", hash: "0xe5743ca98e26b2cb63e714a55f6644cd26b5b1a3237f0b460e95a183f65bf087", nonce: "1", blockHash: "0xf4f10a1cfd1bbc6fdef95bd9c8fa4bc19e87c257200e37a5ba0ab1064a5b389e", transactionIndex: "28", from: "0x1d1fa9b986b2510a41f9b07329e9e3b1515e1f9e", to: "0x690508422d576edb99d676320ea251036d164062", value: "10000000000000000", gas: "102417", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x158952da626f62616e6d0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1107724", gasUsed: "93106", confirmations: "3153181"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x626f62616e6d0000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x626f62616e6d0000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511193632 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "50575634957843500" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: tipUser( \"0x766f6e756d00000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589342", timeStamp: "1511194382", hash: "0xc3a28b31bea45b82d46ac4e5e397c6de77f6fce77a59f0250f368435ba32f53e", nonce: "10", blockHash: "0x68fc1048ee970cfb34659707e755f7d8f8038fae991935fa5f9d69c878944dfa", transactionIndex: "88", from: "0xc834b38ba4470b43537169cd404fffb4d5615f12", to: "0x690508422d576edb99d676320ea251036d164062", value: "4000000000000000", gas: "102346", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x158952da766f6e756d000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5089180", gasUsed: "93042", confirmations: "3153128"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_username", value: "0x766f6e756d000000000000000000000000000000000000000000000000000000"}], name: "tipUser", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "tipUser(bytes32)" ]( "0x766f6e756d000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511194382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3061908388616500" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "173764801935140880" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
