const ESOP = artifacts.require( "./ESOP.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ESOP" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xda7c27c04f66842FAF20644814B644E25E1766Ea", "0x11A1cEE1C6681EE8e6891164a3e3EAf17Ed0E207", "0x0c53Fe380ABA335d144b6F0dbC6B588633f783d7", "0xF3A85b1c8818629e52D61236e9FF5f531E52d8Ed", "0x2aD565023D39f5F8A6AFDc625C0285BBC2D52276", "0xD35504e0F9BDCF8bcA1cE7EC51Fa2Db514029182", "0x6a58a4e262B6eAd9EB40f41313D6D1FbbbB41c16", "0x523143aa3105D43abEEc9beF0E055585beafE2eA", "0xAC7bf7D1fE17050D27260f22A428A2BaB53cD4AC", "0x9899037ae30430928F3bd702Ba573A3Bb540A6f1", "0xD744556989864B2A35784ED46b39b0e3144445AA", "0x2597e3EEF899164fd2E74b969c536C738E3E462F", "0x03158526a0264CC2a83dD18c56d4fE8E612B2Dc1", "0xf888ED6beee93a36FB8BCD8E41F2C3EAA2570C81", "0x1Eb1B679dFeA232DB3EDd9F280213FF46B26303C", "0x5712f5c9af2f98D3d02a2728067Dc781a5bAC677", "0xfE5b9418d0b295f00D2890927F2ECf595902FAF4", "0x4a12930eC5E332BC3884Df385d68CdcD21F80296", "0x3ECc4c639cF7E05D8082A75c7D0EE9242b964507", "0x1CDF10C007AE95E59Ad904221084e47B0EEC8bef", "0x3a2faD948734806448C3D0922ab16915F49E1583", "0x21641e088D2514d1b1CbA5CF80c0C288Ce12c4B8", "0x8a6A8d4f88534C96883eB67b9211a3682b1ab867", "0xf6178758Ac7B3e266e89B6c9FC4094c7FDCBa8D6", "0xE673Cc1Ee50b57EDEa036394b5b1A3312778582e"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "employees", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "exerciseOptionsDeadline", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalExtraOptions", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MINIMUM_MANUAL_SIGN_PERIOD", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "esopState", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "rootOfTrust", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "companyAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "optionsCalculator", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "codeUpdateState", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "ESOPLegalWrapperIPFSHash", outputs: [{name: "", type: "bytes"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "conversionOfferedAt", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "remainingPoolOptions", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "e", type: "address"}, {name: "calcAtTime", type: "uint32"}], name: "calcEffectiveOptionsForEmployee", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentTime", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "optionsConverter", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalPoolOptions", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "suspendedAt", type: "uint32"}], name: "SuspendEmployee", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "continuedAt", type: "uint32"}, {indexed: false, name: "suspendedPeriod", type: "uint32"}], name: "ContinueSuspendedEmployee", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "exercisedFor", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "disableAcceleratedVesting", type: "bool"}], name: "EmployeeOptionsExercised", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "migration", type: "address"}, {indexed: false, name: "pool", type: "uint256"}, {indexed: false, name: "extra", type: "uint256"}], name: "EmployeeMigrated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "company", type: "address"}], name: "ESOPOpened", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "company", type: "address"}, {indexed: false, name: "converter", type: "address"}, {indexed: false, name: "convertedAt", type: "uint32"}, {indexed: false, name: "exercisePeriodDeadline", type: "uint32"}], name: "OptionsConversionOffered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "rc", type: "uint8"}], name: "ReturnCode", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ESOPOffered(address,address,uint32,uint32)", "EmployeeSignedToESOP(address)", "SuspendEmployee(address,uint32)", "ContinueSuspendedEmployee(address,uint32,uint32)", "TerminateEmployee(address,address,uint32,uint8)", "EmployeeOptionsExercised(address,address,uint32,bool)", "EmployeeMigrated(address,address,uint256,uint256)", "ESOPOpened(address)", "OptionsConversionOffered(address,address,uint32,uint32)", "ReturnCode(uint8)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x20eea675d38b6201dfef10fe1b4211fc58b92a6be381b306500ebb90fdd2f8b2", "0x06155e9532ee6dc12fad75fb22ffb46f42fc8c2a6342389c1ac5776da7deab10", "0xa37936f901fbcd5e8455f5da64afeb1eee7e74207631fa526cce2e557e8558ac", "0x6de60a07a7acf5461118186c54b115d32be4a3cc02b6a674a6b56424dbedc885", "0xe50007b93d68f8c61678fdbb36438f34cd76aeeba091445432b39cf3cff7edc0", "0xfc0174951e12af0f97c4b84ada6bdb5015397b78a3d712b134dc42b020fe060b", "0xa2b60f437b09871b72346a12264375fdf4a272a23df50039401a420a0727e317", "0xe78e3ab131dd310bd60879eedc2fd4820925351befc3ec2cb94cc674c8800c10", "0x431ef9b58d5b4525645a818291a692f150c556f6b681cdd8c1631a47676ee5c3", "0xe5357b0241f8529e759880237b81c113a08b50b43251aa0d18d1578a6e32dedf"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3884283 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 5835115 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "company", value: 4}, {type: "address", name: "pRootOfTrust", value: 5}, {type: "address", name: "pOptionsCalculator", value: 6}, {type: "address", name: "pEmployeesList", value: 7}], name: "ESOP", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "employees", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "employees()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "exerciseOptionsDeadline", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exerciseOptionsDeadline()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalExtraOptions", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalExtraOptions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MINIMUM_MANUAL_SIGN_PERIOD", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MINIMUM_MANUAL_SIGN_PERIOD()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "esopState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "esopState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rootOfTrust", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rootOfTrust()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "companyAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "companyAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "optionsCalculator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "optionsCalculator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "codeUpdateState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "codeUpdateState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ESOPLegalWrapperIPFSHash", outputs: [{name: "", type: "bytes"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ESOPLegalWrapperIPFSHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "conversionOfferedAt", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "conversionOfferedAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "remainingPoolOptions", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "remainingPoolOptions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "e", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint32", name: "calcAtTime", value: random.range( maxRandom )}], name: "calcEffectiveOptionsForEmployee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcEffectiveOptionsForEmployee(address,uint32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentTime", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "optionsConverter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "optionsConverter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalPoolOptions", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPoolOptions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ESOP", function( accounts ) {

	it( "TEST: ESOP( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3884283", timeStamp: "1497651880", hash: "0xe66e2c64d07cff0724bef5ad772cc7155a57bd8abd999cfe1cb84de5cf32cde9", nonce: "36", blockHash: "0x6bd54956104b977130de4888c55e2edff4b74a744b1c1aa3f1209b39aeffaa28", transactionIndex: "12", from: "0x11a1cee1c6681ee8e6891164a3e3eaf17ed0e207", to: 0, value: "0", gas: "4300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xc58145870000000000000000000000000c53fe380aba335d144b6f0dbc6b588633f783d7000000000000000000000000f3a85b1c8818629e52d61236e9ff5f531e52d8ed0000000000000000000000002ad565023d39f5f8a6afdc625c0285bbc2d52276000000000000000000000000d35504e0f9bdcf8bca1ce7ec51fa2db514029182", contractAddress: "0xda7c27c04f66842faf20644814b644e25e1766ea", cumulativeGasUsed: "4564786", gasUsed: "4191903", confirmations: "3791003"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "company", value: addressList[4]}, {type: "address", name: "pRootOfTrust", value: addressList[5]}, {type: "address", name: "pOptionsCalculator", value: addressList[6]}, {type: "address", name: "pEmployeesList", value: addressList[7]}], name: "ESOP", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ESOP.new( addressList[4], addressList[5], addressList[6], addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1497651880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ESOP.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1195416000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: openESOP( \"1000080\", \"0x516d57375642444d3345446... )", async function( ) {
		const txOriginal = {blockNumber: "3917838", timeStamp: "1498219430", hash: "0xc35d622673c8ddaff845fb9fc0b70d2aabf6cefac51a64130f093ab194834090", nonce: "9", blockHash: "0x6525d38a1c4a9452f7bf595cf97093fe968656cb52f77e232f527f0a7dc1cd38", transactionIndex: "82", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x8769beea00000000000000000000000000000000000000000000000000000000000f42900000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d57375642444d33454468545662576476435743654c7864527a317169776174327a4e584d706646566d567975000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2700499", gasUsed: "134117", confirmations: "3757448"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "pTotalPoolOptions", value: "1000080"}, {type: "bytes", name: "pESOPLegalWrapperIPFSHash", value: "0x516d57375642444d33454468545662576476435743654c7864527a317169776174327a4e584d706646566d567975"}], name: "openESOP", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openESOP(uint32,bytes)" ]( "1000080", "0x516d57375642444d33454468545662576476435743654c7864527a317169776174327a4e584d706646566d567975", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1498219430 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "company", type: "address"}], name: "ESOPOpened", type: "event"} ;
		console.error( "eventCallOriginal[1,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ESOPOpened", events: [{name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[1,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[8], \"1476050400\", \"149951... )", async function( ) {
		const txOriginal = {blockNumber: "3917868", timeStamp: "1498219953", hash: "0x6a69ac56f55fae1e42a54e541238c5df84e400c18b7119eee480f7ef52fee022", nonce: "10", blockHash: "0xd26d9a038839ced1a722163d7ee83ab68b0da7dc8b0f69fa296c7efce886bd29", transactionIndex: "30", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xcc96b9430000000000000000000000006a58a4e262b6ead9eb40f41313d6d1fbbbb41c160000000000000000000000000000000000000000000000000000000057fabde0000000000000000000000000000000000000000000000000000000005960cc0600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1744117", gasUsed: "128599", confirmations: "3757418"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[8]}, {type: "uint32", name: "issueDate", value: "1476050400"}, {type: "uint32", name: "timeToSign", value: "1499515910"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[8], "1476050400", "1499515910", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1498219953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x6a58a4e262b6ead9eb40f41313d6d1fbbbb41c16"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 5, c: [100008]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3917892", timeStamp: "1498220293", hash: "0xf0494b60c1f83abb87e043d5d05b000dbb118cb416070c271eab109cdf2cbc20", nonce: "0", blockHash: "0x170887ad6ded6d3de6996a58700ea1b116ee5cf59e4200b8c907e03bdb3af4f9", transactionIndex: "25", from: "0x6a58a4e262b6ead9eb40f41313d6d1fbbbb41c16", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "684010", gasUsed: "44742", confirmations: "3757394"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1498220293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x6a58a4e262b6ead9eb40f41313d6d1fbbbb41c16"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[9], \"1489532400\", \"149951... )", async function( ) {
		const txOriginal = {blockNumber: "3917905", timeStamp: "1498220538", hash: "0xbef77d19e86fd7687e8b5d16aa6389c1b1dd2166690eb5ad03776fe9f7e171ea", nonce: "11", blockHash: "0x69ab2a2c72dfb1f92caacfc5353b6c6cda593d5c53479010763e3200b2fb916c", transactionIndex: "18", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xcc96b943000000000000000000000000523143aa3105d43abeec9bef0e055585beafe2ea0000000000000000000000000000000000000000000000000000000058c875f0000000000000000000000000000000000000000000000000000000005960ce5600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "612460", gasUsed: "126095", confirmations: "3757381"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[9]}, {type: "uint32", name: "issueDate", value: "1489532400"}, {type: "uint32", name: "timeToSign", value: "1499516502"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[9], "1489532400", "1499516502", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1498220538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x523143aa3105d43abeec9bef0e055585beafe2ea"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [90007]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3917919", timeStamp: "1498220703", hash: "0x8370206962c64e43c9be3da206b2ed859c13ddbfc1a9812d46ddd8ee36214536", nonce: "0", blockHash: "0x57481417e8c018d26c7aec87107bb0dc49b76d1f7f8e84c37998557948537974", transactionIndex: "20", from: "0x523143aa3105d43abeec9bef0e055585beafe2ea", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "817412", gasUsed: "44742", confirmations: "3757367"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1498220703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x523143aa3105d43abeec9bef0e055585beafe2ea"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49060418000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[10], \"1490997600\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932053", timeStamp: "1498467570", hash: "0xa95bd3f1c49c812f33d1b3a70db96ca7d84d3ff0d6fe88dd51aa76d5b02f75f8", nonce: "12", blockHash: "0x6cfe6370f0c798a36814b5a7c7494945f24483acf45f75e16f1d40aad87e70a5", transactionIndex: "23", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b943000000000000000000000000ac7bf7d1fe17050d27260f22a428a2bab53cd4ac0000000000000000000000000000000000000000000000000000000058ded160000000000000000000000000000000000000000000000000000000005964934900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1138861", gasUsed: "138593", confirmations: "3743233"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[10]}, {type: "uint32", name: "issueDate", value: "1490997600"}, {type: "uint32", name: "timeToSign", value: "1499763529"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[10], "1490997600", "1499763529", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1498467570 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xac7bf7d1fe17050d27260f22a428a2bab53cd4ac"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [81007]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3932063", timeStamp: "1498467798", hash: "0x5f4e8d5725920e880c578af5a4939e695908ca3915c1f4ea35011a7bb8cc43a9", nonce: "0", blockHash: "0x68ecddf5188b99d82d82f6381565a0f8009dec0ff5216b96dd0c89c24db3403f", transactionIndex: "28", from: "0xac7bf7d1fe17050d27260f22a428a2bab53cd4ac", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1185965", gasUsed: "44742", confirmations: "3743223"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1498467798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0xac7bf7d1fe17050d27260f22a428a2bab53cd4ac"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "9849642064000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[11], \"1492120800\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932072", timeStamp: "1498467953", hash: "0x3e903911b6ba7fbbcd2c4420e46636ed02e99876272a417232979ae190df0c1c", nonce: "13", blockHash: "0x8c2c641c91f337a5268df57d0c6b54ccd6d46a49452273539699372db9db004c", transactionIndex: "29", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b9430000000000000000000000009899037ae30430928f3bd702ba573a3bb540a6f10000000000000000000000000000000000000000000000000000000058eff4e000000000000000000000000000000000000000000000000000000000596494ca00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2392451", gasUsed: "151091", confirmations: "3743214"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[11]}, {type: "uint32", name: "issueDate", value: "1492120800"}, {type: "uint32", name: "timeToSign", value: "1499763914"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[11], "1492120800", "1499763914", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1498467953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x9899037ae30430928f3bd702ba573a3bb540a6f1"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [72906]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3932082", timeStamp: "1498468088", hash: "0x57c92451577b592dc74fd3a2e18d980a81f2d45034ac33078f6a60795d8b28c4", nonce: "0", blockHash: "0x237f5a5b5abd7184d5597f993b2a740cf1dfe361ade932d96743c10921efda04", transactionIndex: "56", from: "0x9899037ae30430928f3bd702ba573a3bb540a6f1", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "2594116", gasUsed: "44742", confirmations: "3743204"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1498468088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x9899037ae30430928f3bd702ba573a3bb540a6f1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "4399642064000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[12], \"1492466400\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932091", timeStamp: "1498468283", hash: "0xd74bfcd1a054ac4d8fb8b6ef4f22b93757f961fc4d0c6755227916d8a9a1bbd1", nonce: "14", blockHash: "0x1537ede73163a8d949d66f198c67358bb80f97ec91c84e69b0bfa82b1a5d7ca8", transactionIndex: "14", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b943000000000000000000000000d744556989864b2a35784ed46b39b0e3144445aa0000000000000000000000000000000000000000000000000000000058f53ae0000000000000000000000000000000000000000000000000000000005964962e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "618337", gasUsed: "163591", confirmations: "3743195"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[12]}, {type: "uint32", name: "issueDate", value: "1492466400"}, {type: "uint32", name: "timeToSign", value: "1499764270"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[12], "1492466400", "1499764270", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1498468283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xd744556989864b2a35784ed46b39b0e3144445aa"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [65615]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3932100", timeStamp: "1498468493", hash: "0xbaaee6f5e03c1124efb605c0832315f13af5c691aa71b2b254009732720e22c9", nonce: "0", blockHash: "0xff551f6b7e62c14e4983bddc2dbba3c8de6649449ce51647bc6c6ae4146c4d8c", transactionIndex: "135", from: "0xd744556989864b2a35784ed46b39b0e3144445aa", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "3281589", gasUsed: "44742", confirmations: "3743186"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1498468493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0xd744556989864b2a35784ed46b39b0e3144445aa"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "6739642064000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[13], \"1494194400\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932110", timeStamp: "1498468670", hash: "0x2b6a444c983cbd8f3323cb1ae16aa0ea4cb48eb04ec909625285ce0c2236d045", nonce: "15", blockHash: "0x744bde8e76e0595fad2502873bf67b94292e887571dd032c554ec0e98c5aa663", transactionIndex: "49", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b9430000000000000000000000002597e3eef899164fd2e74b969c536c738e3e462f00000000000000000000000000000000000000000000000000000000590f98e0000000000000000000000000000000000000000000000000000000005964978900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1798438", gasUsed: "176092", confirmations: "3743176"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[13]}, {type: "uint32", name: "issueDate", value: "1494194400"}, {type: "uint32", name: "timeToSign", value: "1499764617"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[13], "1494194400", "1499764617", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1498468670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x2597e3eef899164fd2e74b969c536c738e3e462f"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [59054]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[13], \"1498469074\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3932140", timeStamp: "1498469115", hash: "0xc3c0d7f0d5b64670f027fd45320e9b7159ca467956d66bc2961b80376f96923c", nonce: "16", blockHash: "0x798d2057f1cf6ccab6c201da68d9014ffa675abd977e80f2df407afc366a4ef2", transactionIndex: "54", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x4c382d990000000000000000000000002597e3eef899164fd2e74b969c536c738e3e462f000000000000000000000000000000000000000000000000000000005950d2d20000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2596971", gasUsed: "36357", confirmations: "3743146"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[13]}, {type: "uint32", name: "terminatedAt", value: "1498469074"}, {type: "uint8", name: "terminationType", value: "1"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[13], "1498469074", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1498469115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0x2597e3eef899164fd2e74b969c536c738e3e462f"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1498469074]}}, {name: "termType", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[14], \"1494194400\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932147", timeStamp: "1498469274", hash: "0x72d3f2f8487a99a713b3639066cf3da4ed280bbd22f81813b8eb5663244c1c94", nonce: "17", blockHash: "0x6dbc26abdd81122dd638f2d8becdb544d2f2968c258a8b82b48963e9c59a6d56", transactionIndex: "53", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b94300000000000000000000000003158526a0264cc2a83dd18c56d4fe8e612b2dc100000000000000000000000000000000000000000000000000000000590f98e000000000000000000000000000000000000000000000000000000000596499f300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2711579", gasUsed: "182179", confirmations: "3743139"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[14]}, {type: "uint32", name: "issueDate", value: "1494194400"}, {type: "uint32", name: "timeToSign", value: "1499765235"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[14], "1494194400", "1499765235", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1498469274 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x03158526a0264cc2a83dd18c56d4fe8e612b2dc1"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [59054]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[15], \"1494453600\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932169", timeStamp: "1498469613", hash: "0xf0a169d865eeff721d443277e6653d074e3f03cde113c0ebbf206ec2d1c0e0b9", nonce: "18", blockHash: "0x1fd9731cf9cf1b6920ed58cc07713c972bb9c6264a6f1a021981587227c01008", transactionIndex: "68", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b943000000000000000000000000f888ed6beee93a36fb8bcd8e41f2c3eaa2570c810000000000000000000000000000000000000000000000000000000059138d600000000000000000000000000000000000000000000000000000000059649b2e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2408940", gasUsed: "194714", confirmations: "3743117"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[15]}, {type: "uint32", name: "issueDate", value: "1494453600"}, {type: "uint32", name: "timeToSign", value: "1499765550"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[15], "1494453600", "1499765550", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1498469613 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xf888ed6beee93a36fb8bcd8e41f2c3eaa2570c81"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [53148]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3932176", timeStamp: "1498469783", hash: "0x48f8eb5a55546678e8c6477f27be0b36bb4998bcb5210977cb35dda0ef44bf1a", nonce: "0", blockHash: "0x9c7c6549b5d349f8496f745656be03e043fa9d8e33babc3a8748bad9cbe75098", transactionIndex: "29", from: "0xf888ed6beee93a36fb8bcd8e41f2c3eaa2570c81", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1859495", gasUsed: "44742", confirmations: "3743110"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1498469783 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0xf888ed6beee93a36fb8bcd8e41f2c3eaa2570c81"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "49642064000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployeeOnlyExtra( addressList[13], \"1471212000\", \"14997... )", async function( ) {
		const txOriginal = {blockNumber: "3932204", timeStamp: "1498470235", hash: "0xbbe3517b12cecfa4acd14c6961b83e70e58b10dfc76949f4519c5be7edd43fbc", nonce: "19", blockHash: "0x864eed9c85aad8c4fe76ead358e3c946d2d1b7ddba418c9c5e0aad23cfea6d98", transactionIndex: "102", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfb062a840000000000000000000000002597e3eef899164fd2e74b969c536c738e3e462f0000000000000000000000000000000000000000000000000000000057b0e9e00000000000000000000000000000000000000000000000000000000059649db10000000000000000000000000000000000000000000000000000000000041eb0", contractAddress: "", cumulativeGasUsed: "3711301", gasUsed: "115912", confirmations: "3743082"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[13]}, {type: "uint32", name: "issueDate", value: "1471212000"}, {type: "uint32", name: "timeToSign", value: "1499766193"}, {type: "uint32", name: "extraOptions", value: "270000"}], name: "offerOptionsToEmployeeOnlyExtra", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployeeOnlyExtra(address,uint32,uint32,uint32)" ]( addressList[13], "1471212000", "1499766193", "270000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1498470235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x2597e3eef899164fd2e74b969c536c738e3e462f"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 5, c: [270000]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3932211", timeStamp: "1498470370", hash: "0xd1e8f32537ebf9a683526f1517b38d2ad7b68294a19f2e9d5df9bbe8a48f0543", nonce: "0", blockHash: "0xc9a07df3627f62410c18eba3a0ce552b52e459190967d9f1e34e320ed543854c", transactionIndex: "28", from: "0x2597e3eef899164fd2e74b969c536c738e3e462f", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1417754", gasUsed: "44742", confirmations: "3743075"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1498470370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x2597e3eef899164fd2e74b969c536c738e3e462f"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "9559000000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "3978247", timeStamp: "1499263418", hash: "0x698792e876d5ac45015341a77b1645fcf5c509d120f0d32eb5ad489cab369b2f", nonce: "0", blockHash: "0x21c31dbe81da3453973ff13ab5bf1ef8103f78f001a8cd7669954ad45da1de53", transactionIndex: "30", from: "0x03158526a0264cc2a83dd18c56d4fe8e612b2dc1", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1858465", gasUsed: "44742", confirmations: "3697039"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1499263418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x03158526a0264cc2a83dd18c56d4fe8e612b2dc1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "49642064000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[16], \"1500847200\", \"15048... )", async function( ) {
		const txOriginal = {blockNumber: "4199082", timeStamp: "1503590333", hash: "0x2ca3429b1db6ef00752b5d56c77bec71d4bfe61e87ab5d754c6201951d706f35", nonce: "20", blockHash: "0x57cb2a4b9a7466e653d2ec83da70cc365acad8e58954e175e863c7ca852264d4", transactionIndex: "49", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xcc96b9430000000000000000000000001eb1b679dfea232db3edd9f280213ff46b26303c0000000000000000000000000000000000000000000000000000000059751c600000000000000000000000000000000000000000000000000000000059b2bb3e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1999535", gasUsed: "219690", confirmations: "3476204"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[16]}, {type: "uint32", name: "issueDate", value: "1500847200"}, {type: "uint32", name: "timeToSign", value: "1504885566"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[16], "1500847200", "1504885566", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1503590333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x1eb1b679dfea232db3edd9f280213ff46b26303c"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [47834]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "4199114", timeStamp: "1503590975", hash: "0x844f640fe103391f857c19f1d7806fca811adefe3f0e70d2c0d9380fb94d3e98", nonce: "0", blockHash: "0x5461baa038dee817284697f65e3bb879a9ad35f2d3fc5ad09a411c70bbccb989", transactionIndex: "53", from: "0x1eb1b679dfea232db3edd9f280213ff46b26303c", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1932400", gasUsed: "44742", confirmations: "3476172"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1503590975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x1eb1b679dfea232db3edd9f280213ff46b26303c"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "8759642064000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[9], \"1513184050\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4726545", timeStamp: "1513184267", hash: "0x98c1988774d7be4b571acb60286b1b7581e76178693d88156b3bacf83c73a81a", nonce: "21", blockHash: "0xc520f6e9ea932d3ae0e596e2a6bf887c097dc67774d468fc8d31b6eb8e1b87d6", transactionIndex: "176", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d99000000000000000000000000523143aa3105d43abeec9bef0e055585beafe2ea000000000000000000000000000000000000000000000000000000005a315b320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5501765", gasUsed: "321480", confirmations: "2948741"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[9]}, {type: "uint32", name: "terminatedAt", value: "1513184050"}, {type: "uint8", name: "terminationType", value: "0"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[9], "1513184050", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1513184267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0x523143aa3105d43abeec9bef0e055585beafe2ea"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1513184050]}}, {name: "termType", type: "uint8", value: "0"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[17], \"1501538400\", \"15144... )", async function( ) {
		const txOriginal = {blockNumber: "4726585", timeStamp: "1513184745", hash: "0x2d55ca2039284556ea12902ad5153e153b78e8c5b01b45e2e4eba5fb00fb6bb3", nonce: "22", blockHash: "0xa0d0dc0557a1367ac6234df6e061c13359d9764d33deb62462afeddb869b697b", transactionIndex: "28", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000005712f5c9af2f98d3d02a2728067dc781a5bac67700000000000000000000000000000000000000000000000000000000597fa860000000000000000000000000000000000000000000000000000000005a45245b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1777352", gasUsed: "239284", confirmations: "2948701"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[17]}, {type: "uint32", name: "issueDate", value: "1501538400"}, {type: "uint32", name: "timeToSign", value: "1514480731"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[17], "1501538400", "1514480731", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1513184745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x5712f5c9af2f98d3d02a2728067dc781a5bac677"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [47833]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "4726651", timeStamp: "1513185708", hash: "0x8f79b19d5dbc3328df504687ba074f085387f731c937561a7d3e1b206ea18f6b", nonce: "0", blockHash: "0xe638e8f408d2bada95ea94b40c3a4928202afae47997ea3eadbfec27d3f6a717", transactionIndex: "23", from: "0x5712f5c9af2f98d3d02a2728067dc781a5bac677", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1078498", gasUsed: "44742", confirmations: "2948635"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1513185708 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x5712f5c9af2f98d3d02a2728067dc781a5bac677"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3074328870000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[15], \"1515970800\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4935284", timeStamp: "1516373428", hash: "0xe3071f9d50c7fbaae1df124aa70f966219631cbdf2f02e4b7fb2757ebe47ca75", nonce: "23", blockHash: "0xf87c5a0faf42363c9c6669ba84478bb9f76ed8a3657b930f9427cc9eba369492", transactionIndex: "140", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d99000000000000000000000000f888ed6beee93a36fb8bcd8e41f2c3eaa2570c81000000000000000000000000000000000000000000000000000000005a5be0f00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4641283", gasUsed: "163287", confirmations: "2740002"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[15]}, {type: "uint32", name: "terminatedAt", value: "1515970800"}, {type: "uint8", name: "terminationType", value: "0"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[15], "1515970800", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1516373428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0xf888ed6beee93a36fb8bcd8e41f2c3eaa2570c81"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1515970800]}}, {name: "termType", type: "uint8", value: "0"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[14], \"1514761200\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4935296", timeStamp: "1516373604", hash: "0x43794fe11dfdcbd04963a7fec4d72a15de2fe3a188bbdb7e588414deec404faa", nonce: "24", blockHash: "0xfe28025a5ca0b7e7a3697f281c914cbfd8b7ae1f0b43c2dc6ebb7476d0c4d710", transactionIndex: "146", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d9900000000000000000000000003158526a0264cc2a83dd18c56d4fe8e612b2dc1000000000000000000000000000000000000000000000000000000005a496bf00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4674033", gasUsed: "176074", confirmations: "2739990"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[14]}, {type: "uint32", name: "terminatedAt", value: "1514761200"}, {type: "uint8", name: "terminationType", value: "0"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[14], "1514761200", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1516373604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0x03158526a0264cc2a83dd18c56d4fe8e612b2dc1"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1514761200]}}, {name: "termType", type: "uint8", value: "0"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[18], \"1511910000\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492093", timeStamp: "1524492168", hash: "0x05a63850884c1806b513448b148836e563a57f62b1047fc8138e33da468301b2", nonce: "25", blockHash: "0x3b304c6e01fbe830be3905efee06150093ab0dbf050d0a3e3c69cc6416325045", transactionIndex: "41", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b943000000000000000000000000fe5b9418d0b295f00d2890927f2ecf595902faf4000000000000000000000000000000000000000000000000000000005a1dea70000000000000000000000000000000000000000000000000000000005af1adb600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2326251", gasUsed: "265968", confirmations: "2183193"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[18]}, {type: "uint32", name: "issueDate", value: "1511910000"}, {type: "uint32", name: "timeToSign", value: "1525788086"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[18], "1511910000", "1525788086", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1524492168 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xfe5b9418d0b295f00d2890927f2ecf595902faf4"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [53148]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[19], \"1514761200\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492701", timeStamp: "1524501347", hash: "0x752c43b5c1f71186e6efcf5af5d39d8a3aa3fe55b67db7b578895c683712c22c", nonce: "26", blockHash: "0x9f00207a8d503082769d5af586faf1ee08281b9ea28ea02b7a4e4abfcb5e01b3", transactionIndex: "83", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000004a12930ec5e332bc3884df385d68cdcd21f80296000000000000000000000000000000000000000000000000000000005a496bf0000000000000000000000000000000000000000000000000000000005af1d0fc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4741477", gasUsed: "278509", confirmations: "2182585"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[19]}, {type: "uint32", name: "issueDate", value: "1514761200"}, {type: "uint32", name: "timeToSign", value: "1525797116"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[19], "1514761200", "1525797116", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1524501347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x4a12930ec5e332bc3884df385d68cdcd21f80296"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [47833]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[20], \"1516230000\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492810", timeStamp: "1524503183", hash: "0x0aa6e01de15406edfa62762a749a5d3af97f8c00fbff0437b9034940e9a44af5", nonce: "27", blockHash: "0x76f7cc4114c3a5ece005898c28aec1831ec0e1553f4255c6d47b5d296eafa9dc", transactionIndex: "74", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000003ecc4c639cf7e05d8082a75c7d0ee9242b964507000000000000000000000000000000000000000000000000000000005a5fd570000000000000000000000000000000000000000000000000000000005af1d8f600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3717200", gasUsed: "291051", confirmations: "2182476"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[20]}, {type: "uint32", name: "issueDate", value: "1516230000"}, {type: "uint32", name: "timeToSign", value: "1525799158"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[20], "1516230000", "1525799158", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1524503183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x3ecc4c639cf7e05d8082a75c7d0ee9242b964507"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [43050]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[21], \"1516834800\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492825", timeStamp: "1524503389", hash: "0x646da4254ce8aec8800eed61f9602da211026d0da9469c0a94b5a07dd3d04042", nonce: "28", blockHash: "0x4ac32c8e6d84b6caafd700ee30d25bd1e389ac7a516e1bec4ccb444261b9d872", transactionIndex: "135", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000001cdf10c007ae95e59ad904221084e47b0eec8bef000000000000000000000000000000000000000000000000000000005a690ff0000000000000000000000000000000000000000000000000000000005af1d9bb00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6901718", gasUsed: "303594", confirmations: "2182461"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[21]}, {type: "uint32", name: "issueDate", value: "1516834800"}, {type: "uint32", name: "timeToSign", value: "1525799355"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[21], "1516834800", "1525799355", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1524503389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x1cdf10c007ae95e59ad904221084e47b0eec8bef"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [38745]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[22], \"1516921200\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492854", timeStamp: "1524503787", hash: "0x15e139cda6e467ba78e82632f0d2b23bc74b7ec25d251cab59b553a61e11fb72", nonce: "29", blockHash: "0x6f20c6af995fa300a3d1ad1b3ec50463bfc9784d211df2174882ba7a4fb58d75", transactionIndex: "53", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000003a2fad948734806448c3d0922ab16915f49e1583000000000000000000000000000000000000000000000000000000005a6a6170000000000000000000000000000000000000000000000000000000005af1db4d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2160638", gasUsed: "316138", confirmations: "2182432"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[22]}, {type: "uint32", name: "issueDate", value: "1516921200"}, {type: "uint32", name: "timeToSign", value: "1525799757"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[22], "1516921200", "1525799757", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1524503787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x3a2fad948734806448c3d0922ab16915f49e1583"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [34871]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[23], \"1517007600\", \"15257... )", async function( ) {
		const txOriginal = {blockNumber: "5492875", timeStamp: "1524504146", hash: "0x6f8d1c288dea888cd3c193e11e69b5c14f822790c29f986fc3c409045a4a5724", nonce: "30", blockHash: "0x2f6c1be2bfdeae88e27c575b51bc7f7448ac7a96a7e6ffe6e590af72ab0c7c05", transactionIndex: "181", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b94300000000000000000000000021641e088d2514d1b1cba5cf80c0c288ce12c4b8000000000000000000000000000000000000000000000000000000005a6bb2f0000000000000000000000000000000000000000000000000000000005af1dc1800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6968796", gasUsed: "328684", confirmations: "2182411"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[23]}, {type: "uint32", name: "issueDate", value: "1517007600"}, {type: "uint32", name: "timeToSign", value: "1525799960"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[23], "1517007600", "1525799960", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1524504146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x21641e088d2514d1b1cba5cf80c0c288ce12c4b8"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [31384]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5502683", timeStamp: "1524651008", hash: "0xd2c83532843765972b2daac790f0cf259f2032bb3c1a5a1c9df1bdb8f72ea362", nonce: "0", blockHash: "0xe3ef9f60de90157021f0100c33e0a1fc0106d5840d1881ce1c0e637f7bf518df", transactionIndex: "38", from: "0x4a12930ec5e332bc3884df385d68cdcd21f80296", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1190390", gasUsed: "44742", confirmations: "2172603"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1524651008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x4a12930ec5e332bc3884df385d68cdcd21f80296"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "36328870000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5502742", timeStamp: "1524651860", hash: "0xf08769f1212f7ecb2f45b10f6ec2fe26741b278fe6ea39c98ddfeba9e3bcf462", nonce: "0", blockHash: "0xef68adf3201e0b6db3d982b0f118d1a0c6650448fb5e6da5ee25ca9703273c97", transactionIndex: "39", from: "0xfe5b9418d0b295f00d2890927f2ecf595902faf4", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1147061", gasUsed: "44742", confirmations: "2172544"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1524651860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0xfe5b9418d0b295f00d2890927f2ecf595902faf4"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "29328870000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[24], \"1521500400\", \"15259... )", async function( ) {
		const txOriginal = {blockNumber: "5505384", timeStamp: "1524691473", hash: "0xcf045de48fdd47f46f65d3eba4c6b6da97ee4269b61509a060e690ff5be16db7", nonce: "31", blockHash: "0xf760ebade1da948de6ef0479cf804d0f7a186e384ef2dc6b8d3688e3ed4224b5", transactionIndex: "80", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000008a6a8d4f88534c96883eb67b9211a3682b1ab867000000000000000000000000000000000000000000000000000000005ab040f0000000000000000000000000000000000000000000000000000000005af4b80600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5655156", gasUsed: "341167", confirmations: "2169902"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[24]}, {type: "uint32", name: "issueDate", value: "1521500400"}, {type: "uint32", name: "timeToSign", value: "1525987334"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[24], "1521500400", "1525987334", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1524691473 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x8a6a8d4f88534c96883eb67b9211a3682b1ab867"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [28245]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[24], \"1524691731\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "5505414", timeStamp: "1524691884", hash: "0x3e8f32d4e0e842f7cf8e1ebaf3def424476de6ab02692d1b91ea3a9fdbb18c85", nonce: "32", blockHash: "0xacd7c472f53b72a71bdefb2575c7393310de498f20a290e1fd49807d19d35284", transactionIndex: "143", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d990000000000000000000000008a6a8d4f88534c96883eb67b9211a3682b1ab867000000000000000000000000000000000000000000000000000000005ae0f3130000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4264927", gasUsed: "36357", confirmations: "2169872"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[24]}, {type: "uint32", name: "terminatedAt", value: "1524691731"}, {type: "uint8", name: "terminationType", value: "1"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[24], "1524691731", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1524691884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0x8a6a8d4f88534c96883eb67b9211a3682b1ab867"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1524691731]}}, {name: "termType", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[24], \"1521759600\", \"15298... )", async function( ) {
		const txOriginal = {blockNumber: "5505422", timeStamp: "1524692005", hash: "0xd432563f5efd42a8810833619f2bb26c6cc8baeb45cf9338ef30a09559eaaf94", nonce: "33", blockHash: "0x5170f30476949208c8970b7f41814a04366b64adb180e0a7adcb9858e361d209", transactionIndex: "91", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000008a6a8d4f88534c96883eb67b9211a3682b1ab867000000000000000000000000000000000000000000000000000000005ab43570000000000000000000000000000000000000000000000000000000005b300dfa00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4707162", gasUsed: "347254", confirmations: "2169864"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[24]}, {type: "uint32", name: "issueDate", value: "1521759600"}, {type: "uint32", name: "timeToSign", value: "1529875962"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[24], "1521759600", "1529875962", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1524692005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x8a6a8d4f88534c96883eb67b9211a3682b1ab867"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [28245]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[25], \"1521759600\", \"15259... )", async function( ) {
		const txOriginal = {blockNumber: "5505435", timeStamp: "1524692171", hash: "0x8528ff23e4949d378f320c0102b5c769a04fc33e28abd4f3e9af9708702c3f56", nonce: "34", blockHash: "0xec380bb1992e6119e3d9c108ff78f93d6f190baa113555d319fcd938d3c57e20", transactionIndex: "83", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b943000000000000000000000000f6178758ac7b3e266e89b6c9fc4094c7fdcba8d6000000000000000000000000000000000000000000000000000000005ab43570000000000000000000000000000000000000000000000000000000005af4bb1b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3902514", gasUsed: "359803", confirmations: "2169851"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[25]}, {type: "uint32", name: "issueDate", value: "1521759600"}, {type: "uint32", name: "timeToSign", value: "1525988123"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[25], "1521759600", "1525988123", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1524692171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xf6178758ac7b3e266e89b6c9fc4094c7fdcba8d6"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [25421]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5507627", timeStamp: "1524724271", hash: "0xae56d1ef41592a94177423e5e99beb8e9169b3918195a35fa4dfb5bfb9105b8f", nonce: "0", blockHash: "0xb630c080dfac3d56e91f7e855366a4d1af7029de7294a3eba21a793a128d7b0c", transactionIndex: "25", from: "0x21641e088d2514d1b1cba5cf80c0c288ce12c4b8", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "913938", gasUsed: "44742", confirmations: "2167659"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1524724271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x21641e088d2514d1b1cba5cf80c0c288ce12c4b8"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "39328870000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5508953", timeStamp: "1524743890", hash: "0x2bb12e36ce5ae6f918bda3c5539ab1da4419dd617fb721229019a7196b94d8cd", nonce: "0", blockHash: "0xff3e0700f96b81c22c236c0398a6e7c302006ad8846f50a8dac944688b716011", transactionIndex: "89", from: "0xf6178758ac7b3e266e89b6c9fc4094c7fdcba8d6", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "3708581", gasUsed: "44742", confirmations: "2166333"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1524743890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0xf6178758ac7b3e266e89b6c9fc4094c7fdcba8d6"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "39223870000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5545357", timeStamp: "1525292881", hash: "0x0cb4e7dadcb04a9aeaf5287ddeea16f9e3594d8f2c34a42c164e8512b2e97a79", nonce: "0", blockHash: "0xc4ca97497228b425deeacabca1043d62234f1e8cd0fd23e0a1d0136e67e8c201", transactionIndex: "3", from: "0x3ecc4c639cf7e05d8082a75c7d0ee9242b964507", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "174557", gasUsed: "44742", confirmations: "2129929"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1525292881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x3ecc4c639cf7e05d8082a75c7d0ee9242b964507"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "23825005000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5545364", timeStamp: "1525293014", hash: "0x1273a5512ec7c052886a45ecdfe2cfa841214333b0531ff22c8960d28413ae15", nonce: "1", blockHash: "0x2192f69121419572a2722ba5a8d154817add43217464cd42e5ae35d3acbcccd8", transactionIndex: "84", from: "0x3ecc4c639cf7e05d8082a75c7d0ee9242b964507", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "4549684", gasUsed: "33591", confirmations: "2129922"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1525293014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "rc", type: "uint8"}], name: "ReturnCode", type: "event"} ;
		console.error( "eventCallOriginal[42,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReturnCode", events: [{name: "rc", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[42,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "23825005000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5568096", timeStamp: "1525637275", hash: "0xfef93aeddb761fd746f61b446b650023e389e2fa06149c67197a28274250af2b", nonce: "0", blockHash: "0x224daa26beb60f9920032456e57cfd5afd3424c5df4630304efe6182b86f9ee7", transactionIndex: "39", from: "0x3a2fad948734806448c3d0922ab16915f49e1583", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1183574", gasUsed: "44742", confirmations: "2107190"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1525637275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x3a2fad948734806448c3d0922ab16915f49e1583"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "38825005000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5568104", timeStamp: "1525637417", hash: "0x096c20f3bc3dca14a807e73952bd26062a12f5e89c798faef9cfe2197416671d", nonce: "1", blockHash: "0xf13552af2a847adb430d7f28d81cd2269c9da27b164fe9aa43ff3f12ca263296", transactionIndex: "40", from: "0x3a2fad948734806448c3d0922ab16915f49e1583", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "1521369", gasUsed: "33591", confirmations: "2107182"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1525637417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "rc", type: "uint8"}], name: "ReturnCode", type: "event"} ;
		console.error( "eventCallOriginal[44,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReturnCode", events: [{name: "rc", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[44,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "38825005000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: employeeSignsToESOP(  )", async function( ) {
		const txOriginal = {blockNumber: "5572467", timeStamp: "1525703032", hash: "0x7179061810aa052844a2e3bd245596746fb35b83b444d1f35d2e7b85f180bf9f", nonce: "0", blockHash: "0xd92ea7d4f24300d0af7ad20af627b73045578fcf3775f7d257b89213759fb3bb", transactionIndex: "25", from: "0x1cdf10c007ae95e59ad904221084e47b0eec8bef", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xfa66e143", contractAddress: "", cumulativeGasUsed: "778852", gasUsed: "44742", confirmations: "2102819"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "employeeSignsToESOP", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "employeeSignsToESOP()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1525703032 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}], name: "EmployeeSignedToESOP", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EmployeeSignedToESOP", events: [{name: "employee", type: "address", value: "0x1cdf10c007ae95e59ad904221084e47b0eec8bef"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "30208083543199740" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[25], \"1529683357\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "5835078", timeStamp: "1529683544", hash: "0x37055060f29436807ffb1ea50bc429219ef6a8e0561131ca1f19beb877d250d1", nonce: "35", blockHash: "0x4d2005569eed290ee2662e9dff820bb728e06656dd192d32bbf9f8d1642f4683", transactionIndex: "31", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d99000000000000000000000000f6178758ac7b3e266e89b6c9fc4094c7fdcba8d6000000000000000000000000000000000000000000000000000000005b2d1d9d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1207258", gasUsed: "36397", confirmations: "1840208"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[25]}, {type: "uint32", name: "terminatedAt", value: "1529683357"}, {type: "uint8", name: "terminationType", value: "1"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[25], "1529683357", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1529683544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0xf6178758ac7b3e266e89b6c9fc4094c7fdcba8d6"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1529683357]}}, {name: "termType", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: terminateEmployee( addressList[24], \"1529683589\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "5835086", timeStamp: "1529683654", hash: "0x2528c5b2c070aa09e98c95487cbb2b276d9396b936d0e69b469d07d6bd759a10", nonce: "36", blockHash: "0x612c222362808c0d2efeda4c53eb47e0d837bef0f91422302ea70d5a8c3febaf", transactionIndex: "38", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4c382d990000000000000000000000008a6a8d4f88534c96883eb67b9211a3682b1ab867000000000000000000000000000000000000000000000000000000005b2d1e850000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2554651", gasUsed: "42444", confirmations: "1840200"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[24]}, {type: "uint32", name: "terminatedAt", value: "1529683589"}, {type: "uint8", name: "terminationType", value: "1"}], name: "terminateEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "terminateEmployee(address,uint32,uint8)" ]( addressList[24], "1529683589", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1529683654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "terminatedAt", type: "uint32"}, {indexed: false, name: "termType", type: "uint8"}], name: "TerminateEmployee", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TerminateEmployee", events: [{name: "employee", type: "address", value: "0x8a6a8d4f88534c96883eb67b9211a3682b1ab867"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "terminatedAt", type: "uint32", value: {s: 1, e: 9, c: [1529683589]}}, {name: "termType", type: "uint8", value: "1"}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[24], \"1519167600\", \"15309... )", async function( ) {
		const txOriginal = {blockNumber: "5835105", timeStamp: "1529683814", hash: "0x91b1c399a41e03eb03167dde37ff52f0ef9d707c275126b382b84d8af1f8321b", nonce: "37", blockHash: "0xbcc90197b8133ee14547fe472c305194fd8c540068264b4cabcca5a4d309904e", transactionIndex: "80", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b9430000000000000000000000008a6a8d4f88534c96883eb67b9211a3682b1ab867000000000000000000000000000000000000000000000000000000005a8ca870000000000000000000000000000000000000000000000000000000005b40e5c200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3512759", gasUsed: "359300", confirmations: "1840181"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[24]}, {type: "uint32", name: "issueDate", value: "1519167600"}, {type: "uint32", name: "timeToSign", value: "1530979778"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[24], "1519167600", "1530979778", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1529683814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0x8a6a8d4f88534c96883eb67b9211a3682b1ab867"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [28245]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: offerOptionsToEmployee( addressList[26], \"1519858800\", \"15309... )", async function( ) {
		const txOriginal = {blockNumber: "5835115", timeStamp: "1529683975", hash: "0xae9bc96684507e8b0e14ce48b694202a580aca0de6a787776994405636f93913", nonce: "38", blockHash: "0x716b6f59f0c16e401c3498420f4ef39b1ab63282823555abf0427699ed8f7e5e", transactionIndex: "51", from: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7", to: "0xda7c27c04f66842faf20644814b644e25e1766ea", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcc96b943000000000000000000000000e673cc1ee50b57edea036394b5b1a3312778582e000000000000000000000000000000000000000000000000000000005a973470000000000000000000000000000000000000000000000000000000005b40e66700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2575675", gasUsed: "371849", confirmations: "1840171"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "e", value: addressList[26]}, {type: "uint32", name: "issueDate", value: "1519858800"}, {type: "uint32", name: "timeToSign", value: "1530979943"}, {type: "uint32", name: "extraOptions", value: "0"}, {type: "bool", name: "poolCleanup", value: true}], name: "offerOptionsToEmployee", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerOptionsToEmployee(address,uint32,uint32,uint32,bool)" ]( addressList[26], "1519858800", "1530979943", "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1529683975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "employee", type: "address"}, {indexed: false, name: "company", type: "address"}, {indexed: false, name: "poolOptions", type: "uint32"}, {indexed: false, name: "extraOptions", type: "uint32"}], name: "ESOPOffered", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ESOPOffered", events: [{name: "employee", type: "address", value: "0xe673cc1ee50b57edea036394b5b1a3312778582e"}, {name: "company", type: "address", value: "0x0c53fe380aba335d144b6f0dbc6b588633f783d7"}, {name: "poolOptions", type: "uint32", value: {s: 1, e: 4, c: [25421]}}, {name: "extraOptions", type: "uint32", value: {s: 1, e: 0, c: [0]}}], address: "0xda7c27c04f66842faf20644814b644e25e1766ea"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "106816574000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
