const Etheroll = artifacts.require( "./Etheroll.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Etheroll" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xD91E45416bfbBEc6e2D1ae4aC83b788A21Acf583", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x73F0ed546Cd7893ABc5e04284B68522602603dD4", "0x24C3235558572cff8054b5a419251D3B0D43E91b", "0x5de92686587b10cD47E03B71f2E2350606fCAf14", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0x17F20515dd55fb487A56482b7A41883726f211Bd", "0x28fa7F0806C76a06ad7C02B5E313C6C5c9E49Fc1", "0x1a067103F0EaA50771Abb1415413DE3bB8bBb32A", "0xA6Ce8B15CaF7464A7DE58f5907bB5E6c1f89A819", "0x544540bE56348E391Cd3a0909f6b582d926a8ffE", "0x8D04679f50FA5d1c3A4c96e1f7D6b3EAe3a983d6"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalWeiWon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addressToCheck", type: "address"}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalWeiWagered", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gasForOraclize", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalBets", outputs: [{name: "", type: "int256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxPendingPayouts", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RefundValue", type: "uint256"}], name: "LogRefund", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "SentToAddress", type: "address"}, {indexed: true, name: "AmountTransferred", type: "uint256"}], name: "LogOwnerTransfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogBet(bytes32,address,uint256,uint256,uint256,uint256)", "LogResult(uint256,bytes32,address,uint256,uint256,uint256,int256,bytes)", "LogRefund(bytes32,address,uint256)", "LogOwnerTransfer(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1cb5bfc4e69cbacf65c8e05bdb84d7a327bd6bb4c034ff82359aefd7443775c4", "0x8dd0b145385d04711e29558ceab40b456976a2b9a7d648cc1bcd416161bf97b9", "0x7b6ccf85690b8ce1b7d21a94ca738803a9da7dc74e10140f269efa0d8d6fb851", "0x42c501a185f41a8eb77b0a3e7b72a6435ea7aa752f8a1a0a13ca4628495eca91"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4426829 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4427704 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Etheroll", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalWeiWon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiWon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitAsPercentOfHouse()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payoutsPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addressToCheck", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playerGetPendingTxByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "treasury()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWeiWagered", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiWagered()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gasForOraclize", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gasForOraclize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBets", outputs: [{name: "", type: "int256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gamePaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdge()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdgeDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxPendingPayouts", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxPendingPayouts()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Etheroll", function( accounts ) {

	it( "TEST: Etheroll(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4426829", timeStamp: "1508934644", hash: "0xc0f7f67de18f90b5a38a4ea162ac0da293e1db15bc543d063d6d1a37627af173", nonce: "211", blockHash: "0x35e7b7915ca4702421b67a035746445353ae827902c3f2e3d12b999755d464fc", transactionIndex: "47", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: 0, value: "0", gas: "3293794", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1558ae4d", contractAddress: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", cumulativeGasUsed: "6125393", gasUsed: "3193794", confirmations: "3297617"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Etheroll", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Etheroll.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508934644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Etheroll.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1139335254416641590088" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: ownerSetTreasury( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "4426853", timeStamp: "1508934984", hash: "0x196071ede23864f744349e5aed6f6ed8298d7a6913f3840db99d93de368ddb49", nonce: "212", blockHash: "0xfef1a371624835309b3e2c6ac2854f2054d810809dfdf53c43d1546612131a8f", transactionIndex: "44", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "128762", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3137524200000000000000000000000024c3235558572cff8054b5a419251d3b0d43e91b", contractAddress: "", cumulativeGasUsed: "1552830", gasUsed: "28762", confirmations: "3297593"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newTreasury", value: addressList[11]}], name: "ownerSetTreasury", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerSetTreasury(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508934984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1139335254416641590088" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"99\" )", async function( ) {
		const txOriginal = {blockNumber: "4427193", timeStamp: "1508939645", hash: "0xa2066dc3e037bb509b05e3859c5fd2c337a6504b01300217ea6ff648f619ce22", nonce: "2777", blockHash: "0x2ef343a9fcd7365119cb31c9af2998e4abb78006444b4560d361e54dcbb91cc5", transactionIndex: "71", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "150000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000063", contractAddress: "", cumulativeGasUsed: "4428507", gasUsed: "194716", confirmations: "3297253"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "99"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "99", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508939645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x06aa77fc01bfda9c3221216fa68ca50a4957e8645f7640e7f02abc07b37da241"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "101020408163265305"}, {name: "ProfitValue", type: "uint256", value: "1020408163265305"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "99"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1483249827405182396" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"99\" )", async function( ) {
		const txOriginal = {blockNumber: "4427194", timeStamp: "1508939647", hash: "0x23443866e6bbafa34b2869fafd2fcd296933305934aa8b8f2a0bf5027011c494", nonce: "2778", blockHash: "0x3b2642096fbdcc84598d499aa6feb16cf1eab19cbdf49d2c160d81328f846293", transactionIndex: "3", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "10000000101", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000063", contractAddress: "", cumulativeGasUsed: "683621", gasUsed: "164716", confirmations: "3297252"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "99"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "99", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508939647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x1da0c8d77f59e5794c3a7fb69bdca8071ca3ec790d32e06a4c82a64112485470"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "101020408163265305"}, {name: "ProfitValue", type: "uint256", value: "1020408163265305"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "99"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1483249827405182396" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"99\" )", async function( ) {
		const txOriginal = {blockNumber: "4427194", timeStamp: "1508939647", hash: "0x61c550a1c35729c98a99fde961ae47902e41cf56611340376bf1f672d3b1e3f1", nonce: "2779", blockHash: "0x3b2642096fbdcc84598d499aa6feb16cf1eab19cbdf49d2c160d81328f846293", transactionIndex: "18", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "294716", gasPrice: "8400000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000063", contractAddress: "", cumulativeGasUsed: "5243510", gasUsed: "164716", confirmations: "3297252"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "99"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "99", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508939647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x69e4623451a85a63d94902d94821e93e313e302fc856cf4f0b28ee01e8f08b7c"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "101020408163265305"}, {name: "ProfitValue", type: "uint256", value: "1020408163265305"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "99"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1483249827405182396" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x06aa77fc01bfda9c3221216fa68ca50a4957... )", async function( ) {
		const txOriginal = {blockNumber: "4427196", timeStamp: "1508939683", hash: "0x955e9ed3672d2e1b6087a2c3a7a46a6ca7d478a72fb4c08434782611007dddac", nonce: "311840", blockHash: "0x094dc36ec041e7051616ede2085be71c61c57b6239e5858d024b0f545655cfa6", transactionIndex: "54", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5006aa77fc01bfda9c3221216fa68ca50a4957e8645f7640e7f02abc07b37da241000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333631382c205b34345d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220f58a8467500993e68038752532ba0fb08212bc5629048b6f4636101b6b254c06000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1691743", gasUsed: "154812", confirmations: "3297250"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x06aa77fc01bfda9c3221216fa68ca50a4957e8645f7640e7f02abc07b37da241"}, {type: "string", name: "result", value: `[143618, [44]]`}, {type: "bytes", name: "proof", value: "0x1220f58a8467500993e68038752532ba0fb08212bc5629048b6f4636101b6b254c06"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x06aa77fc01bfda9c3221216fa68ca50a4957e8645f7640e7f02abc07b37da241", `[143618, [44]]`, "0x1220f58a8467500993e68038752532ba0fb08212bc5629048b6f4636101b6b254c06", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508939683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143618"}, {name: "BetID", type: "bytes32", value: "0x06aa77fc01bfda9c3221216fa68ca50a4957e8645f7640e7f02abc07b37da241"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "99"}, {name: "DiceResult", type: "uint256", value: "44"}, {name: "Value", type: "uint256", value: "101020408163265305"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220f58a8467500993e68038752532ba0fb08212bc5629048b6f4636101b6b254c06"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x69e4623451a85a63d94902d94821e93e313e... )", async function( ) {
		const txOriginal = {blockNumber: "4427196", timeStamp: "1508939683", hash: "0xdf6de34f44ddd1dac87f41e939704fdc64e8aa46974d0ad82bf9a2db5df47c8d", nonce: "311841", blockHash: "0x094dc36ec041e7051616ede2085be71c61c57b6239e5858d024b0f545655cfa6", transactionIndex: "104", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5069e4623451a85a63d94902d94821e93e313e302fc856cf4f0b28ee01e8f08b7c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b3134333631392c205b355d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bc94c34f4e962c1741a8ae5ae830a98a484d6a2ccbc25e340dd6bad1dd1ec44c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6278528", gasUsed: "153784", confirmations: "3297250"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x69e4623451a85a63d94902d94821e93e313e302fc856cf4f0b28ee01e8f08b7c"}, {type: "string", name: "result", value: `[143619, [5]]`}, {type: "bytes", name: "proof", value: "0x1220bc94c34f4e962c1741a8ae5ae830a98a484d6a2ccbc25e340dd6bad1dd1ec44c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x69e4623451a85a63d94902d94821e93e313e302fc856cf4f0b28ee01e8f08b7c", `[143619, [5]]`, "0x1220bc94c34f4e962c1741a8ae5ae830a98a484d6a2ccbc25e340dd6bad1dd1ec44c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508939683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143619"}, {name: "BetID", type: "bytes32", value: "0x69e4623451a85a63d94902d94821e93e313e302fc856cf4f0b28ee01e8f08b7c"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "99"}, {name: "DiceResult", type: "uint256", value: "5"}, {name: "Value", type: "uint256", value: "101020408163265305"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220bc94c34f4e962c1741a8ae5ae830a98a484d6a2ccbc25e340dd6bad1dd1ec44c"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x1da0c8d77f59e5794c3a7fb69bdca8071ca3... )", async function( ) {
		const txOriginal = {blockNumber: "4427197", timeStamp: "1508939688", hash: "0xd083d113b489ff292aafd941d6f4659f6b8d6e415b688938406ec2997b635830", nonce: "311842", blockHash: "0xc272f812b910797df33a9b2db0c3327b946b4af0f1375734c37feda6b02cf14e", transactionIndex: "4", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa501da0c8d77f59e5794c3a7fb69bdca8071ca3ec790d32e06a4c82a64112485470000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632302c205b33355d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122017405d69829e8869ed7d987a23ced0c4ffd93c65b67e4cf7bddb611c11f9b837000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "580532", gasUsed: "139812", confirmations: "3297249"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x1da0c8d77f59e5794c3a7fb69bdca8071ca3ec790d32e06a4c82a64112485470"}, {type: "string", name: "result", value: `[143620, [35]]`}, {type: "bytes", name: "proof", value: "0x122017405d69829e8869ed7d987a23ced0c4ffd93c65b67e4cf7bddb611c11f9b837"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x1da0c8d77f59e5794c3a7fb69bdca8071ca3ec790d32e06a4c82a64112485470", `[143620, [35]]`, "0x122017405d69829e8869ed7d987a23ced0c4ffd93c65b67e4cf7bddb611c11f9b837", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508939688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143620"}, {name: "BetID", type: "bytes32", value: "0x1da0c8d77f59e5794c3a7fb69bdca8071ca3ec790d32e06a4c82a64112485470"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "99"}, {name: "DiceResult", type: "uint256", value: "35"}, {name: "Value", type: "uint256", value: "101020408163265305"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x122017405d69829e8869ed7d987a23ced0c4ffd93c65b67e4cf7bddb611c11f9b837"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"97\" )", async function( ) {
		const txOriginal = {blockNumber: "4427411", timeStamp: "1508942534", hash: "0xe3591cbeab7c758a84e7dd7a0e447259b7911aacbcdffb38918d659454e8ca55", nonce: "91", blockHash: "0x18f03e308ec0bbb00d5e943c578632d9d89139bfc5b0d1fd83ca93e0d6d5119b", transactionIndex: "71", from: "0x17f20515dd55fb487a56482b7a41883726f211bd", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000061", contractAddress: "", cumulativeGasUsed: "3087550", gasUsed: "179716", confirmations: "3297035"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "97"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "97", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508942534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x3bffac65a395a94fb2e2f11c487016958021cf6057769287e1620bb9b3dbb89a"}, {name: "PlayerAddress", type: "address", value: "0x17f20515dd55fb487a56482b7a41883726f211bd"}, {name: "RewardValue", type: "uint256", value: "103124999999999999"}, {name: "ProfitValue", type: "uint256", value: "3124999999999999"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "97"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "13101881055837670" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3bffac65a395a94fb2e2f11c487016958021... )", async function( ) {
		const txOriginal = {blockNumber: "4427414", timeStamp: "1508942558", hash: "0xf44be89e521f905bec0184957f9a48b37b2c199de1ff152b1f6c8bf83f36111f", nonce: "311853", blockHash: "0xc6caa81492ec11267d4268d64e934f135d020b83159cfd90f68fa613e6b471ba", transactionIndex: "23", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa503bffac65a395a94fb2e2f11c487016958021cf6057769287e1620bb9b3dbb89a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b3134333632312c205b365d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212201d5280b35edf2b8af4e78d13ae1a3284bf1e3e2333136aa485ce0e09ad11e317000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "933524", gasUsed: "138784", confirmations: "3297032"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x3bffac65a395a94fb2e2f11c487016958021cf6057769287e1620bb9b3dbb89a"}, {type: "string", name: "result", value: `[143621, [6]]`}, {type: "bytes", name: "proof", value: "0x12201d5280b35edf2b8af4e78d13ae1a3284bf1e3e2333136aa485ce0e09ad11e317"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x3bffac65a395a94fb2e2f11c487016958021cf6057769287e1620bb9b3dbb89a", `[143621, [6]]`, "0x12201d5280b35edf2b8af4e78d13ae1a3284bf1e3e2333136aa485ce0e09ad11e317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508942558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143621"}, {name: "BetID", type: "bytes32", value: "0x3bffac65a395a94fb2e2f11c487016958021cf6057769287e1620bb9b3dbb89a"}, {name: "PlayerAddress", type: "address", value: "0x17f20515dd55fb487a56482b7a41883726f211bd"}, {name: "PlayerNumber", type: "uint256", value: "97"}, {name: "DiceResult", type: "uint256", value: "6"}, {name: "Value", type: "uint256", value: "103124999999999999"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12201d5280b35edf2b8af4e78d13ae1a3284bf1e3e2333136aa485ce0e09ad11e317"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4427504", timeStamp: "1508943872", hash: "0x28131adf54dfdbc4c0180b6a2b73c00376507b8515577c4ab2fafcb36cadfd05", nonce: "3598", blockHash: "0xe9fe46b2a1b3f30e33642ad57172da32674b3fa4e82e643d9980b32a49c11989", transactionIndex: "29", from: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "102000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2432175", gasUsed: "179716", confirmations: "3296942"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "102000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508943872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x5bb9dabc13fb494d5cc074f5848e6fcc96064a54d87863f7149355ad72f97bb9"}, {name: "PlayerAddress", type: "address", value: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1"}, {name: "RewardValue", type: "uint256", value: "206081632653061223"}, {name: "ProfitValue", type: "uint256", value: "104081632653061223"}, {name: "BetValue", type: "uint256", value: "102000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "50"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "102128058961399169367" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x5bb9dabc13fb494d5cc074f5848e6fcc9606... )", async function( ) {
		const txOriginal = {blockNumber: "4427507", timeStamp: "1508943944", hash: "0xeb0fbc50b73dad690c0328d46b50a6b8d8fcf7bcc9a5a88001151d297e8f75be", nonce: "311857", blockHash: "0xe0aaffea9c260ed91bd82e0b81f2f9b7798eaf1f01075bd54994a15113606cc2", transactionIndex: "42", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa505bb9dabc13fb494d5cc074f5848e6fcc96064a54d87863f7149355ad72f97bb9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632322c205b31325d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212201e4a1c869c069998d18137b1dc27702981c3834ebf718c563127db7422ea45e9000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1941464", gasUsed: "139812", confirmations: "3296939"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x5bb9dabc13fb494d5cc074f5848e6fcc96064a54d87863f7149355ad72f97bb9"}, {type: "string", name: "result", value: `[143622, [12]]`}, {type: "bytes", name: "proof", value: "0x12201e4a1c869c069998d18137b1dc27702981c3834ebf718c563127db7422ea45e9"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x5bb9dabc13fb494d5cc074f5848e6fcc96064a54d87863f7149355ad72f97bb9", `[143622, [12]]`, "0x12201e4a1c869c069998d18137b1dc27702981c3834ebf718c563127db7422ea45e9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508943944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143622"}, {name: "BetID", type: "bytes32", value: "0x5bb9dabc13fb494d5cc074f5848e6fcc96064a54d87863f7149355ad72f97bb9"}, {name: "PlayerAddress", type: "address", value: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1"}, {name: "PlayerNumber", type: "uint256", value: "50"}, {name: "DiceResult", type: "uint256", value: "12"}, {name: "Value", type: "uint256", value: "206081632653061223"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12201e4a1c869c069998d18137b1dc27702981c3834ebf718c563127db7422ea45e9"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4427532", timeStamp: "1508944225", hash: "0xb0535939a5be1d99f8ef979b9614be24f9975bca29985be062e1f9a7438644dd", nonce: "3599", blockHash: "0x9169ced3ac960a5c5088c1fa913bae373c63bba97d10c9d692b57c7687b9dd27", transactionIndex: "24", from: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "106000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1669736", gasUsed: "179716", confirmations: "3296914"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "106000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508944225 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x20bdf1830541b82c0326e4db48129a1ce8b3c72d0a83af05de993f3341c5503c"}, {name: "PlayerAddress", type: "address", value: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1"}, {name: "RewardValue", type: "uint256", value: "214163265306122448"}, {name: "ProfitValue", type: "uint256", value: "108163265306122448"}, {name: "BetValue", type: "uint256", value: "106000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "50"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "102128058961399169367" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x20bdf1830541b82c0326e4db48129a1ce8b3... )", async function( ) {
		const txOriginal = {blockNumber: "4427534", timeStamp: "1508944260", hash: "0x7fb56eab69a0070ab6ee5931d9b7bd104bdb0707fa6452fba88e7183c6235a23", nonce: "311858", blockHash: "0xda82fd315e77a9693c1937b36ca1892ebaca8704332f77bdf037b29f9f8f1dd2", transactionIndex: "19", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5020bdf1830541b82c0326e4db48129a1ce8b3c72d0a83af05de993f3341c5503c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632332c205b32325d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220632c0e7bb5f16d53b89ece90c7f87ac859bcaf1207beb29cc041d69b87d0910e000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "595832", gasUsed: "139812", confirmations: "3296912"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x20bdf1830541b82c0326e4db48129a1ce8b3c72d0a83af05de993f3341c5503c"}, {type: "string", name: "result", value: `[143623, [22]]`}, {type: "bytes", name: "proof", value: "0x1220632c0e7bb5f16d53b89ece90c7f87ac859bcaf1207beb29cc041d69b87d0910e"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x20bdf1830541b82c0326e4db48129a1ce8b3c72d0a83af05de993f3341c5503c", `[143623, [22]]`, "0x1220632c0e7bb5f16d53b89ece90c7f87ac859bcaf1207beb29cc041d69b87d0910e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508944260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143623"}, {name: "BetID", type: "bytes32", value: "0x20bdf1830541b82c0326e4db48129a1ce8b3c72d0a83af05de993f3341c5503c"}, {name: "PlayerAddress", type: "address", value: "0x28fa7f0806c76a06ad7c02b5e313c6c5c9e49fc1"}, {name: "PlayerNumber", type: "uint256", value: "50"}, {name: "DiceResult", type: "uint256", value: "22"}, {name: "Value", type: "uint256", value: "214163265306122448"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220632c0e7bb5f16d53b89ece90c7f87ac859bcaf1207beb29cc041d69b87d0910e"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4427534", timeStamp: "1508944260", hash: "0xd4cf74de3be862144c58528d132b2438c2dbf7c27bb2d395a74dbff52b136da6", nonce: "68", blockHash: "0xda82fd315e77a9693c1937b36ca1892ebaca8704332f77bdf037b29f9f8f1dd2", transactionIndex: "33", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1175643", gasUsed: "179716", confirmations: "3296912"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508944260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xc72aca35b4f8e5fcd78315144940beec36d49e71e27cabd9da9747c9d0580700"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "202040816326530611"}, {name: "ProfitValue", type: "uint256", value: "102040816326530611"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "50"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xc72aca35b4f8e5fcd78315144940beec36d4... )", async function( ) {
		const txOriginal = {blockNumber: "4427536", timeStamp: "1508944331", hash: "0xa69b26f705b0b6502dfdb70ae3ed1269613b1f0696ce13a705da342dec622aac", nonce: "311859", blockHash: "0x084c2b8a04fca930780cab5db72258d28f2db94e2fd2e61153710ddaeee24045", transactionIndex: "83", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50c72aca35b4f8e5fcd78315144940beec36d49e71e27cabd9da9747c9d0580700000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632342c205b32395d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220e10641c45ae93eafc3087b206dd946da7b6e133abb734012eb0f9a401f00c32f000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3759451", gasUsed: "139684", confirmations: "3296910"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xc72aca35b4f8e5fcd78315144940beec36d49e71e27cabd9da9747c9d0580700"}, {type: "string", name: "result", value: `[143624, [29]]`}, {type: "bytes", name: "proof", value: "0x1220e10641c45ae93eafc3087b206dd946da7b6e133abb734012eb0f9a401f00c32f"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xc72aca35b4f8e5fcd78315144940beec36d49e71e27cabd9da9747c9d0580700", `[143624, [29]]`, "0x1220e10641c45ae93eafc3087b206dd946da7b6e133abb734012eb0f9a401f00c32f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508944331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143624"}, {name: "BetID", type: "bytes32", value: "0xc72aca35b4f8e5fcd78315144940beec36d49e71e27cabd9da9747c9d0580700"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "50"}, {name: "DiceResult", type: "uint256", value: "29"}, {name: "Value", type: "uint256", value: "202040816326530611"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220e10641c45ae93eafc3087b206dd946da7b6e133abb734012eb0f9a401f00c32f"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"86\" )", async function( ) {
		const txOriginal = {blockNumber: "4427559", timeStamp: "1508944533", hash: "0x1235f02e8cbfbcf57f57c198595b8f53ff27969ce93179032fd8b341c8aeff6e", nonce: "33", blockHash: "0xab3905bf4660464b591714bc0f845d30fcb9ef3cd8fbcbded9630cf806d357b0", transactionIndex: "31", from: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "250000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000056", contractAddress: "", cumulativeGasUsed: "1285187", gasUsed: "179716", confirmations: "3296887"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "86"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "86", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508944533 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xd91f62749545a79cd1faff457b6900b1030923aec23f8211beba9927f7292f3c"}, {name: "PlayerAddress", type: "address", value: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819"}, {name: "RewardValue", type: "uint256", value: "291176470588235293"}, {name: "ProfitValue", type: "uint256", value: "41176470588235293"}, {name: "BetValue", type: "uint256", value: "250000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "86"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "1042524731628469" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd91f62749545a79cd1faff457b6900b10309... )", async function( ) {
		const txOriginal = {blockNumber: "4427561", timeStamp: "1508944563", hash: "0x5a01c410eeef03e8f2a5293eb8f3bb3e05a33c1e5f364b7b2816137530305c03", nonce: "311866", blockHash: "0x64dfe55f1fd4e5563196dc6bfdd82da7b08537b11b5b7dbf7be3f01e6540587b", transactionIndex: "27", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50d91f62749545a79cd1faff457b6900b1030923aec23f8211beba9927f7292f3c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632352c205b35315d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220df81eb80b589e9f7e52ff53d7f1031396121814cd089933861411519a6ea6cc1000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1142127", gasUsed: "139748", confirmations: "3296885"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd91f62749545a79cd1faff457b6900b1030923aec23f8211beba9927f7292f3c"}, {type: "string", name: "result", value: `[143625, [51]]`}, {type: "bytes", name: "proof", value: "0x1220df81eb80b589e9f7e52ff53d7f1031396121814cd089933861411519a6ea6cc1"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xd91f62749545a79cd1faff457b6900b1030923aec23f8211beba9927f7292f3c", `[143625, [51]]`, "0x1220df81eb80b589e9f7e52ff53d7f1031396121814cd089933861411519a6ea6cc1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508944563 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143625"}, {name: "BetID", type: "bytes32", value: "0xd91f62749545a79cd1faff457b6900b1030923aec23f8211beba9927f7292f3c"}, {name: "PlayerAddress", type: "address", value: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819"}, {name: "PlayerNumber", type: "uint256", value: "86"}, {name: "DiceResult", type: "uint256", value: "51"}, {name: "Value", type: "uint256", value: "291176470588235293"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220df81eb80b589e9f7e52ff53d7f1031396121814cd089933861411519a6ea6cc1"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"48\" )", async function( ) {
		const txOriginal = {blockNumber: "4427562", timeStamp: "1508944567", hash: "0xd1b708571e5d06f34f59c066ed2723463875783075c9683302c69777d69edcdd", nonce: "69", blockHash: "0x1ef2e1aa448fe2881f5041029326b6f3ae6f51a6b4803da2f9dbcdfc867cbfbe", transactionIndex: "20", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000030", contractAddress: "", cumulativeGasUsed: "1254142", gasUsed: "179716", confirmations: "3296884"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "48"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "48", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508944567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xfa2f994a3deafd18bc7dc2848a3510ba18ec19859d34d86e2ad32d3aab0dd42a"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "210638297872340424"}, {name: "ProfitValue", type: "uint256", value: "110638297872340424"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "48"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfa2f994a3deafd18bc7dc2848a3510ba18ec... )", async function( ) {
		const txOriginal = {blockNumber: "4427564", timeStamp: "1508944602", hash: "0xc75410714e9a6366bc030f032316dd136cf7571a1b06abb2de2d8b94afdbff04", nonce: "311867", blockHash: "0xc5e4c11025f46ea5a4b69c08f88112bbdf7f336670ebcbbc8149c3ab770469e7", transactionIndex: "28", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50fa2f994a3deafd18bc7dc2848a3510ba18ec19859d34d86e2ad32d3aab0dd42a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000f5b3134333632362c205b3130305d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220b021e6ada1f77bdea175c758966817f1189c29ffa7b265d59e5ed8be4ca4573d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1090829", gasUsed: "130081", confirmations: "3296882"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfa2f994a3deafd18bc7dc2848a3510ba18ec19859d34d86e2ad32d3aab0dd42a"}, {type: "string", name: "result", value: `[143626, [100]]`}, {type: "bytes", name: "proof", value: "0x1220b021e6ada1f77bdea175c758966817f1189c29ffa7b265d59e5ed8be4ca4573d"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xfa2f994a3deafd18bc7dc2848a3510ba18ec19859d34d86e2ad32d3aab0dd42a", `[143626, [100]]`, "0x1220b021e6ada1f77bdea175c758966817f1189c29ffa7b265d59e5ed8be4ca4573d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508944602 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143626"}, {name: "BetID", type: "bytes32", value: "0xfa2f994a3deafd18bc7dc2848a3510ba18ec19859d34d86e2ad32d3aab0dd42a"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "48"}, {name: "DiceResult", type: "uint256", value: "100"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220b021e6ada1f77bdea175c758966817f1189c29ffa7b265d59e5ed8be4ca4573d"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"84\" )", async function( ) {
		const txOriginal = {blockNumber: "4427569", timeStamp: "1508944671", hash: "0xd9e5f840c411fc7bdfd59a2254ed1015fcafde681b1d65acab11ece7b9ef58e4", nonce: "34", blockHash: "0x82cb7bdf62a3e79fdf5002f0810a005a3a346bb182382a7257c44e24bd1fb24e", transactionIndex: "98", from: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "250000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000054", contractAddress: "", cumulativeGasUsed: "6598226", gasUsed: "179716", confirmations: "3296877"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "84"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "84", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508944671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x0ba3f9d55d8149f4189e6ea1a4ce0aa6f1283f8821cf5419f9f455a1c171a7bc"}, {name: "PlayerAddress", type: "address", value: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819"}, {name: "RewardValue", type: "uint256", value: "298192771084337348"}, {name: "ProfitValue", type: "uint256", value: "48192771084337348"}, {name: "BetValue", type: "uint256", value: "250000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "84"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "1042524731628469" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x0ba3f9d55d8149f4189e6ea1a4ce0aa6f128... )", async function( ) {
		const txOriginal = {blockNumber: "4427572", timeStamp: "1508944720", hash: "0xff9289b40070acdcb7bea8111b724a648707b10392069e62bbd680b8102f275b", nonce: "311868", blockHash: "0xd45c80d90660ce59abf28f923bc31dc790096458e2f6851fceaa68d4121a3a81", transactionIndex: "32", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa500ba3f9d55d8149f4189e6ea1a4ce0aa6f1283f8821cf5419f9f455a1c171a7bc000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632372c205b38385d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220dc0ca8ad90c5a73cc2ec5a732436b28e94edb18d5fe38e90613a71735490f32d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1649922", gasUsed: "129053", confirmations: "3296874"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x0ba3f9d55d8149f4189e6ea1a4ce0aa6f1283f8821cf5419f9f455a1c171a7bc"}, {type: "string", name: "result", value: `[143627, [88]]`}, {type: "bytes", name: "proof", value: "0x1220dc0ca8ad90c5a73cc2ec5a732436b28e94edb18d5fe38e90613a71735490f32d"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x0ba3f9d55d8149f4189e6ea1a4ce0aa6f1283f8821cf5419f9f455a1c171a7bc", `[143627, [88]]`, "0x1220dc0ca8ad90c5a73cc2ec5a732436b28e94edb18d5fe38e90613a71735490f32d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508944720 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143627"}, {name: "BetID", type: "bytes32", value: "0x0ba3f9d55d8149f4189e6ea1a4ce0aa6f1283f8821cf5419f9f455a1c171a7bc"}, {name: "PlayerAddress", type: "address", value: "0xa6ce8b15caf7464a7de58f5907bb5e6c1f89a819"}, {name: "PlayerNumber", type: "uint256", value: "84"}, {name: "DiceResult", type: "uint256", value: "88"}, {name: "Value", type: "uint256", value: "250000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220dc0ca8ad90c5a73cc2ec5a732436b28e94edb18d5fe38e90613a71735490f32d"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"48\" )", async function( ) {
		const txOriginal = {blockNumber: "4427581", timeStamp: "1508944889", hash: "0xdd0daf05c84470838b42b2df4aa809098faf97d6fcf344cb77377e1e591ed651", nonce: "70", blockHash: "0x488f6f4e25cd4d16787adacab6d6e2a4953ea5491b0ed5269905fa79f42fb3ec", transactionIndex: "82", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000030", contractAddress: "", cumulativeGasUsed: "3433039", gasUsed: "179716", confirmations: "3296865"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "48"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "48", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508944889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x02d7876227ccfead536eefc1004ab0d63e8eafcdcd4e09c8860e53d458ae7908"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "210638297872340424"}, {name: "ProfitValue", type: "uint256", value: "110638297872340424"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "48"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x02d7876227ccfead536eefc1004ab0d63e8e... )", async function( ) {
		const txOriginal = {blockNumber: "4427583", timeStamp: "1508944912", hash: "0xe0cd371208d1d5848ae9f0772161771cea01dc39f1c119fbb003b88e73da3c73", nonce: "311869", blockHash: "0x2cd2cddcc9c7d261dfce698305097ecbc787837a387e8e9dd0717e318ad0e836", transactionIndex: "33", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5002d7876227ccfead536eefc1004ab0d63e8eafcdcd4e09c8860e53d458ae7908000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632382c205b33395d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220ea20b616ff4f5e21710a97b1748607c02e5af32660b353012550bf64e83640a4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1637509", gasUsed: "139748", confirmations: "3296863"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x02d7876227ccfead536eefc1004ab0d63e8eafcdcd4e09c8860e53d458ae7908"}, {type: "string", name: "result", value: `[143628, [39]]`}, {type: "bytes", name: "proof", value: "0x1220ea20b616ff4f5e21710a97b1748607c02e5af32660b353012550bf64e83640a4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x02d7876227ccfead536eefc1004ab0d63e8eafcdcd4e09c8860e53d458ae7908", `[143628, [39]]`, "0x1220ea20b616ff4f5e21710a97b1748607c02e5af32660b353012550bf64e83640a4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508944912 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143628"}, {name: "BetID", type: "bytes32", value: "0x02d7876227ccfead536eefc1004ab0d63e8eafcdcd4e09c8860e53d458ae7908"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "48"}, {name: "DiceResult", type: "uint256", value: "39"}, {name: "Value", type: "uint256", value: "210638297872340424"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220ea20b616ff4f5e21710a97b1748607c02e5af32660b353012550bf64e83640a4"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"49\" )", async function( ) {
		const txOriginal = {blockNumber: "4427592", timeStamp: "1508945048", hash: "0xb6af5f41d007acd01007ae5e9faf597bae592656b9c6f32fc41b138c0d822d15", nonce: "71", blockHash: "0x75bd1a281ec4ae548b078863ee0ce57d6959b6a6606bb00c6a1c57bdd8ed5d22", transactionIndex: "120", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "200000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000031", contractAddress: "", cumulativeGasUsed: "4525128", gasUsed: "179716", confirmations: "3296854"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "49"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "49", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508945048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xa05c7c56103fcc72732e86c8e7294c82309cffbaee19dcf82c4c8f97c924a285"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "412499999999999999"}, {name: "ProfitValue", type: "uint256", value: "212499999999999999"}, {name: "BetValue", type: "uint256", value: "200000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "49"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa05c7c56103fcc72732e86c8e7294c82309c... )", async function( ) {
		const txOriginal = {blockNumber: "4427594", timeStamp: "1508945073", hash: "0x8cb4a140031e77b8bea206d56c49588c61a01d037bf127b6ee05c34ae6be9aa1", nonce: "311870", blockHash: "0x99beb1215fadd692f3593c4fffc236fbdaf163609669c86b1ac7e554a563ea65", transactionIndex: "11", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50a05c7c56103fcc72732e86c8e7294c82309cffbaee19dcf82c4c8f97c924a285000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333632392c205b34335d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220be7c01c7b9044fd0beb3af4f269f5c2666f694945aed019fa580a8b2d8876da0000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "893671", gasUsed: "139812", confirmations: "3296852"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa05c7c56103fcc72732e86c8e7294c82309cffbaee19dcf82c4c8f97c924a285"}, {type: "string", name: "result", value: `[143629, [43]]`}, {type: "bytes", name: "proof", value: "0x1220be7c01c7b9044fd0beb3af4f269f5c2666f694945aed019fa580a8b2d8876da0"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xa05c7c56103fcc72732e86c8e7294c82309cffbaee19dcf82c4c8f97c924a285", `[143629, [43]]`, "0x1220be7c01c7b9044fd0beb3af4f269f5c2666f694945aed019fa580a8b2d8876da0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508945073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143629"}, {name: "BetID", type: "bytes32", value: "0xa05c7c56103fcc72732e86c8e7294c82309cffbaee19dcf82c4c8f97c924a285"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "49"}, {name: "DiceResult", type: "uint256", value: "43"}, {name: "Value", type: "uint256", value: "412499999999999999"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220be7c01c7b9044fd0beb3af4f269f5c2666f694945aed019fa580a8b2d8876da0"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"49\" )", async function( ) {
		const txOriginal = {blockNumber: "4427603", timeStamp: "1508945176", hash: "0x01ebc8cafa65b563e27873d66e2cbb724e8c9ca17a82fa7fee5a4a619bab713c", nonce: "72", blockHash: "0x570a458c8f689946fef2e70e7875fa04c9e11f3e44459f471e9d7d3763c7be95", transactionIndex: "82", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "200000000000000000", gas: "250000", gasPrice: "8693750000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000031", contractAddress: "", cumulativeGasUsed: "3217036", gasUsed: "179716", confirmations: "3296843"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "49"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "49", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508945176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xb401f52bcf77a4eb7cd5e22121ab3cec9a7188cb961916db5390b3a7773f5274"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "412499999999999999"}, {name: "ProfitValue", type: "uint256", value: "212499999999999999"}, {name: "BetValue", type: "uint256", value: "200000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "49"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xb401f52bcf77a4eb7cd5e22121ab3cec9a71... )", async function( ) {
		const txOriginal = {blockNumber: "4427605", timeStamp: "1508945265", hash: "0x49e51c8a4c0e860bd44c9288de0df71eb5e5928848e9ff3dd6136f751b5f986a", nonce: "311871", blockHash: "0xcd61d8f79fa703aba6eab4214734082b8020fbc5d6d9d59ee00e31d3d7d37de2", transactionIndex: "24", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50b401f52bcf77a4eb7cd5e22121ab3cec9a7188cb961916db5390b3a7773f5274000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633302c205b35315d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122040eb5b14062b598bfd2ae4d43e6569e7681cac455757e6665d897d22b45744ad000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1157725", gasUsed: "129053", confirmations: "3296841"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xb401f52bcf77a4eb7cd5e22121ab3cec9a7188cb961916db5390b3a7773f5274"}, {type: "string", name: "result", value: `[143630, [51]]`}, {type: "bytes", name: "proof", value: "0x122040eb5b14062b598bfd2ae4d43e6569e7681cac455757e6665d897d22b45744ad"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xb401f52bcf77a4eb7cd5e22121ab3cec9a7188cb961916db5390b3a7773f5274", `[143630, [51]]`, "0x122040eb5b14062b598bfd2ae4d43e6569e7681cac455757e6665d897d22b45744ad", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508945265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143630"}, {name: "BetID", type: "bytes32", value: "0xb401f52bcf77a4eb7cd5e22121ab3cec9a7188cb961916db5390b3a7773f5274"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "49"}, {name: "DiceResult", type: "uint256", value: "51"}, {name: "Value", type: "uint256", value: "200000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x122040eb5b14062b598bfd2ae4d43e6569e7681cac455757e6665d897d22b45744ad"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"34\" )", async function( ) {
		const txOriginal = {blockNumber: "4427610", timeStamp: "1508945331", hash: "0x4e13283fd0f30608fb246a2c8c7486d0823776eda6f1843a7eb7c5273eaaf093", nonce: "73", blockHash: "0xe29cd2c2c232f0ec6acc36c29091fc05b5154a5a2a994ac08713702296791dd4", transactionIndex: "34", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000022", contractAddress: "", cumulativeGasUsed: "1794341", gasUsed: "179716", confirmations: "3296836"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "34"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "34", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508945331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x3a69bf3ea21c41090b8008a26612eba42326e6f046985a4f2487e39a04570c2e"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "299999999999999999"}, {name: "ProfitValue", type: "uint256", value: "199999999999999999"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "34"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3a69bf3ea21c41090b8008a26612eba42326... )", async function( ) {
		const txOriginal = {blockNumber: "4427612", timeStamp: "1508945348", hash: "0x92338a33b127defae4feb915dd2881d53df2d8f36c1a4398a974dc1da62d7c22", nonce: "311872", blockHash: "0xeabd1b9615c5dfbc5c147cf23a5e6d014e65142df5563bbb3d7e89904ef7cdec", transactionIndex: "33", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa503a69bf3ea21c41090b8008a26612eba42326e6f046985a4f2487e39a04570c2e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633312c205b39305d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220ad0b32009d654a5b1d5f4278281a9844c5f912a79666925b70dbe099f5730e17000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1840979", gasUsed: "128989", confirmations: "3296834"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x3a69bf3ea21c41090b8008a26612eba42326e6f046985a4f2487e39a04570c2e"}, {type: "string", name: "result", value: `[143631, [90]]`}, {type: "bytes", name: "proof", value: "0x1220ad0b32009d654a5b1d5f4278281a9844c5f912a79666925b70dbe099f5730e17"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x3a69bf3ea21c41090b8008a26612eba42326e6f046985a4f2487e39a04570c2e", `[143631, [90]]`, "0x1220ad0b32009d654a5b1d5f4278281a9844c5f912a79666925b70dbe099f5730e17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508945348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143631"}, {name: "BetID", type: "bytes32", value: "0x3a69bf3ea21c41090b8008a26612eba42326e6f046985a4f2487e39a04570c2e"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "34"}, {name: "DiceResult", type: "uint256", value: "90"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220ad0b32009d654a5b1d5f4278281a9844c5f912a79666925b70dbe099f5730e17"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"83\" )", async function( ) {
		const txOriginal = {blockNumber: "4427616", timeStamp: "1508945389", hash: "0x63a44686627e86fe00bf32daa0278e9d7a687144df37469a4a713775c371845b", nonce: "0", blockHash: "0xcfba7bef5f225aab40e3418ef88ef520f47137499e5e676e2d842fea1d4c84e7", transactionIndex: "19", from: "0x544540be56348e391cd3a0909f6b582d926a8ffe", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "500000000000000000", gas: "250000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000053", contractAddress: "", cumulativeGasUsed: "752615", gasUsed: "179716", confirmations: "3296830"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "83"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "83", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508945389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x6d03f13040fb9ae9e662aaca08f57e8f3b5246ce1a7af3876589b061434d681c"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "RewardValue", type: "uint256", value: "603658536585365852"}, {name: "ProfitValue", type: "uint256", value: "103658536585365852"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "83"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "9268985487425976" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6d03f13040fb9ae9e662aaca08f57e8f3b52... )", async function( ) {
		const txOriginal = {blockNumber: "4427619", timeStamp: "1508945443", hash: "0xe75fec34078bd531eeef488500402a351e6920a71a94fb07ab7a64e454b0ed23", nonce: "311873", blockHash: "0x9e501b93fd93fa44ddfb258e49eeef7edd2c7c913f4aa43f8edd9cf75d35c68b", transactionIndex: "15", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa506d03f13040fb9ae9e662aaca08f57e8f3b5246ce1a7af3876589b061434d681c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633322c205b37375d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212200e6a83683166b87d481a2cc7b7cf611566352461ad719b5b877b453057a6f36a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "832745", gasUsed: "139812", confirmations: "3296827"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x6d03f13040fb9ae9e662aaca08f57e8f3b5246ce1a7af3876589b061434d681c"}, {type: "string", name: "result", value: `[143632, [77]]`}, {type: "bytes", name: "proof", value: "0x12200e6a83683166b87d481a2cc7b7cf611566352461ad719b5b877b453057a6f36a"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x6d03f13040fb9ae9e662aaca08f57e8f3b5246ce1a7af3876589b061434d681c", `[143632, [77]]`, "0x12200e6a83683166b87d481a2cc7b7cf611566352461ad719b5b877b453057a6f36a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508945443 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143632"}, {name: "BetID", type: "bytes32", value: "0x6d03f13040fb9ae9e662aaca08f57e8f3b5246ce1a7af3876589b061434d681c"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "PlayerNumber", type: "uint256", value: "83"}, {name: "DiceResult", type: "uint256", value: "77"}, {name: "Value", type: "uint256", value: "603658536585365852"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12200e6a83683166b87d481a2cc7b7cf611566352461ad719b5b877b453057a6f36a"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"86\" )", async function( ) {
		const txOriginal = {blockNumber: "4427632", timeStamp: "1508945656", hash: "0x5e164557c642fd98ec48c6d3334b7729400350e470d384dfa7349b7819879fd7", nonce: "1", blockHash: "0x2ef91a2acb9e155712c9530b62433c7a0971ccbc24d7c363d1150ce1c8bf2e47", transactionIndex: "2", from: "0x544540be56348e391cd3a0909f6b582d926a8ffe", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "500000000000000000", gas: "250000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000056", contractAddress: "", cumulativeGasUsed: "224036", gasUsed: "179716", confirmations: "3296814"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "86"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "86", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508945656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x70899f79afa1aaa10b1e6943133b70bf9ca5a1d61a46aa0ecc1a71fc389d2623"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "RewardValue", type: "uint256", value: "582352941176470587"}, {name: "ProfitValue", type: "uint256", value: "82352941176470587"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "86"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "9268985487425976" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x70899f79afa1aaa10b1e6943133b70bf9ca5... )", async function( ) {
		const txOriginal = {blockNumber: "4427636", timeStamp: "1508945684", hash: "0xe4c78629eca322e0c509aeec23c1aa82ccc7552b9ee124d6fccbfdf6a2950e07", nonce: "311875", blockHash: "0x2410b2b803c046c50dffe155a51e8f4ca859796df3a6c32f46446b0b49889c26", transactionIndex: "6", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5070899f79afa1aaa10b1e6943133b70bf9ca5a1d61a46aa0ecc1a71fc389d2623000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633342c205b34325d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220e42b88e2b244c801c765074e3aa21d83025ba2dbb30b2a91170dd8d485f1f5c7000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "392211", gasUsed: "139812", confirmations: "3296810"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x70899f79afa1aaa10b1e6943133b70bf9ca5a1d61a46aa0ecc1a71fc389d2623"}, {type: "string", name: "result", value: `[143634, [42]]`}, {type: "bytes", name: "proof", value: "0x1220e42b88e2b244c801c765074e3aa21d83025ba2dbb30b2a91170dd8d485f1f5c7"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x70899f79afa1aaa10b1e6943133b70bf9ca5a1d61a46aa0ecc1a71fc389d2623", `[143634, [42]]`, "0x1220e42b88e2b244c801c765074e3aa21d83025ba2dbb30b2a91170dd8d485f1f5c7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1508945684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143634"}, {name: "BetID", type: "bytes32", value: "0x70899f79afa1aaa10b1e6943133b70bf9ca5a1d61a46aa0ecc1a71fc389d2623"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "PlayerNumber", type: "uint256", value: "86"}, {name: "DiceResult", type: "uint256", value: "42"}, {name: "Value", type: "uint256", value: "582352941176470587"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220e42b88e2b244c801c765074e3aa21d83025ba2dbb30b2a91170dd8d485f1f5c7"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"63\" )", async function( ) {
		const txOriginal = {blockNumber: "4427645", timeStamp: "1508945803", hash: "0x6e769778b058218a28ffc2ac26172addece3f4bf0fd91fa1aa41bd7829ad6bf8", nonce: "26", blockHash: "0xbf1ad2f9290611ebc4743ca92f0d57274b851112306da405f252dc335b54a2ce", transactionIndex: "24", from: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd152000000000000000000000000000000000000000000000000000000000000003f", contractAddress: "", cumulativeGasUsed: "886765", gasUsed: "179716", confirmations: "3296801"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "63"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "63", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508945803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xfb724f86ebd11f8e82188ecdd29783aabe646c7142143ec2a508dda84a7a1bb1"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "RewardValue", type: "uint256", value: "159677419354838709"}, {name: "ProfitValue", type: "uint256", value: "59677419354838709"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "63"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfb724f86ebd11f8e82188ecdd29783aabe64... )", async function( ) {
		const txOriginal = {blockNumber: "4427647", timeStamp: "1508945828", hash: "0xaa7d34c69f112b4dcf6cd3ef5d98a3243e5c5408a6b831e80fb9a56abb9ee290", nonce: "311876", blockHash: "0xf80566c331bdd7424baca6c669d32571ee126e36e98671caa8876e89d6ec09b5", transactionIndex: "27", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50fb724f86ebd11f8e82188ecdd29783aabe646c7142143ec2a508dda84a7a1bb1000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633352c205b32395d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212209e16d032e3017bdc0395871a762debe1121ac4f209ef69527675c0041303d861000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2015959", gasUsed: "139812", confirmations: "3296799"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfb724f86ebd11f8e82188ecdd29783aabe646c7142143ec2a508dda84a7a1bb1"}, {type: "string", name: "result", value: `[143635, [29]]`}, {type: "bytes", name: "proof", value: "0x12209e16d032e3017bdc0395871a762debe1121ac4f209ef69527675c0041303d861"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xfb724f86ebd11f8e82188ecdd29783aabe646c7142143ec2a508dda84a7a1bb1", `[143635, [29]]`, "0x12209e16d032e3017bdc0395871a762debe1121ac4f209ef69527675c0041303d861", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508945828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143635"}, {name: "BetID", type: "bytes32", value: "0xfb724f86ebd11f8e82188ecdd29783aabe646c7142143ec2a508dda84a7a1bb1"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "PlayerNumber", type: "uint256", value: "63"}, {name: "DiceResult", type: "uint256", value: "29"}, {name: "Value", type: "uint256", value: "159677419354838709"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12209e16d032e3017bdc0395871a762debe1121ac4f209ef69527675c0041303d861"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"80\" )", async function( ) {
		const txOriginal = {blockNumber: "4427657", timeStamp: "1508945985", hash: "0xbbfc64ab5b735f3a5d0e11b35e413a2135343ef2b110427275ebfe7393aaf875", nonce: "2", blockHash: "0x9bcdf83ae8bf3c5ec2aed0e1f3fb20b56620380f0ce6ca534ba158a960a5b790", transactionIndex: "55", from: "0x544540be56348e391cd3a0909f6b582d926a8ffe", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "200000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000050", contractAddress: "", cumulativeGasUsed: "2179828", gasUsed: "179716", confirmations: "3296789"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "80"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "80", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508945985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x49f8eddd8884ab5b9b1b5285eefe5e2ec31e434b6fec63fd3cb6b8f822898ee6"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "RewardValue", type: "uint256", value: "250632911392405062"}, {name: "ProfitValue", type: "uint256", value: "50632911392405062"}, {name: "BetValue", type: "uint256", value: "200000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "80"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "9268985487425976" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x49f8eddd8884ab5b9b1b5285eefe5e2ec31e... )", async function( ) {
		const txOriginal = {blockNumber: "4427659", timeStamp: "1508946037", hash: "0xe29b9f876d1e03d9d318f3dc3245397bf0f9d511abd31107e3f7b355bc4e5abc", nonce: "311877", blockHash: "0x84031ff9b9e5fdf72f581123ed57e9ad80e1d452534319bce1d8691022f3d8ed", transactionIndex: "45", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5049f8eddd8884ab5b9b1b5285eefe5e2ec31e434b6fec63fd3cb6b8f822898ee6000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633362c205b39375d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220268b6ffbb89fd6c9073a3dd267500a16d34fdced965574793760e641e2fc4d72000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1754982", gasUsed: "129053", confirmations: "3296787"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x49f8eddd8884ab5b9b1b5285eefe5e2ec31e434b6fec63fd3cb6b8f822898ee6"}, {type: "string", name: "result", value: `[143636, [97]]`}, {type: "bytes", name: "proof", value: "0x1220268b6ffbb89fd6c9073a3dd267500a16d34fdced965574793760e641e2fc4d72"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x49f8eddd8884ab5b9b1b5285eefe5e2ec31e434b6fec63fd3cb6b8f822898ee6", `[143636, [97]]`, "0x1220268b6ffbb89fd6c9073a3dd267500a16d34fdced965574793760e641e2fc4d72", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508946037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143636"}, {name: "BetID", type: "bytes32", value: "0x49f8eddd8884ab5b9b1b5285eefe5e2ec31e434b6fec63fd3cb6b8f822898ee6"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "PlayerNumber", type: "uint256", value: "80"}, {name: "DiceResult", type: "uint256", value: "97"}, {name: "Value", type: "uint256", value: "200000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220268b6ffbb89fd6c9073a3dd267500a16d34fdced965574793760e641e2fc4d72"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"64\" )", async function( ) {
		const txOriginal = {blockNumber: "4427659", timeStamp: "1508946037", hash: "0x8dcd8d99b06e46cb9723326831613b34289e3cd9ad9e68051f002f2989d15cdb", nonce: "27", blockHash: "0x84031ff9b9e5fdf72f581123ed57e9ad80e1d452534319bce1d8691022f3d8ed", transactionIndex: "62", from: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000040", contractAddress: "", cumulativeGasUsed: "3081131", gasUsed: "179716", confirmations: "3296787"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "64"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "64", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508946037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xf839de307baf602b2c680ef32ee0947bf349ec5f15cd5b13697be80e8ac0584f"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "RewardValue", type: "uint256", value: "157142857142857142"}, {name: "ProfitValue", type: "uint256", value: "57142857142857142"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "64"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xf839de307baf602b2c680ef32ee0947bf349... )", async function( ) {
		const txOriginal = {blockNumber: "4427661", timeStamp: "1508946064", hash: "0xfb85801a384d648b789066ff5a189a5084496d428b3968b14758214336fc7099", nonce: "311878", blockHash: "0x7663c1adc2f8ec9e558af42e4407ba8d9b91974b5228da2ccfdcf544139b04f6", transactionIndex: "32", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50f839de307baf602b2c680ef32ee0947bf349ec5f15cd5b13697be80e8ac0584f000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000f5b3134333633372c205b3130305d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220628673915cc58742df811492c67143dbef46cd1aba51078f4a4a66cb8619b1ff000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1125114", gasUsed: "130081", confirmations: "3296785"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xf839de307baf602b2c680ef32ee0947bf349ec5f15cd5b13697be80e8ac0584f"}, {type: "string", name: "result", value: `[143637, [100]]`}, {type: "bytes", name: "proof", value: "0x1220628673915cc58742df811492c67143dbef46cd1aba51078f4a4a66cb8619b1ff"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xf839de307baf602b2c680ef32ee0947bf349ec5f15cd5b13697be80e8ac0584f", `[143637, [100]]`, "0x1220628673915cc58742df811492c67143dbef46cd1aba51078f4a4a66cb8619b1ff", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508946064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143637"}, {name: "BetID", type: "bytes32", value: "0xf839de307baf602b2c680ef32ee0947bf349ec5f15cd5b13697be80e8ac0584f"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "PlayerNumber", type: "uint256", value: "64"}, {name: "DiceResult", type: "uint256", value: "100"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220628673915cc58742df811492c67143dbef46cd1aba51078f4a4a66cb8619b1ff"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"83\" )", async function( ) {
		const txOriginal = {blockNumber: "4427670", timeStamp: "1508946172", hash: "0xcb2c34a887e864e0e031b52b7022d80ded5a8e92d457b1fb809bd7dbf8cab534", nonce: "3", blockHash: "0xe15e6b770ce30bb755387693834dc919a981ee07273cfba07c65384ae8ce5c56", transactionIndex: "60", from: "0x544540be56348e391cd3a0909f6b582d926a8ffe", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "490000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000053", contractAddress: "", cumulativeGasUsed: "2740229", gasUsed: "179716", confirmations: "3296776"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "490000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "83"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "83", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1508946172 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xce30ace7c7fbbdb21dc8d6bacf1a00a029d023c9c8791965876e4a12979e6b5f"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "RewardValue", type: "uint256", value: "591585365853658536"}, {name: "ProfitValue", type: "uint256", value: "101585365853658536"}, {name: "BetValue", type: "uint256", value: "490000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "83"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "9268985487425976" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xce30ace7c7fbbdb21dc8d6bacf1a00a029d0... )", async function( ) {
		const txOriginal = {blockNumber: "4427674", timeStamp: "1508946250", hash: "0xa1ec977950d5127c0cea6f6436b9e7a999fc6717fe076325939ec225dbc535ca", nonce: "311879", blockHash: "0x1b2752355348057469be659bebcb85d5997c735812e43410a153316a3406a7d8", transactionIndex: "48", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50ce30ace7c7fbbdb21dc8d6bacf1a00a029d023c9c8791965876e4a12979e6b5f000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633382c205b35365d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212200f31b3689a78ef8c7ab23261c4b1dc7dff0937568b076e49ad2192aeb5a8731d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1983451", gasUsed: "139748", confirmations: "3296772"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xce30ace7c7fbbdb21dc8d6bacf1a00a029d023c9c8791965876e4a12979e6b5f"}, {type: "string", name: "result", value: `[143638, [56]]`}, {type: "bytes", name: "proof", value: "0x12200f31b3689a78ef8c7ab23261c4b1dc7dff0937568b076e49ad2192aeb5a8731d"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xce30ace7c7fbbdb21dc8d6bacf1a00a029d023c9c8791965876e4a12979e6b5f", `[143638, [56]]`, "0x12200f31b3689a78ef8c7ab23261c4b1dc7dff0937568b076e49ad2192aeb5a8731d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508946250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143638"}, {name: "BetID", type: "bytes32", value: "0xce30ace7c7fbbdb21dc8d6bacf1a00a029d023c9c8791965876e4a12979e6b5f"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "PlayerNumber", type: "uint256", value: "83"}, {name: "DiceResult", type: "uint256", value: "56"}, {name: "Value", type: "uint256", value: "591585365853658536"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12200f31b3689a78ef8c7ab23261c4b1dc7dff0937568b076e49ad2192aeb5a8731d"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4427674", timeStamp: "1508946250", hash: "0xcd08bc72281c0b77affd6f4c401c9f5442635cf76d8176e58022cbb4422cf93b", nonce: "28", blockHash: "0x1b2752355348057469be659bebcb85d5997c735812e43410a153316a3406a7d8", transactionIndex: "92", from: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4062738", gasUsed: "179716", confirmations: "3296772"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508946250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x683e1317cc5e4537a6daa5ee409220571932771e0b7672b708bba594327d6a33"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "RewardValue", type: "uint256", value: "202040816326530611"}, {name: "ProfitValue", type: "uint256", value: "102040816326530611"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "50"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x683e1317cc5e4537a6daa5ee409220571932... )", async function( ) {
		const txOriginal = {blockNumber: "4427676", timeStamp: "1508946289", hash: "0x32834d046c9fa60357124b30cedbb26922e49ab546982d8253ad4ee5108d57af", nonce: "311880", blockHash: "0xbb28eece5d2913db75ff54f65a45abd3d25b75e53bb178aeeec19a602d24532a", transactionIndex: "30", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50683e1317cc5e4537a6daa5ee409220571932771e0b7672b708bba594327d6a33000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333633392c205b31355d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212205336aff1ab9d111ce8d218d157fd3112588a3f8c9d9eed062098d6aeb9e2b0e2000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1498318", gasUsed: "139812", confirmations: "3296770"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x683e1317cc5e4537a6daa5ee409220571932771e0b7672b708bba594327d6a33"}, {type: "string", name: "result", value: `[143639, [15]]`}, {type: "bytes", name: "proof", value: "0x12205336aff1ab9d111ce8d218d157fd3112588a3f8c9d9eed062098d6aeb9e2b0e2"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x683e1317cc5e4537a6daa5ee409220571932771e0b7672b708bba594327d6a33", `[143639, [15]]`, "0x12205336aff1ab9d111ce8d218d157fd3112588a3f8c9d9eed062098d6aeb9e2b0e2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508946289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143639"}, {name: "BetID", type: "bytes32", value: "0x683e1317cc5e4537a6daa5ee409220571932771e0b7672b708bba594327d6a33"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "PlayerNumber", type: "uint256", value: "50"}, {name: "DiceResult", type: "uint256", value: "15"}, {name: "Value", type: "uint256", value: "202040816326530611"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12205336aff1ab9d111ce8d218d157fd3112588a3f8c9d9eed062098d6aeb9e2b0e2"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"81\" )", async function( ) {
		const txOriginal = {blockNumber: "4427685", timeStamp: "1508946404", hash: "0xc1ba10039215529c6037002ffec0f823f3542a2d2aa86c7ab4d333d4ed4b7da1", nonce: "29", blockHash: "0x5c26a175cbc076214b991f0b2d0e7dc8d3c1295c77a399c378f4cee82a132b6e", transactionIndex: "109", from: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000051", contractAddress: "", cumulativeGasUsed: "6608325", gasUsed: "179716", confirmations: "3296761"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "81"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "81", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508946404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xcc3d7ff79b89da4383327c685dfbd5ce2c4da5f9711f81cb4d1ef34309a4a9e5"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "RewardValue", type: "uint256", value: "123750000000000000"}, {name: "ProfitValue", type: "uint256", value: "23750000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "81"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xcc3d7ff79b89da4383327c685dfbd5ce2c4d... )", async function( ) {
		const txOriginal = {blockNumber: "4427688", timeStamp: "1508946454", hash: "0xa3cb0c37baef83eaf7fe7e19cc896f49ee39e1386718c324f27067d98b711bb4", nonce: "311881", blockHash: "0x12b425b68f3ff7402f80af8f88d7732c1d3e660cb8aa9e1683e60850edc6e9c8", transactionIndex: "11", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50cc3d7ff79b89da4383327c685dfbd5ce2c4da5f9711f81cb4d1ef34309a4a9e5000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333634302c205b35325d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220932d78565a84fe8d9985df4669b1be5fd8bb82629efa7f4128b8142c30f6f5ea000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "452535", gasUsed: "139812", confirmations: "3296758"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xcc3d7ff79b89da4383327c685dfbd5ce2c4da5f9711f81cb4d1ef34309a4a9e5"}, {type: "string", name: "result", value: `[143640, [52]]`}, {type: "bytes", name: "proof", value: "0x1220932d78565a84fe8d9985df4669b1be5fd8bb82629efa7f4128b8142c30f6f5ea"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xcc3d7ff79b89da4383327c685dfbd5ce2c4da5f9711f81cb4d1ef34309a4a9e5", `[143640, [52]]`, "0x1220932d78565a84fe8d9985df4669b1be5fd8bb82629efa7f4128b8142c30f6f5ea", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508946454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143640"}, {name: "BetID", type: "bytes32", value: "0xcc3d7ff79b89da4383327c685dfbd5ce2c4da5f9711f81cb4d1ef34309a4a9e5"}, {name: "PlayerAddress", type: "address", value: "0x8d04679f50fa5d1c3a4c96e1f7d6b3eae3a983d6"}, {name: "PlayerNumber", type: "uint256", value: "81"}, {name: "DiceResult", type: "uint256", value: "52"}, {name: "Value", type: "uint256", value: "123750000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220932d78565a84fe8d9985df4669b1be5fd8bb82629efa7f4128b8142c30f6f5ea"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4427694", timeStamp: "1508946517", hash: "0x16cfbcb5dc8641393bf506558cc4e410d28fab5780c7d5f2e4632956800115b9", nonce: "74", blockHash: "0xeb4ffd618635b114bddaca24ad8340733a709ae6a1f5991218156d05c5da5deb", transactionIndex: "38", from: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "100000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2063232", gasUsed: "179716", confirmations: "3296752"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508946517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x6c4e927bba35ea7e50e2878e04b523fa2bd366fe860955bb136e60dbe59d9d4a"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "RewardValue", type: "uint256", value: "202040816326530611"}, {name: "ProfitValue", type: "uint256", value: "102040816326530611"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "50"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "47926430999813270" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6c4e927bba35ea7e50e2878e04b523fa2bd3... )", async function( ) {
		const txOriginal = {blockNumber: "4427696", timeStamp: "1508946546", hash: "0x43ee271e6a570f63c9e71052c6562d61751d20cb1fb39218356078128bee1f40", nonce: "311882", blockHash: "0x24af17df969d3c3073e0321afa6208253c5a7a8992b61904ead2e62a6de57d68", transactionIndex: "25", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa506c4e927bba35ea7e50e2878e04b523fa2bd366fe860955bb136e60dbe59d9d4a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333634312c205b38325d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122004ac155f2855dd7758a04c40b806403503128eaddb5a40e6d55c186f720b8a13000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "841570", gasUsed: "129053", confirmations: "3296750"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x6c4e927bba35ea7e50e2878e04b523fa2bd366fe860955bb136e60dbe59d9d4a"}, {type: "string", name: "result", value: `[143641, [82]]`}, {type: "bytes", name: "proof", value: "0x122004ac155f2855dd7758a04c40b806403503128eaddb5a40e6d55c186f720b8a13"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x6c4e927bba35ea7e50e2878e04b523fa2bd366fe860955bb136e60dbe59d9d4a", `[143641, [82]]`, "0x122004ac155f2855dd7758a04c40b806403503128eaddb5a40e6d55c186f720b8a13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508946546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143641"}, {name: "BetID", type: "bytes32", value: "0x6c4e927bba35ea7e50e2878e04b523fa2bd366fe860955bb136e60dbe59d9d4a"}, {name: "PlayerAddress", type: "address", value: "0x1a067103f0eaa50771abb1415413de3bb8bbb32a"}, {name: "PlayerNumber", type: "uint256", value: "50"}, {name: "DiceResult", type: "uint256", value: "82"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x122004ac155f2855dd7758a04c40b806403503128eaddb5a40e6d55c186f720b8a13"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"84\" )", async function( ) {
		const txOriginal = {blockNumber: "4427702", timeStamp: "1508946584", hash: "0x3bb2120e76a02bb3ef825cca0f892b582a091e5a5b770f08469f0469a04aded7", nonce: "4", blockHash: "0x530d5b9e8682bea8aecaf8d7d675fe2ce970b46741548242213d24b746600120", transactionIndex: "20", from: "0x544540be56348e391cd3a0909f6b582d926a8ffe", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "500000000000000000", gas: "250000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000054", contractAddress: "", cumulativeGasUsed: "818414", gasUsed: "179716", confirmations: "3296744"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "84"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "84", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508946584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xa64bc878684e6987566f35f62d880eee8d7d7e5ba26252d77014c7af3ca4491d"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "RewardValue", type: "uint256", value: "596385542168674698"}, {name: "ProfitValue", type: "uint256", value: "96385542168674698"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "84"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "9268985487425976" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa64bc878684e6987566f35f62d880eee8d7d... )", async function( ) {
		const txOriginal = {blockNumber: "4427704", timeStamp: "1508946625", hash: "0xb1eae0c061b7ec6f139036e2bcdabc4cadf55e1a19004024b9e48c1b06e5b5aa", nonce: "311883", blockHash: "0x9e53c5ad3ecadade9883e44b4353a339fb67cd77546af63d233097e5528b5e6f", transactionIndex: "24", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50a64bc878684e6987566f35f62d880eee8d7d7e5ba26252d77014c7af3ca4491d000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e5b3134333634322c205b34305d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122066f41a7b662327b33bbf0ebd90cdeb6d3eeeb80641c000e2d26590ce5380be2a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1185890", gasUsed: "139748", confirmations: "3296742"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa64bc878684e6987566f35f62d880eee8d7d7e5ba26252d77014c7af3ca4491d"}, {type: "string", name: "result", value: `[143642, [40]]`}, {type: "bytes", name: "proof", value: "0x122066f41a7b662327b33bbf0ebd90cdeb6d3eeeb80641c000e2d26590ce5380be2a"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xa64bc878684e6987566f35f62d880eee8d7d7e5ba26252d77014c7af3ca4491d", `[143642, [40]]`, "0x122066f41a7b662327b33bbf0ebd90cdeb6d3eeeb80641c000e2d26590ce5380be2a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508946625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "143642"}, {name: "BetID", type: "bytes32", value: "0xa64bc878684e6987566f35f62d880eee8d7d7e5ba26252d77014c7af3ca4491d"}, {name: "PlayerAddress", type: "address", value: "0x544540be56348e391cd3a0909f6b582d926a8ffe"}, {name: "PlayerNumber", type: "uint256", value: "84"}, {name: "DiceResult", type: "uint256", value: "40"}, {name: "Value", type: "uint256", value: "596385542168674698"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x122066f41a7b662327b33bbf0ebd90cdeb6d3eeeb80641c000e2d26590ce5380be2a"}], address: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1128963893249607532" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
