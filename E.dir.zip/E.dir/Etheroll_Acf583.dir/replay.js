var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "Etheroll"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xD91E45416bfbBEc6e2D1ae4aC83b788A21Acf583","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0x73F0ed546Cd7893ABc5e04284B68522602603dD4","0x24C3235558572cff8054b5a419251D3B0D43E91b","0x5de92686587b10cD47E03B71f2E2350606fCAf14","0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51","0x17F20515dd55fb487A56482b7A41883726f211Bd","0x28fa7F0806C76a06ad7C02B5E313C6C5c9E49Fc1","0x1a067103F0EaA50771Abb1415413DE3bB8bBb32A","0xA6Ce8B15CaF7464A7DE58f5907bB5E6c1f89A819","0x544540bE56348E391Cd3a0909f6b582d926a8ffE","0x8D04679f50FA5d1c3A4c96e1f7D6b3EAe3a983d6"]
addressListOriginal.length = 20
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"totalWeiWon","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxProfitAsPercentOfHouse","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"payoutsPaused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxNumber","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"addressToCheck","type":"address"}],"name":"playerGetPendingTxByAddress","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxProfitDivisor","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"minNumber","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"treasury","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalWeiWagered","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"gasForOraclize","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"contractBalance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"minBet","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxProfit","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalBets","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"gamePaused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"houseEdge","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"houseEdgeDivisor","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxPendingPayouts","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"BetID","type":"bytes32"},{"indexed":true,"name":"PlayerAddress","type":"address"},{"indexed":true,"name":"RewardValue","type":"uint256"},{"indexed":false,"name":"ProfitValue","type":"uint256"},{"indexed":false,"name":"BetValue","type":"uint256"},{"indexed":false,"name":"PlayerNumber","type":"uint256"}],"name":"LogBet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"ResultSerialNumber","type":"uint256"},{"indexed":true,"name":"BetID","type":"bytes32"},{"indexed":true,"name":"PlayerAddress","type":"address"},{"indexed":false,"name":"PlayerNumber","type":"uint256"},{"indexed":false,"name":"DiceResult","type":"uint256"},{"indexed":false,"name":"Value","type":"uint256"},{"indexed":false,"name":"Status","type":"int256"},{"indexed":false,"name":"Proof","type":"bytes"}],"name":"LogResult","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"BetID","type":"bytes32"},{"indexed":true,"name":"PlayerAddress","type":"address"},{"indexed":true,"name":"RefundValue","type":"uint256"}],"name":"LogRefund","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"SentToAddress","type":"address"},{"indexed":true,"name":"AmountTransferred","type":"uint256"}],"name":"LogOwnerTransfer","type":"event"}]
eventSignatureListOriginal = ["LogBet(bytes32,address,uint256,uint256,uint256,uint256)","LogResult(uint256,bytes32,address,uint256,uint256,uint256,int256,bytes)","LogRefund(bytes32,address,uint256)","LogOwnerTransfer(address,uint256)"]
topicListOriginal = ["0x1cb5bfc4e69cbacf65c8e05bdb84d7a327bd6bb4c034ff82359aefd7443775c4","0x8dd0b145385d04711e29558ceab40b456976a2b9a7d648cc1bcd416161bf97b9","0x7b6ccf85690b8ce1b7d21a94ca738803a9da7dc74e10140f269efa0d8d6fb851","0x42c501a185f41a8eb77b0a3e7b72a6435ea7aa752f8a1a0a13ca4628495eca91"]
nBlocksOriginal = 50
fromBlockOriginal = 4426829
toBlockOriginal = 4427704
constructorPrototypeOriginal = {"inputs":[],"name":"Etheroll","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4426829","timeStamp":"1508934644","hash":"0xc0f7f67de18f90b5a38a4ea162ac0da293e1db15bc543d063d6d1a37627af173","nonce":"211","blockHash":"0x35e7b7915ca4702421b67a035746445353ae827902c3f2e3d12b999755d464fc","transactionIndex":"47","from":"0x73f0ed546cd7893abc5e04284b68522602603dd4","to":0,"value":"0","gas":"3293794","gasPrice":"8000000000","isError":"0","txreceipt_status":"1","input":"0x1558ae4d","contractAddress":"0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583","cumulativeGasUsed":"6125393","gasUsed":"3193794","confirmations":"3297617"}
txOptions[0] = {"from":"0x28a8746e75304c0780E011BEd21C72cD78cd535E","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"Etheroll","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
