const EmcoVoucher = artifacts.require( "./EmcoVoucher.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "EmcoVoucher" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6c228baDcf181fEbF7F3B4A61F8e26086942a3dB", "0x75c6A0Af58CEeCd9f6E691deC7cEE280D5aBa3C5", "0xD97E471695f73d8186dEABc1AB5B8765e667Cd96", "0x132FAb4E7be95cF6e79Ad3C2EcEE169eaED6a663", "0x2F618C7606F040340Fb2f34f4c58fF2183119913", "0xdd56021A701d66267d67515E8cBC28423965E353", "0x8f74774d24A30ec36DE5520a43F248144767a176", "0xF0105322f9dFAbf5c793F49680E26265e6ACB956", "0x468742B99cf1b6E7A92AC28cFC5c81cdC7e1d7eD", "0x493f534E2c7dA0BA8089951061ba3B0fC13113ba", "0x215ff2A960d318D53292423B7522Fcd6003e5064", "0xD2edc7c701202B1B3E9ba5676d720A30631Afb48", "0x33aB2396Ef7872d5e13c9606406A874b914cCA2b", "0x041797aFDbc4b576897E9b62cF765D6EB6Bf8e2d", "0x6b38CC121D72509193dC911E745d222aD073D1ff", "0x4a1e1EBE12946185868873014a7761103fBE901d", "0x417012CaDe61B605BF91AA8C851cC575d9B4abA0", "0x2F0A32804e12e9F6B3e2Ea2f9fDc774c93b5A64C", "0x65A834EACFa8a1EeA64e99ea5f5c2EcB2d4c2fED", "0x536a53558D6eC3E8201f3099A051C4AEcDd0Ee82", "0x0F794895A65c411a0BEeb6CF0485Ce7aA0CEf52c", "0x230e21979fDbb465E3C34959D0B8c90EAbA3a682", "0x6Bdce18491eff1D5a03FEFf79cc52fB76D364678"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_nonce", type: "uint256"}], name: "isNonceUsed", outputs: [{name: "isUsed", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["VoucherRedemption(address,uint256,uint256)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x63a68ae837e5978794ee766a078db1dd98e02ca34057b407e853b89534e9568f", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6662185 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6673304 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}], name: "EmcoVoucher", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "isNonceUsed", outputs: [{name: "isUsed", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isNonceUsed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "EmcoVoucher", function( accounts ) {

	it( "TEST: EmcoVoucher( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6662185", timeStamp: "1541622477", hash: "0x137dd2221f0d367d810d792e5e533ffc93b97ef8e53724be747738393f77a4ef", nonce: "1", blockHash: "0x1c046d58a97b4257a2347bb6ef03b9e4f2b924ea1cf3f0dde80c3d4fd6e535d0", transactionIndex: "84", from: "0x75c6a0af58ceecd9f6e691dec7cee280d5aba3c5", to: 0, value: "0", gas: "738670", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0x377d1190000000000000000000000000d97e471695f73d8186deabc1ab5b8765e667cd96", contractAddress: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", cumulativeGasUsed: "7535704", gasUsed: "738670", confirmations: "1058450"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}], name: "EmcoVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = EmcoVoucher.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541622477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = EmcoVoucher.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "75268568262586581" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setSignerAddress( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6662547", timeStamp: "1541627549", hash: "0xa957b4a70e3a6a58f20c395e4e86103e784e3a7485bd5fe52978b7c041b52b0c", nonce: "4", blockHash: "0x56e496f80b059d722099c4c68180195110b07b0188f16da8421eeaeb357fbacd", transactionIndex: "54", from: "0x75c6a0af58ceecd9f6e691dec7cee280d5aba3c5", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "65400", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x046dc166000000000000000000000000132fab4e7be95cf6e79ad3c2ecee169eaed6a663", contractAddress: "", cumulativeGasUsed: "3535115", gasUsed: "43600", confirmations: "1058088"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[5]}], name: "setSignerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSignerAddress(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541627549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "75268568262586581" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"2\", \"1000000000000000000\", \"0xf6ca... )", async function( ) {
		const txOriginal = {blockNumber: "6662577", timeStamp: "1541627899", hash: "0xeb3b4931f6896b5a69d65447eed35ad2406d5ce313709c5670eb6312748d75e7", nonce: "1", blockHash: "0x4efaae4806c502aad8d0b03ea13a2d55e01dce47cceca4778f13a4fe94a4670c", transactionIndex: "40", from: "0x2f618c7606f040340fb2f34f4c58ff2183119913", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86596", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f6caeb85de0d0b2e7faa250e50f43898e7ded989e7fc41d3c898808c1766a5be5876c4cc5547e74d106cf7ae5ab827da0f5bfc2db35b5ed952468a465cbbf2911c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2148664", gasUsed: "86596", confirmations: "1058058"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "2"}, {type: "uint256", name: "amount", value: "1000000000000000000"}, {type: "bytes", name: "signature", value: "0xf6caeb85de0d0b2e7faa250e50f43898e7ded989e7fc41d3c898808c1766a5be5876c4cc5547e74d106cf7ae5ab827da0f5bfc2db35b5ed952468a465cbbf2911c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "2", "1000000000000000000", "0xf6caeb85de0d0b2e7faa250e50f43898e7ded989e7fc41d3c898808c1766a5be5876c4cc5547e74d106cf7ae5ab827da0f5bfc2db35b5ed952468a465cbbf2911c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541627899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f618c7606f040340fb2f34f4c58ff2183119913"}, {name: "nonce", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22785\", \"1000000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6662711", timeStamp: "1541629733", hash: "0x52439cad9d9ddd37d37b9bc3cc61b18c9943c8feaafe2e906526a3bc80436882", nonce: "0", blockHash: "0xe44deea5023c872a63cf735e1d709d30aa1f087de2bf46c215bdabecde35f484", transactionIndex: "124", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000059010000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004132de1220a7ca9cf4962c23ed6ae89c2a64d28b5b441a2701b718193cb3beb49e681327e98b6d847560a8dd276a7f35a6cac7b2549bfc53b32ba2d5dd21b338901c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7035599", gasUsed: "86660", confirmations: "1057924"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22785"}, {type: "uint256", name: "amount", value: "1000000000000000000"}, {type: "bytes", name: "signature", value: "0x32de1220a7ca9cf4962c23ed6ae89c2a64d28b5b441a2701b718193cb3beb49e681327e98b6d847560a8dd276a7f35a6cac7b2549bfc53b32ba2d5dd21b338901c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22785", "1000000000000000000", "0x32de1220a7ca9cf4962c23ed6ae89c2a64d28b5b441a2701b718193cb3beb49e681327e98b6d847560a8dd276a7f35a6cac7b2549bfc53b32ba2d5dd21b338901c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541629733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "22785"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22786\", \"1000000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6665891", timeStamp: "1541674822", hash: "0x8217bc579d4173be73f4a752ddbe00eeed137f836a7a14410907e6a7f8ec4e11", nonce: "0", blockHash: "0x884519c014af344e132353be955e0b46e3369823720159e3a40cf6ecfefe8037", transactionIndex: "156", from: "0x8f74774d24a30ec36de5520a43f248144767a176", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000059020000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041ad8c12dc579ab3afec1c38c2ed1b4ee9c176290462a8871d91f5dca9a406a36c33d3bba9151721561afd4b7f634550c67493b37c30fcf90b40e9b4297a97aebd1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5326527", gasUsed: "71660", confirmations: "1054744"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22786"}, {type: "uint256", name: "amount", value: "1000000000000000000"}, {type: "bytes", name: "signature", value: "0xad8c12dc579ab3afec1c38c2ed1b4ee9c176290462a8871d91f5dca9a406a36c33d3bba9151721561afd4b7f634550c67493b37c30fcf90b40e9b4297a97aebd1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22786", "1000000000000000000", "0xad8c12dc579ab3afec1c38c2ed1b4ee9c176290462a8871d91f5dca9a406a36c33d3bba9151721561afd4b7f634550c67493b37c30fcf90b40e9b4297a97aebd1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541674822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x8f74774d24a30ec36de5520a43f248144767a176"}, {name: "nonce", type: "uint256", value: "22786"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "90823605560000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22787\", \"100000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6665908", timeStamp: "1541675031", hash: "0x00f2eb87f13f446460062352950015b4d208b6a18559f7865717e0e616bbb0ba", nonce: "1", blockHash: "0x11b3b2a12e6313977653184054a43e29346afa8e91600641ccc9090be335b11b", transactionIndex: "63", from: "0x8f74774d24a30ec36de5520a43f248144767a176", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71724", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000059030000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004174344bd21257dae9d8971cb4f7ad1abe0c363f3c1619bdb424ce9ac27918024d263f6b48990628b45ea2959c1351b29cf5df23800132d0c9eb08d9ac01ca47a61b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4404534", gasUsed: "71724", confirmations: "1054727"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22787"}, {type: "uint256", name: "amount", value: "100000000000000000000"}, {type: "bytes", name: "signature", value: "0x74344bd21257dae9d8971cb4f7ad1abe0c363f3c1619bdb424ce9ac27918024d263f6b48990628b45ea2959c1351b29cf5df23800132d0c9eb08d9ac01ca47a61b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22787", "100000000000000000000", "0x74344bd21257dae9d8971cb4f7ad1abe0c363f3c1619bdb424ce9ac27918024d263f6b48990628b45ea2959c1351b29cf5df23800132d0c9eb08d9ac01ca47a61b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541675031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x8f74774d24a30ec36de5520a43f248144767a176"}, {name: "nonce", type: "uint256", value: "22787"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "90823605560000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22593\", \"2\", \"0xf3ca54ae21e4e087ce... )", async function( ) {
		const txOriginal = {blockNumber: "6667028", timeStamp: "1541691319", hash: "0xec8ab8e5f7b26bbfadd276379a0b9bf6a191861458b2e585dc39d1b991706119", nonce: "0", blockHash: "0x06ec3ff754e12feac59fedeb37b53d062bdf79d05294db36dac1427a340a7bd0", transactionIndex: "83", from: "0xf0105322f9dfabf5c793f49680e26265e6acb956", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000005841000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f3ca54ae21e4e087cec06d18723d7ace30fe5a3e44c8cb6dee2e62452d88bc2a173953b5f6c653f8f1795a45e82f4f5ba0925eb4aef5e4f0fa4028ac69bb8b2c1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7482540", gasUsed: "86340", confirmations: "1053607"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22593"}, {type: "uint256", name: "amount", value: "2"}, {type: "bytes", name: "signature", value: "0xf3ca54ae21e4e087cec06d18723d7ace30fe5a3e44c8cb6dee2e62452d88bc2a173953b5f6c653f8f1795a45e82f4f5ba0925eb4aef5e4f0fa4028ac69bb8b2c1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22593", "2", "0xf3ca54ae21e4e087cec06d18723d7ace30fe5a3e44c8cb6dee2e62452d88bc2a173953b5f6c653f8f1795a45e82f4f5ba0925eb4aef5e4f0fa4028ac69bb8b2c1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541691319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xf0105322f9dfabf5c793f49680e26265e6acb956"}, {name: "nonce", type: "uint256", value: "22593"}, {name: "amount", type: "uint256", value: "2"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14476790835258449" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22594\", \"3\", \"0xe682d665950e64f96b... )", async function( ) {
		const txOriginal = {blockNumber: "6667215", timeStamp: "1541693739", hash: "0xa5bacf7e43639a0985e7fb092735fb5948252115d22ba6d09030d0d42fd2293d", nonce: "2", blockHash: "0x9c4b0f5e6f4ca335754f4586b1b3554271923a1137d16e4c9fd3d692a35cd3c2", transactionIndex: "55", from: "0xf0105322f9dfabf5c793f49680e26265e6acb956", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000005842000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041e682d665950e64f96b9bed5753d9fb04add18be413bef4b42c57e821c2bb84926399f65c03555eb0abcb36b45431de1a8272b0eff7b6c67cf7a671e0afd5a7871b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6251661", gasUsed: "86340", confirmations: "1053420"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22594"}, {type: "uint256", name: "amount", value: "3"}, {type: "bytes", name: "signature", value: "0xe682d665950e64f96b9bed5753d9fb04add18be413bef4b42c57e821c2bb84926399f65c03555eb0abcb36b45431de1a8272b0eff7b6c67cf7a671e0afd5a7871b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22594", "3", "0xe682d665950e64f96b9bed5753d9fb04add18be413bef4b42c57e821c2bb84926399f65c03555eb0abcb36b45431de1a8272b0eff7b6c67cf7a671e0afd5a7871b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541693739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xf0105322f9dfabf5c793f49680e26265e6acb956"}, {name: "nonce", type: "uint256", value: "22594"}, {name: "amount", type: "uint256", value: "3"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14476790835258449" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22713\", \"107\", \"0xad7448e98608455d... )", async function( ) {
		const txOriginal = {blockNumber: "6667561", timeStamp: "1541698402", hash: "0x696cc5cd4a2e3b7f145997c536aeb86260ea030a379f6a3fb6638d1a9112c5a7", nonce: "3", blockHash: "0xae9e0adcedbf1e8e18d038d266081b23a2db528340ba0440bb78a40d167abcd1", transactionIndex: "75", from: "0xf0105322f9dfabf5c793f49680e26265e6acb956", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71276", gasPrice: "5600000001", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000058b9000000000000000000000000000000000000000000000000000000000000006b00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041ad7448e98608455d2f3bf77faac31d66e8bf81a2e193cfa9e4f76cc396d1619979e5821f2dd270bd7f03a80b4a75188ed4a1b2578809829e00f193ea23aee6da1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4122244", gasUsed: "71276", confirmations: "1053074"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22713"}, {type: "uint256", name: "amount", value: "107"}, {type: "bytes", name: "signature", value: "0xad7448e98608455d2f3bf77faac31d66e8bf81a2e193cfa9e4f76cc396d1619979e5821f2dd270bd7f03a80b4a75188ed4a1b2578809829e00f193ea23aee6da1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22713", "107", "0xad7448e98608455d2f3bf77faac31d66e8bf81a2e193cfa9e4f76cc396d1619979e5821f2dd270bd7f03a80b4a75188ed4a1b2578809829e00f193ea23aee6da1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541698402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xf0105322f9dfabf5c793f49680e26265e6acb956"}, {name: "nonce", type: "uint256", value: "22713"}, {name: "amount", type: "uint256", value: "107"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14476790835258449" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"20271\", \"1\", \"0x53cefbe9156a91d26f... )", async function( ) {
		const txOriginal = {blockNumber: "6667755", timeStamp: "1541701380", hash: "0x35699578472c4a1b8c05616d1c4aa3c6e713b12ebceaae54d2160f95bf3bf9e3", nonce: "0", blockHash: "0x62c6e5e92a49eea0ed9d9827a9709104f1f7b702d24afa258692d18b7dec9b36", transactionIndex: "62", from: "0x468742b99cf1b6e7a92ac28cfc5c81cdc7e1d7ed", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000004f2f00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004153cefbe9156a91d26fb5afa5239a383d107449b58d88f5699362d0ba50e606f366346aa84b2492c5a82e51327152eeb0952d1ebd6a88c03815b7d98c0d4b6c921b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7273851", gasUsed: "86340", confirmations: "1052880"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "20271"}, {type: "uint256", name: "amount", value: "1"}, {type: "bytes", name: "signature", value: "0x53cefbe9156a91d26fb5afa5239a383d107449b58d88f5699362d0ba50e606f366346aa84b2492c5a82e51327152eeb0952d1ebd6a88c03815b7d98c0d4b6c921b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "20271", "1", "0x53cefbe9156a91d26fb5afa5239a383d107449b58d88f5699362d0ba50e606f366346aa84b2492c5a82e51327152eeb0952d1ebd6a88c03815b7d98c0d4b6c921b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541701380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x468742b99cf1b6e7a92ac28cfc5c81cdc7e1d7ed"}, {name: "nonce", type: "uint256", value: "20271"}, {name: "amount", type: "uint256", value: "1"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3149410000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"10102\", \"1\", \"0xa2c15e85f2ab06c880... )", async function( ) {
		const txOriginal = {blockNumber: "6668010", timeStamp: "1541704836", hash: "0x6027dcf898a63479c25e7cde7d4e96fc6694ecbf5f41bbf12380c480554192ee", nonce: "0", blockHash: "0x9a2933737f0091455683b8d449bfb0de85f1981e6455c9e56e198299f5656ff7", transactionIndex: "195", from: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000002776000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041a2c15e85f2ab06c880afcfe5436f99f6b1d728460b5ec05108e4ead86c8797631fa7b51352f958e8dd26e7749288f78d0b5bba0d4f75ef6f77a544176c74fab41b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5200019", gasUsed: "86340", confirmations: "1052625"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "10102"}, {type: "uint256", name: "amount", value: "1"}, {type: "bytes", name: "signature", value: "0xa2c15e85f2ab06c880afcfe5436f99f6b1d728460b5ec05108e4ead86c8797631fa7b51352f958e8dd26e7749288f78d0b5bba0d4f75ef6f77a544176c74fab41b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "10102", "1", "0xa2c15e85f2ab06c880afcfe5436f99f6b1d728460b5ec05108e4ead86c8797631fa7b51352f958e8dd26e7749288f78d0b5bba0d4f75ef6f77a544176c74fab41b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541704836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba"}, {name: "nonce", type: "uint256", value: "10102"}, {name: "amount", type: "uint256", value: "1"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "84405880164930098" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"19261\", \"6\", \"0xd88214ef420622067d... )", async function( ) {
		const txOriginal = {blockNumber: "6668490", timeStamp: "1541711686", hash: "0x4c0812cb7a6280791d55a9e65615c0896d075cb262c67ee17fff210cf8f5ba25", nonce: "0", blockHash: "0x3ee4fe376c6f87d8f1377fd0bf157a74f201c7c390ac844fc158355514e84f2a", transactionIndex: "100", from: "0x215ff2a960d318d53292423b7522fcd6003e5064", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "5200000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000004b3d000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041d88214ef420622067dc01f2dca937edb937915384cf2892641acfe774025f8f36edf374485778c12d1bdbaac5fd6a4e29a057b9c93e5671023a104d8dac3f32b1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7466978", gasUsed: "86340", confirmations: "1052145"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "19261"}, {type: "uint256", name: "amount", value: "6"}, {type: "bytes", name: "signature", value: "0xd88214ef420622067dc01f2dca937edb937915384cf2892641acfe774025f8f36edf374485778c12d1bdbaac5fd6a4e29a057b9c93e5671023a104d8dac3f32b1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "19261", "6", "0xd88214ef420622067dc01f2dca937edb937915384cf2892641acfe774025f8f36edf374485778c12d1bdbaac5fd6a4e29a057b9c93e5671023a104d8dac3f32b1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541711686 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x215ff2a960d318d53292423b7522fcd6003e5064"}, {name: "nonce", type: "uint256", value: "19261"}, {name: "amount", type: "uint256", value: "6"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "12161556350306204" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22579\", \"1\", \"0x0128bd5fdf03c4c9b6... )", async function( ) {
		const txOriginal = {blockNumber: "6668529", timeStamp: "1541712250", hash: "0x0bf495493c17911d083e110c28807c009cfa422c77b1da859f6e8bad93c52bdb", nonce: "1", blockHash: "0x3090d524b8867f88ab9719e85ccaf9026f3c2d16f54e8ff33200e663ac15315e", transactionIndex: "107", from: "0x215ff2a960d318d53292423b7522fcd6003e5064", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71340", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000058330000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000410128bd5fdf03c4c9b6e7074e9fb7688c36420c31d2ed877fb6b0b7d482124b022fe0d496738bf8446cefdfef35c283d224ce4c07d63d5a464fcf876740876ca01b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6989210", gasUsed: "71340", confirmations: "1052106"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22579"}, {type: "uint256", name: "amount", value: "1"}, {type: "bytes", name: "signature", value: "0x0128bd5fdf03c4c9b6e7074e9fb7688c36420c31d2ed877fb6b0b7d482124b022fe0d496738bf8446cefdfef35c283d224ce4c07d63d5a464fcf876740876ca01b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22579", "1", "0x0128bd5fdf03c4c9b6e7074e9fb7688c36420c31d2ed877fb6b0b7d482124b022fe0d496738bf8446cefdfef35c283d224ce4c07d63d5a464fcf876740876ca01b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541712250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x215ff2a960d318d53292423b7522fcd6003e5064"}, {name: "nonce", type: "uint256", value: "22579"}, {name: "amount", type: "uint256", value: "1"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "12161556350306204" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"15905\", \"3\", \"0x99ecd8951e01c17788... )", async function( ) {
		const txOriginal = {blockNumber: "6668682", timeStamp: "1541714197", hash: "0x81d825ca9d4a6d894bab43ff8f13221faba5664d91fb76c815ed6f744f19cbb9", nonce: "2", blockHash: "0x4e2d7bc70d6cab02df4995d61e026ea9aaeee502d1c2e3ed7516f8790e08731c", transactionIndex: "62", from: "0x215ff2a960d318d53292423b7522fcd6003e5064", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71276", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000003e2100000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004199ecd8951e01c1778883984ab595e60c0b89297b41f920a5a5a6007e136a3b0f5a76103e8392a92e119896eafa23d5996bd030ee96bb5a53020cf91b9b19a65f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4169275", gasUsed: "71276", confirmations: "1051953"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "15905"}, {type: "uint256", name: "amount", value: "3"}, {type: "bytes", name: "signature", value: "0x99ecd8951e01c1778883984ab595e60c0b89297b41f920a5a5a6007e136a3b0f5a76103e8392a92e119896eafa23d5996bd030ee96bb5a53020cf91b9b19a65f1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "15905", "3", "0x99ecd8951e01c1778883984ab595e60c0b89297b41f920a5a5a6007e136a3b0f5a76103e8392a92e119896eafa23d5996bd030ee96bb5a53020cf91b9b19a65f1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541714197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x215ff2a960d318d53292423b7522fcd6003e5064"}, {name: "nonce", type: "uint256", value: "15905"}, {name: "amount", type: "uint256", value: "3"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "12161556350306204" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"9791\", \"74\", \"0x7226fdf605e01f8810... )", async function( ) {
		const txOriginal = {blockNumber: "6669310", timeStamp: "1541723487", hash: "0xabe3c35d2504727cb19ab4075de4f78dedc5140864380eb845a6159acf4331cf", nonce: "0", blockHash: "0x1d9d3f8e8725df243fcdcf1bd2c0315cea4babfddf91aabb5e37575c15dc4d91", transactionIndex: "110", from: "0xd2edc7c701202b1b3e9ba5676d720a30631afb48", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "4110000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000263f000000000000000000000000000000000000000000000000000000000000004a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000417226fdf605e01f8810d889b909ce9983a65b4c53c09e13a53faf308e23d41d253b8274a5a65c7c4ee868bb1c3c61cd71a8a4cda36d5ca1a0dd5e685c0b39cf421c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6068413", gasUsed: "86340", confirmations: "1051325"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "9791"}, {type: "uint256", name: "amount", value: "74"}, {type: "bytes", name: "signature", value: "0x7226fdf605e01f8810d889b909ce9983a65b4c53c09e13a53faf308e23d41d253b8274a5a65c7c4ee868bb1c3c61cd71a8a4cda36d5ca1a0dd5e685c0b39cf421c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "9791", "74", "0x7226fdf605e01f8810d889b909ce9983a65b4c53c09e13a53faf308e23d41d253b8274a5a65c7c4ee868bb1c3c61cd71a8a4cda36d5ca1a0dd5e685c0b39cf421c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541723487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xd2edc7c701202b1b3e9ba5676d720a30631afb48"}, {name: "nonce", type: "uint256", value: "9791"}, {name: "amount", type: "uint256", value: "74"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "125035763690222189" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22534\", \"1003\", \"0x563a1cba48e9c33... )", async function( ) {
		const txOriginal = {blockNumber: "6669707", timeStamp: "1541729030", hash: "0x4416c5dd7cae2bb7f49254945bed09c83cfd95057a570e027812a019eec1ce50", nonce: "2", blockHash: "0x426406812ccb8eae5819a70112f61df7df4bfab6530e1ee0744581a754f90995", transactionIndex: "23", from: "0xd2edc7c701202b1b3e9ba5676d720a30631afb48", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86276", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000580600000000000000000000000000000000000000000000000000000000000003eb00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041563a1cba48e9c333b5945c82b60b48339f1a9e00bb32c1eb44ca91de1a00a3987347b4d91f3dab2c2f8f820fd0159eb6456fcd9b138a680ec7b7d375e5e92f251c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "958352", gasUsed: "86276", confirmations: "1050928"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22534"}, {type: "uint256", name: "amount", value: "1003"}, {type: "bytes", name: "signature", value: "0x563a1cba48e9c333b5945c82b60b48339f1a9e00bb32c1eb44ca91de1a00a3987347b4d91f3dab2c2f8f820fd0159eb6456fcd9b138a680ec7b7d375e5e92f251c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22534", "1003", "0x563a1cba48e9c333b5945c82b60b48339f1a9e00bb32c1eb44ca91de1a00a3987347b4d91f3dab2c2f8f820fd0159eb6456fcd9b138a680ec7b7d375e5e92f251c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541729030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xd2edc7c701202b1b3e9ba5676d720a30631afb48"}, {name: "nonce", type: "uint256", value: "22534"}, {name: "amount", type: "uint256", value: "1003"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "125035763690222189" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22784\", \"8\", \"0x9ce72763379452a74e... )", async function( ) {
		const txOriginal = {blockNumber: "6670987", timeStamp: "1541747393", hash: "0x0eca0ceeca8a28d396db60f4313168c1d0ce26114ad676bdce9191bf765e0e12", nonce: "7", blockHash: "0xedaa1a1d311d266234a3bbfd8aceca5aec6ba650f3332b752d5e2ea522b4c01f", transactionIndex: "54", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86148", gasPrice: "8500000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000059000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000419ce72763379452a74e57b69b01aecd0169c11f0049a429757fd7a853515ada1565151f4a193747ade9110055e08336e861ade3e03b214738c860d57e438255811c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3843716", gasUsed: "86148", confirmations: "1049648"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22784"}, {type: "uint256", name: "amount", value: "8"}, {type: "bytes", name: "signature", value: "0x9ce72763379452a74e57b69b01aecd0169c11f0049a429757fd7a853515ada1565151f4a193747ade9110055e08336e861ade3e03b214738c860d57e438255811c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22784", "8", "0x9ce72763379452a74e57b69b01aecd0169c11f0049a429757fd7a853515ada1565151f4a193747ade9110055e08336e861ade3e03b214738c860d57e438255811c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541747393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "22784"}, {name: "amount", type: "uint256", value: "8"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"23538\", \"107000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6671156", timeStamp: "1541750066", hash: "0x14d324c2b5af15c25edc6fba8db757107892d5139a7de661af02f3977f9062ba", nonce: "8", blockHash: "0xb0079605ad0e5a348d6c2f6d5b2466bff5a4bc03a399f91db6d3ea4bb9f8610c", transactionIndex: "147", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71724", gasPrice: "8500000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000005bf2000000000000000000000000000000000000000000000005ccec5d16f6cc000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041e112706817514d99e57fec07e1cd3379c13f2af4db90f81a48faf04aad2bfd4d4ab5ba26d29563eea2bde8618e52d502e6681cbba25d7c1129ab17f76a3c64691b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6212100", gasUsed: "71724", confirmations: "1049479"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "23538"}, {type: "uint256", name: "amount", value: "107000000000000000000"}, {type: "bytes", name: "signature", value: "0xe112706817514d99e57fec07e1cd3379c13f2af4db90f81a48faf04aad2bfd4d4ab5ba26d29563eea2bde8618e52d502e6681cbba25d7c1129ab17f76a3c64691b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "23538", "107000000000000000000", "0xe112706817514d99e57fec07e1cd3379c13f2af4db90f81a48faf04aad2bfd4d4ab5ba26d29563eea2bde8618e52d502e6681cbba25d7c1129ab17f76a3c64691b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541750066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "23538"}, {name: "amount", type: "uint256", value: "107000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"6649\", \"332\", \"0xd1e79281b0f7696ac... )", async function( ) {
		const txOriginal = {blockNumber: "6671302", timeStamp: "1541752089", hash: "0x48c74d82981e1165d6fc88e243693a663536fb8daee2244e90357f93c6ce28a0", nonce: "0", blockHash: "0x01c4941b64c6fd369e772e7213fc1e13d39610427109c86634faaa25e866290f", transactionIndex: "121", from: "0x33ab2396ef7872d5e13c9606406a874b914cca2b", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000019f9000000000000000000000000000000000000000000000000000000000000014c00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041d1e79281b0f7696ac74e789c34a932c300154e4e6aad14ad5b029e784a34f6781e26377c2fa19cbbc3edcf403c54989c74cd7f3186843f01bb46504825b5a14f1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7530523", gasUsed: "86340", confirmations: "1049333"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "6649"}, {type: "uint256", name: "amount", value: "332"}, {type: "bytes", name: "signature", value: "0xd1e79281b0f7696ac74e789c34a932c300154e4e6aad14ad5b029e784a34f6781e26377c2fa19cbbc3edcf403c54989c74cd7f3186843f01bb46504825b5a14f1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "6649", "332", "0xd1e79281b0f7696ac74e789c34a932c300154e4e6aad14ad5b029e784a34f6781e26377c2fa19cbbc3edcf403c54989c74cd7f3186843f01bb46504825b5a14f1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541752089 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x33ab2396ef7872d5e13c9606406a874b914cca2b"}, {name: "nonce", type: "uint256", value: "6649"}, {name: "amount", type: "uint256", value: "332"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1142118336321300" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22783\", \"268\", \"0x18390acba0eb6cad... )", async function( ) {
		const txOriginal = {blockNumber: "6671882", timeStamp: "1541760107", hash: "0x180a0a1ef933095e5e2b689d80a0b32aa1c1d3669c938dc7c8378e3b163b6e9d", nonce: "10", blockHash: "0x5ae8fa99e598160f30924b6e0473fc62301898f7290d37412c3111c052be5e39", transactionIndex: "137", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71404", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000058ff000000000000000000000000000000000000000000000000000000000000010c0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004118390acba0eb6cad8131d5f494b34c13daa5f4ffe9e1f0bb977e6070d61fcca51fe22a0cf88869be1dc3b520919c1c5fcc5bc5aecd99be1e300edbcd911025751c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7000868", gasUsed: "71404", confirmations: "1048753"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22783"}, {type: "uint256", name: "amount", value: "268"}, {type: "bytes", name: "signature", value: "0x18390acba0eb6cad8131d5f494b34c13daa5f4ffe9e1f0bb977e6070d61fcca51fe22a0cf88869be1dc3b520919c1c5fcc5bc5aecd99be1e300edbcd911025751c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22783", "268", "0x18390acba0eb6cad8131d5f494b34c13daa5f4ffe9e1f0bb977e6070d61fcca51fe22a0cf88869be1dc3b520919c1c5fcc5bc5aecd99be1e300edbcd911025751c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541760107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "22783"}, {name: "amount", type: "uint256", value: "268"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"22340\", \"4224\", \"0x569591b06df644e... )", async function( ) {
		const txOriginal = {blockNumber: "6672098", timeStamp: "1541762865", hash: "0x896ac348901b4f9893b27456fc6d624c44b4a202ff421f4e2ae1241dbb524e93", nonce: "0", blockHash: "0xd19592ac58d5089bed17a3992ae74ed75ec4a643f725c35b3729b809c22391cd", transactionIndex: "59", from: "0x041797afdbc4b576897e9b62cf765d6eb6bf8e2d", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86340", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000005744000000000000000000000000000000000000000000000000000000000000108000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041569591b06df644ed190420e5270085af1eb4c425ebf64c3be0444ddaf4b7b1f25b53132abf9c9a9187dcbabbf063a5d73affc2492d4f4ab3149cfc0fb5d35f281c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7995479", gasUsed: "86340", confirmations: "1048537"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22340"}, {type: "uint256", name: "amount", value: "4224"}, {type: "bytes", name: "signature", value: "0x569591b06df644ed190420e5270085af1eb4c425ebf64c3be0444ddaf4b7b1f25b53132abf9c9a9187dcbabbf063a5d73affc2492d4f4ab3149cfc0fb5d35f281c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "22340", "4224", "0x569591b06df644ed190420e5270085af1eb4c425ebf64c3be0444ddaf4b7b1f25b53132abf9c9a9187dcbabbf063a5d73affc2492d4f4ab3149cfc0fb5d35f281c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541762865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x041797afdbc4b576897e9b62cf765d6eb6bf8e2d"}, {name: "nonce", type: "uint256", value: "22340"}, {name: "amount", type: "uint256", value: "4224"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "58531657368136" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"46591\", \"107000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6672163", timeStamp: "1541763659", hash: "0x7e6e484d544f7811fdd7ab8321ae003903617caf529b04615351d23709529262", nonce: "11", blockHash: "0xcce3535e96337f3a4845d30b15de1ed8ed71a58aa56206935c19646af274cbcd", transactionIndex: "57", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71724", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000b5ff000000000000000000000000000000000000000000000005ccec5d16f6cc000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f6f61174040652bb9ce3fb685474d6a888f61eaa0db44388596a49a4938da234353f2b9d6269b28146638ef757aa51f93e5de64609431d79a18ed78e909d913e1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7957744", gasUsed: "71724", confirmations: "1048472"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "46591"}, {type: "uint256", name: "amount", value: "107000000000000000000"}, {type: "bytes", name: "signature", value: "0xf6f61174040652bb9ce3fb685474d6a888f61eaa0db44388596a49a4938da234353f2b9d6269b28146638ef757aa51f93e5de64609431d79a18ed78e909d913e1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "46591", "107000000000000000000", "0xf6f61174040652bb9ce3fb685474d6a888f61eaa0db44388596a49a4938da234353f2b9d6269b28146638ef757aa51f93e5de64609431d79a18ed78e909d913e1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541763659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "46591"}, {name: "amount", type: "uint256", value: "107000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"46698\", \"1990000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6672394", timeStamp: "1541766936", hash: "0xee70bfa15c48ce55ab1b35ced66f253f5da4582e46c530b3750033727afec0b9", nonce: "12", blockHash: "0x87f3b18e0592e8ed7fd5ff85bf313df87eca8ba488bac3366688f18523fbd06a", transactionIndex: "119", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000b66a0000000000000000000000000000000000000000000000001b9de674df07000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041a6750b0ce72fa8ebec8a3ea58bb3d3506adfa8a27c341cb45d883cec8898ae051e0702d603f6e34d07d044a29138217c127807b11d050d508ef376313f7ed7b21c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5270854", gasUsed: "71660", confirmations: "1048241"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "46698"}, {type: "uint256", name: "amount", value: "1990000000000000000"}, {type: "bytes", name: "signature", value: "0xa6750b0ce72fa8ebec8a3ea58bb3d3506adfa8a27c341cb45d883cec8898ae051e0702d603f6e34d07d044a29138217c127807b11d050d508ef376313f7ed7b21c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "46698", "1990000000000000000", "0xa6750b0ce72fa8ebec8a3ea58bb3d3506adfa8a27c341cb45d883cec8898ae051e0702d603f6e34d07d044a29138217c127807b11d050d508ef376313f7ed7b21c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541766936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "46698"}, {name: "amount", type: "uint256", value: "1990000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69593\", \"8000000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673082", timeStamp: "1541776707", hash: "0x405843f81a24944a5d5c175d9c89c2192eb03a54f6dde0875e1467e928543dc8", nonce: "13", blockHash: "0xd3aa70e545392461f0667c97388750e6b717ac856b25836feb7d61ca4400c268", transactionIndex: "43", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71724", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010fd90000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000417a5fa0c299d85725540f049626ab5fc81d69c48f8dd1e01e624a4c75e073d661501d393e4028a4de72c606fd5045f1be43ad95889139101b1c3fb4737b45db1c1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1634854", gasUsed: "71724", confirmations: "1047553"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69593"}, {type: "uint256", name: "amount", value: "8000000000000000000"}, {type: "bytes", name: "signature", value: "0x7a5fa0c299d85725540f049626ab5fc81d69c48f8dd1e01e624a4c75e073d661501d393e4028a4de72c606fd5045f1be43ad95889139101b1c3fb4737b45db1c1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69593", "8000000000000000000", "0x7a5fa0c299d85725540f049626ab5fc81d69c48f8dd1e01e624a4c75e073d661501d393e4028a4de72c606fd5045f1be43ad95889139101b1c3fb4737b45db1c1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541776707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "69593"}, {name: "amount", type: "uint256", value: "8000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"67862\", \"5970000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673122", timeStamp: "1541777268", hash: "0x86207e26d9f2bbc34c404e85dc8ee6188ca84104da3e0e21211c6cf25f319111", nonce: "1", blockHash: "0x9efcaf3cb32e93c551c52503cb3afac5f23319fa28e684f08f07f6034167e3a7", transactionIndex: "192", from: "0x6b38cc121d72509193dc911e745d222ad073d1ff", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000001091600000000000000000000000000000000000000000000000052d9b35e9d150000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000414475467f8be610aa7746847aa13a5448b1c2266802e0e78a2007f9d52dc7e6e1301d87f488f7575e1360563000338b081aca99745d787521810469e3907935b41b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6854342", gasUsed: "86660", confirmations: "1047513"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "67862"}, {type: "uint256", name: "amount", value: "5970000000000000000"}, {type: "bytes", name: "signature", value: "0x4475467f8be610aa7746847aa13a5448b1c2266802e0e78a2007f9d52dc7e6e1301d87f488f7575e1360563000338b081aca99745d787521810469e3907935b41b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "67862", "5970000000000000000", "0x4475467f8be610aa7746847aa13a5448b1c2266802e0e78a2007f9d52dc7e6e1301d87f488f7575e1360563000338b081aca99745d787521810469e3907935b41b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541777268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x6b38cc121d72509193dc911e745d222ad073d1ff"}, {name: "nonce", type: "uint256", value: "67862"}, {name: "amount", type: "uint256", value: "5970000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "51892711607557912" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69592\", \"268000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673122", timeStamp: "1541777268", hash: "0xd66953dbb52b1e3e1623d0c6f7a12f53a5da8a33691c02ceea0ec657eb259432", nonce: "14", blockHash: "0x9efcaf3cb32e93c551c52503cb3afac5f23319fa28e684f08f07f6034167e3a7", transactionIndex: "199", from: "0xdd56021a701d66267d67515e8cbc28423965e353", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71788", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010fd800000000000000000000000000000000000000000000000e873f44133cb00000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000416ae0f12449a0934990d595b5dcb01c48cf9709d9d7ee475f9c92e2300b42d30c34cf4ecc72444cd701d0bc45c9435a2ea9e52189e76f0738b312bd8f2b1a13351b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7056100", gasUsed: "71788", confirmations: "1047513"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69592"}, {type: "uint256", name: "amount", value: "268000000000000000000"}, {type: "bytes", name: "signature", value: "0x6ae0f12449a0934990d595b5dcb01c48cf9709d9d7ee475f9c92e2300b42d30c34cf4ecc72444cd701d0bc45c9435a2ea9e52189e76f0738b312bd8f2b1a13351b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69592", "268000000000000000000", "0x6ae0f12449a0934990d595b5dcb01c48cf9709d9d7ee475f9c92e2300b42d30c34cf4ecc72444cd701d0bc45c9435a2ea9e52189e76f0738b312bd8f2b1a13351b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541777268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xdd56021a701d66267d67515e8cbc28423965e353"}, {name: "nonce", type: "uint256", value: "69592"}, {name: "amount", type: "uint256", value: "268000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "572009890500000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"67863\", \"9950000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673145", timeStamp: "1541777547", hash: "0x323406b1c535c9ff875a8008de2678a212010f1bbf1cc9486dea7c41ad0e5bb4", nonce: "2", blockHash: "0x4aca4a10eb75b1ebebc118efa426a8715fa7cdacfff92f979d7b4d19ec0ec172", transactionIndex: "106", from: "0x6b38cc121d72509193dc911e745d222ad073d1ff", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d52100000000000000000000000000000000000000000000000000000000000109170000000000000000000000000000000000000000000000008a1580485b2300000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004194c55673560505f791bfc57484f89995a6ed500026fac924dcdcbe6c07d43c0b3291170d8f1d2329506550cdbc80cc0b3482de24c395d30b8f0566b70e01b6fa1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6455199", gasUsed: "71660", confirmations: "1047490"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "67863"}, {type: "uint256", name: "amount", value: "9950000000000000000"}, {type: "bytes", name: "signature", value: "0x94c55673560505f791bfc57484f89995a6ed500026fac924dcdcbe6c07d43c0b3291170d8f1d2329506550cdbc80cc0b3482de24c395d30b8f0566b70e01b6fa1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "67863", "9950000000000000000", "0x94c55673560505f791bfc57484f89995a6ed500026fac924dcdcbe6c07d43c0b3291170d8f1d2329506550cdbc80cc0b3482de24c395d30b8f0566b70e01b6fa1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541777547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x6b38cc121d72509193dc911e745d222ad073d1ff"}, {name: "nonce", type: "uint256", value: "67863"}, {name: "amount", type: "uint256", value: "9950000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "51892711607557912" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"49083\", \"4564530000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "6673174", timeStamp: "1541777967", hash: "0x7ee18e2b93103a67b0b8a44045488e1e3276240b196e44a2b58ffc4def8f9c87", nonce: "0", blockHash: "0x4f9ef73a5eb435aed0b8c4b060a44e10517c3103c50d34f327483e17ba946e99", transactionIndex: "38", from: "0x4a1e1ebe12946185868873014a7761103fbe901d", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000bfbb0000000000000000000000000000000000000000000000f771942b1565c5000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041fbbd510b173eb1691a64cf33585e189bf185ae495628a88f4ac16ba099919d8164adb489ab612fd90890187bb2c874d560f7f5f31367a2044d8ef6f25395a18f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5816001", gasUsed: "86724", confirmations: "1047461"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "49083"}, {type: "uint256", name: "amount", value: "4564530000000000000000"}, {type: "bytes", name: "signature", value: "0xfbbd510b173eb1691a64cf33585e189bf185ae495628a88f4ac16ba099919d8164adb489ab612fd90890187bb2c874d560f7f5f31367a2044d8ef6f25395a18f1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "49083", "4564530000000000000000", "0xfbbd510b173eb1691a64cf33585e189bf185ae495628a88f4ac16ba099919d8164adb489ab612fd90890187bb2c874d560f7f5f31367a2044d8ef6f25395a18f1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541777967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x4a1e1ebe12946185868873014a7761103fbe901d"}, {name: "nonce", type: "uint256", value: "49083"}, {name: "amount", type: "uint256", value: "4564530000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "128286469504874310" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"64314\", \"9950000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673202", timeStamp: "1541778321", hash: "0x9abc6954f99730de68b46308e7e646df61c9b7f311216ade1b1f02aa2dc8c163", nonce: "1", blockHash: "0xba11fce15336a0fd7d0dff6a82c008b3ba8e64f4f61ab4dd01ac5ed2630d2d6f", transactionIndex: "109", from: "0x4a1e1ebe12946185868873014a7761103fbe901d", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000fb3a0000000000000000000000000000000000000000000000008a1580485b23000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041ac687735f39314eb28ec6adc9d246f67422e9ae579774bb2f7fb746c6f1875d1154155ea8fd8a9c43f36dca04620ce86108b4ffcbcaad07b8db5afa6efd777ac1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4413239", gasUsed: "71660", confirmations: "1047433"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "64314"}, {type: "uint256", name: "amount", value: "9950000000000000000"}, {type: "bytes", name: "signature", value: "0xac687735f39314eb28ec6adc9d246f67422e9ae579774bb2f7fb746c6f1875d1154155ea8fd8a9c43f36dca04620ce86108b4ffcbcaad07b8db5afa6efd777ac1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "64314", "9950000000000000000", "0xac687735f39314eb28ec6adc9d246f67422e9ae579774bb2f7fb746c6f1875d1154155ea8fd8a9c43f36dca04620ce86108b4ffcbcaad07b8db5afa6efd777ac1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541778321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x4a1e1ebe12946185868873014a7761103fbe901d"}, {name: "nonce", type: "uint256", value: "64314"}, {name: "amount", type: "uint256", value: "9950000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "128286469504874310" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"54822\", \"240500000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673228", timeStamp: "1541778703", hash: "0x1902366444b00e883757a3029bd1f5d7792e27aaa09d201a6015448f93fc552a", nonce: "0", blockHash: "0x500b0aeabeb45d396b6cd7f5f5976d76761e8c5412a76a9afe30307e23875289", transactionIndex: "139", from: "0x417012cade61b605bf91aa8c851cc575d9b4aba0", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000d62600000000000000000000000000000000000000000000000d099ba3c6c17200000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004198eb78f2b97abda39d2cbfddfddabb260e0aff593e9adec6f61ee9b0c783734c160de90b84b42c3b21bbda35020f8b2dbaac086f2c76e058d913a4604dd0a78c1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7836671", gasUsed: "86724", confirmations: "1047407"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "54822"}, {type: "uint256", name: "amount", value: "240500000000000000000"}, {type: "bytes", name: "signature", value: "0x98eb78f2b97abda39d2cbfddfddabb260e0aff593e9adec6f61ee9b0c783734c160de90b84b42c3b21bbda35020f8b2dbaac086f2c76e058d913a4604dd0a78c1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "54822", "240500000000000000000", "0x98eb78f2b97abda39d2cbfddfddabb260e0aff593e9adec6f61ee9b0c783734c160de90b84b42c3b21bbda35020f8b2dbaac086f2c76e058d913a4604dd0a78c1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541778703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x417012cade61b605bf91aa8c851cc575d9b4aba0"}, {name: "nonce", type: "uint256", value: "54822"}, {name: "amount", type: "uint256", value: "240500000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1225876461174530" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"47344\", \"1061850000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "6673231", timeStamp: "1541778776", hash: "0xcfe91c81fe6625929db0dfe736d456194b555621cf2933d3b62c1fe6e00d9f8c", nonce: "0", blockHash: "0x936661660a7d1e47b543cb9431c631d7d9e58af8ff9baa5b5039583c9283eab8", transactionIndex: "49", from: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000b8f000000000000000000000000000000000000000000000003990210513dc89000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041c5a750dfcf70f7d0c2f8ac19a2cb7888ca8b6602fa19b2b162fc931f5261d5857aa487bc9327b50a0a7750b2a7aa72cade8cfcfa8c6e79325b7af87c3a85aa571c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6979351", gasUsed: "86724", confirmations: "1047404"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47344"}, {type: "uint256", name: "amount", value: "1061850000000000000000"}, {type: "bytes", name: "signature", value: "0xc5a750dfcf70f7d0c2f8ac19a2cb7888ca8b6602fa19b2b162fc931f5261d5857aa487bc9327b50a0a7750b2a7aa72cade8cfcfa8c6e79325b7af87c3a85aa571c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "47344", "1061850000000000000000", "0xc5a750dfcf70f7d0c2f8ac19a2cb7888ca8b6602fa19b2b162fc931f5261d5857aa487bc9327b50a0a7750b2a7aa72cade8cfcfa8c6e79325b7af87c3a85aa571c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541778776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c"}, {name: "nonce", type: "uint256", value: "47344"}, {name: "amount", type: "uint256", value: "1061850000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "48511350757034181" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69427\", \"122540000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673234", timeStamp: "1541778877", hash: "0x1042592f47728c0d3d63ffdc012adc41afaebf989c637841e1b667ef2c0c7759", nonce: "1", blockHash: "0x12704af8a2fbac24321b4339e1e6825206b0f939349ebb5c7b7cdf481c5a6228", transactionIndex: "150", from: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71788", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010f33000000000000000000000000000000000000000000000006a49588c1585e0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000417c1a17e62138e9580c7b9b74972d6ee907ef854ba888892f34fe4b5e1ab85f5033cd8e73cb873f177ada8bf4a78da37cfff1c5b41447fbceb9b76d516e4e6a5d1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7753566", gasUsed: "71788", confirmations: "1047401"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69427"}, {type: "uint256", name: "amount", value: "122540000000000000000"}, {type: "bytes", name: "signature", value: "0x7c1a17e62138e9580c7b9b74972d6ee907ef854ba888892f34fe4b5e1ab85f5033cd8e73cb873f177ada8bf4a78da37cfff1c5b41447fbceb9b76d516e4e6a5d1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69427", "122540000000000000000", "0x7c1a17e62138e9580c7b9b74972d6ee907ef854ba888892f34fe4b5e1ab85f5033cd8e73cb873f177ada8bf4a78da37cfff1c5b41447fbceb9b76d516e4e6a5d1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541778877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c"}, {name: "nonce", type: "uint256", value: "69427"}, {name: "amount", type: "uint256", value: "122540000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "48511350757034181" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69428\", \"63760000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673239", timeStamp: "1541779006", hash: "0xb6ea8e6a49a4a41c9b86bbb1bfd277473d3db9d981b62011704070e5c087cf4d", nonce: "2", blockHash: "0x32ea3551bf6c3a8eae1fedaf32ef204b70176f03fca48d3f27a144155a8eae91", transactionIndex: "104", from: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71788", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010f3400000000000000000000000000000000000000000000000374d9062f5ee800000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004103254e595a964186d74beb4681985f631a9244351f92827880b9cbb0b73d76f41d5bcb8f14e88742e94399473ac321ffafb4e64ddfcf29f38596a172bd468f411c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7862103", gasUsed: "71788", confirmations: "1047396"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69428"}, {type: "uint256", name: "amount", value: "63760000000000000000"}, {type: "bytes", name: "signature", value: "0x03254e595a964186d74beb4681985f631a9244351f92827880b9cbb0b73d76f41d5bcb8f14e88742e94399473ac321ffafb4e64ddfcf29f38596a172bd468f411c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69428", "63760000000000000000", "0x03254e595a964186d74beb4681985f631a9244351f92827880b9cbb0b73d76f41d5bcb8f14e88742e94399473ac321ffafb4e64ddfcf29f38596a172bd468f411c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541779006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c"}, {name: "nonce", type: "uint256", value: "69428"}, {name: "amount", type: "uint256", value: "63760000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "48511350757034181" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"49742\", \"13930000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673244", timeStamp: "1541779098", hash: "0x1068285fbc13dbea05d0224a108a1062bc14a51afcf378820cc2ecf5769a1900", nonce: "5", blockHash: "0xc3aca3446f7254a1cd9117ebeaff0155461db17526e9ced4898e110a666fbf52", transactionIndex: "104", from: "0xf0105322f9dfabf5c793f49680e26265e6acb956", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000c24e000000000000000000000000000000000000000000000000c1514d321931000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041ea0f1992dc21670411b0227d687e7dc99c3676fe26c6a557fb46e1e266eefd7a3250e4a2b5e09a0a9d243dc4d8f8474d1c8133bc35f446acb35e0c7eb5ea79b91c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6854417", gasUsed: "86660", confirmations: "1047391"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "49742"}, {type: "uint256", name: "amount", value: "13930000000000000000"}, {type: "bytes", name: "signature", value: "0xea0f1992dc21670411b0227d687e7dc99c3676fe26c6a557fb46e1e266eefd7a3250e4a2b5e09a0a9d243dc4d8f8474d1c8133bc35f446acb35e0c7eb5ea79b91c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "49742", "13930000000000000000", "0xea0f1992dc21670411b0227d687e7dc99c3676fe26c6a557fb46e1e266eefd7a3250e4a2b5e09a0a9d243dc4d8f8474d1c8133bc35f446acb35e0c7eb5ea79b91c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541779098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xf0105322f9dfabf5c793f49680e26265e6acb956"}, {name: "nonce", type: "uint256", value: "49742"}, {name: "amount", type: "uint256", value: "13930000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14476790835258449" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"48710\", \"134450000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673248", timeStamp: "1541779150", hash: "0x7d93cc17f588a57fbb1e39fb621fa6a02dc2581a15c01d25a41840af128ea801", nonce: "0", blockHash: "0x650dd7da280e611867e88373ef3cdeb4b335fe26bdbb095416e25cb02bdecea5", transactionIndex: "184", from: "0x65a834eacfa8a1eea64e99ea5f5c2ecb2d4c2fed", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000be4600000000000000000000000000000000000000000000000749de5aa74345000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041817a5055e68695c9f94cd0dcb523854d3194f9ba0d28177531bf7e4492f9f23d1c22c1daf4af0ca690fc90a4d6d4cf3082dc5f03b4029712e6ef4bea317b268d1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6473090", gasUsed: "86724", confirmations: "1047387"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "48710"}, {type: "uint256", name: "amount", value: "134450000000000000000"}, {type: "bytes", name: "signature", value: "0x817a5055e68695c9f94cd0dcb523854d3194f9ba0d28177531bf7e4492f9f23d1c22c1daf4af0ca690fc90a4d6d4cf3082dc5f03b4029712e6ef4bea317b268d1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "48710", "134450000000000000000", "0x817a5055e68695c9f94cd0dcb523854d3194f9ba0d28177531bf7e4492f9f23d1c22c1daf4af0ca690fc90a4d6d4cf3082dc5f03b4029712e6ef4bea317b268d1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541779150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x65a834eacfa8a1eea64e99ea5f5c2ecb2d4c2fed"}, {name: "nonce", type: "uint256", value: "48710"}, {name: "amount", type: "uint256", value: "134450000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "899639804035605" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"47619\", \"314500000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673254", timeStamp: "1541779267", hash: "0x5afa69c6558ec306eecef5fa2072925b612a9595618f5356170c3286decd5952", nonce: "0", blockHash: "0xe9f87a65de5f78943cdfe7e632bfe0be7b4d7729a929afac38c1e883a03a8554", transactionIndex: "127", from: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000ba030000000000000000000000000000000000000000000000110c9073b5245a000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f770fdaa0b0bff961c5c68f5fdce90104206ef0180364a54272e494cdf8235746b1de8202a55c1226864434d72381770845211226b388839017fedff7147eee61c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7973301", gasUsed: "86724", confirmations: "1047381"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47619"}, {type: "uint256", name: "amount", value: "314500000000000000000"}, {type: "bytes", name: "signature", value: "0xf770fdaa0b0bff961c5c68f5fdce90104206ef0180364a54272e494cdf8235746b1de8202a55c1226864434d72381770845211226b388839017fedff7147eee61c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "47619", "314500000000000000000", "0xf770fdaa0b0bff961c5c68f5fdce90104206ef0180364a54272e494cdf8235746b1de8202a55c1226864434d72381770845211226b388839017fedff7147eee61c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541779267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82"}, {name: "nonce", type: "uint256", value: "47619"}, {name: "amount", type: "uint256", value: "314500000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2197717881329166" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"51478\", \"4980000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673256", timeStamp: "1541779276", hash: "0x2a46475ab4cfd7b74b646767470fd088d294a25e00a69349360ef2373c05b506", nonce: "0", blockHash: "0x3049d402d93208ac3b1ab5c55a205bac9ce00ad418764b944399264426a60ba7", transactionIndex: "71", from: "0x0f794895a65c411a0beeb6cf0485ce7aa0cef52c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000c916000000000000000000000000000000000000000000000000451c839d6572000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f49fcec6242a096a6d4b04483f1b31c839abd849819b52fcb63cf5f2d002deac1dfa315278fbd0ab014130fa94e56330a554a28548fedf3013386dc7c7afd1aa1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3330532", gasUsed: "86660", confirmations: "1047379"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "51478"}, {type: "uint256", name: "amount", value: "4980000000000000000"}, {type: "bytes", name: "signature", value: "0xf49fcec6242a096a6d4b04483f1b31c839abd849819b52fcb63cf5f2d002deac1dfa315278fbd0ab014130fa94e56330a554a28548fedf3013386dc7c7afd1aa1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "51478", "4980000000000000000", "0xf49fcec6242a096a6d4b04483f1b31c839abd849819b52fcb63cf5f2d002deac1dfa315278fbd0ab014130fa94e56330a554a28548fedf3013386dc7c7afd1aa1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541779276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x0f794895a65c411a0beeb6cf0485ce7aa0cef52c"}, {name: "nonce", type: "uint256", value: "51478"}, {name: "amount", type: "uint256", value: "4980000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "19789632520000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"47622\", \"10600000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673264", timeStamp: "1541779486", hash: "0x3fce17b48f6bba8e814bce5028364bc524589fa2e99d505d876f205fa0e8b590", nonce: "1", blockHash: "0xf4e6cb65de10dc8e9be5ad17e2da8f2313f94e23e773da3657873cfc79297e50", transactionIndex: "185", from: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000ba06000000000000000000000000000000000000000000000000931ac3d6bb24000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041da3ca9dccadc5fd4c2b74719e08da6da587f1d9b5c141e96e201f3315e76ee4a3b86d7bbefe719e22016b4c784a3f299881815f9959e88ed808ae1ae74d3b72c1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7981823", gasUsed: "71660", confirmations: "1047371"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47622"}, {type: "uint256", name: "amount", value: "10600000000000000000"}, {type: "bytes", name: "signature", value: "0xda3ca9dccadc5fd4c2b74719e08da6da587f1d9b5c141e96e201f3315e76ee4a3b86d7bbefe719e22016b4c784a3f299881815f9959e88ed808ae1ae74d3b72c1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "47622", "10600000000000000000", "0xda3ca9dccadc5fd4c2b74719e08da6da587f1d9b5c141e96e201f3315e76ee4a3b86d7bbefe719e22016b4c784a3f299881815f9959e88ed808ae1ae74d3b72c1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541779486 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82"}, {name: "nonce", type: "uint256", value: "47622"}, {name: "amount", type: "uint256", value: "10600000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2197717881329166" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"48766\", \"11040000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673266", timeStamp: "1541779534", hash: "0x427ee6dd959347fe09b97c71225170888f45be4dacfb2d5db711625f0886966a", nonce: "1", blockHash: "0x1459324e92071c493274c321d0be3d2fb51e8de46afedc8a7575ec73f7a638e8", transactionIndex: "91", from: "0x65a834eacfa8a1eea64e99ea5f5c2ecb2d4c2fed", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71596", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000be7e0000000000000000000000000000000000000000000000009935f581f050000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041fadcee1ea293eb64f6db8ce79130d4ff4b611eef11e713ad8a915693ce26037c38c30cb896d4f186910d38432c6b00ea3ab873627b4e274f41573e630796d4931b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6069724", gasUsed: "71596", confirmations: "1047369"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "48766"}, {type: "uint256", name: "amount", value: "11040000000000000000"}, {type: "bytes", name: "signature", value: "0xfadcee1ea293eb64f6db8ce79130d4ff4b611eef11e713ad8a915693ce26037c38c30cb896d4f186910d38432c6b00ea3ab873627b4e274f41573e630796d4931b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "48766", "11040000000000000000", "0xfadcee1ea293eb64f6db8ce79130d4ff4b611eef11e713ad8a915693ce26037c38c30cb896d4f186910d38432c6b00ea3ab873627b4e274f41573e630796d4931b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541779534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x65a834eacfa8a1eea64e99ea5f5c2ecb2d4c2fed"}, {name: "nonce", type: "uint256", value: "48766"}, {name: "amount", type: "uint256", value: "11040000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "899639804035605" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"53917\", \"1900000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673266", timeStamp: "1541779534", hash: "0x4b6759cff100108a63b967441afdbfbc5cb5254cd50a19a60f6416710292400e", nonce: "0", blockHash: "0x1459324e92071c493274c321d0be3d2fb51e8de46afedc8a7575ec73f7a638e8", transactionIndex: "110", from: "0x230e21979fdbb465e3c34959d0b8c90eaba3a682", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000d29d0000000000000000000000000000000000000000000000001a5e27eef13e000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041cbcb44f89075e32ac76debd589b7947f345630bcf1074a7643ec0ec0e0747e1307af2d4e32e30f314ce833f578f2039b4aaa4e0ed5a65f625e0219b1c120524f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7218384", gasUsed: "86660", confirmations: "1047369"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "53917"}, {type: "uint256", name: "amount", value: "1900000000000000000"}, {type: "bytes", name: "signature", value: "0xcbcb44f89075e32ac76debd589b7947f345630bcf1074a7643ec0ec0e0747e1307af2d4e32e30f314ce833f578f2039b4aaa4e0ed5a65f625e0219b1c120524f1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "53917", "1900000000000000000", "0xcbcb44f89075e32ac76debd589b7947f345630bcf1074a7643ec0ec0e0747e1307af2d4e32e30f314ce833f578f2039b4aaa4e0ed5a65f625e0219b1c120524f1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541779534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x230e21979fdbb465e3c34959d0b8c90eaba3a682"}, {name: "nonce", type: "uint256", value: "53917"}, {name: "amount", type: "uint256", value: "1900000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "26280983362477154" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"56909\", \"1990000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673266", timeStamp: "1541779534", hash: "0x2fcc8cba0f08f76f9827ebba6a09f5d70defff73ad6f671d7591c2d896181fdf", nonce: "1", blockHash: "0x1459324e92071c493274c321d0be3d2fb51e8de46afedc8a7575ec73f7a638e8", transactionIndex: "121", from: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71596", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000de4d0000000000000000000000000000000000000000000000001b9de674df0700000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004151f6722fb2e6c2d48aeb120b06fd131d1a44fef82b2f6922dc95afa65725e017322ebd9dff23f698b09e2a21e870e2ad33cb2e45cb637666db8420003dd92c3b1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7666771", gasUsed: "71596", confirmations: "1047369"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "56909"}, {type: "uint256", name: "amount", value: "1990000000000000000"}, {type: "bytes", name: "signature", value: "0x51f6722fb2e6c2d48aeb120b06fd131d1a44fef82b2f6922dc95afa65725e017322ebd9dff23f698b09e2a21e870e2ad33cb2e45cb637666db8420003dd92c3b1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "56909", "1990000000000000000", "0x51f6722fb2e6c2d48aeb120b06fd131d1a44fef82b2f6922dc95afa65725e017322ebd9dff23f698b09e2a21e870e2ad33cb2e45cb637666db8420003dd92c3b1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541779534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba"}, {name: "nonce", type: "uint256", value: "56909"}, {name: "amount", type: "uint256", value: "1990000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "84405880164930098" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"47624\", \"1990000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673272", timeStamp: "1541779639", hash: "0xedb552e7bb75c7bf8b21cbc1d716239fa70f642b008a18cfb0d63aaeb7481938", nonce: "2", blockHash: "0x699ea1ae99c605fa71df44891cc2e57027c4146e15f92da62fccd03715d698f9", transactionIndex: "25", from: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71596", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000ba080000000000000000000000000000000000000000000000001b9de674df07000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041067cd9bd29146025d3f552355b5c721fba6ae1fb9c027ad0d39300ed4e75cb3a331cab185a095ff2513f9406b1689b962121be8a0fe2e85dfe371fe5803e6ee51b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2495223", gasUsed: "71596", confirmations: "1047363"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47624"}, {type: "uint256", name: "amount", value: "1990000000000000000"}, {type: "bytes", name: "signature", value: "0x067cd9bd29146025d3f552355b5c721fba6ae1fb9c027ad0d39300ed4e75cb3a331cab185a095ff2513f9406b1689b962121be8a0fe2e85dfe371fe5803e6ee51b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "47624", "1990000000000000000", "0x067cd9bd29146025d3f552355b5c721fba6ae1fb9c027ad0d39300ed4e75cb3a331cab185a095ff2513f9406b1689b962121be8a0fe2e85dfe371fe5803e6ee51b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541779639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82"}, {name: "nonce", type: "uint256", value: "47624"}, {name: "amount", type: "uint256", value: "1990000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2197717881329166" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"47626\", \"1990000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673276", timeStamp: "1541779692", hash: "0xe31b569e0218fca1ca0412cf8d5ab431e6b49c3bd25a745e30247e9c06b316b1", nonce: "3", blockHash: "0x3dae94301a18d5af9b6773948bdebdfc421728e1d73ce2f845219a9c18157e70", transactionIndex: "75", from: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "5600000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000ba0a0000000000000000000000000000000000000000000000001b9de674df070000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000416a44a7b96584ba5565bfe9bb9ab7fc10286a4b627a50db81275c96bd26755f801d06088e7f527cfbcb8ab7133a20b0cba4d1f56a4a45751bc356ff682a2222461b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3426211", gasUsed: "71660", confirmations: "1047359"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47626"}, {type: "uint256", name: "amount", value: "1990000000000000000"}, {type: "bytes", name: "signature", value: "0x6a44a7b96584ba5565bfe9bb9ab7fc10286a4b627a50db81275c96bd26755f801d06088e7f527cfbcb8ab7133a20b0cba4d1f56a4a45751bc356ff682a2222461b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "47626", "1990000000000000000", "0x6a44a7b96584ba5565bfe9bb9ab7fc10286a4b627a50db81275c96bd26755f801d06088e7f527cfbcb8ab7133a20b0cba4d1f56a4a45751bc356ff682a2222461b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541779692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x536a53558d6ec3e8201f3099a051c4aecdd0ee82"}, {name: "nonce", type: "uint256", value: "47626"}, {name: "amount", type: "uint256", value: "1990000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2197717881329166" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"55486\", \"5000000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673286", timeStamp: "1541779863", hash: "0xc9b84c386bc4e6160a6122793ad0a408fb6e76fd87da9a441c9bc293b9b69709", nonce: "2", blockHash: "0x838dbba02d8d0cf66233760c324c451ca4b84bdea2c5bc7c831798905f6b8771", transactionIndex: "96", from: "0x417012cade61b605bf91aa8c851cc575d9b4aba0", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000d8be0000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041aff6b2e99855625f7de62f1aa623922df6ad77642097e6ab263528d1c9fb789526227e500ed468fde66f5694337d77e31e46dca96b9acaf87c32c925027aea9e1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4976349", gasUsed: "86660", confirmations: "1047349"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "55486"}, {type: "uint256", name: "amount", value: "5000000000000000000"}, {type: "bytes", name: "signature", value: "0xaff6b2e99855625f7de62f1aa623922df6ad77642097e6ab263528d1c9fb789526227e500ed468fde66f5694337d77e31e46dca96b9acaf87c32c925027aea9e1b"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "55486", "5000000000000000000", "0xaff6b2e99855625f7de62f1aa623922df6ad77642097e6ab263528d1c9fb789526227e500ed468fde66f5694337d77e31e46dca96b9acaf87c32c925027aea9e1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541779863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x417012cade61b605bf91aa8c851cc575d9b4aba0"}, {name: "nonce", type: "uint256", value: "55486"}, {name: "amount", type: "uint256", value: "5000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1225876461174530" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69429\", \"82780000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673287", timeStamp: "1541779877", hash: "0x70bea2d251a382431a94f8e3a8facfdf991c23ba4a85ec810ffba03eac5fb9c6", nonce: "3", blockHash: "0x1bccf1417d24538e02dd1b852e8d81936015087288572e73d58eeb3977d52f3b", transactionIndex: "57", from: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71788", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010f350000000000000000000000000000000000000000000000047ccda369aad60000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000412689d15fd23b2ca4c875aed5ca8eec283546fbc7e2fa16bf470e11f0a070204d1392c4b10b2d9b3cee721141e6f834db55933397fdcc9b2b25683e08701978a01c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4417887", gasUsed: "71788", confirmations: "1047348"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69429"}, {type: "uint256", name: "amount", value: "82780000000000000000"}, {type: "bytes", name: "signature", value: "0x2689d15fd23b2ca4c875aed5ca8eec283546fbc7e2fa16bf470e11f0a070204d1392c4b10b2d9b3cee721141e6f834db55933397fdcc9b2b25683e08701978a01c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69429", "82780000000000000000", "0x2689d15fd23b2ca4c875aed5ca8eec283546fbc7e2fa16bf470e11f0a070204d1392c4b10b2d9b3cee721141e6f834db55933397fdcc9b2b25683e08701978a01c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541779877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c"}, {name: "nonce", type: "uint256", value: "69429"}, {name: "amount", type: "uint256", value: "82780000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "48511350757034181" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"55492\", \"3000000000000000000\", \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "6673297", timeStamp: "1541779981", hash: "0x7822f1aac200bee54809791ffdb3e57efb43deafe2ed27fd492cc471cfe38a4a", nonce: "3", blockHash: "0x56b070e51c4add7f7e0e51449fa717f004d2695fce0bc2168ea4e1029a512281", transactionIndex: "162", from: "0x417012cade61b605bf91aa8c851cc575d9b4aba0", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71468", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000d8c400000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041039a0000c9aecc9a7c2e9ec990be9e7f3d3185211eb106c7006a4d3f1cf482ea28d16d6b6d6f15d798c0e1b16af480036d128322b9ff42d66e0b4a87fcc97c681c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6159650", gasUsed: "71468", confirmations: "1047338"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "55492"}, {type: "uint256", name: "amount", value: "3000000000000000000"}, {type: "bytes", name: "signature", value: "0x039a0000c9aecc9a7c2e9ec990be9e7f3d3185211eb106c7006a4d3f1cf482ea28d16d6b6d6f15d798c0e1b16af480036d128322b9ff42d66e0b4a87fcc97c681c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "55492", "3000000000000000000", "0x039a0000c9aecc9a7c2e9ec990be9e7f3d3185211eb106c7006a4d3f1cf482ea28d16d6b6d6f15d798c0e1b16af480036d128322b9ff42d66e0b4a87fcc97c681c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541779981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x417012cade61b605bf91aa8c851cc575d9b4aba0"}, {name: "nonce", type: "uint256", value: "55492"}, {name: "amount", type: "uint256", value: "3000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1225876461174530" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"55905\", \"780000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673297", timeStamp: "1541779981", hash: "0x0bd410c4d10e17fd67e8c0f52f6ceea30ebf3027fb1dab421217c0171ec2ade8", nonce: "2", blockHash: "0x56b070e51c4add7f7e0e51449fa717f004d2695fce0bc2168ea4e1029a512281", transactionIndex: "172", from: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71660", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000da6100000000000000000000000000000000000000000000002a48acab6204b00000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000413bbf819efae5f37f7d8e46ebe8cfc8b9f1d7e4edbb63e1d34f745df4f8c6ed4d17d4ca8a11d88ccaf3b88ab482bc63d0198600918425653f83a108e02ffd3cbe1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6805700", gasUsed: "71660", confirmations: "1047338"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "55905"}, {type: "uint256", name: "amount", value: "780000000000000000000"}, {type: "bytes", name: "signature", value: "0x3bbf819efae5f37f7d8e46ebe8cfc8b9f1d7e4edbb63e1d34f745df4f8c6ed4d17d4ca8a11d88ccaf3b88ab482bc63d0198600918425653f83a108e02ffd3cbe1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "55905", "780000000000000000000", "0x3bbf819efae5f37f7d8e46ebe8cfc8b9f1d7e4edbb63e1d34f745df4f8c6ed4d17d4ca8a11d88ccaf3b88ab482bc63d0198600918425653f83a108e02ffd3cbe1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541779981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x493f534e2c7da0ba8089951061ba3b0fc13113ba"}, {name: "nonce", type: "uint256", value: "55905"}, {name: "amount", type: "uint256", value: "780000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "84405880164930098" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69430\", \"63560000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673297", timeStamp: "1541779981", hash: "0x154a4a835804c5d1ae20c4bb327405162f0233a369f6fc604a50af8704aac230", nonce: "4", blockHash: "0x56b070e51c4add7f7e0e51449fa717f004d2695fce0bc2168ea4e1029a512281", transactionIndex: "176", from: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71788", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010f3600000000000000000000000000000000000000000000000372127b3ea3d4000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041e55d56146b5de8e7db8f9a2f1444115ad17f3ef1a87e0e7f732aa20fb699aba12cd7dcd66277e0c6aef1ab8ee7e8eac3e180cfbf912b17881aaae36d9eed4f171c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7039683", gasUsed: "71788", confirmations: "1047338"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69430"}, {type: "uint256", name: "amount", value: "63560000000000000000"}, {type: "bytes", name: "signature", value: "0xe55d56146b5de8e7db8f9a2f1444115ad17f3ef1a87e0e7f732aa20fb699aba12cd7dcd66277e0c6aef1ab8ee7e8eac3e180cfbf912b17881aaae36d9eed4f171c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69430", "63560000000000000000", "0xe55d56146b5de8e7db8f9a2f1444115ad17f3ef1a87e0e7f732aa20fb699aba12cd7dcd66277e0c6aef1ab8ee7e8eac3e180cfbf912b17881aaae36d9eed4f171c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541779981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x2f0a32804e12e9f6b3e2ea2f9fdc774c93b5a64c"}, {name: "nonce", type: "uint256", value: "69430"}, {name: "amount", type: "uint256", value: "63560000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "48511350757034181" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"48715\", \"38410000000000000000\", \"0... )", async function( ) {
		const txOriginal = {blockNumber: "6673302", timeStamp: "1541780052", hash: "0xd19b662a12607c349cacd0025988101db11b34e7d1544b23229a987511147a45", nonce: "0", blockHash: "0x54fe7c440ac3bcc50a35ab7ddad08b2b623ea3a7e7c182a6ea9489d6d98727fc", transactionIndex: "91", from: "0x6bdce18491eff1d5a03feff79cc52fb76d364678", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "86724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d521000000000000000000000000000000000000000000000000000000000000be4b000000000000000000000000000000000000000000000002150bbb7ebec10000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000413848e3cd2ac629e3d3799fdb5a7dfc63e83253aefaf4ed89d41792a56b48db1c38d31d354b21b13281282e34d8e4a61fafadb843a9f2bff61d6e588dd3b90fb81c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3506325", gasUsed: "86724", confirmations: "1047333"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "48715"}, {type: "uint256", name: "amount", value: "38410000000000000000"}, {type: "bytes", name: "signature", value: "0x3848e3cd2ac629e3d3799fdb5a7dfc63e83253aefaf4ed89d41792a56b48db1c38d31d354b21b13281282e34d8e4a61fafadb843a9f2bff61d6e588dd3b90fb81c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "48715", "38410000000000000000", "0x3848e3cd2ac629e3d3799fdb5a7dfc63e83253aefaf4ed89d41792a56b48db1c38d31d354b21b13281282e34d8e4a61fafadb843a9f2bff61d6e588dd3b90fb81c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541780052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0x6bdce18491eff1d5a03feff79cc52fb76d364678"}, {name: "nonce", type: "uint256", value: "48715"}, {name: "amount", type: "uint256", value: "38410000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "49431090010180429" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: activateVoucher( \"69522\", \"107000000000000000000\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6673304", timeStamp: "1541780071", hash: "0x5595d008436e39e9efaf4360e8d1a6c2fde1d9f1931f7cf7e1b550ae5aa01688", nonce: "6", blockHash: "0x190007f173d71e57cba120440f05ea7c021005ee4a2e267201228060c2b5ceb2", transactionIndex: "79", from: "0xf0105322f9dfabf5c793f49680e26265e6acb956", to: "0x6c228badcf181febf7f3b4a61f8e26086942a3db", value: "0", gas: "71724", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc21d5210000000000000000000000000000000000000000000000000000000000010f92000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004107f1ebbf3f390b5c527b00cacc8e059f9f3db85e2a6bc68365dd3ad36ea8ea3e3b1e8605d31a766213a6134148a7a3a0838ea48fe61ffcbfd469837f86e131fe1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4780727", gasUsed: "71724", confirmations: "1047331"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "69522"}, {type: "uint256", name: "amount", value: "107000000000000000000"}, {type: "bytes", name: "signature", value: "0x07f1ebbf3f390b5c527b00cacc8e059f9f3db85e2a6bc68365dd3ad36ea8ea3e3b1e8605d31a766213a6134148a7a3a0838ea48fe61ffcbfd469837f86e131fe1c"}], name: "activateVoucher", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateVoucher(uint256,uint256,bytes)" ]( "69522", "107000000000000000000", "0x07f1ebbf3f390b5c527b00cacc8e059f9f3db85e2a6bc68365dd3ad36ea8ea3e3b1e8605d31a766213a6134148a7a3a0838ea48fe61ffcbfd469837f86e131fe1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541780071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: true, name: "nonce", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "VoucherRedemption", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "VoucherRedemption", events: [{name: "caller", type: "address", value: "0xf0105322f9dfabf5c793f49680e26265e6acb956"}, {name: "nonce", type: "uint256", value: "69522"}, {name: "amount", type: "uint256", value: "107000000000000000000"}], address: "0x6c228badcf181febf7f3b4a61f8e26086942a3db"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14476790835258449" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
