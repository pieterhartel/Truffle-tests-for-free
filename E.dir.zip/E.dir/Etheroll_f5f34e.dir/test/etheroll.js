const Etheroll = artifacts.require( "./Etheroll.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Etheroll" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xEce701C76bD00D1C3f96410a0C69eA8Dfcf5f34E", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x73F0ed546Cd7893ABc5e04284B68522602603dD4", "0x24C3235558572cff8054b5a419251D3B0D43E91b", "0x5de92686587b10cD47E03B71f2E2350606fCAf14", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0x6Ecd5bBD600931D2FFAd11E2948939b284AFd5D6", "0x5ACFAf158a56bdB6E628517C1Bb088eA7097144F", "0x7078944645Cd2291D1e4Dde68AE4a8F19611Fb6c", "0xCF4e8aa069A7336744cEE5f50d32a5f7bA94b14D", "0x8Dfb44050708B5Fd8dD0c3AF4B680838A42ED866", "0xB00e8Ef510eeaD6e8c867FA9D485dD7a06ec99a4", "0xdf9c6c6dB6922F78Ab990d0836503587815E5Ebc", "0x70c4bCC07A2bFc0Cff3c7099B4a9e0EbcA181c02", "0xc4b3f4622C7c7526f9721d8687C3cE07A99D5624", "0x5c8C5096C3e7Ce3A86413eCf650bdB0c4d977287"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalWeiWon", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "addressToCheck", type: "address"}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalWeiWagered", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "gasForOraclize", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalBets", outputs: [{name: "", type: "int256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxPendingPayouts", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RefundValue", type: "uint256"}], name: "LogRefund", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "SentToAddress", type: "address"}, {indexed: true, name: "AmountTransferred", type: "uint256"}], name: "LogOwnerTransfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogBet(bytes32,address,uint256,uint256,uint256,uint256)", "LogResult(uint256,bytes32,address,uint256,uint256,uint256,int256,bytes)", "LogRefund(bytes32,address,uint256)", "LogOwnerTransfer(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1cb5bfc4e69cbacf65c8e05bdb84d7a327bd6bb4c034ff82359aefd7443775c4", "0x8dd0b145385d04711e29558ceab40b456976a2b9a7d648cc1bcd416161bf97b9", "0x7b6ccf85690b8ce1b7d21a94ca738803a9da7dc74e10140f269efa0d8d6fb851", "0x42c501a185f41a8eb77b0a3e7b72a6435ea7aa752f8a1a0a13ca4628495eca91"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3753601 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3754930 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Etheroll", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalWeiWon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiWon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitAsPercentOfHouse()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payoutsPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addressToCheck", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playerGetPendingTxByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "treasury()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWeiWagered", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiWagered()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gasForOraclize", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gasForOraclize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBets", outputs: [{name: "", type: "int256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gamePaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdge()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdgeDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxPendingPayouts", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxPendingPayouts()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Etheroll", function( accounts ) {

	it( "TEST: Etheroll(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3753601", timeStamp: "1495531993", hash: "0xb88b9f22f086cd7a0f14e8dfd53c31ba84c8b2cbe02262edac41bd88eceb418f", nonce: "121", blockHash: "0x58c80144b29f2e9d3e8c65891b9b7954bbaff3e82b1b3a60dd9407b36aeccef3", transactionIndex: "10", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: 0, value: "0", gas: "3274041", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1558ae4d", contractAddress: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", cumulativeGasUsed: "3873360", gasUsed: "3174040", confirmations: "3921382"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Etheroll", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Etheroll.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1495531993 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Etheroll.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "914690819703579555783" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: ownerSetOraclizeSafeGas( \"235000\" )", async function( ) {
		const txOriginal = {blockNumber: "3753725", timeStamp: "1495533801", hash: "0xc4832b611744e392cb30e3967af00e0d368127a366d432511225e9675c1acbc2", nonce: "122", blockHash: "0x04a20ad44494344de05002e9edf9b561e8bc137592033ada967842ab07d7849e", transactionIndex: "30", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "128042", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd207e75700000000000000000000000000000000000000000000000000000000000395f8", contractAddress: "", cumulativeGasUsed: "879663", gasUsed: "28041", confirmations: "3921258"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "newSafeGasToOraclize", value: "235000"}], name: "ownerSetOraclizeSafeGas", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerSetOraclizeSafeGas(uint32)" ]( "235000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1495533801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "914690819703579555783" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: ownerSetTreasury( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "3753846", timeStamp: "1495535497", hash: "0x2945043cd74d9077d2bc7656c1a24adfda8fdb488fd798e1eca61d437d262b7b", nonce: "123", blockHash: "0x409be631ca7b7e42110dc21bd37cf72f86b4d3e7cd7f011a23716f0a67f06f83", transactionIndex: "44", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x3137524200000000000000000000000024c3235558572cff8054b5a419251d3b0d43e91b", contractAddress: "", cumulativeGasUsed: "1707449", gasUsed: "28737", confirmations: "3921137"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newTreasury", value: addressList[10]}], name: "ownerSetTreasury", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerSetTreasury(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1495535497 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "914690819703579555783" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: ownerPauseGame( true )", async function( ) {
		const txOriginal = {blockNumber: "3754058", timeStamp: "1495538907", hash: "0xfdf762b32873f15cb70fc9c580acf988eacd3460de422c72bcc5cb97b67b8d4c", nonce: "126", blockHash: "0x08b56be75c41b8e807c83eccdd9ed37bb682a2e5e4348220bd4fafc2597270c3", transactionIndex: "47", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "127672", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6eacd48a0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2833994", gasUsed: "27671", confirmations: "3920925"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "newStatus", value: true}], name: "ownerPauseGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerPauseGame(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1495538907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "914690819703579555783" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: ownerPauseGame( false )", async function( ) {
		const txOriginal = {blockNumber: "3754149", timeStamp: "1495540196", hash: "0x1058d8bf707dcad3cb12dc65455c34983d3cd85273f830281bc8b7b9a4e7abaa", nonce: "129", blockHash: "0x457dc53d0fcc63efdbe4c400025fd6d9fa46290ce927bc847a937d819f3ff29f", transactionIndex: "19", from: "0x73f0ed546cd7893abc5e04284b68522602603dd4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "127608", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6eacd48a0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "884703", gasUsed: "27607", confirmations: "3920834"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "newStatus", value: false}], name: "ownerPauseGame", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerPauseGame(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1495540196 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "914690819703579555783" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"99\" )", async function( ) {
		const txOriginal = {blockNumber: "3754151", timeStamp: "1495540245", hash: "0x9f4719d63aefa4a350428dcf8fc1b228636e3a412f228849678185b96ad21d97", nonce: "2711", blockHash: "0xd39039fb747ab30b9ce0279b2587f340257230a6a7e9e0ff6dab7753fbe881c7", transactionIndex: "17", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000063", contractAddress: "", cumulativeGasUsed: "920432", gasUsed: "244939", confirmations: "3920832"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "99"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "99", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1495540245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x38e89b09a92755d7d23b7dfcb4f95e32cd9ebb62a969eb36fb556cec3ca135cf"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "101020408163265305"}, {name: "ProfitValue", type: "uint256", value: "1020408163265305"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "99"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1583669827405182396" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x38e89b09a92755d7d23b7dfcb4f95e32cd9e... )", async function( ) {
		const txOriginal = {blockNumber: "3754154", timeStamp: "1495540303", hash: "0x074953c673a9cc155e2d6c01057f93a19465c3cf5238e79b9a1d7baf7927f2c7", nonce: "97516", blockHash: "0x60f404a2e54bb8fcdf0734a32226f22ee5bf9dfba46b6baff17b7b580f55675d", transactionIndex: "6", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa5038e89b09a92755d7d23b7dfcb4f95e32cd9ebb62a969eb36fb556cec3ca135cf000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303335362c205b39315d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220d1d74e2125b9e8e3e5e6b9e0da6b5b97baa36ccb59ce2e79cd375de2a25a5b92000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "319696", gasUsed: "133433", confirmations: "3920829"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x38e89b09a92755d7d23b7dfcb4f95e32cd9ebb62a969eb36fb556cec3ca135cf"}, {type: "string", name: "result", value: `[10356, [91]]`}, {type: "bytes", name: "proof", value: "0x1220d1d74e2125b9e8e3e5e6b9e0da6b5b97baa36ccb59ce2e79cd375de2a25a5b92"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x38e89b09a92755d7d23b7dfcb4f95e32cd9ebb62a969eb36fb556cec3ca135cf", `[10356, [91]]`, "0x1220d1d74e2125b9e8e3e5e6b9e0da6b5b97baa36ccb59ce2e79cd375de2a25a5b92", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1495540303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10356"}, {name: "BetID", type: "bytes32", value: "0x38e89b09a92755d7d23b7dfcb4f95e32cd9ebb62a969eb36fb556cec3ca135cf"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "99"}, {name: "DiceResult", type: "uint256", value: "91"}, {name: "Value", type: "uint256", value: "101020408163265305"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220d1d74e2125b9e8e3e5e6b9e0da6b5b97baa36ccb59ce2e79cd375de2a25a5b92"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3754157", timeStamp: "1495540407", hash: "0xbff4e3e40a8261b9774c58b831f2fb24b60c27854a83b234350ca0e0b6c74169", nonce: "2712", blockHash: "0x3f7a7427dfec218813465cc20001e8c8a67ac9455d539a5745245ed74fcc47c7", transactionIndex: "52", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3664508", gasUsed: "229939", confirmations: "3920826"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "2"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1495540407 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x3cd93a3dd3b2893449e90208223effa25899795a1bbba31a5ab5cc255ff8c564"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "9900000000000000000"}, {name: "ProfitValue", type: "uint256", value: "9800000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "2"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1583669827405182396" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3cd93a3dd3b2893449e90208223effa25899... )", async function( ) {
		const txOriginal = {blockNumber: "3754162", timeStamp: "1495540461", hash: "0x588d333fb71e84b2a12508e470e419bb479f80230816a5b9230e417aba505bcb", nonce: "97517", blockHash: "0xf1afe629991ab8479ffb13da026c3ce3d61b5c43524d52fca054191f7769e3af", transactionIndex: "31", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa503cd93a3dd3b2893449e90208223effa25899795a1bbba31a5ab5cc255ff8c564000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303335372c205b37355d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220300d8173571d1541597690920a53c22c5343df2481e37b29f4fcc9c1703519e3000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2871251", gasUsed: "122633", confirmations: "3920821"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x3cd93a3dd3b2893449e90208223effa25899795a1bbba31a5ab5cc255ff8c564"}, {type: "string", name: "result", value: `[10357, [75]]`}, {type: "bytes", name: "proof", value: "0x1220300d8173571d1541597690920a53c22c5343df2481e37b29f4fcc9c1703519e3"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x3cd93a3dd3b2893449e90208223effa25899795a1bbba31a5ab5cc255ff8c564", `[10357, [75]]`, "0x1220300d8173571d1541597690920a53c22c5343df2481e37b29f4fcc9c1703519e3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1495540461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10357"}, {name: "BetID", type: "bytes32", value: "0x3cd93a3dd3b2893449e90208223effa25899795a1bbba31a5ab5cc255ff8c564"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "2"}, {name: "DiceResult", type: "uint256", value: "75"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220300d8173571d1541597690920a53c22c5343df2481e37b29f4fcc9c1703519e3"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754181", timeStamp: "1495540894", hash: "0x449b824c15b75b3288f7e0b3aa2b6e51e8447f5948d4dff7dce9fc12953bc1fc", nonce: "2713", blockHash: "0xcf1e488f191ffba0d7458d44a4fdba197872b87109389d1cbb51608a5783a9ee", transactionIndex: "27", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20828696557", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1949330", gasUsed: "229939", confirmations: "3920802"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1495540894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x50ad86777b1bcd6383ad18aa4cff3892f31a5088386b43da1a3a98690f2930ed"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1583669827405182396" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x50ad86777b1bcd6383ad18aa4cff3892f31a... )", async function( ) {
		const txOriginal = {blockNumber: "3754185", timeStamp: "1495540929", hash: "0xd64b6927d9254ca959239dec3e4448059c3f0227c0f4037bc73d697975a06908", nonce: "97518", blockHash: "0xa7a1b440ed4ddf13758a6ef0a2c556dd2c271254e4cdc098802b07d585498bc8", transactionIndex: "13", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa5050ad86777b1bcd6383ad18aa4cff3892f31a5088386b43da1a3a98690f2930ed000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303335382c205b34335d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220cafd643cb4f5c5e5c8da3f7cc07485ad7d54c8fc257f9d0d2cbbe58906703686000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1910247", gasUsed: "133433", confirmations: "3920798"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x50ad86777b1bcd6383ad18aa4cff3892f31a5088386b43da1a3a98690f2930ed"}, {type: "string", name: "result", value: `[10358, [43]]`}, {type: "bytes", name: "proof", value: "0x1220cafd643cb4f5c5e5c8da3f7cc07485ad7d54c8fc257f9d0d2cbbe58906703686"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x50ad86777b1bcd6383ad18aa4cff3892f31a5088386b43da1a3a98690f2930ed", `[10358, [43]]`, "0x1220cafd643cb4f5c5e5c8da3f7cc07485ad7d54c8fc257f9d0d2cbbe58906703686", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1495540929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10358"}, {name: "BetID", type: "bytes32", value: "0x50ad86777b1bcd6383ad18aa4cff3892f31a5088386b43da1a3a98690f2930ed"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "43"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220cafd643cb4f5c5e5c8da3f7cc07485ad7d54c8fc257f9d0d2cbbe58906703686"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"31\" )", async function( ) {
		const txOriginal = {blockNumber: "3754276", timeStamp: "1495542012", hash: "0x65a486f264e2bf6c23c0adafbdb890708918b7f814d942067667df98ad187930", nonce: "5", blockHash: "0xe05e48d67e96772c4e6d649e585e2e93004eadb13e86cd053cc832b5560ff810", transactionIndex: "22", from: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd152000000000000000000000000000000000000000000000000000000000000001f", contractAddress: "", cumulativeGasUsed: "3024650", gasUsed: "229939", confirmations: "3920707"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "31"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "31", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1495542012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xf5ff73b7de3782921edc3d38c521c1fbeaffc900ecf9290ee363d0906e5aeb78"}, {name: "PlayerAddress", type: "address", value: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6"}, {name: "RewardValue", type: "uint256", value: "329999999999999999"}, {name: "ProfitValue", type: "uint256", value: "229999999999999999"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "31"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "22817747209212310" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3754287", timeStamp: "1495542176", hash: "0xfc937aaeb27cbe87cc9eddaf81538cfd2500286451855c7fe14275c4099214b4", nonce: "2714", blockHash: "0x1dabab6f7ec1b92490d1669bb0967a760df60465e06e490d4e87f65a9e106a7c", transactionIndex: "27", from: "0x5de92686587b10cd47e03b71f2e2350606fcaf14", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1656808", gasUsed: "214939", confirmations: "3920696"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "2"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1495542176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xe11cf05bf7d0f3b5aa3665833ee137d60d0f98431eb41f129cd8b36abfe98e76"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "RewardValue", type: "uint256", value: "9900000000000000000"}, {name: "ProfitValue", type: "uint256", value: "9800000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "2"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1583669827405182396" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xf5ff73b7de3782921edc3d38c521c1fbeaff... )", async function( ) {
		const txOriginal = {blockNumber: "3754287", timeStamp: "1495542176", hash: "0xd54aed9eebedf63034266167e40b7ffb8337451791fc4b55553c9153fd7a503d", nonce: "97528", blockHash: "0x1dabab6f7ec1b92490d1669bb0967a760df60465e06e490d4e87f65a9e106a7c", transactionIndex: "29", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50f5ff73b7de3782921edc3d38c521c1fbeaffc900ecf9290ee363d0906e5aeb78000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c5b31303335392c205b395d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212200d3f7ebdc0834b3154bd1c501e0449b92cd2f79b60e16a2de1701dd992088af4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1838579", gasUsed: "147301", confirmations: "3920696"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xf5ff73b7de3782921edc3d38c521c1fbeaffc900ecf9290ee363d0906e5aeb78"}, {type: "string", name: "result", value: `[10359, [9]]`}, {type: "bytes", name: "proof", value: "0x12200d3f7ebdc0834b3154bd1c501e0449b92cd2f79b60e16a2de1701dd992088af4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xf5ff73b7de3782921edc3d38c521c1fbeaffc900ecf9290ee363d0906e5aeb78", `[10359, [9]]`, "0x12200d3f7ebdc0834b3154bd1c501e0449b92cd2f79b60e16a2de1701dd992088af4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1495542176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10359"}, {name: "BetID", type: "bytes32", value: "0xf5ff73b7de3782921edc3d38c521c1fbeaffc900ecf9290ee363d0906e5aeb78"}, {name: "PlayerAddress", type: "address", value: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6"}, {name: "PlayerNumber", type: "uint256", value: "31"}, {name: "DiceResult", type: "uint256", value: "9"}, {name: "Value", type: "uint256", value: "329999999999999999"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12200d3f7ebdc0834b3154bd1c501e0449b92cd2f79b60e16a2de1701dd992088af4"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe11cf05bf7d0f3b5aa3665833ee137d60d0f... )", async function( ) {
		const txOriginal = {blockNumber: "3754290", timeStamp: "1495542228", hash: "0x9910c95c153a517eb5719e52e691a3d38f46476d8309b7b9e0426b995fab1e01", nonce: "97529", blockHash: "0x14beb89f9716afaa4c37191e1802b5540dccc7e91533ff1ffa1804df0605d700", transactionIndex: "36", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50e11cf05bf7d0f3b5aa3665833ee137d60d0f98431eb41f129cd8b36abfe98e76000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336302c205b36355d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122069daaa52b31a1f2ec37920ff30cc4e1d9c97d56ef301b9aae6b41b439650cf89000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3208658", gasUsed: "122633", confirmations: "3920693"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe11cf05bf7d0f3b5aa3665833ee137d60d0f98431eb41f129cd8b36abfe98e76"}, {type: "string", name: "result", value: `[10360, [65]]`}, {type: "bytes", name: "proof", value: "0x122069daaa52b31a1f2ec37920ff30cc4e1d9c97d56ef301b9aae6b41b439650cf89"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xe11cf05bf7d0f3b5aa3665833ee137d60d0f98431eb41f129cd8b36abfe98e76", `[10360, [65]]`, "0x122069daaa52b31a1f2ec37920ff30cc4e1d9c97d56ef301b9aae6b41b439650cf89", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1495542228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10360"}, {name: "BetID", type: "bytes32", value: "0xe11cf05bf7d0f3b5aa3665833ee137d60d0f98431eb41f129cd8b36abfe98e76"}, {name: "PlayerAddress", type: "address", value: "0x5de92686587b10cd47e03b71f2e2350606fcaf14"}, {name: "PlayerNumber", type: "uint256", value: "2"}, {name: "DiceResult", type: "uint256", value: "65"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x122069daaa52b31a1f2ec37920ff30cc4e1d9c97d56ef301b9aae6b41b439650cf89"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"39\" )", async function( ) {
		const txOriginal = {blockNumber: "3754338", timeStamp: "1495542924", hash: "0x4c71483eb39dbf02479e933ae691b811532c4ecd25d3e9d8f6825a9a85551c2a", nonce: "6", blockHash: "0x8c0ff43b03a08a9d1b05ed62e76fcd61ba2bd1f04fc6e47554b07be7fcc98aff", transactionIndex: "10", from: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "200000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000027", contractAddress: "", cumulativeGasUsed: "592533", gasUsed: "229939", confirmations: "3920645"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "39"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "39", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1495542924 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xa8d907100ab3d46d8e13b0936e6b4b5d509cf4c5c05e65205ce520625d68deef"}, {name: "PlayerAddress", type: "address", value: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6"}, {name: "RewardValue", type: "uint256", value: "521052631578947367"}, {name: "ProfitValue", type: "uint256", value: "321052631578947367"}, {name: "BetValue", type: "uint256", value: "200000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "39"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "22817747209212310" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa8d907100ab3d46d8e13b0936e6b4b5d509c... )", async function( ) {
		const txOriginal = {blockNumber: "3754343", timeStamp: "1495543023", hash: "0x38cd4fab0a0a89d8a88cb387dfb9fb6f1f2f6f4b1b8424154485973af497c64e", nonce: "97541", blockHash: "0xd6fb1275186445f44828435a008a0af6a9cb9b648e9de6fe9d38ce1a54e18722", transactionIndex: "19", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50a8d907100ab3d46d8e13b0936e6b4b5d509cf4c5c05e65205ce520625d68deef000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336312c205b34325d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220397868d3637b1b2ef1afb1422da3ccc8d6f17c40d8b34dce154d1c005f60078d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1344802", gasUsed: "122569", confirmations: "3920640"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa8d907100ab3d46d8e13b0936e6b4b5d509cf4c5c05e65205ce520625d68deef"}, {type: "string", name: "result", value: `[10361, [42]]`}, {type: "bytes", name: "proof", value: "0x1220397868d3637b1b2ef1afb1422da3ccc8d6f17c40d8b34dce154d1c005f60078d"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xa8d907100ab3d46d8e13b0936e6b4b5d509cf4c5c05e65205ce520625d68deef", `[10361, [42]]`, "0x1220397868d3637b1b2ef1afb1422da3ccc8d6f17c40d8b34dce154d1c005f60078d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1495543023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10361"}, {name: "BetID", type: "bytes32", value: "0xa8d907100ab3d46d8e13b0936e6b4b5d509cf4c5c05e65205ce520625d68deef"}, {name: "PlayerAddress", type: "address", value: "0x6ecd5bbd600931d2ffad11e2948939b284afd5d6"}, {name: "PlayerNumber", type: "uint256", value: "39"}, {name: "DiceResult", type: "uint256", value: "42"}, {name: "Value", type: "uint256", value: "200000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220397868d3637b1b2ef1afb1422da3ccc8d6f17c40d8b34dce154d1c005f60078d"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"81\" )", async function( ) {
		const txOriginal = {blockNumber: "3754486", timeStamp: "1495545363", hash: "0xa8bb90345942c0c49e04af0c0bcff82ed288e1f68f9d8e0b314981828ec86ca0", nonce: "1", blockHash: "0x88b41db9f6521ede2bbabeacf54ff541217fb6df049e378e85c7615a99b44cc3", transactionIndex: "53", from: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000051", contractAddress: "", cumulativeGasUsed: "2637986", gasUsed: "229939", confirmations: "3920497"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "81"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "81", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1495545363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x5d5c7099eaae6ac4b651e078ed1372c705e32f4e295ee188c3961046dcae0801"}, {name: "PlayerAddress", type: "address", value: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f"}, {name: "RewardValue", type: "uint256", value: "123750000000000000"}, {name: "ProfitValue", type: "uint256", value: "23750000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "81"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x5d5c7099eaae6ac4b651e078ed1372c705e3... )", async function( ) {
		const txOriginal = {blockNumber: "3754490", timeStamp: "1495545424", hash: "0x74be72075913d6202703a8730685b54b8611d9be3859377e6cddb7b84ed534cb", nonce: "97568", blockHash: "0xfe6da9556dc861de3210439c55481b63498908e4294e87980dc229f3982e9540", transactionIndex: "31", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa505d5c7099eaae6ac4b651e078ed1372c705e32f4e295ee188c3961046dcae0801000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336322c205b35375d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122083e51539e1650270b9c423092bdb6855ae642038f5ffc3d9bf01d390e2305824000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1251487", gasUsed: "133433", confirmations: "3920493"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x5d5c7099eaae6ac4b651e078ed1372c705e32f4e295ee188c3961046dcae0801"}, {type: "string", name: "result", value: `[10362, [57]]`}, {type: "bytes", name: "proof", value: "0x122083e51539e1650270b9c423092bdb6855ae642038f5ffc3d9bf01d390e2305824"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x5d5c7099eaae6ac4b651e078ed1372c705e32f4e295ee188c3961046dcae0801", `[10362, [57]]`, "0x122083e51539e1650270b9c423092bdb6855ae642038f5ffc3d9bf01d390e2305824", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1495545424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10362"}, {name: "BetID", type: "bytes32", value: "0x5d5c7099eaae6ac4b651e078ed1372c705e32f4e295ee188c3961046dcae0801"}, {name: "PlayerAddress", type: "address", value: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f"}, {name: "PlayerNumber", type: "uint256", value: "81"}, {name: "DiceResult", type: "uint256", value: "57"}, {name: "Value", type: "uint256", value: "123750000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x122083e51539e1650270b9c423092bdb6855ae642038f5ffc3d9bf01d390e2305824"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754499", timeStamp: "1495545611", hash: "0x0a05e957c7ab4ac9c3773e9a9f1683c0f10586ea35816350b0041fe402e2f30c", nonce: "0", blockHash: "0xc7a8f1a95e8c0cdaf34caa3924586daa764fd7b56720b59ecf3e19730feaf17d", transactionIndex: "28", from: "0x7078944645cd2291d1e4dde68ae4a8f19611fb6c", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1206209", gasUsed: "229939", confirmations: "3920484"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1495545611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xe3b2ffdcc3e909a6486d8e837cffb055b2ea2675370a01862ef4dabdb3a52276"}, {name: "PlayerAddress", type: "address", value: "0x7078944645cd2291d1e4dde68ae4a8f19611fb6c"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "17419442482702361" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe3b2ffdcc3e909a6486d8e837cffb055b2ea... )", async function( ) {
		const txOriginal = {blockNumber: "3754502", timeStamp: "1495545643", hash: "0x0e178130fc5dfb76413bc514adf8f5500b37d7bcbab51133dafc8a3cbf86ed82", nonce: "97571", blockHash: "0xcaf45a47faeb18ca496ffb567e8e4e84a29de242e177cfc55edd9fc1ccc8a4c0", transactionIndex: "27", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50e3b2ffdcc3e909a6486d8e837cffb055b2ea2675370a01862ef4dabdb3a52276000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336332c205b38325d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122000c10467ae2e5b6609785d35326ea31df6e08c8571e0ac573fdc1344d33a3e44000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1235936", gasUsed: "122569", confirmations: "3920481"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe3b2ffdcc3e909a6486d8e837cffb055b2ea2675370a01862ef4dabdb3a52276"}, {type: "string", name: "result", value: `[10363, [82]]`}, {type: "bytes", name: "proof", value: "0x122000c10467ae2e5b6609785d35326ea31df6e08c8571e0ac573fdc1344d33a3e44"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xe3b2ffdcc3e909a6486d8e837cffb055b2ea2675370a01862ef4dabdb3a52276", `[10363, [82]]`, "0x122000c10467ae2e5b6609785d35326ea31df6e08c8571e0ac573fdc1344d33a3e44", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1495545643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10363"}, {name: "BetID", type: "bytes32", value: "0xe3b2ffdcc3e909a6486d8e837cffb055b2ea2675370a01862ef4dabdb3a52276"}, {name: "PlayerAddress", type: "address", value: "0x7078944645cd2291d1e4dde68ae4a8f19611fb6c"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "82"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x122000c10467ae2e5b6609785d35326ea31df6e08c8571e0ac573fdc1344d33a3e44"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754557", timeStamp: "1495546502", hash: "0x65962a155d332a83681c13711d7e96b9e13b872156cd8c97df0be153121aa8a6", nonce: "22", blockHash: "0x727c12119f20a1236c86e9c0b03bafe3e26817e739e14fc3107ec9cc41374bcf", transactionIndex: "17", from: "0xcf4e8aa069a7336744cee5f50d32a5f7ba94b14d", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1324569", gasUsed: "229939", confirmations: "3920426"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1495546502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x09fd0ee6bccb10ac8d6e6375f877c9b04ca8c87fe06b6eda7f5c5034d53fc2e9"}, {name: "PlayerAddress", type: "address", value: "0xcf4e8aa069a7336744cee5f50d32a5f7ba94b14d"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500718590113900000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x09fd0ee6bccb10ac8d6e6375f877c9b04ca8... )", async function( ) {
		const txOriginal = {blockNumber: "3754562", timeStamp: "1495546529", hash: "0x4ece7c7beb65a86c72983a34914ffaa58a434b8a96bb08f9cb4457a7fd7a097a", nonce: "97582", blockHash: "0x497e10cf4600abf5a59b53a373ecd3373143863a4cb20c211eec75e29f5d0135", transactionIndex: "6", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa5009fd0ee6bccb10ac8d6e6375f877c9b04ca8c87fe06b6eda7f5c5034d53fc2e9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c5b31303336342c205b345d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212206b9a1c30a16a86af51b69de8614c408cfb989582c39fb7eb5ecfcbf5f4ffbbd2000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "655801", gasUsed: "132365", confirmations: "3920421"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x09fd0ee6bccb10ac8d6e6375f877c9b04ca8c87fe06b6eda7f5c5034d53fc2e9"}, {type: "string", name: "result", value: `[10364, [4]]`}, {type: "bytes", name: "proof", value: "0x12206b9a1c30a16a86af51b69de8614c408cfb989582c39fb7eb5ecfcbf5f4ffbbd2"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x09fd0ee6bccb10ac8d6e6375f877c9b04ca8c87fe06b6eda7f5c5034d53fc2e9", `[10364, [4]]`, "0x12206b9a1c30a16a86af51b69de8614c408cfb989582c39fb7eb5ecfcbf5f4ffbbd2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1495546529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10364"}, {name: "BetID", type: "bytes32", value: "0x09fd0ee6bccb10ac8d6e6375f877c9b04ca8c87fe06b6eda7f5c5034d53fc2e9"}, {name: "PlayerAddress", type: "address", value: "0xcf4e8aa069a7336744cee5f50d32a5f7ba94b14d"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "4"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12206b9a1c30a16a86af51b69de8614c408cfb989582c39fb7eb5ecfcbf5f4ffbbd2"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754619", timeStamp: "1495547692", hash: "0x5a770b5fb23e84541867e2bb745d90fe2d81997e7c8192999e34eaeca0355b0b", nonce: "0", blockHash: "0xcfa3018c5d78c62dfd01251b4656b51c312fd75e190ea42a6672feb8be4dae1b", transactionIndex: "56", from: "0x8dfb44050708b5fd8dd0c3af4b680838a42ed866", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "3105153", gasUsed: "229939", confirmations: "3920364"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1495547692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x564573228fffbad96c7ebd88570076a43447042b02878aeede4e7b77888606d4"}, {name: "PlayerAddress", type: "address", value: "0x8dfb44050708b5fd8dd0c3af4b680838a42ed866"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "406814030801467" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xadeb6a6d4ab0e770ef708739acec4328e234... )", async function( ) {
		const txOriginal = {blockNumber: "3754635", timeStamp: "1495547865", hash: "0xc77714dc6b8859a861fe20881c495617b4f467767d0ef0745cbb0550a3ce8845", nonce: "97596", blockHash: "0x9ec952c7554463b7ebac398c4249ed5be2da5e13b47009f925094f13d1531443", transactionIndex: "53", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x38bbfa50adeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c5b31303336362c205b335d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3761188", gasUsed: "235000", confirmations: "3920348"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xadeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9"}, {type: "string", name: "result", value: `[10366, [3]]`}, {type: "bytes", name: "proof", value: "0x122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754636", timeStamp: "1495547888", hash: "0x572fffe793321df7548abbbc20961007e02cb807443069bfaffa708fa8f79d61", nonce: "2", blockHash: "0x42b3ee2a8862a9754704fbf1016614602d17cb711943a044462d259f105e08df", transactionIndex: "50", from: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "500000000000000000", gas: "250000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "2009283", gasUsed: "214939", confirmations: "3920347"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1495547888 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xadeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9"}, {name: "PlayerAddress", type: "address", value: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f"}, {name: "RewardValue", type: "uint256", value: "990000000000000000"}, {name: "ProfitValue", type: "uint256", value: "490000000000000000"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x564573228fffbad96c7ebd88570076a43447... )", async function( ) {
		const txOriginal = {blockNumber: "3754674", timeStamp: "1495548424", hash: "0xf9556efafeb73cb10a1359ba1d31501dd56ac0cba1c789549f5710c8cf728bf5", nonce: "97604", blockHash: "0xb11fdff1e5910c21740dba3b93973400b936a69825d460bce0db093c893728b2", transactionIndex: "49", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50564573228fffbad96c7ebd88570076a43447042b02878aeede4e7b77888606d4000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336352c205b35375d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a7ffa62765bbecee3f94058c2a1f89fde53a44da7e05caca311220c83cfdea6b000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3318853", gasUsed: "137569", confirmations: "3920309"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x564573228fffbad96c7ebd88570076a43447042b02878aeede4e7b77888606d4"}, {type: "string", name: "result", value: `[10365, [57]]`}, {type: "bytes", name: "proof", value: "0x1220a7ffa62765bbecee3f94058c2a1f89fde53a44da7e05caca311220c83cfdea6b"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x564573228fffbad96c7ebd88570076a43447042b02878aeede4e7b77888606d4", `[10365, [57]]`, "0x1220a7ffa62765bbecee3f94058c2a1f89fde53a44da7e05caca311220c83cfdea6b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1495548424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10365"}, {name: "BetID", type: "bytes32", value: "0x564573228fffbad96c7ebd88570076a43447042b02878aeede4e7b77888606d4"}, {name: "PlayerAddress", type: "address", value: "0x8dfb44050708b5fd8dd0c3af4b680838a42ed866"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "57"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220a7ffa62765bbecee3f94058c2a1f89fde53a44da7e05caca311220c83cfdea6b"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"92\" )", async function( ) {
		const txOriginal = {blockNumber: "3754691", timeStamp: "1495548723", hash: "0x49837f4c450d932e35f3e8497f65b5a012c2f898929a7037c71076687b05a71c", nonce: "68", blockHash: "0xeed750db9a44dcdff96ff9cf4a78c9a2d4620678a6a79d93f30968bb325fa954", transactionIndex: "12", from: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "200000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd152000000000000000000000000000000000000000000000000000000000000005c", contractAddress: "", cumulativeGasUsed: "616412", gasUsed: "214939", confirmations: "3920292"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "92"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "92", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1495548723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x90ec14e6d55c33d5e4beca80a3dedfb32d089ea6b942e954e7989ca948147e84"}, {name: "PlayerAddress", type: "address", value: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4"}, {name: "RewardValue", type: "uint256", value: "217582417582417582"}, {name: "ProfitValue", type: "uint256", value: "17582417582417582"}, {name: "BetValue", type: "uint256", value: "200000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "92"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1948300000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x90ec14e6d55c33d5e4beca80a3dedfb32d08... )", async function( ) {
		const txOriginal = {blockNumber: "3754694", timeStamp: "1495548750", hash: "0x8cb8834cded436949a3ddc28530baabc99dc2359b5bb4a6161467f61c295e527", nonce: "97608", blockHash: "0x413b72aa08cccad747df2f5602a302b71c788aba74f5469216cb587de833586a", transactionIndex: "15", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa5090ec14e6d55c33d5e4beca80a3dedfb32d089ea6b942e954e7989ca948147e84000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336372c205b31325d5d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122019c418fddd3cea46434350385bb0eaea47f9c574f8b59344e85345816cb75588000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1620445", gasUsed: "148433", confirmations: "3920289"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x90ec14e6d55c33d5e4beca80a3dedfb32d089ea6b942e954e7989ca948147e84"}, {type: "string", name: "result", value: `[10367, [12]]`}, {type: "bytes", name: "proof", value: "0x122019c418fddd3cea46434350385bb0eaea47f9c574f8b59344e85345816cb75588"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x90ec14e6d55c33d5e4beca80a3dedfb32d089ea6b942e954e7989ca948147e84", `[10367, [12]]`, "0x122019c418fddd3cea46434350385bb0eaea47f9c574f8b59344e85345816cb75588", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1495548750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10367"}, {name: "BetID", type: "bytes32", value: "0x90ec14e6d55c33d5e4beca80a3dedfb32d089ea6b942e954e7989ca948147e84"}, {name: "PlayerAddress", type: "address", value: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4"}, {name: "PlayerNumber", type: "uint256", value: "92"}, {name: "DiceResult", type: "uint256", value: "12"}, {name: "Value", type: "uint256", value: "217582417582417582"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x122019c418fddd3cea46434350385bb0eaea47f9c574f8b59344e85345816cb75588"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"92\" )", async function( ) {
		const txOriginal = {blockNumber: "3754699", timeStamp: "1495548804", hash: "0x091ea37f9692f3794157069cfe89cdfafffb66cb75767a43f3f94f8fb63331c5", nonce: "69", blockHash: "0x7585effbccd2f4c7a8bd70ab4303ac22e02baaffa1df4bfdd9915d0bddfc8d64", transactionIndex: "24", from: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "300000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd152000000000000000000000000000000000000000000000000000000000000005c", contractAddress: "", cumulativeGasUsed: "1315351", gasUsed: "214939", confirmations: "3920284"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "92"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "92", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1495548804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xddd5ef2fae3ac284517907278132ccce132c935cca9d045c1adecc368242ffd0"}, {name: "PlayerAddress", type: "address", value: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4"}, {name: "RewardValue", type: "uint256", value: "326373626373626373"}, {name: "ProfitValue", type: "uint256", value: "26373626373626373"}, {name: "BetValue", type: "uint256", value: "300000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "92"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1948300000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xddd5ef2fae3ac284517907278132ccce132c... )", async function( ) {
		const txOriginal = {blockNumber: "3754701", timeStamp: "1495548884", hash: "0x596ec684a63823ed9e6d12bda6354828bbb7234b8c5bf217883a296de59d455e", nonce: "97611", blockHash: "0x77b7863125ffd91dc11819a8c212cf9213bde9e0340c852464c84cc20a663212", transactionIndex: "20", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50ddd5ef2fae3ac284517907278132ccce132c935cca9d045c1adecc368242ffd0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336382c205b38315d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220ce9c768554cb97454b97e493df5561ef62f39bd5d6ea82401b02b5b4f5bc342b000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1565052", gasUsed: "148433", confirmations: "3920282"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xddd5ef2fae3ac284517907278132ccce132c935cca9d045c1adecc368242ffd0"}, {type: "string", name: "result", value: `[10368, [81]]`}, {type: "bytes", name: "proof", value: "0x1220ce9c768554cb97454b97e493df5561ef62f39bd5d6ea82401b02b5b4f5bc342b"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xddd5ef2fae3ac284517907278132ccce132c935cca9d045c1adecc368242ffd0", `[10368, [81]]`, "0x1220ce9c768554cb97454b97e493df5561ef62f39bd5d6ea82401b02b5b4f5bc342b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1495548884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10368"}, {name: "BetID", type: "bytes32", value: "0xddd5ef2fae3ac284517907278132ccce132c935cca9d045c1adecc368242ffd0"}, {name: "PlayerAddress", type: "address", value: "0xb00e8ef510eead6e8c867fa9d485dd7a06ec99a4"}, {name: "PlayerNumber", type: "uint256", value: "92"}, {name: "DiceResult", type: "uint256", value: "81"}, {name: "Value", type: "uint256", value: "326373626373626373"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220ce9c768554cb97454b97e493df5561ef62f39bd5d6ea82401b02b5b4f5bc342b"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754768", timeStamp: "1495549862", hash: "0x3d9909502b8271bc65ed7a0ebe410094f34ee0d70a37eae1c17160c6092e0906", nonce: "17", blockHash: "0x10702d55b59e2a1d57ac60cc4554d4cea6a9232715d0bc02277a1096efdd982a", transactionIndex: "7", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "860588", gasUsed: "214939", confirmations: "3920215"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1495549862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xccdf0c180da254c16ad99b83f2aad9590d4708c4dac406d34d835851399d809a"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xccdf0c180da254c16ad99b83f2aad9590d47... )", async function( ) {
		const txOriginal = {blockNumber: "3754771", timeStamp: "1495549892", hash: "0x8e207dbe558afeec8d9141e1dc1e2d5a959346d4f30157edbb811aae4759a3c5", nonce: "97620", blockHash: "0x441db345cc3646d76b37f7c97dfab55aff95b7e57378f519e509e6dce7d0c487", transactionIndex: "13", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50ccdf0c180da254c16ad99b83f2aad9590d4708c4dac406d34d835851399d809a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303336392c205b33305d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220e6466b3a5bc5d5bde1d615910f77830d0f585b5c970a3cdee1db7d4056b4651a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1192020", gasUsed: "148433", confirmations: "3920212"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xccdf0c180da254c16ad99b83f2aad9590d4708c4dac406d34d835851399d809a"}, {type: "string", name: "result", value: `[10369, [30]]`}, {type: "bytes", name: "proof", value: "0x1220e6466b3a5bc5d5bde1d615910f77830d0f585b5c970a3cdee1db7d4056b4651a"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xccdf0c180da254c16ad99b83f2aad9590d4708c4dac406d34d835851399d809a", `[10369, [30]]`, "0x1220e6466b3a5bc5d5bde1d615910f77830d0f585b5c970a3cdee1db7d4056b4651a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1495549892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10369"}, {name: "BetID", type: "bytes32", value: "0xccdf0c180da254c16ad99b83f2aad9590d4708c4dac406d34d835851399d809a"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "30"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220e6466b3a5bc5d5bde1d615910f77830d0f585b5c970a3cdee1db7d4056b4651a"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754793", timeStamp: "1495550221", hash: "0x3a4e571f19f92cab645d612ea334fbe541ebac2665c349c4ba0bba9d2ba63ffa", nonce: "18", blockHash: "0xea07c9179cf6958a274d242e0b8c7a7737f8c82b6635a5a6b406f2bc9facc4ac", transactionIndex: "20", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "937180", gasUsed: "214939", confirmations: "3920190"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1495550221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xd223ef8085820d672b3110f9255b787b843eec1500db020e33487240bd0dd656"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754796", timeStamp: "1495550307", hash: "0x5ef76ddf1dfefd08deedeba604228837e856ab80bf108431ac5f3478732d3891", nonce: "336", blockHash: "0xf6c0db3430f2288b7a14baa5402bd4b9027fa479736fd764a2161af7ff879b07", transactionIndex: "24", from: "0x70c4bcc07a2bfc0cff3c7099b4a9e0ebca181c02", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1926961", gasUsed: "214939", confirmations: "3920187"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1495550307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xd44183e04d89c9daf05467fd0f958d73edb2aeee2766300f6ab526633855cb9d"}, {name: "PlayerAddress", type: "address", value: "0x70c4bcc07a2bfc0cff3c7099b4a9e0ebca181c02"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "456157953339312810" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd223ef8085820d672b3110f9255b787b843e... )", async function( ) {
		const txOriginal = {blockNumber: "3754796", timeStamp: "1495550307", hash: "0x76c61d0cafd26d07aa87538246697d5e77742fb80d8607dd18a8ba9feb5740e4", nonce: "97625", blockHash: "0xf6c0db3430f2288b7a14baa5402bd4b9027fa479736fd764a2161af7ff879b07", transactionIndex: "27", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50d223ef8085820d672b3110f9255b787b843eec1500db020e33487240bd0dd656000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337302c205b32325d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212203ea0ead192a3bd2ae49319e7a370dfd033391b24c17adbc28351895c74dd2cc0000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2117330", gasUsed: "148369", confirmations: "3920187"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd223ef8085820d672b3110f9255b787b843eec1500db020e33487240bd0dd656"}, {type: "string", name: "result", value: `[10370, [22]]`}, {type: "bytes", name: "proof", value: "0x12203ea0ead192a3bd2ae49319e7a370dfd033391b24c17adbc28351895c74dd2cc0"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xd223ef8085820d672b3110f9255b787b843eec1500db020e33487240bd0dd656", `[10370, [22]]`, "0x12203ea0ead192a3bd2ae49319e7a370dfd033391b24c17adbc28351895c74dd2cc0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1495550307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10370"}, {name: "BetID", type: "bytes32", value: "0xd223ef8085820d672b3110f9255b787b843eec1500db020e33487240bd0dd656"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "22"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12203ea0ead192a3bd2ae49319e7a370dfd033391b24c17adbc28351895c74dd2cc0"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd44183e04d89c9daf05467fd0f958d73edb2... )", async function( ) {
		const txOriginal = {blockNumber: "3754799", timeStamp: "1495550382", hash: "0xa4c38b91b5c2af1fedb4f62c4414329cb9ae6e43037f322798b39211a88f62d3", nonce: "97626", blockHash: "0xa0b6b71df96f8bb42e9a92ddde6c8f103e51e3820fb038f424f543fd6c1cfecd", transactionIndex: "20", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50d44183e04d89c9daf05467fd0f958d73edb2aeee2766300f6ab526633855cb9d000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337312c205b37385d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212207d132ad5ac2f2e314ae28ca821ea1a26a163a2232a622987ec8b9f011f6e41b5000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "819310", gasUsed: "137633", confirmations: "3920184"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd44183e04d89c9daf05467fd0f958d73edb2aeee2766300f6ab526633855cb9d"}, {type: "string", name: "result", value: `[10371, [78]]`}, {type: "bytes", name: "proof", value: "0x12207d132ad5ac2f2e314ae28ca821ea1a26a163a2232a622987ec8b9f011f6e41b5"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xd44183e04d89c9daf05467fd0f958d73edb2aeee2766300f6ab526633855cb9d", `[10371, [78]]`, "0x12207d132ad5ac2f2e314ae28ca821ea1a26a163a2232a622987ec8b9f011f6e41b5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1495550382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10371"}, {name: "BetID", type: "bytes32", value: "0xd44183e04d89c9daf05467fd0f958d73edb2aeee2766300f6ab526633855cb9d"}, {name: "PlayerAddress", type: "address", value: "0x70c4bcc07a2bfc0cff3c7099b4a9e0ebca181c02"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "78"}, {name: "Value", type: "uint256", value: "100000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x12207d132ad5ac2f2e314ae28ca821ea1a26a163a2232a622987ec8b9f011f6e41b5"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754801", timeStamp: "1495550407", hash: "0x557fc12401346904f13e75a2e291140d710fd92f1776a1657f0bbcc4fd711717", nonce: "19", blockHash: "0x123cd49d4d0edc6c76c8bb6669a4682343964696df9d6624c5d4d5d4337a3982", transactionIndex: "8", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "1000000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "432804", gasUsed: "214939", confirmations: "3920182"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1495550407 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xda0964ab5ca1c4b877f57b75843305c45792ea7e7fbd90eaeae09f3eb4fb4210"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "1980000000000000000"}, {name: "ProfitValue", type: "uint256", value: "980000000000000000"}, {name: "BetValue", type: "uint256", value: "1000000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xda0964ab5ca1c4b877f57b75843305c45792... )", async function( ) {
		const txOriginal = {blockNumber: "3754804", timeStamp: "1495550445", hash: "0x0912e92b376e4344896e7a277c838759ca5dc9e4777f20ef165f3585408fd647", nonce: "97627", blockHash: "0xc71e3817d02f2df58f0caffc11d071b3942332dd0b98b524935ca8f60ad39106", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50da0964ab5ca1c4b877f57b75843305c45792ea7e7fbd90eaeae09f3eb4fb4210000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337322c205b37325d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220cb994729fa2fbd9658f430809aae9eaf1f7c60da0ba7ba9719f72581a9991e04000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "445475", gasUsed: "137633", confirmations: "3920179"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xda0964ab5ca1c4b877f57b75843305c45792ea7e7fbd90eaeae09f3eb4fb4210"}, {type: "string", name: "result", value: `[10372, [72]]`}, {type: "bytes", name: "proof", value: "0x1220cb994729fa2fbd9658f430809aae9eaf1f7c60da0ba7ba9719f72581a9991e04"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xda0964ab5ca1c4b877f57b75843305c45792ea7e7fbd90eaeae09f3eb4fb4210", `[10372, [72]]`, "0x1220cb994729fa2fbd9658f430809aae9eaf1f7c60da0ba7ba9719f72581a9991e04", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1495550445 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10372"}, {name: "BetID", type: "bytes32", value: "0xda0964ab5ca1c4b877f57b75843305c45792ea7e7fbd90eaeae09f3eb4fb4210"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "72"}, {name: "Value", type: "uint256", value: "1000000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [0]}}, {name: "Proof", type: "bytes", value: "0x1220cb994729fa2fbd9658f430809aae9eaf1f7c60da0ba7ba9719f72581a9991e04"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754823", timeStamp: "1495550691", hash: "0xd5e5f3010d5ba8f4342d05e909af255ccb95a34ffe3a28dd9d41252750952bf5", nonce: "20", blockHash: "0x10a240ca00eedd7c4dc6fb8dba83fb615d2037d68a8e9e6023200dcdcf374b63", transactionIndex: "46", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "2912321", gasUsed: "214939", confirmations: "3920160"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1495550691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xe0126d373174ad12c58aa3fb33f9011f4158d998c07d037d0f2384a38bcdc1b8"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe0126d373174ad12c58aa3fb33f9011f4158... )", async function( ) {
		const txOriginal = {blockNumber: "3754826", timeStamp: "1495550710", hash: "0xe254505c49e4c71ed5c604987e5c9d7d369d91fc509044af0ca038ab5f2ccec0", nonce: "97633", blockHash: "0xea59e063cbc09363d9bf35e55a2c537f27d37b0655c68a115c41f500a96be326", transactionIndex: "28", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50e0126d373174ad12c58aa3fb33f9011f4158d998c07d037d0f2384a38bcdc1b8000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337332c205b34385d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a8a0f1ced48680cb4233723194ff8b2b2640df826ecf9aca886f4b787488c65f000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1111990", gasUsed: "148433", confirmations: "3920157"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe0126d373174ad12c58aa3fb33f9011f4158d998c07d037d0f2384a38bcdc1b8"}, {type: "string", name: "result", value: `[10373, [48]]`}, {type: "bytes", name: "proof", value: "0x1220a8a0f1ced48680cb4233723194ff8b2b2640df826ecf9aca886f4b787488c65f"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xe0126d373174ad12c58aa3fb33f9011f4158d998c07d037d0f2384a38bcdc1b8", `[10373, [48]]`, "0x1220a8a0f1ced48680cb4233723194ff8b2b2640df826ecf9aca886f4b787488c65f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1495550710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10373"}, {name: "BetID", type: "bytes32", value: "0xe0126d373174ad12c58aa3fb33f9011f4158d998c07d037d0f2384a38bcdc1b8"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "48"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220a8a0f1ced48680cb4233723194ff8b2b2640df826ecf9aca886f4b787488c65f"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754861", timeStamp: "1495551385", hash: "0xe71ae31f1e4a9b0e42702769f5fbbb68a4cc907d204ecd3baefb0795b03e0b9c", nonce: "21", blockHash: "0x400709d6d77d0b45474340c6c257547782cc1d3e48b30064f9d9195ce6bf641a", transactionIndex: "36", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "3300527", gasUsed: "214939", confirmations: "3920122"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1495551385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x4a08d5fbc61015eb3f2a3b70ec07c39cd5902f2c48268241a702593324bef499"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4a08d5fbc61015eb3f2a3b70ec07c39cd590... )", async function( ) {
		const txOriginal = {blockNumber: "3754866", timeStamp: "1495551417", hash: "0xdd9685240ddc6454921424ba3c466319811ed3b0a6306a7d6d9034725c108adf", nonce: "97640", blockHash: "0xc76432b4fede08fcca0190b3a16ad5f93ec7079dadf84d7bca9da03ff98d7f20", transactionIndex: "20", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa504a08d5fbc61015eb3f2a3b70ec07c39cd5902f2c48268241a702593324bef499000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337342c205b33335d5d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220445deebaba67159207d10fdf9a71c39f147224c054216971c51fa49fdc975f45000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1939574", gasUsed: "148433", confirmations: "3920117"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4a08d5fbc61015eb3f2a3b70ec07c39cd5902f2c48268241a702593324bef499"}, {type: "string", name: "result", value: `[10374, [33]]`}, {type: "bytes", name: "proof", value: "0x1220445deebaba67159207d10fdf9a71c39f147224c054216971c51fa49fdc975f45"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4a08d5fbc61015eb3f2a3b70ec07c39cd5902f2c48268241a702593324bef499", `[10374, [33]]`, "0x1220445deebaba67159207d10fdf9a71c39f147224c054216971c51fa49fdc975f45", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1495551417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10374"}, {name: "BetID", type: "bytes32", value: "0x4a08d5fbc61015eb3f2a3b70ec07c39cd5902f2c48268241a702593324bef499"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "33"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x1220445deebaba67159207d10fdf9a71c39f147224c054216971c51fa49fdc975f45"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754878", timeStamp: "1495551761", hash: "0xe6cae3bfb9cf9c5e560d74318deddd0ba9d696f35607742b0eb0cb181b76c6b7", nonce: "26", blockHash: "0x51fd511d431a4bdd44859ae960629675ed1bae4d0cacd27eecbe71653f0d442b", transactionIndex: "20", from: "0xc4b3f4622c7c7526f9721d8687c3ce07a99d5624", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1800536", gasUsed: "214939", confirmations: "3920105"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1495551761 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0x5073b2f6f5c85514f589d97727cabe39b874032f294f76e426eee8f685bdc3f8"}, {name: "PlayerAddress", type: "address", value: "0xc4b3f4622c7c7526f9721d8687c3ce07a99d5624"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "1009263557688925462" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x5073b2f6f5c85514f589d97727cabe39b874... )", async function( ) {
		const txOriginal = {blockNumber: "3754880", timeStamp: "1495551782", hash: "0xb0775a8a7d35da31f8df7575785b3c9b3eba35e3f8accd98bd8d8ea8d0417c7d", nonce: "97641", blockHash: "0xe41983067bac02eb3ff722b92065ad227622a6aaa0d7e48aaac7072be418b9e3", transactionIndex: "34", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa505073b2f6f5c85514f589d97727cabe39b874032f294f76e426eee8f685bdc3f8000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337352c205b32345d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212201fd57063a26cea10b2b36f8c9e7577da94575d0d5291f1cb31b5d565e8c3bfde000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1623297", gasUsed: "148433", confirmations: "3920103"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x5073b2f6f5c85514f589d97727cabe39b874032f294f76e426eee8f685bdc3f8"}, {type: "string", name: "result", value: `[10375, [24]]`}, {type: "bytes", name: "proof", value: "0x12201fd57063a26cea10b2b36f8c9e7577da94575d0d5291f1cb31b5d565e8c3bfde"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x5073b2f6f5c85514f589d97727cabe39b874032f294f76e426eee8f685bdc3f8", `[10375, [24]]`, "0x12201fd57063a26cea10b2b36f8c9e7577da94575d0d5291f1cb31b5d565e8c3bfde", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1495551782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10375"}, {name: "BetID", type: "bytes32", value: "0x5073b2f6f5c85514f589d97727cabe39b874032f294f76e426eee8f685bdc3f8"}, {name: "PlayerAddress", type: "address", value: "0xc4b3f4622c7c7526f9721d8687c3ce07a99d5624"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "24"}, {name: "Value", type: "uint256", value: "198000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12201fd57063a26cea10b2b36f8c9e7577da94575d0d5291f1cb31b5d565e8c3bfde"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754913", timeStamp: "1495552206", hash: "0x97850d14e5171ce41dbcf306afa4307d6e1a4a56efe9cc9e0f84c49cc0c5cba4", nonce: "22", blockHash: "0x7c7761f983472fa738c4c3b2e2f26daee34ff6d56f534566e7b4d5540daf0f84", transactionIndex: "14", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "500000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "2159874", gasUsed: "214939", confirmations: "3920070"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1495552206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xb736017902dc1e080b74299ad266ba8f6c29463ba5be4dc28ec5315fdde3851b"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "990000000000000000"}, {name: "ProfitValue", type: "uint256", value: "490000000000000000"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xb736017902dc1e080b74299ad266ba8f6c29... )", async function( ) {
		const txOriginal = {blockNumber: "3754916", timeStamp: "1495552338", hash: "0x0fca39575f6857c4edf2e3feebae92a3dbbd9d6dea565455a47def73bee57b0b", nonce: "97643", blockHash: "0xd471be3b1534d8709cafb97c9ce211c25508549a77d953bebee13709e3ca9899", transactionIndex: "45", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50b736017902dc1e080b74299ad266ba8f6c29463ba5be4dc28ec5315fdde3851b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d5b31303337362c205b34325d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212202f23dbb3410a8c56341d819ade318053e1c77455e0581f38961b2747cb8174f4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2861717", gasUsed: "148433", confirmations: "3920067"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xb736017902dc1e080b74299ad266ba8f6c29463ba5be4dc28ec5315fdde3851b"}, {type: "string", name: "result", value: `[10376, [42]]`}, {type: "bytes", name: "proof", value: "0x12202f23dbb3410a8c56341d819ade318053e1c77455e0581f38961b2747cb8174f4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xb736017902dc1e080b74299ad266ba8f6c29463ba5be4dc28ec5315fdde3851b", `[10376, [42]]`, "0x12202f23dbb3410a8c56341d819ade318053e1c77455e0581f38961b2747cb8174f4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1495552338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10376"}, {name: "BetID", type: "bytes32", value: "0xb736017902dc1e080b74299ad266ba8f6c29463ba5be4dc28ec5315fdde3851b"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "42"}, {name: "Value", type: "uint256", value: "990000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x12202f23dbb3410a8c56341d819ade318053e1c77455e0581f38961b2747cb8174f4"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xadeb6a6d4ab0e770ef708739acec4328e234... )", async function( ) {
		const txOriginal = {blockNumber: "3754925", timeStamp: "1495552587", hash: "0x635278afa3d906566b3c0177eb51c000d2b8f023d78311c688e9fc78ce84f49d", nonce: "97644", blockHash: "0x90f8604e384953a322c7da6bd9ec60e61f214b72295883b1f2a4573fe4646f5c", transactionIndex: "57", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "0", gas: "235000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x38bbfa50adeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c5b31303336362c205b335d5d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4117812", gasUsed: "132365", confirmations: "3920058"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xadeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9"}, {type: "string", name: "result", value: `[10366, [3]]`}, {type: "bytes", name: "proof", value: "0x122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xadeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9", `[10366, [3]]`, "0x122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1495552587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "ResultSerialNumber", type: "uint256"}, {indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: false, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "Proof", type: "bytes"}], name: "LogResult", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogResult", events: [{name: "ResultSerialNumber", type: "uint256", value: "10366"}, {name: "BetID", type: "bytes32", value: "0xadeb6a6d4ab0e770ef708739acec4328e2349c27148f5b20dd7b47a5b89ec5f9"}, {name: "PlayerAddress", type: "address", value: "0x5acfaf158a56bdb6e628517c1bb088ea7097144f"}, {name: "PlayerNumber", type: "uint256", value: "51"}, {name: "DiceResult", type: "uint256", value: "3"}, {name: "Value", type: "uint256", value: "990000000000000000"}, {name: "Status", type: "int256", value: {s: 1, e: 0, c: [1]}}, {name: "Proof", type: "bytes", value: "0x122031a2ea6c517db8c4792676a36e403a81c340f8a1af61974713e7b294fb0ad5d6"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754926", timeStamp: "1495552592", hash: "0xa194a5526c4138c79750ca5d38246ace74bb420ff866d3522c24e8e6b8ba14d2", nonce: "0", blockHash: "0xa9fb69514222679a8f8ab3cce0c2ccf25415a1ad9a232651ddd42d6306afa25c", transactionIndex: "18", from: "0x5c8c5096c3e7ce3a86413ecf650bdb0c4d977287", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1833400", gasUsed: "229939", confirmations: "3920057"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1495552592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xc8972370838b9b811874bef0d1e59a1170ebe6b830e89b234c783e60450a2d89"}, {name: "PlayerAddress", type: "address", value: "0x5c8c5096c3e7ce3a86413ecf650bdb0c4d977287"}, {name: "RewardValue", type: "uint256", value: "198000000000000000"}, {name: "ProfitValue", type: "uint256", value: "98000000000000000"}, {name: "BetValue", type: "uint256", value: "100000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "126131138399091332" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: playerRollDice( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "3754930", timeStamp: "1495552686", hash: "0x6242c7b07c315e6a2e33827fe62cfd2c366955b3cacafe4aac307e166bb68717", nonce: "23", blockHash: "0xb61eadacf3bdb585365dfd08d6d293d35e3126fc5d8297fee16eac00cbc20a9f", transactionIndex: "83", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e", value: "500000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xdc6dd1520000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "3946424", gasUsed: "214939", confirmations: "3920053"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "playerRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playerRollDice(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1495552686 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "bytes32"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "RewardValue", type: "uint256"}, {indexed: false, name: "ProfitValue", type: "uint256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "PlayerNumber", type: "uint256"}], name: "LogBet", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBet", events: [{name: "BetID", type: "bytes32", value: "0xa9f5e49c486ead68f39b30c5e7e091800d899d1ada316c4ac192da4d884381db"}, {name: "PlayerAddress", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}, {name: "RewardValue", type: "uint256", value: "990000000000000000"}, {name: "ProfitValue", type: "uint256", value: "490000000000000000"}, {name: "BetValue", type: "uint256", value: "500000000000000000"}, {name: "PlayerNumber", type: "uint256", value: "51"}], address: "0xece701c76bd00d1c3f96410a0c69ea8dfcf5f34e"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "787096774193548388" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
