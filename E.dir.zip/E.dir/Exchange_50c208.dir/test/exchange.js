const Exchange = artifacts.require( "./Exchange.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Exchange" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2a0c0DBEcC7E4D658f48E01e3fA353F44050c208", "0x33DAeDaBAb9085bd1a94460a652e7FffF592Dfe3", "0x034767f3C519f361c5ECF46EbfC08981C629D381", "0x9C536B0E7aFB8a545b5A506244c95a92d9f8C3D9", "0xA6CE6213db97cDf3A37201Fd5bD961c9725066D8", "0x744d70FDBE2Ba4CF95131626614a1763DF805B9E", "0x4532357AaAA23398E5fdb6a5F6069d2CDFA520dF", "0x992CE14aa2f6a56F57f10A6cBc33feA71088a751", "0x6F642280FA98C0ddFC6fB6f078B91B89DF3914Ca", "0x74719D7F5C54f747c6F8c18ce948D641C90a037b", "0x31F2CFE8bCb177f4dC4A727BcBE537b6A039a7eE", "0xC01838dCA02cC6129B68182d0e6FaD16B7D9BdfC", "0x0Baf598c6e07d199fcC62BCA2dBCE243325F3fEE"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "lastActiveTransaction", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "withdrawn", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "admins", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "tokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feeAccount", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "invalidOrder", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "traded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "inactivityReleasePeriod", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "orderFills", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "token", type: "address"}, {name: "user", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "SetOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenBuy", type: "address"}, {indexed: false, name: "amountBuy", type: "uint256"}, {indexed: false, name: "tokenSell", type: "address"}, {indexed: false, name: "amountSell", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "v", type: "uint8"}, {indexed: false, name: "r", type: "bytes32"}, {indexed: false, name: "s", type: "bytes32"}], name: "Order", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenBuy", type: "address"}, {indexed: false, name: "amountBuy", type: "uint256"}, {indexed: false, name: "tokenSell", type: "address"}, {indexed: false, name: "amountSell", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "v", type: "uint8"}, {indexed: false, name: "r", type: "bytes32"}, {indexed: false, name: "s", type: "bytes32"}], name: "Cancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenBuy", type: "address"}, {indexed: false, name: "amountBuy", type: "uint256"}, {indexed: false, name: "tokenSell", type: "address"}, {indexed: false, name: "amountSell", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SetOwner(address,address)", "Order(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)", "Cancel(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)", "Trade(address,uint256,address,uint256,address,address)", "Deposit(address,address,uint256,uint256)", "Withdraw(address,address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcbf985117192c8f614a58aaf97226bb80a754772f5f6edf06f87c675f2e6c663", "0x91daf02b6d1454acd74c097a67e389a9d9371da3ff51366947022dc36748ce4d", "0x1e0b760c386003e9cb9bcf4fcf3997886042859d9b6ed6320e804597fcdb28b0", "0x6effdda786735d5033bfad5f53e5131abcced9e52be6c507b62d639685fbed6d", "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7", "0xf341246adaac6f497bc2a656f546ab9e182111d630394f0c57c710a59a2cb567"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4317141 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4317964 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "feeAccount_", value: 4}], name: "Exchange", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "lastActiveTransaction", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastActiveTransaction(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "withdrawn", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawn(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "admins", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "admins(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeAccount", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeAccount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "invalidOrder", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "invalidOrder(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "traded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "traded(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "inactivityReleasePeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "inactivityReleasePeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "orderFills", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "orderFills(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "token", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Exchange", function( accounts ) {

	it( "TEST: Exchange( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4317141", timeStamp: "1506545029", hash: "0x24b99bebf8a908be3d09bb8101446350cc7d1bea467b5242352c9c53e85c5283", nonce: "693", blockHash: "0x273ed0c29cd1ce05fb4317406a2ca8248e7c369f56f75934b1a84eb4975b5182", transactionIndex: "110", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: 0, value: "0", gas: "2500000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x459659a4000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381", contractAddress: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", cumulativeGasUsed: "5608706", gasUsed: "2070494", confirmations: "3391616"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "feeAccount_", value: addressList[4]}], name: "Exchange", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Exchange.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1506545029 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Exchange.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setAdmin( addressList[5], true )", async function( ) {
		const txOriginal = {blockNumber: "4317164", timeStamp: "1506545741", hash: "0xbea9881619d8326f0a5428469f511f7bcb43d9f17f0ef3a37dd4f2d04cad6efa", nonce: "694", blockHash: "0xa7922d6ee6a05e88ec608b17755b8c099bac95813e425bb403b80ceffeb9a85f", transactionIndex: "42", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "2500000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x4b0bddd20000000000000000000000009c536b0e7afb8a545b5a506244c95a92d9f8c3d90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1513372", gasUsed: "44032", confirmations: "3391593"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin", value: addressList[5]}, {type: "bool", name: "isAdmin", value: true}], name: "setAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdmin(address,bool)" ]( addressList[5], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1506545741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344029521624394522436" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setAdmin( addressList[6], true )", async function( ) {
		const txOriginal = {blockNumber: "4317183", timeStamp: "1506546315", hash: "0x9099da33dfa2faba850713fd943282d315ac0f77a2e07a769de12e5d661f5f0b", nonce: "695", blockHash: "0x731fdc0f2101cde5853f2be5d7195be82ae843dfe88d634f27939fee0bdb1583", transactionIndex: "38", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "2500000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x4b0bddd2000000000000000000000000a6ce6213db97cdf3a37201fd5bd961c9725066d80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1952533", gasUsed: "44032", confirmations: "3391574"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin", value: addressList[6]}, {type: "bool", name: "isAdmin", value: true}], name: "setAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdmin(address,bool)" ]( addressList[6], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1506546315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344029521624394522436" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[7], \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4317305", timeStamp: "1506550072", hash: "0x871ed6388e87c39965c3b59a207eca53e485f6c98dbd1fe6863110d4253e7f17", nonce: "4", blockHash: "0x9278443414405b99f45a29f136c3367ec1addbfb24901a6580bd0e39d750f476", transactionIndex: "79", from: "0x034767f3c519f361c5ecf46ebfc08981c629d381", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "90000", gasPrice: "4000000000", isError: "1", txreceipt_status: "", input: "0x338b5dea000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e0000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "6711468", gasUsed: "90000", confirmations: "3391452"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "10000000000000000000"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "9632123621621509" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344029521624394522436" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317324", timeStamp: "1506550572", hash: "0x52897291dba0a7b255ee7a27a8ca44a9e8d6919ca14f917616444bf974c48897", nonce: "5", blockHash: "0xaf26c50522c676569f71b790d87204e49b826e771eed04321f0b6952250bf742", transactionIndex: "62", from: "0x034767f3c519f361c5ecf46ebfc08981c629d381", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "4500000000000000000", gas: "90000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "2462867", gasUsed: "64725", confirmations: "3391433"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "4500000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1506550572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "4500000000000000000"}, {name: "balance", type: "uint256", value: "4500000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "9632123621621509" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344029521624394522436" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setAdmin( addressList[8], true )", async function( ) {
		const txOriginal = {blockNumber: "4317352", timeStamp: "1506551295", hash: "0xf5e9c39ef2ee606c08276cfd48dc81331b5d44e772f2c270a67b2809706ec422", nonce: "699", blockHash: "0x3a804c6f52af298397cd708d51dc9f9b7e48ccb221801a1b61701e4728b5bc16", transactionIndex: "219", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x4b0bddd20000000000000000000000004532357aaaa23398e5fdb6a5f6069d2cdfa520df0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6352386", gasUsed: "44032", confirmations: "3391405"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin", value: addressList[8]}, {type: "bool", name: "isAdmin", value: true}], name: "setAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdmin(address,bool)" ]( addressList[8], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1506551295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344429521624394522436" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setAdmin( addressList[9], true )", async function( ) {
		const txOriginal = {blockNumber: "4317355", timeStamp: "1506551334", hash: "0x4c949ffa3a88ee088e2dee3d2b7dbd0834e40ffde2762e943a0e2f5dcfbc6181", nonce: "700", blockHash: "0x36e7ebb4cdca17f813ee8a18d4f4e5e80e0adfe40ea8522d06803411ceaeb260", transactionIndex: "27", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x4b0bddd2000000000000000000000000992ce14aa2f6a56f57f10a6cbc33fea71088a7510000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "679011", gasUsed: "44032", confirmations: "3391402"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin", value: addressList[9]}, {type: "bool", name: "isAdmin", value: true}], name: "setAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdmin(address,bool)" ]( addressList[9], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1506551334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51344429521624394522436" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setAdmin( addressList[10], true )", async function( ) {
		const txOriginal = {blockNumber: "4317358", timeStamp: "1506551464", hash: "0x25ce20665239c572d525ee9b7c43f7a1c2ffe5d5a62f8286a9c86cfea570d4b9", nonce: "701", blockHash: "0xae70470d393722a25688d9afb75a29ccac621932a50622f5a19a8e30e4accd29", transactionIndex: "52", from: "0x33daedabab9085bd1a94460a652e7ffff592dfe3", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "13000000000", isError: "0", txreceipt_status: "", input: "0x4b0bddd20000000000000000000000006f642280fa98c0ddfc6fb6f078b91b89df3914ca0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1880314", gasUsed: "44032", confirmations: "3391399"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin", value: addressList[10]}, {type: "bool", name: "isAdmin", value: true}], name: "setAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdmin(address,bool)" ]( addressList[10], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1506551464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "184125236000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51337826221624394522433" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[7], \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4317374", timeStamp: "1506551989", hash: "0xfe538a10a33f3ab3726e225c7fb8c0ceff64f372e292e3238d7efe447fe8a706", nonce: "8", blockHash: "0xc78a8edaba0838831e673ccea15bb1156ea0fac5d05b54018118f9945d28247e", transactionIndex: "107", from: "0x034767f3c519f361c5ecf46ebfc08981c629d381", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x338b5dea000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e0000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "3620182", gasUsed: "124891", confirmations: "3391383"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "10000000000000000000"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[7], "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1506551989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "balance", type: "uint256", value: "10000000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "9632123621621509" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51337423847007297752127" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[0], \"4500000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "4317380", timeStamp: "1506552223", hash: "0xe52e9c569fe659556d1e56d8cca2084db0b452cd889f55ec3b4e2f3af61faa57", nonce: "1", blockHash: "0x14799d55593c3335c85f49540a9ea6922f013972881c53dec51e4bab37a1801a", transactionIndex: "45", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e73362871420000000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d38100000000000000000000000000000000000000000000000000000000000009b8000000000000000000000000000000000000000000000000000000000000001c2ff9e42705028af2df3a711b22183a181529f21117655b0028b27e31698322705db4fae295ee9d710e1bf54aca70744a6ebaf5c9d8a669bd714feffd149c0b110000000000000000000000000000000000000000000000000000650e124ef1c7", contractAddress: "", cumulativeGasUsed: "2374929", gasUsed: "82749", confirmations: "3391377"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[0]}, {type: "uint256", name: "amount", value: "4500000000000000000"}, {type: "address", name: "user", value: addressList[4]}, {type: "uint256", name: "nonce", value: "2488"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x2ff9e42705028af2df3a711b22183a181529f21117655b0028b27e3169832270"}, {type: "bytes32", name: "s", value: "0x5db4fae295ee9d710e1bf54aca70744a6ebaf5c9d8a669bd714feffd149c0b11"}, {type: "uint256", name: "feeWithdrawal", value: "111111111111111"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[0], "4500000000000000000", addressList[4], "2488", "28", "0x2ff9e42705028af2df3a711b22183a181529f21117655b0028b27e3169832270", "0x5db4fae295ee9d710e1bf54aca70744a6ebaf5c9d8a669bd714feffd149c0b11", "111111111111111", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1506552223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "4499500000000000000"}, {name: "balance", type: "uint256", value: "499999999999999"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51337423847007297752127" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[7], \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4317387", timeStamp: "1506552339", hash: "0x765aaec0620d100ed7bc67b9f95c57f3502f5d48bc4b2765a40d6b6b9ebab114", nonce: "6", blockHash: "0x0f7ab8a408d7346d49febea34ff2f90ad985a69743a2bfb4e5f4bbd441cf0b3f", transactionIndex: "23", from: "0x74719d7f5c54f747c6f8c18ce948d641c90a037b", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "", input: "0x338b5dea000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e0000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "1872045", gasUsed: "127586", confirmations: "3391370"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "10000000000000000000"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[7], "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1506552339 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x74719d7f5c54f747c6f8c18ce948d641c90a037b"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "balance", type: "uint256", value: "10000000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "9503149400000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51333106951051830379889" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317398", timeStamp: "1506552733", hash: "0x314e1a9fe4c0c5e3f5ebbd2f0e1b27b98747bc3c5fae1f738e4831e7c35ee5d1", nonce: "9", blockHash: "0x24054fa28dc4d5de5e46ecfd4bdeec0182606233686b31f7f04ba9fe7f77cc4e", transactionIndex: "77", from: "0x034767f3c519f361c5ecf46ebfc08981c629d381", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "1000000000000000000", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "3274356", gasUsed: "34725", confirmations: "3391359"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1506552733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "balance", type: "uint256", value: "1000499999999999999"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "9632123621621509" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51333606951051830379889" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"100000000000000000\",\"10000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317409", timeStamp: "1506553069", hash: "0x87bbc5fe23574dc757ab818a9011cf6c18bf5066f57788e6dd2bd1fc147eae25", nonce: "2", blockHash: "0x009340efc6b449252697fb30194cc639da5f919a02d35c4bf029fe66a810e69c", transactionIndex: "40", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000009c0000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000000000000000009ce00000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000254db1c22440000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001b7989fcc0981aeef02a756b4ef5e94a71a4d53609ec8e39b96dfb04d62f729bf100a7369a963c7db03e8a2ef8e56b11c3ccdaea8090a61603dfb0e64ddfd5db0da282cdd71437cae74ff0589e13d50ed96c12c1314d56e650272f149fbc10e548281f3a8ff7646a5fadcf6ed5275dde80ce90e5c6ff6d7ee94ca1ca4504bf9207", contractAddress: "", cumulativeGasUsed: "2707680", gasUsed: "142324", confirmations: "3391348"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["100000000000000000","1000000000000000000","190000","2496","100000000000000000","2510","1000000000000000","10500000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[4],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["28","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x7989fcc0981aeef02a756b4ef5e94a71a4d53609ec8e39b96dfb04d62f729bf1","0x00a7369a963c7db03e8a2ef8e56b11c3ccdaea8090a61603dfb0e64ddfd5db0d","0xa282cdd71437cae74ff0589e13d50ed96c12c1314d56e650272f149fbc10e548","0x281f3a8ff7646a5fadcf6ed5275dde80ce90e5c6ff6d7ee94ca1ca4504bf9207"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["100000000000000000","1000000000000000000","190000","2496","100000000000000000","2510","1000000000000000","10500000000000000"], [addressList[0],addressList[7],addressList[4],addressList[4]], ["28","27"], ["0x7989fcc0981aeef02a756b4ef5e94a71a4d53609ec8e39b96dfb04d62f729bf1","0x00a7369a963c7db03e8a2ef8e56b11c3ccdaea8090a61603dfb0e64ddfd5db0d","0xa282cdd71437cae74ff0589e13d50ed96c12c1314d56e650272f149fbc10e548","0x281f3a8ff7646a5fadcf6ed5275dde80ce90e5c6ff6d7ee94ca1ca4504bf9207"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1506553069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209298191219064377362" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"495350000000000\",\"50000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317416", timeStamp: "1506553483", hash: "0xbbe1a352d0edd1e9c9352c08887f5858571678ee978d9cd68cdb71751b2ae581", nonce: "1", blockHash: "0xc1c3ce3eb90c80ed4df46c3ce44667c9cdd227e323490306457a66b7648256ec", transactionIndex: "62", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000001c284a8ca1c000000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000001c284a8ca1c0000000000000000000000000000000000000000000000000000000000000009d800000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000074719d7f5c54f747c6f8c18ce948d641c90a037b000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b206c197b94c06a6f945ded20f94e6c651664ab0a9876595bf44f3e112d59e02164325eec9b4204837508ede9c5e8fff8a65ed5c7f47b336fe8fcec08ef57a763fc1ba203f143c75ee5e7f9b2e3cdce30b7b14292d015c2c358dac3361a701090329852aae0ccaecf51b09294a85f06e6491f45ff05a622fd110c540fe4ae2085", contractAddress: "", cumulativeGasUsed: "6386596", gasUsed: "157324", confirmations: "3391341"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["495350000000000","5000000000000000000","190000","7","495350000000000","2520","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[11],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x206c197b94c06a6f945ded20f94e6c651664ab0a9876595bf44f3e112d59e021","0x64325eec9b4204837508ede9c5e8fff8a65ed5c7f47b336fe8fcec08ef57a763","0xfc1ba203f143c75ee5e7f9b2e3cdce30b7b14292d015c2c358dac3361a701090","0x329852aae0ccaecf51b09294a85f06e6491f45ff05a622fd110c540fe4ae2085"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["495350000000000","5000000000000000000","190000","7","495350000000000","2520","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[11],addressList[4]], ["27","27"], ["0x206c197b94c06a6f945ded20f94e6c651664ab0a9876595bf44f3e112d59e021","0x64325eec9b4204837508ede9c5e8fff8a65ed5c7f47b336fe8fcec08ef57a763","0xfc1ba203f143c75ee5e7f9b2e3cdce30b7b14292d015c2c358dac3361a701090","0x329852aae0ccaecf51b09294a85f06e6491f45ff05a622fd110c540fe4ae2085"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1506553483 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209298191219064377362" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317434", timeStamp: "1506554023", hash: "0x3ab29be53879b939bca738dfd4ba6a4fd2d17e65a58c160c58e330435a1816c8", nonce: "7", blockHash: "0x6856e635f7056d8c0012dd64358b1b88fac353ad1a88660852d10e7730d7743b", transactionIndex: "69", from: "0x74719d7f5c54f747c6f8c18ce948d641c90a037b", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "75000000000000000", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "3788465", gasUsed: "34725", confirmations: "3391323"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "75000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1506554023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x74719d7f5c54f747c6f8c18ce948d641c90a037b"}, {name: "amount", type: "uint256", value: "75000000000000000"}, {name: "balance", type: "uint256", value: "75494854650000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "9503149400000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"10000000000000000\",\"100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317434", timeStamp: "1506554023", hash: "0xa77c2bc65be11c2df001355b2cd2f28cbb9c5c790f1072ace4c0ef75e8e6909a", nonce: "0", blockHash: "0x6856e635f7056d8c0012dd64358b1b88fac353ad1a88660852d10e7730d7743b", transactionIndex: "92", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000009db000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000009e300000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000001351609ff7580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c435b76f082b9e7c5345536dee0cd0bb988e860a36de276cb20d260dd2f8cc497282e215ff9631851cb822021e627afddcda2ab9a192f03fae1bfedcefe845a83353599b30b244dc2e40659e6c3bf5076b55e32e9463546bfb0f0f30b853b686225c9e8942032770967aa43cb724cff2cf072730b5d66e1ea640a51fe0b92265d", contractAddress: "", cumulativeGasUsed: "5705384", gasUsed: "142324", confirmations: "3391323"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["10000000000000000","1000000000000000000","190000","2523","10000000000000000","2531","1000000000000000","87000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[4],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x435b76f082b9e7c5345536dee0cd0bb988e860a36de276cb20d260dd2f8cc497","0x282e215ff9631851cb822021e627afddcda2ab9a192f03fae1bfedcefe845a83","0x353599b30b244dc2e40659e6c3bf5076b55e32e9463546bfb0f0f30b853b6862","0x25c9e8942032770967aa43cb724cff2cf072730b5d66e1ea640a51fe0b92265d"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["10000000000000000","1000000000000000000","190000","2523","10000000000000000","2531","1000000000000000","87000000000000000"], [addressList[0],addressList[7],addressList[4],addressList[4]], ["27","28"], ["0x435b76f082b9e7c5345536dee0cd0bb988e860a36de276cb20d260dd2f8cc497","0x282e215ff9631851cb822021e627afddcda2ab9a192f03fae1bfedcefe845a83","0x353599b30b244dc2e40659e6c3bf5076b55e32e9463546bfb0f0f30b853b6862","0x25c9e8942032770967aa43cb724cff2cf072730b5d66e1ea640a51fe0b92265d"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1506554023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"10000000000000000\",\"100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317434", timeStamp: "1506554023", hash: "0x241490f67b1c76fe86a61cc0725c012407ab51f12a3827acca1ac7296f7a4421", nonce: "0", blockHash: "0x6856e635f7056d8c0012dd64358b1b88fac353ad1a88660852d10e7730d7743b", transactionIndex: "93", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000009de000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000009e400000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000001351609ff7580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001bdac8af9a1f8c5b759e835920c37aaf6d7469489be5c8882f1304439841e33b4577cea7fcb4ff91e94cc5ae88ee3a2ea197e9c7a118957c97e62212b5fb6c62839dc9db16d6afbc8ab979832c5bfcc79ba3ba802505b02085108f49497a6cef657be33da5508aa1e9d38c672128dac822375f054f46052987b6da3d4cafd0e505", contractAddress: "", cumulativeGasUsed: "5847708", gasUsed: "142324", confirmations: "3391323"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["10000000000000000","1000000000000000000","190000","2526","10000000000000000","2532","1000000000000000","87000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[4],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["28","27"]}, {type: "bytes32[4]", name: "rs", value: ["0xdac8af9a1f8c5b759e835920c37aaf6d7469489be5c8882f1304439841e33b45","0x77cea7fcb4ff91e94cc5ae88ee3a2ea197e9c7a118957c97e62212b5fb6c6283","0x9dc9db16d6afbc8ab979832c5bfcc79ba3ba802505b02085108f49497a6cef65","0x7be33da5508aa1e9d38c672128dac822375f054f46052987b6da3d4cafd0e505"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["10000000000000000","1000000000000000000","190000","2526","10000000000000000","2532","1000000000000000","87000000000000000"], [addressList[0],addressList[7],addressList[4],addressList[4]], ["28","27"], ["0xdac8af9a1f8c5b759e835920c37aaf6d7469489be5c8882f1304439841e33b45","0x77cea7fcb4ff91e94cc5ae88ee3a2ea197e9c7a118957c97e62212b5fb6c6283","0x9dc9db16d6afbc8ab979832c5bfcc79ba3ba802505b02085108f49497a6cef65","0x7be33da5508aa1e9d38c672128dac822375f054f46052987b6da3d4cafd0e505"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1506554023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"10000000000000000\",\"100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317434", timeStamp: "1506554023", hash: "0xcf568721a37b63e5a09c378b88ae563e099144a16f46926b892533980f910c18", nonce: "0", blockHash: "0x6856e635f7056d8c0012dd64358b1b88fac353ad1a88660852d10e7730d7743b", transactionIndex: "94", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000009e1000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000009e500000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000001351609ff7580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001bd6e44be5174aabf55f27fe7d5e7f35dce8b4d817b43918686ae2ce966eee20b41918aee2fbcbfed084c599aa3ceeeeed2e8d13d5051707221a85b206e5cb9eba958c888c3f8e161961a47be99227c72e68c145ed6dfb074f06966637abb4b2fa24f07c9d16da59ab004e414f7fc175fb3072fecc45c818bbbfa2fc73f563d2f6", contractAddress: "", cumulativeGasUsed: "5989968", gasUsed: "142260", confirmations: "3391323"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["10000000000000000","1000000000000000000","190000","2529","10000000000000000","2533","1000000000000000","87000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[4],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["28","27"]}, {type: "bytes32[4]", name: "rs", value: ["0xd6e44be5174aabf55f27fe7d5e7f35dce8b4d817b43918686ae2ce966eee20b4","0x1918aee2fbcbfed084c599aa3ceeeeed2e8d13d5051707221a85b206e5cb9eba","0x958c888c3f8e161961a47be99227c72e68c145ed6dfb074f06966637abb4b2fa","0x24f07c9d16da59ab004e414f7fc175fb3072fecc45c818bbbfa2fc73f563d2f6"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["10000000000000000","1000000000000000000","190000","2529","10000000000000000","2533","1000000000000000","87000000000000000"], [addressList[0],addressList[7],addressList[4],addressList[4]], ["28","27"], ["0xd6e44be5174aabf55f27fe7d5e7f35dce8b4d817b43918686ae2ce966eee20b4","0x1918aee2fbcbfed084c599aa3ceeeeed2e8d13d5051707221a85b206e5cb9eba","0x958c888c3f8e161961a47be99227c72e68c145ed6dfb074f06966637abb4b2fa","0x24f07c9d16da59ab004e414f7fc175fb3072fecc45c818bbbfa2fc73f563d2f6"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1506554023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"10000000000000000\",\"100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317434", timeStamp: "1506554023", hash: "0x25470145081812ca6554a0af2621b5523e386e7befd3d1720d6e9ac7029702bf", nonce: "3", blockHash: "0x6856e635f7056d8c0012dd64358b1b88fac353ad1a88660852d10e7730d7743b", transactionIndex: "96", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000009e8000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000009ea00000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000001351609ff7580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d381000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001be5da209e87d23163d5cba0d0802cab236a55b636b07430e560f8085f3d55c34f057d30716721b8490adde230041f7b14e6ceeb1829319b26830a9a99a7565cd3d25f9558788e1301b9743334d2a61c2ed1dcb9d2bd43c619ed40767248be735364d326c3202f036643386522e5cc94f6942d652b60172e67271d20a05e9b93bb", contractAddress: "", cumulativeGasUsed: "6225470", gasUsed: "142324", confirmations: "3391323"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["10000000000000000","1000000000000000000","190000","2536","10000000000000000","2538","1000000000000000","87000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[4],addressList[4]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0xe5da209e87d23163d5cba0d0802cab236a55b636b07430e560f8085f3d55c34f","0x057d30716721b8490adde230041f7b14e6ceeb1829319b26830a9a99a7565cd3","0xd25f9558788e1301b9743334d2a61c2ed1dcb9d2bd43c619ed40767248be7353","0x64d326c3202f036643386522e5cc94f6942d652b60172e67271d20a05e9b93bb"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["10000000000000000","1000000000000000000","190000","2536","10000000000000000","2538","1000000000000000","87000000000000000"], [addressList[0],addressList[7],addressList[4],addressList[4]], ["27","27"], ["0xe5da209e87d23163d5cba0d0802cab236a55b636b07430e560f8085f3d55c34f","0x057d30716721b8490adde230041f7b14e6ceeb1829319b26830a9a99a7565cd3","0xd25f9558788e1301b9743334d2a61c2ed1dcb9d2bd43c619ed40767248be7353","0x64d326c3202f036643386522e5cc94f6942d652b60172e67271d20a05e9b93bb"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1506554023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"2000000000000000\",\"4000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317510", timeStamp: "1506556141", hash: "0x5c98201bb273e78a47ccf3eda3041382015fc83beb74ae945c9d57f64351c938", nonce: "2", blockHash: "0x6c33173625c4d3a71480777a0b04518f301a4503507d8e1b3a2c2534c08ddf6b", transactionIndex: "17", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000000071afd498d00000000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000002e630000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000071afd498d0000000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000074719d7f5c54f747c6f8c18ce948d641c90a037b00000000000000000000000074719d7f5c54f747c6f8c18ce948d641c90a037b000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001bb2d8600a85287f0b281d79e9e2ca587e60137bae7c550f2ffc714642ead399821dcd743fa5504de81a1e93db4d0bec96cf7fb38df6c3054bd1f5396f4dc7a9a23f033f6b64e8dd2551b6ee3d2c564514f6b12da99d8af04a99d2d581fd789b8c333e90af6f99b437089b3f1d2105204efad9c0ccdc2cf42d3f09432e4aa35c1c", contractAddress: "", cumulativeGasUsed: "5752347", gasUsed: "142132", confirmations: "3391247"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["2000000000000000","4000000000000000000","190000","48","2000000000000000","50","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[11],addressList[11]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0xb2d8600a85287f0b281d79e9e2ca587e60137bae7c550f2ffc714642ead39982","0x1dcd743fa5504de81a1e93db4d0bec96cf7fb38df6c3054bd1f5396f4dc7a9a2","0x3f033f6b64e8dd2551b6ee3d2c564514f6b12da99d8af04a99d2d581fd789b8c","0x333e90af6f99b437089b3f1d2105204efad9c0ccdc2cf42d3f09432e4aa35c1c"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["2000000000000000","4000000000000000000","190000","48","2000000000000000","50","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[11],addressList[11]], ["27","27"], ["0xb2d8600a85287f0b281d79e9e2ca587e60137bae7c550f2ffc714642ead39982","0x1dcd743fa5504de81a1e93db4d0bec96cf7fb38df6c3054bd1f5396f4dc7a9a2","0x3f033f6b64e8dd2551b6ee3d2c564514f6b12da99d8af04a99d2d581fd789b8c","0x333e90af6f99b437089b3f1d2105204efad9c0ccdc2cf42d3f09432e4aa35c1c"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1506556141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317552", timeStamp: "1506557581", hash: "0xfb0c9fb63f2d719cdfa2d2a5c7b4e77e95a5156097f6449c165dd99ff7329a63", nonce: "10", blockHash: "0x935310c367c3b617b3211ba2b1e222482dad3a17366ca702712490c58e44ac05", transactionIndex: "88", from: "0x31f2cfe8bcb177f4dc4a727bcbe537b6a039a7ee", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "50000000000000000", gas: "200000", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "3827308", gasUsed: "64725", confirmations: "3391205"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1506557581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x31f2cfe8bcb177f4dc4a727bcbe537b6a039a7ee"}, {name: "amount", type: "uint256", value: "50000000000000000"}, {name: "balance", type: "uint256", value: "50000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "73141076800000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[7], \"15400000000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4317558", timeStamp: "1506557786", hash: "0xfd09a232f0f0cf1014a1dd159517f0eb6ce1f2a7e565785145de25778dc1f88d", nonce: "1", blockHash: "0xd25cbad87d4912659ece7c85cc052703b6dfeb7b206c4de57e9ba7194514c59d", transactionIndex: "36", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000000000000000000000000000d5b7ca6845040000000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d3810000000000000000000000000000000000000000000000000000000000000a1a000000000000000000000000000000000000000000000000000000000000001b6128f7b828a745762ae255dd7d9006becccaa3158e800b63be90a8de5100c4d35789ce51643c8c2afd08e328e63b4413a59b0f4b43335c18f30d0d386e5dd30e000000000000000000000000000000000000000000000000000b5531b6f153f7", contractAddress: "", cumulativeGasUsed: "3152886", gasUsed: "146287", confirmations: "3391199"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "15400000000000000000"}, {type: "address", name: "user", value: addressList[4]}, {type: "uint256", name: "nonce", value: "2586"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6128f7b828a745762ae255dd7d9006becccaa3158e800b63be90a8de5100c4d3"}, {type: "bytes32", name: "s", value: "0x5789ce51643c8c2afd08e328e63b4413a59b0f4b43335c18f30d0d386e5dd30e"}, {type: "uint256", name: "feeWithdrawal", value: "3189896754844663"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[7], "15400000000000000000", addressList[4], "2586", "27", "0x6128f7b828a745762ae255dd7d9006becccaa3158e800b63be90a8de5100c4d3", "0x5789ce51643c8c2afd08e328e63b4413a59b0f4b43335c18f30d0d386e5dd30e", "3189896754844663", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1506557786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "15350875589975392189"}, {name: "balance", type: "uint256", value: "49124410024607810"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51209495032219064377362" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[0], \"1000007145349999999\",... )", async function( ) {
		const txOriginal = {blockNumber: "4317558", timeStamp: "1506557786", hash: "0x3e54175420df59c4b0b2edca54d415e8337e71e0ab6e7e750c8027a1281f24d5", nonce: "1", blockHash: "0xd25cbad87d4912659ece7c85cc052703b6dfeb7b206c4de57e9ba7194514c59d", transactionIndex: "37", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0bd334f706d7f000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d3810000000000000000000000000000000000000000000000000000000000000a18000000000000000000000000000000000000000000000000000000000000001b0088149849c21e9bcb9ae16a7efb2a43c4dcb6c214c41a8e2b54f496fe1161bb01c04122a4b021443314cd6f81121f32f66ccd9caf2499b313d6bd6ef93c199d0000000000000000000000000000000000000000000000000001c6be7d70f1ff", contractAddress: "", cumulativeGasUsed: "3235827", gasUsed: "82941", confirmations: "3391199"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[0]}, {type: "uint256", name: "amount", value: "1000007145349999999"}, {type: "address", name: "user", value: addressList[4]}, {type: "uint256", name: "nonce", value: "2584"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0088149849c21e9bcb9ae16a7efb2a43c4dcb6c214c41a8e2b54f496fe1161bb"}, {type: "bytes32", name: "s", value: "0x01c04122a4b021443314cd6f81121f32f66ccd9caf2499b313d6bd6ef93c199d"}, {type: "uint256", name: "feeWithdrawal", value: "499996427350527"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[0], "1000007145349999999", addressList[4], "2584", "27", "0x0088149849c21e9bcb9ae16a7efb2a43c4dcb6c214c41a8e2b54f496fe1161bb", "0x01c04122a4b021443314cd6f81121f32f66ccd9caf2499b313d6bd6ef93c199d", "499996427350527", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1506557786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "999507145349999999"}, {name: "balance", type: "uint256", value: "499999999999999"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51211493872179064377362" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"1800000000000000\",\"2000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317558", timeStamp: "1506557786", hash: "0x978482e1e16ae7e30e25c51ee59b0f8259797c43b8fc8420efe09ff5c840434b", nonce: "1", blockHash: "0xd25cbad87d4912659ece7c85cc052703b6dfeb7b206c4de57e9ba7194514c59d", transactionIndex: "41", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000000066517289880000000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000000350000000000000000000000000000000000000000000000000006651728988000000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000074719d7f5c54f747c6f8c18ce948d641c90a037b00000000000000000000000031f2cfe8bcb177f4dc4a727bcbe537b6a039a7ee000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001ca930100f39f8f4bcb45299bf54a8047837b10805f149a7bf1d379d7b6e95203a5101f328e45420033f0f284b41ea3a28a1910a900a5496481ead91df53bb1e39905135a9b43fa214f2af43f0a5593ece3f25b0b4af88b375ca9fb76ae05486d7746a2851fabe1273c839f43c2aa16893cfad5b86221d816b8adafff8f7131d52", contractAddress: "", cumulativeGasUsed: "3494441", gasUsed: "157260", confirmations: "3391199"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["1800000000000000","2000000000000000000","190000","53","1800000000000000","52","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[11],addressList[12]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0xa930100f39f8f4bcb45299bf54a8047837b10805f149a7bf1d379d7b6e95203a","0x5101f328e45420033f0f284b41ea3a28a1910a900a5496481ead91df53bb1e39","0x905135a9b43fa214f2af43f0a5593ece3f25b0b4af88b375ca9fb76ae05486d7","0x746a2851fabe1273c839f43c2aa16893cfad5b86221d816b8adafff8f7131d52"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["1800000000000000","2000000000000000000","190000","53","1800000000000000","52","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[11],addressList[12]], ["27","28"], ["0xa930100f39f8f4bcb45299bf54a8047837b10805f149a7bf1d379d7b6e95203a","0x5101f328e45420033f0f284b41ea3a28a1910a900a5496481ead91df53bb1e39","0x905135a9b43fa214f2af43f0a5593ece3f25b0b4af88b375ca9fb76ae05486d7","0x746a2851fabe1273c839f43c2aa16893cfad5b86221d816b8adafff8f7131d52"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1506557786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51211393952559045050302" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[7], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "4317575", timeStamp: "1506558362", hash: "0xdc997d097f081ccc67a49b3db450cd1f4eb7e17145f18fd6a463a9fb19ed55ef", nonce: "4", blockHash: "0x262297ae36687789c040d1eb39c3a4f30e0adf28b7721de9285ad059823660c4", transactionIndex: "120", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000031f2cfe8bcb177f4dc4a727bcbe537b6a039a7ee0000000000000000000000000000000000000000000000000000000000000036000000000000000000000000000000000000000000000000000000000000001c9daebcf9962c34a4f67b2c851c44da82b8c65ce7fd166b3b034ed0925f9c3b3e27ee7236b70f357b71a8e338c5d4d1dd7122654ca8d3d185cf5c33b2dca1983200000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "4927176", gasUsed: "158464", confirmations: "3391182"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "1000000000000000000"}, {type: "address", name: "user", value: addressList[12]}, {type: "uint256", name: "nonce", value: "54"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x9daebcf9962c34a4f67b2c851c44da82b8c65ce7fd166b3b034ed0925f9c3b3e"}, {type: "bytes32", name: "s", value: "0x27ee7236b70f357b71a8e338c5d4d1dd7122654ca8d3d185cf5c33b2dca19832"}, {type: "uint256", name: "feeWithdrawal", value: "50000000000000000"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[7], "1000000000000000000", addressList[12], "54", "28", "0x9daebcf9962c34a4f67b2c851c44da82b8c65ce7fd166b3b034ed0925f9c3b3e", "0x27ee7236b70f357b71a8e338c5d4d1dd7122654ca8d3d185cf5c33b2dca19832", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1506558362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x31f2cfe8bcb177f4dc4a727bcbe537b6a039a7ee"}, {name: "amount", type: "uint256", value: "950000000000000000"}, {name: "balance", type: "uint256", value: "800000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51211393952559045050302" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[7], \"299124410024607810\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4317593", timeStamp: "1506558805", hash: "0x05f3271a7752c1552f80c245d38dea7af627e477217dce2012e5f1de5109f39b", nonce: "5", blockHash: "0xc4518ef64f57f4d45eb627d6818693b5a394ed7f1e36390eb42e020a0823cdf0", transactionIndex: "56", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e0000000000000000000000000000000000000000000000000426b410eb2a4042000000000000000000000000034767f3c519f361c5ecf46ebfc08981c629d3810000000000000000000000000000000000000000000000000000000000000a1c000000000000000000000000000000000000000000000000000000000000001cb73c750a4a38ea869ec6cf8f79182f01b0f75df16e89512fe6708abe0db915fe0c7590f0baccb055d12265184ccc4c30b50c2d2d69330b3b487c49395ee2ae7d0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3103782", gasUsed: "130989", confirmations: "3391164"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "299124410024607810"}, {type: "address", name: "user", value: addressList[4]}, {type: "uint256", name: "nonce", value: "2588"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xb73c750a4a38ea869ec6cf8f79182f01b0f75df16e89512fe6708abe0db915fe"}, {type: "bytes32", name: "s", value: "0x0c7590f0baccb055d12265184ccc4c30b50c2d2d69330b3b487c49395ee2ae7d"}, {type: "uint256", name: "feeWithdrawal", value: "0"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[7], "299124410024607810", addressList[4], "2588", "28", "0xb73c750a4a38ea869ec6cf8f79182f01b0f75df16e89512fe6708abe0db915fe", "0x0c7590f0baccb055d12265184ccc4c30b50c2d2d69330b3b487c49395ee2ae7d", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1506558805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x034767f3c519f361c5ecf46ebfc08981c629d381"}, {name: "amount", type: "uint256", value: "299124410024607810"}, {name: "balance", type: "uint256", value: "0"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203927778455262530439" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[7], \"15350875589975392189\" )", async function( ) {
		const txOriginal = {blockNumber: "4317692", timeStamp: "1506561568", hash: "0xfae4baab02b4cd1ea1802288c26d3134804ee7775a4f45e6c6b6515dbb1cc084", nonce: "1", blockHash: "0x61963300e9d029b1b1bc4a2393c25dedbae7456e1f4bc268592209383cd62506", transactionIndex: "44", from: "0xc01838dca02cc6129b68182d0e6fad16b7d9bdfc", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x338b5dea000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000000000000000000000000000d509440443b2bfbd", contractAddress: "", cumulativeGasUsed: "2095227", gasUsed: "127714", confirmations: "3391065"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "15350875589975392189"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[7], "15350875589975392189", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1506561568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0xc01838dca02cc6129b68182d0e6fad16b7d9bdfc"}, {name: "amount", type: "uint256", value: "15350875589975392189"}, {name: "balance", type: "uint256", value: "15350875589975392189"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "41526887141171583" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203927778455262530439" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317704", timeStamp: "1506561781", hash: "0xf6de648aa7a6aa65ce48a1edf01bce18d85b02f3bb8ab1e8b677da7c4b369903", nonce: "2", blockHash: "0xe591970642bc6904c24952eefc74742ccb3fd600d4c349af60e4ba0495f4db64", transactionIndex: "40", from: "0xc01838dca02cc6129b68182d0e6fad16b7d9bdfc", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "1900000000000000000", gas: "200000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "1906858", gasUsed: "49725", confirmations: "3391053"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1506561781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0xc01838dca02cc6129b68182d0e6fad16b7d9bdfc"}, {name: "amount", type: "uint256", value: "1900000000000000000"}, {name: "balance", type: "uint256", value: "1900000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "41526887141171583" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203724511030562530440" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"132297506191726483\",\"12958296869862... )", async function( ) {
		const txOriginal = {blockNumber: "4317733", timeStamp: "1506562496", hash: "0x5628914dadf90b22b5c033c247a101cb064f478442aa31ce692c50d208a7cb3f", nonce: "3", blockHash: "0x6a1030f547b3bce2b6b2a6607c605ade442f17d18ddd6d9af997e3eb71d05008", transactionIndex: "94", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000001d603e1853a579300000000000000000000000000000000000000000000000011fbb63c1638be20000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a1f000000000000000000000000000000000000000000000000000907b1c6d980680000000000000000000000000000000000000000000000000000000000000a3300000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a00b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922af03821068088df3be9bd3011a7dd926e48d61739ea14df578b8bb9e7410521091662b66b68e983045a4920f93671b2ecfa19de854a998a96a297e0c9ffc29f3d", contractAddress: "", cumulativeGasUsed: "6248438", gasUsed: "157644", confirmations: "3391024"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["132297506191726483","1295829686986260000","190000","2591","2541734917144680","2611","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0xf03821068088df3be9bd3011a7dd926e48d61739ea14df578b8bb9e741052109","0x1662b66b68e983045a4920f93671b2ecfa19de854a998a96a297e0c9ffc29f3d"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["132297506191726483","1295829686986260000","190000","2591","2541734917144680","2611","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0xf03821068088df3be9bd3011a7dd926e48d61739ea14df578b8bb9e741052109","0x1662b66b68e983045a4920f93671b2ecfa19de854a998a96a297e0c9ffc29f3d"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1506562496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203724511030562530440" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"132297506191726483\",\"12958296869862... )", async function( ) {
		const txOriginal = {blockNumber: "4317733", timeStamp: "1506562496", hash: "0x82c54a23f0cc0de1e4082769d1a27228b6bbb44597542fffaf6d9ee33ae3d5d5", nonce: "2", blockHash: "0x6a1030f547b3bce2b6b2a6607c605ade442f17d18ddd6d9af997e3eb71d05008", transactionIndex: "95", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000001d603e1853a579300000000000000000000000000000000000000000000000011fbb63c1638be20000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a1f000000000000000000000000000000000000000000000000006af2f9abf11fe20000000000000000000000000000000000000000000000000000000000000a3500000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000006b6b683639ee390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a00b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a2591b91eb364d6aba6c2c88e70d8dadabc3f86f22ac6e6f4f1d2fdf913163f0b78a83ab59f7e622425612a2ad3c95621124f8b9da9e85053cf8d94a9f524555b", contractAddress: "", cumulativeGasUsed: "6376146", gasUsed: "127708", confirmations: "3391024"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["132297506191726483","1295829686986260000","190000","2591","30103501676814306","2613","1000000000000000","30235917838577209"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0x2591b91eb364d6aba6c2c88e70d8dadabc3f86f22ac6e6f4f1d2fdf913163f0b","0x78a83ab59f7e622425612a2ad3c95621124f8b9da9e85053cf8d94a9f524555b"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["132297506191726483","1295829686986260000","190000","2591","30103501676814306","2613","1000000000000000","30235917838577209"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0x2591b91eb364d6aba6c2c88e70d8dadabc3f86f22ac6e6f4f1d2fdf913163f0b","0x78a83ab59f7e622425612a2ad3c95621124f8b9da9e85053cf8d94a9f524555b"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1506562496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203724511030562530440" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"257044780182535020\",\"24968268000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317735", timeStamp: "1506562523", hash: "0x377bff9bb83fb5f66043da67583d5cdb2b8b5bd4ca9bfc4afd65a9ca1573807d", nonce: "6", blockHash: "0x147b162468383a3811436f0cbc212d1230c7431439aadef98ce81635811b3f0d", transactionIndex: "42", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000039134dd9e25fb6c00000000000000000000000000000000000000000000000022a682beeface000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a2e000000000000000000000000000000000000000000000000022375acdb2a48ec0000000000000000000000000000000000000000000000000000000000000a3900000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000001ab3cb3cf648bf0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c4dd310470d48170074e8766d981e573c82df5e0f3a8e34ca33cbc45bfaa46b8c416c6672390b7699b52c599d4a92e97ae62e0020020dd7363c94e8996f3cdd8388fb4459ce32754f4828ce60b4fed045b5f8c1e5982466b840d25255bdebb25a6314a76c45c9873d6bebf4fbf00372044c6a31d56b9ef69f7ff094b4b0243471", contractAddress: "", cumulativeGasUsed: "2025264", gasUsed: "142644", confirmations: "3391022"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["257044780182535020","2496826800000000000","190000","2606","154096197532535020","2617","1000000000000000","7516034876983487"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x4dd310470d48170074e8766d981e573c82df5e0f3a8e34ca33cbc45bfaa46b8c","0x416c6672390b7699b52c599d4a92e97ae62e0020020dd7363c94e8996f3cdd83","0x88fb4459ce32754f4828ce60b4fed045b5f8c1e5982466b840d25255bdebb25a","0x6314a76c45c9873d6bebf4fbf00372044c6a31d56b9ef69f7ff094b4b0243471"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["257044780182535020","2496826800000000000","190000","2606","154096197532535020","2617","1000000000000000","7516034876983487"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x4dd310470d48170074e8766d981e573c82df5e0f3a8e34ca33cbc45bfaa46b8c","0x416c6672390b7699b52c599d4a92e97ae62e0020020dd7363c94e8996f3cdd83","0x88fb4459ce32754f4828ce60b4fed045b5f8c1e5982466b840d25255bdebb25a","0x6314a76c45c9873d6bebf4fbf00372044c6a31d56b9ef69f7ff094b4b0243471"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1506562523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203724511030562530440" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"133204110969343835\",\"12950259250000... )", async function( ) {
		const txOriginal = {blockNumber: "4317735", timeStamp: "1506562523", hash: "0x8940578dac54d57647282696ff7e7622713ce5fa28a5c4db4d76d0c5300939af", nonce: "2", blockHash: "0x147b162468383a3811436f0cbc212d1230c7431439aadef98ce81635811b3f0d", transactionIndex: "43", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000001d93c6ee4f30f5b00000000000000000000000000000000000000000000000011f8db37aa8bf200000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a2500000000000000000000000000000000000000000000000001d93c6ee4f30f5b0000000000000000000000000000000000000000000000000000000000000a3800000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000001dc6a49139e6340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001cc25110e35ecddcbfa0012714edbb4b2c4aaf8b93259136a0edfd298122d707043f3c59505b6b31992d1e157e19274f1fd0aa4549205f078515afb62f413ab393d148b716331b4034a7e68ac6f05d294205ba9dcafb2940433210610300daa6e110bb3d621aebf368885937d70bbee9b49d40ca2b6801ef7f5c16d8e80c477abf", contractAddress: "", cumulativeGasUsed: "2167972", gasUsed: "142708", confirmations: "3391022"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["133204110969343835","1295025925000000000","190000","2597","133204110969343835","2616","1000000000000000","8381184438036020"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0xc25110e35ecddcbfa0012714edbb4b2c4aaf8b93259136a0edfd298122d70704","0x3f3c59505b6b31992d1e157e19274f1fd0aa4549205f078515afb62f413ab393","0xd148b716331b4034a7e68ac6f05d294205ba9dcafb2940433210610300daa6e1","0x10bb3d621aebf368885937d70bbee9b49d40ca2b6801ef7f5c16d8e80c477abf"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["133204110969343835","1295025925000000000","190000","2597","133204110969343835","2616","1000000000000000","8381184438036020"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0xc25110e35ecddcbfa0012714edbb4b2c4aaf8b93259136a0edfd298122d70704","0x3f3c59505b6b31992d1e157e19274f1fd0aa4549205f078515afb62f413ab393","0xd148b716331b4034a7e68ac6f05d294205ba9dcafb2940433210610300daa6e1","0x10bb3d621aebf368885937d70bbee9b49d40ca2b6801ef7f5c16d8e80c477abf"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1506562523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51203752260398275163104" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"132297506191726483\",\"12958296869862... )", async function( ) {
		const txOriginal = {blockNumber: "4317735", timeStamp: "1506562523", hash: "0xe69d0085c1444db8af894722e3ff5cc2834a0045ef1db1616acd1046b6a0dda3", nonce: "2", blockHash: "0x147b162468383a3811436f0cbc212d1230c7431439aadef98ce81635811b3f0d", transactionIndex: "44", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000001d603e1853a579300000000000000000000000000000000000000000000000011fbb63c1638be20000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a1f00000000000000000000000000000000000000000000000001620936126fb7480000000000000000000000000000000000000000000000000000000000000a3700000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000002568ab912037b50000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a00b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a8ef14c47cbab8ff2e0961d7db55cd6f99f3acd93ce503fabd75ad653c8a1f214637685f872adbae28c7a96c67ad26a235d18d3031a585ee7d5f39c7cfdd7abb6", contractAddress: "", cumulativeGasUsed: "2295744", gasUsed: "127772", confirmations: "3391022"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["132297506191726483","1295829686986260000","190000","2591","99652269597767496","2615","1000000000000000","10529660221798325"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0x8ef14c47cbab8ff2e0961d7db55cd6f99f3acd93ce503fabd75ad653c8a1f214","0x637685f872adbae28c7a96c67ad26a235d18d3031a585ee7d5f39c7cfdd7abb6"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["132297506191726483","1295829686986260000","190000","2591","99652269597767496","2615","1000000000000000","10529660221798325"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x14154cd59c5c5b421153f2617fc57f722417312a139ce1ed68b8dcfc0d2b64a0","0x0b95d50ee1000a7804e476775731f18a8be0e848f06201ff9aff85ea8a04922a","0x8ef14c47cbab8ff2e0961d7db55cd6f99f3acd93ce503fabd75ad653c8a1f214","0x637685f872adbae28c7a96c67ad26a235d18d3031a585ee7d5f39c7cfdd7abb6"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1506562523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51205742510398275163104" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"120000000000000000\",\"12000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317820", timeStamp: "1506564910", hash: "0x8657023e5047d03c0e436cc028cbe90d17e1071e59908083c3e05bf35c3aede5", nonce: "7", blockHash: "0xab04d922f1754d1747f5240b497a36b9e1fd3c5630901432083011b01995b793", transactionIndex: "50", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000010a741a462780000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a5000000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000000000000a5200000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000020453e58b5b5550000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001c6df2689641f28993d5676fcbd9e00295c8f81ebd156ed2192b2f7c594ab1013869634ae74812bc2b4da80498ac81bab291e2dd397b6cf3f147a45ff37ffcc1d29d41ef0b3d9a22bd2ea02f8b62698206cbf5f52b6c80070b83f6130004fc4ef05f4110d0242ff09fbc20a31e2202787cbea4b5540501d30d5d3162ca766b06c4", contractAddress: "", cumulativeGasUsed: "3842767", gasUsed: "142388", confirmations: "3390937"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["120000000000000000","1200000000000000000","190000","2640","120000000000000000","2642","1000000000000000","9083333333333333"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["28","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x6df2689641f28993d5676fcbd9e00295c8f81ebd156ed2192b2f7c594ab10138","0x69634ae74812bc2b4da80498ac81bab291e2dd397b6cf3f147a45ff37ffcc1d2","0x9d41ef0b3d9a22bd2ea02f8b62698206cbf5f52b6c80070b83f6130004fc4ef0","0x5f4110d0242ff09fbc20a31e2202787cbea4b5540501d30d5d3162ca766b06c4"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["120000000000000000","1200000000000000000","190000","2640","120000000000000000","2642","1000000000000000","9083333333333333"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["28","28"], ["0x6df2689641f28993d5676fcbd9e00295c8f81ebd156ed2192b2f7c594ab10138","0x69634ae74812bc2b4da80498ac81bab291e2dd397b6cf3f147a45ff37ffcc1d2","0x9d41ef0b3d9a22bd2ea02f8b62698206cbf5f52b6c80070b83f6130004fc4ef0","0x5f4110d0242ff09fbc20a31e2202787cbea4b5540501d30d5d3162ca766b06c4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1506564910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204617661302257272222" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317820", timeStamp: "1506564910", hash: "0xd83b36a461b26b5a5ba4c19937da357c1be09be7c9beb200188e4dfbac7a9216", nonce: "4", blockHash: "0xab04d922f1754d1747f5240b497a36b9e1fd3c5630901432083011b01995b793", transactionIndex: "55", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a5500000000000000000000000000000000000000000000000000012abfb0150b800000000000000000000000000000000000000000000000000000000000000a5700000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0497b9e0bdcff5ae1892d173bcd22a5fde4d27696ed3fea2bcf853e72b8a12233294f383ea6b340765e6aa02c207477c627ead39db0745df09bda94f197e5fdf4", contractAddress: "", cumulativeGasUsed: "4974853", gasUsed: "142644", confirmations: "3390937"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","328477758000000","2647","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x497b9e0bdcff5ae1892d173bcd22a5fde4d27696ed3fea2bcf853e72b8a12233","0x294f383ea6b340765e6aa02c207477c627ead39db0745df09bda94f197e5fdf4"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","328477758000000","2647","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x497b9e0bdcff5ae1892d173bcd22a5fde4d27696ed3fea2bcf853e72b8a12233","0x294f383ea6b340765e6aa02c207477c627ead39db0745df09bda94f197e5fdf4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1506564910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204617661302257272222" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317820", timeStamp: "1506564910", hash: "0x0bb345a2cd53584968294211b35d33d16804f58a133e4d64d60a1ac8372fa29a", nonce: "3", blockHash: "0xab04d922f1754d1747f5240b497a36b9e1fd3c5630901432083011b01995b793", transactionIndex: "56", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a5500000000000000000000000000000000000000000000000000018ce90bf5c9b50000000000000000000000000000000000000000000000000000000000000a5900000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef06e0e4aa454a18ec268ddb1a0f16a404ac97637df672173b9efe1198bb5890bd82b6f3335daf1fa3311354cc65b892089bacb5183fa2811d7df4268a96a753856", contractAddress: "", cumulativeGasUsed: "5102497", gasUsed: "127644", confirmations: "3390937"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","436407532636597","2649","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x6e0e4aa454a18ec268ddb1a0f16a404ac97637df672173b9efe1198bb5890bd8","0x2b6f3335daf1fa3311354cc65b892089bacb5183fa2811d7df4268a96a753856"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","436407532636597","2649","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x6e0e4aa454a18ec268ddb1a0f16a404ac97637df672173b9efe1198bb5890bd8","0x2b6f3335daf1fa3311354cc65b892089bacb5183fa2811d7df4268a96a753856"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1506564910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204859172982257272222" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317822", timeStamp: "1506564923", hash: "0xa68d75e7be188e32c5606d3298c1ac7bc5bea66ad022f4f96ebeb22032e5f3f0", nonce: "3", blockHash: "0x2eee01f9611ba22c56eff931ea9b8966196790dcf17b2126e1054aa8058786f8", transactionIndex: "27", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a55000000000000000000000000000000000000000000000000000f66bee4ce17070000000000000000000000000000000000000000000000000000000000000a5b00000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef08e3e50d38f36096cf2e628fe573d75d08735a02d3652dd5a454115064049c6d47f7451837dc987b3ae6b3af305e2e3a40d6c7a70ae5e4061f99620f54b47c37f", contractAddress: "", cumulativeGasUsed: "1391028", gasUsed: "127644", confirmations: "3390935"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","4335094719190791","2651","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x8e3e50d38f36096cf2e628fe573d75d08735a02d3652dd5a454115064049c6d4","0x7f7451837dc987b3ae6b3af305e2e3a40d6c7a70ae5e4061f99620f54b47c37f"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","4335094719190791","2651","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x8e3e50d38f36096cf2e628fe573d75d08735a02d3652dd5a454115064049c6d4","0x7f7451837dc987b3ae6b3af305e2e3a40d6c7a70ae5e4061f99620f54b47c37f"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1506564923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204859172982257272222" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317825", timeStamp: "1506565020", hash: "0x698649d04ab54e418a26e95efef10dccec4bd3bfacfb732c3f692c3c625661d0", nonce: "8", blockHash: "0xee0b811d1e449c0a0416d55437dfbf9e391dc94acced8add21c371cc635e67b5", transactionIndex: "72", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a550000000000000000000000000000000000000000000000000184feed4611a4000000000000000000000000000000000000000000000000000000000000000a5f00000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000022af78d42976250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0d6342c782324318b28dc6eefc7b57a3e68f9d614984391676e2e4da7f280d94210de7976bcc50fc870fa927bd3d8d073a78eedd20bf76d5eedf34582271617c0", contractAddress: "", cumulativeGasUsed: "3007598", gasUsed: "127708", confirmations: "3390932"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","109492586000000000","2655","1000000000000000","9763082698585637"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0xd6342c782324318b28dc6eefc7b57a3e68f9d614984391676e2e4da7f280d942","0x10de7976bcc50fc870fa927bd3d8d073a78eedd20bf76d5eedf34582271617c0"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","109492586000000000","2655","1000000000000000","9763082698585637"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0xd6342c782324318b28dc6eefc7b57a3e68f9d614984391676e2e4da7f280d942","0x10de7976bcc50fc870fa927bd3d8d073a78eedd20bf76d5eedf34582271617c0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1506565020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204859172982257272222" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317825", timeStamp: "1506565020", hash: "0x298007d2132c706216be5c60f1581e3cafbf1d6dedfaf352b554e1bff2f3b8f7", nonce: "5", blockHash: "0xee0b811d1e449c0a0416d55437dfbf9e391dc94acced8add21c371cc635e67b5", transactionIndex: "74", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a550000000000000000000000000000000000000000000000000099a0bc4436ceb00000000000000000000000000000000000000000000000000000000000000a6100000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000004cf097abc7b27a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef05fedc396b8da986b93bf915637b91b7b9b039e408874885ab7deb56a645264c35289e21b89e5836357052eae598f7be1c1a54b6ca504e6ca9343c13f67c32a84", contractAddress: "", cumulativeGasUsed: "3243356", gasUsed: "127708", confirmations: "3390932"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","43242401895468720","2657","1000000000000000","21656632442729082"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x5fedc396b8da986b93bf915637b91b7b9b039e408874885ab7deb56a645264c3","0x5289e21b89e5836357052eae598f7be1c1a54b6ca504e6ca9343c13f67c32a84"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","43242401895468720","2657","1000000000000000","21656632442729082"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x5fedc396b8da986b93bf915637b91b7b9b039e408874885ab7deb56a645264c3","0x5289e21b89e5836357052eae598f7be1c1a54b6ca504e6ca9343c13f67c32a84"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1506565020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204859172982257272222" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317825", timeStamp: "1506565020", hash: "0xee17b9806e282ad865b24af34691c2b081e4fefc400f023c38e318edc00cb1c5", nonce: "4", blockHash: "0xee0b811d1e449c0a0416d55437dfbf9e391dc94acced8add21c371cc635e67b5", transactionIndex: "76", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a55000000000000000000000000000000000000000000000000000f66c144d01c100000000000000000000000000000000000000000000000000000000000000a6300000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef031d0ef498110908e6c4e5999ea3476c603820a391035208a94c02dfaf6bc59595bf091fdeee1d1b9875f00f83bad6e49d57ee27fd763515e57065d7ad502d7c9", contractAddress: "", cumulativeGasUsed: "3828255", gasUsed: "127580", confirmations: "3390932"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","4335104919870480","2659","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x31d0ef498110908e6c4e5999ea3476c603820a391035208a94c02dfaf6bc5959","0x5bf091fdeee1d1b9875f00f83bad6e49d57ee27fd763515e57065d7ad502d7c9"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","4335104919870480","2659","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x31d0ef498110908e6c4e5999ea3476c603820a391035208a94c02dfaf6bc5959","0x5bf091fdeee1d1b9875f00f83bad6e49d57ee27fd763515e57065d7ad502d7c9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1506565020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51204859172982257272222" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317825", timeStamp: "1506565020", hash: "0x012d9d4e416404ab5297f1da28df45b528d3c289a70a2fa162a27450d182647b", nonce: "3", blockHash: "0xee0b811d1e449c0a0416d55437dfbf9e391dc94acced8add21c371cc635e67b5", transactionIndex: "77", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a55000000000000000000000000000000000000000000000000001349e6eed3a6bc0000000000000000000000000000000000000000000000000000000000000a5d00000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0cc784638f6db1568f4261726afec05e2f3f785bc21b8f7b2637eff88aee1479651c1af2255470bb52f35110ea169d6defe6b6a7c2e3d416a6008d8627994217f", contractAddress: "", cumulativeGasUsed: "3955899", gasUsed: "127644", confirmations: "3390932"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","5429280755656380","2653","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0xcc784638f6db1568f4261726afec05e2f3f785bc21b8f7b2637eff88aee14796","0x51c1af2255470bb52f35110ea169d6defe6b6a7c2e3d416a6008d8627994217f"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","5429280755656380","2653","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0xcc784638f6db1568f4261726afec05e2f3f785bc21b8f7b2637eff88aee14796","0x51c1af2255470bb52f35110ea169d6defe6b6a7c2e3d416a6008d8627994217f"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1506565020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51194109230113801280647" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317829", timeStamp: "1506565067", hash: "0xb25d0894291b75b39868fb4a8268c844caa81a72f391a3dc494abcc133e6d5a3", nonce: "4", blockHash: "0xc7b1da8aa191e0448ccb2b0ab3eb8de251490fc4e78d654cdef0f16e435748f0", transactionIndex: "51", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a5500000000000000000000000000000000000000000000000000132d15b3c555540000000000000000000000000000000000000000000000000000000000000a6500000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef065f07944d07148c54e93309b6c31db84808fe11b72e98329de91a6fad7f3013978736db2dacdd6a9423f1f96bab38586e7dd4d0da236c549112db3ad0d7827a5", contractAddress: "", cumulativeGasUsed: "1821168", gasUsed: "127644", confirmations: "3390928"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","5397595791119700","2661","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x65f07944d07148c54e93309b6c31db84808fe11b72e98329de91a6fad7f30139","0x78736db2dacdd6a9423f1f96bab38586e7dd4d0da236c549112db3ad0d7827a5"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","5397595791119700","2661","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x65f07944d07148c54e93309b6c31db84808fe11b72e98329de91a6fad7f30139","0x78736db2dacdd6a9423f1f96bab38586e7dd4d0da236c549112db3ad0d7827a5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1506565067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51185937469713801280627" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317829", timeStamp: "1506565067", hash: "0xa5c775dc25e1f517d15b73a03e86c9939306c1a4f0f51b3cdeabcf6ad93992c2", nonce: "5", blockHash: "0xc7b1da8aa191e0448ccb2b0ab3eb8de251490fc4e78d654cdef0f16e435748f0", transactionIndex: "52", from: "0x4532357aaaa23398e5fdb6a5f6069d2cdfa520df", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a5500000000000000000000000000000000000000000000000000012a02977fbeb10000000000000000000000000000000000000000000000000000000000000a6700000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef02fa33b6c995714541b5f459b5a3fdbb1096efdb9702ba49679d4e78a921188ac579b7045c009fd45d1dc36da80f828a0f5c921ff4e2d2a4a8ba592313d959664", contractAddress: "", cumulativeGasUsed: "1948812", gasUsed: "127644", confirmations: "3390928"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","327665596743345","2663","1000000000000000","100000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x2fa33b6c995714541b5f459b5a3fdbb1096efdb9702ba49679d4e78a921188ac","0x579b7045c009fd45d1dc36da80f828a0f5c921ff4e2d2a4a8ba592313d959664"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","327665596743345","2663","1000000000000000","100000000000000000"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","28"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x2fa33b6c995714541b5f459b5a3fdbb1096efdb9702ba49679d4e78a921188ac","0x579b7045c009fd45d1dc36da80f828a0f5c921ff4e2d2a4a8ba592313d959664"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1506565067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51185937469713801280627" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317829", timeStamp: "1506565067", hash: "0x36a99d812af9ff495fd070fa6b563d824ca18b9313709fefee8395f2d61ffe2a", nonce: "9", blockHash: "0xc7b1da8aa191e0448ccb2b0ab3eb8de251490fc4e78d654cdef0f16e435748f0", transactionIndex: "53", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a55000000000000000000000000000000000000000000000000023cddd184f14ca80000000000000000000000000000000000000000000000000000000000000a6b00000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000019d54c0a619d400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef04653a4511d607cb2f5ab5e5652da2331299c7438dea22ccd3e6079536ff993c05ee53583ea4c11397faa0c74667a4d9d8d8a6b1ed732fd054ba3e271fa1a12b4", contractAddress: "", cumulativeGasUsed: "2076584", gasUsed: "127772", confirmations: "3390928"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","161247578626804904","2667","1000000000000000","7271396986166592"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x4653a4511d607cb2f5ab5e5652da2331299c7438dea22ccd3e6079536ff993c0","0x5ee53583ea4c11397faa0c74667a4d9d8d8a6b1ed732fd054ba3e271fa1a12b4"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","161247578626804904","2667","1000000000000000","7271396986166592"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x4653a4511d607cb2f5ab5e5652da2331299c7438dea22ccd3e6079536ff993c0","0x5ee53583ea4c11397faa0c74667a4d9d8d8a6b1ed732fd054ba3e271fa1a12b4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1506565067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51185937469713801280627" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"360805444016500000\",\"32952500000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317829", timeStamp: "1506565067", hash: "0x810a42a2990333ad5f2615b759d4e25e214674ffb771b437e17ae67b39f09b09", nonce: "4", blockHash: "0xc7b1da8aa191e0448ccb2b0ab3eb8de251490fc4e78d654cdef0f16e435748f0", transactionIndex: "56", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef3435880000000000000000000000000000000000000000000000000501d6a3c3a16d200000000000000000000000000000000000000000000000002dbb146a801b2000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a55000000000000000000000000000000000000000000000000005d330094a5eaba0000000000000000000000000000000000000000000000000000000000000a6900000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000007a381900132bb50000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001b82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef01efa6352fd77e8232e74e5ade02b00235a4d2190cfa2f49f2b6c3c40afaed4101a014219cc386a678c739ef096cc6130a6992e2111529c6682ed594759e57e2c", contractAddress: "", cumulativeGasUsed: "3118738", gasUsed: "127516", confirmations: "3390928"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["360805444016500000","3295250000000000000","190000","2645","26233250421009082","2665","1000000000000000","34401627185294261"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[13]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x1efa6352fd77e8232e74e5ade02b00235a4d2190cfa2f49f2b6c3c40afaed410","0x1a014219cc386a678c739ef096cc6130a6992e2111529c6682ed594759e57e2c"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["360805444016500000","3295250000000000000","190000","2645","26233250421009082","2665","1000000000000000","34401627185294261"], [addressList[0],addressList[7],addressList[13],addressList[13]], ["27","27"], ["0x82faa14fc7f95f570f7cb410a86a0a87a7eed34002eb3c8b989613f383b25ace","0x04a98cd74772990e0b6576f593e01504f704995a030bbb1f0c6d4c087c0ddef0","0x1efa6352fd77e8232e74e5ade02b00235a4d2190cfa2f49f2b6c3c40afaed410","0x1a014219cc386a678c739ef096cc6130a6992e2111529c6682ed594759e57e2c"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1506565067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51186127469713801280627" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "4317947", timeStamp: "1506568554", hash: "0xb6a0d9dadd38183b888759545d2b2cd9ddc5aa5f415c5a519f714468ec6e147e", nonce: "0", blockHash: "0xfad76c1820bab6ee59e83ea83acf49253eee6354626746c39be77f8666f0e217", transactionIndex: "69", from: "0x0baf598c6e07d199fcc62bca2dbce243325f3fee", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "90000000000000000", gas: "200000", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "2944249", gasUsed: "64725", confirmations: "3390810"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1506568554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x0baf598c6e07d199fcc62bca2dbce243325f3fee"}, {name: "amount", type: "uint256", value: "90000000000000000"}, {name: "balance", type: "uint256", value: "90000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "97071525000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51187537469713801280627" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"9600000000000000\",\"8000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317951", timeStamp: "1506568727", hash: "0xd6c136c71349c9b7cf8fd06407b60527216ceaaf6145177820fc1e503f190680", nonce: "6", blockHash: "0xaf640f8a7a0237368818dba1f7d5b9fe3aa265158abdd8675ec81e0a98f273a9", transactionIndex: "110", from: "0xa6ce6213db97cdf3a37201fd5bd961c9725066d8", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef34358800000000000000000000000000000000000000000000000000221b262dd800000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000002e6300000000000000000000000000000000000000000000000000000000000000a7c00000000000000000000000000000000000000000000000000221b262dd8000000000000000000000000000000000000000000000000000000000000000000b100000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000141ab2a8709daaa0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000c01838dca02cc6129b68182d0e6fad16b7d9bdfc0000000000000000000000000baf598c6e07d199fcc62bca2dbce243325f3fee000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c49c7e1864804363e45b3cc38edf7c219fa76640cd62786a6c9ee804c2d68da6a015e83f6c83c1fd8ef90fa2dfc54e56c93146061fedf7b694969bf5721493700ab52aa9b95e61caad1250b395f19f065c0d85f3ab17eca64a594d4e41741fac24c2283babf15e717dd20d608791b7b36d9d158f153a692031c567af3b87b2443", contractAddress: "", cumulativeGasUsed: "6284474", gasUsed: "157260", confirmations: "3390806"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["9600000000000000","8000000000000000000","190000","2684","9600000000000000","177","1000000000000000","90541666666666666"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[0],addressList[7],addressList[13],addressList[14]]}, {type: "uint8[2]", name: "v", value: ["27","28"]}, {type: "bytes32[4]", name: "rs", value: ["0x49c7e1864804363e45b3cc38edf7c219fa76640cd62786a6c9ee804c2d68da6a","0x015e83f6c83c1fd8ef90fa2dfc54e56c93146061fedf7b694969bf5721493700","0xab52aa9b95e61caad1250b395f19f065c0d85f3ab17eca64a594d4e41741fac2","0x4c2283babf15e717dd20d608791b7b36d9d158f153a692031c567af3b87b2443"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["9600000000000000","8000000000000000000","190000","2684","9600000000000000","177","1000000000000000","90541666666666666"], [addressList[0],addressList[7],addressList[13],addressList[14]], ["27","28"], ["0x49c7e1864804363e45b3cc38edf7c219fa76640cd62786a6c9ee804c2d68da6a","0x015e83f6c83c1fd8ef90fa2dfc54e56c93146061fedf7b694969bf5721493700","0xab52aa9b95e61caad1250b395f19f065c0d85f3ab17eca64a594d4e41741fac2","0x4c2283babf15e717dd20d608791b7b36d9d158f153a692031c567af3b87b2443"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1506568727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51187537469713801280627" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: trade( [\"10000000000000000\",\"100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4317957", timeStamp: "1506569025", hash: "0x1e11084a699190eee41ed60f43aeeb8afca5b093c62ff0e8131c76ec8363b866", nonce: "5", blockHash: "0xf1f2505783d64ad639f7368a0415f79b52bd355309e0daf3e7cac96602864a5c", transactionIndex: "94", from: "0x992ce14aa2f6a56f57f10a6cbc33fea71088a751", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xef343588000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000002e63000000000000000000000000000000000000000000000000000000000000000b9000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000000bb00000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000001351609ff758000000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000baf598c6e07d199fcc62bca2dbce243325f3fee0000000000000000000000000baf598c6e07d199fcc62bca2dbce243325f3fee000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001bed350a4c6ab1e57c0318785614aa99913672acb8f39b22bee6300a8ed13add1f241b11c8afec89486b478ac2aff7d8604060bffd32e7b0e092dcbba5c3023feff7ef5952e1bb7e76072861fbfef63d1bd2726a1987aa983de0b8acab91bc655d7c6307a69e5ac8df0fec07e8cfa4d59206ec13583f78065f3b660b8c4aa2046d", contractAddress: "", cumulativeGasUsed: "4168883", gasUsed: "142132", confirmations: "3390800"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[8]", name: "tradeValues", value: ["10000000000000000","10000000000000000","190000","185","10000000000000000","187","1000000000000000","87000000000000000"]}, {type: "address[4]", name: "tradeAddresses", value: [addressList[7],addressList[0],addressList[14],addressList[14]]}, {type: "uint8[2]", name: "v", value: ["27","27"]}, {type: "bytes32[4]", name: "rs", value: ["0xed350a4c6ab1e57c0318785614aa99913672acb8f39b22bee6300a8ed13add1f","0x241b11c8afec89486b478ac2aff7d8604060bffd32e7b0e092dcbba5c3023fef","0xf7ef5952e1bb7e76072861fbfef63d1bd2726a1987aa983de0b8acab91bc655d","0x7c6307a69e5ac8df0fec07e8cfa4d59206ec13583f78065f3b660b8c4aa2046d"]}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(uint256[8],address[4],uint8[2],bytes32[4])" ]( ["10000000000000000","10000000000000000","190000","185","10000000000000000","187","1000000000000000","87000000000000000"], [addressList[7],addressList[0],addressList[14],addressList[14]], ["27","27"], ["0xed350a4c6ab1e57c0318785614aa99913672acb8f39b22bee6300a8ed13add1f","0x241b11c8afec89486b478ac2aff7d8604060bffd32e7b0e092dcbba5c3023fef","0xf7ef5952e1bb7e76072861fbfef63d1bd2726a1987aa983de0b8acab91bc655d","0x7c6307a69e5ac8df0fec07e8cfa4d59206ec13583f78065f3b660b8c4aa2046d"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1506569025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49800000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51187537469713801280627" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[7], \"1275656666666666672\",... )", async function( ) {
		const txOriginal = {blockNumber: "4317964", timeStamp: "1506569181", hash: "0x25048ade8bcef9054e09fe4ba0ce05578daf8471d8432690c631241b83465c8b", nonce: "10", blockHash: "0x29a0c203cf4dc0bed2cdeb8aedb5183537d800aa381a92f59badfbea02b33b9e", transactionIndex: "86", from: "0x9c536b0e7afb8a545b5a506244c95a92d9f8c3d9", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000000000000000000000000000011b40afac8068ab00000000000000000000000000baf598c6e07d199fcc62bca2dbce243325f3fee00000000000000000000000000000000000000000000000000000000000000bf000000000000000000000000000000000000000000000000000000000000001cb6e5b2c3de28e8f14cf3a53946e4910dd7951d997062e1b5da451c0bfc8d096d75e9ade723a3b296263b4473d7768bc90b4b61617e7ae6dcfb2639c16a0139b00000000000000000000000000000000000000000000000000010785f938f0a43", contractAddress: "", cumulativeGasUsed: "3099678", gasUsed: "158720", confirmations: "3390793"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[7]}, {type: "uint256", name: "amount", value: "1275656666666666672"}, {type: "address", name: "user", value: addressList[14]}, {type: "uint256", name: "nonce", value: "191"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xb6e5b2c3de28e8f14cf3a53946e4910dd7951d997062e1b5da451c0bfc8d096d"}, {type: "bytes32", name: "s", value: "0x75e9ade723a3b296263b4473d7768bc90b4b61617e7ae6dcfb2639c16a0139b0"}, {type: "uint256", name: "feeWithdrawal", value: "4635951520221763"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[7], "1275656666666666672", addressList[14], "191", "28", "0xb6e5b2c3de28e8f14cf3a53946e4910dd7951d997062e1b5da451c0bfc8d096d", "0x75e9ade723a3b296263b4473d7768bc90b4b61617e7ae6dcfb2639c16a0139b0", "4635951520221763", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1506569181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x744d70fdbe2ba4cf95131626614a1763df805b9e"}, {name: "user", type: "address", value: "0x0baf598c6e07d199fcc62bca2dbce243325f3fee"}, {name: "amount", type: "uint256", value: "1269742784203552311"}, {name: "balance", type: "uint256", value: "6000000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "71417300000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51129016515987741853174" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: adminWithdraw( addressList[0], \"9530000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "4317964", timeStamp: "1506569181", hash: "0xb3904b1c80897ac174a4419451fb2c7c153d98cb98c1b8dfa8b6e268a263f375", nonce: "5", blockHash: "0x29a0c203cf4dc0bed2cdeb8aedb5183537d800aa381a92f59badfbea02b33b9e", transactionIndex: "90", from: "0x6f642280fa98c0ddfc6fb6f078b91b89df3914ca", to: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208", value: "0", gas: "290000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x2295115b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000021db7c08b5a0000000000000000000000000000baf598c6e07d199fcc62bca2dbce243325f3fee00000000000000000000000000000000000000000000000000000000000000bd000000000000000000000000000000000000000000000000000000000000001c4d5bc71af11e4ec621324e7951297b9af90fb48ab88f54ecb2bfaa63b37aa73a21c0e35a5d319db481c6e96a7ed27888b8790ffc1177818a2884b6158aec630300000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "4554256", gasUsed: "82685", confirmations: "3390793"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[0]}, {type: "uint256", name: "amount", value: "9530000000000000"}, {type: "address", name: "user", value: addressList[14]}, {type: "uint256", name: "nonce", value: "189"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x4d5bc71af11e4ec621324e7951297b9af90fb48ab88f54ecb2bfaa63b37aa73a"}, {type: "bytes32", name: "s", value: "0x21c0e35a5d319db481c6e96a7ed27888b8790ffc1177818a2884b6158aec6303"}, {type: "uint256", name: "feeWithdrawal", value: "50000000000000000"}], name: "adminWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)" ]( addressList[0], "9530000000000000", addressList[14], "189", "28", "0x4d5bc71af11e4ec621324e7951297b9af90fb48ab88f54ecb2bfaa63b37aa73a", "0x21c0e35a5d319db481c6e96a7ed27888b8790ffc1177818a2884b6158aec6303", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1506569181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x0baf598c6e07d199fcc62bca2dbce243325f3fee"}, {name: "amount", type: "uint256", value: "9053500000000000"}, {name: "balance", type: "uint256", value: "70000000000000000"}], address: "0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "79584720605900000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51130816515987741853174" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
