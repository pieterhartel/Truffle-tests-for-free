const airPort = artifacts.require( "./airPort.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "airPort" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4b71AD9C1A84b9B643aa54FdD66E2deC96E8b152", "0xAd8bc819BACeE51760C01501E7760cD6913de9Ae", "0x5d07DD9FC10C2cb223dfa0F1ddaA889e4ceff2b5", "0xEf266E135E0E11ec49C37f910c0A12dC99758323", "0x81aA82c94Be994fD72355Cc239d0e91d6186E2Ea", "0xd320928dc84091B16Fa9A52bA15Eec1b9E76cFbb", "0xb8f87887F4CcC557865C6a16fca4ECE4D2084Dc2", "0x2B5006D3DcE09DAfEC33Bfd08ebEc9327f1612D8", "0xaD83A37c7B7993A3443fdE7164199A1e0A62613D", "0x2819c144D5946404C0516B6f817a960dB37D4929", "0x3734aC31544D081B78503c6348d6dc310C7dADC7", "0xB96b78d32DAE7bB0AE3A847758841A9f1b513A9F", "0x0bd5d9B6F8e0A380E0a060E3C541f98B61ab827F", "0x91ADf14f4C0782634E04Dfc6e9Be16d950AA4daA", "0xD3273EBa07248020bf98A8B560ec1576a612102F", "0x5BCbdfB6cc624b959c39A2D16110D1f2D9204F72", "0x532017b238c7bAab39c6B789A27bbcA687b66C7B", "0x0C9D732967C472F5dE12Aa82Fa2641B0e9Fb0734", "0x457F6120FF2c2344DDD8e747107AB4E38E242363", "0x008024771614F4290696B63ba3Dd3a1ceB34d4d9", "0x22eF069b693b8e4Ca65c73f8A88178D816f5eEF9", "0xE2D185A469777a5cd55edC2a78e75dBd84970437", "0xAeEc6f5aCA72F3A005af1B3420ab8c8c7009BaC8", "0x3052cD6BF951449A984fe4B5a38B46AEF9455c8E", "0xE70296FBdb7b18AdEFb88F3Fef504d2FA1a16a09", "0xf646CBe3B030fb6c2569215F0117dbA58baDB95E", "0xE8613be0178c625e7f2325348D98DFb8A7Be5C59", "0xF4a2eFf88a408ff4c4550148151c33c93442619e", "0x356439D46a046A7e8aE767a92D51C2EA4F1F723b", "0x073903b967e40FF9f1190DF3adAd3929A5d3903f", "0xb3AAAae47070264f3595c5032eE94b620A583a39", "0xB6AaC3b56FF818496B747EA57fCBe42A9aae6218", "0x8271B2E8CBe29396e9563229030c89679B9470db", "0x19df7D24370A98D819CC4DaA80192A8a227a08A9", "0xB9760F9755bBE8310482c9eFDe8dE5eCf6939cEb", "0x62600d264c2F76b40469b6d55f357361B0229469", "0xFb3fefEc0E025D5e6883F750929aA5FD0582DBf3", "0x3695627c5620b707f6f050d8BE2f4D86AD332765", "0x070F3492CD778CfC3DbAd6D25Bfb3bCbB498298b", "0x11e52c75998fe2E7928B191bfc5B25937Ca16741", "0x22F14Cb872871a37B1d981B342B865F8A31fbAF9", "0x5768e444cAb65831FF16Eff46a85237C92ef5dDF", "0x825D5D0dF3B2D59f69CC673F041ca91A296b8183", "0xebD5fd8A5A81B2e7128c69F1A8511184Da6B6f94", "0xbB1b61089321ad51369C8327fE23D04aDa2ED746", "0xc951D3463EbBa4e9Ec8dDfe1f42bc5895C46eC8f", "0xd7053Daa42729d66cf4f7921298550f95123a965", "0xEB645819ee33AdE920C7ee775a77062e92Ef9116", "0xef764BAC8a438E7E498c2E5fcCf0f174c3E3F8dB", "0xFaeB12396529A30E7F4E74aDa8d01FCCa0c8Ffd0", "0xfbF9320B5C7e08199008A926A3F911877327DaBF", "0xFD26f25d6588b752a90e600AFF038A654D64a42C", "0x1C870c98ef9Eca9abdE6ebeA1f542e685e76C95A", "0xda2101021A7937e4C12036205F16694eF1e7a3C0", "0xE3314bbF3334228b257779E28228CfB86fA4261B", "0xE4fBBFec7C8c5718cCd8c1CeD82C72aCb05BeDBf", "0x73957709695E73Fd175582105c44743CF0fB6f2f", "0x994A109E48861d5241C30d745eFDd25791f98788", "0x57b9B843B7E8A09CFfBDac5B86BE0649D4880F33", "0xF1E9F20839eF5fa8bf093833937c54A9B930cbE0", "0x5Ad4864d36F7fE63F657A6E862117F688D263F3d", "0xc837F51A0eFa33F8ECA03570e3D01a4B2CF97FfD", "0xF9c9ef9A9A494aDfF0AB70cf29D7A48DEc3C6169", "0xC78bd238DcB0FE7d928033973Bc42b5E3a11C841", "0xFC61863066783137904a760Caa2C654e389626ce", "0x1a6db538813Dbfa63E1F19f8804447187B7D401d", "0x8F0dA283B796B3F72391120c76cD04c0ceBAA895", "0x8f7131da7c374566aD3084049d4E1806Ed183a27", "0xd839f75fdf7a6Db762a1c46f7a33305f850BaB22", "0xDb59f29F7242989A3eDA271483b89E1F74353FFA", "0xf389695d89F3782E1b588b4D46061Ae1356B17a9", "0x1D1E7AbFFE36D3ccC84866FBcEc8Ac050AE19D1A", "0x4F86602783Ad7a81584dAE05187136b2E4fdcFaa", "0xAF898fc38e04824985bDD9b461b71Cc4e0363646", "0xBD575402e18DDA5a97ff4875A40344d9498e0936", "0xC91eA14b75B6735AaaF9b4Bc5a927793a0A0cB55", "0xECBb3B7aEEFA9F1bb932E29CC5fb2aa6c350f0A1", "0xf8FD7ce0fe9D279Fb6F79fECb3E56DDC49cDEcd1", "0x4Cc34cC03fb09119Bef8e9c49e6A95B3F70608Be", "0xD635519Df9a25cDFdaEe3ffFFB4E11EfA759f702", "0xd6dAFcE429CB878549eC8E357C2aA2606FB4fCb1", "0x136D0159Be4313a5BDd38C5c8b5CEf8dcFf15FC8", "0x8Da4F82Dc4D03c5421BB2087F858750c650d8571", "0x93811dabfbeE9736035025cBa91491d7747cfD47", "0x01796395624b9ebaA46fC4FCc9F5F0C02175F81B", "0x0e70FD4ea2A0063396feD52a999d64F661774BE2", "0xEA1c2d9b52C61F4E716eb028f7Bc38F78E473eAB", "0xfbE00d5fd051a5b1753A673E268277552F8d9d92", "0x44AAf38296A6E28E3A92A70B034586aBaB0de5a2", "0xa43d3CFaF7A968d008e693D193d892c3474622CC", "0xCc48857242141CC7F4f8555f8a3d5bED03556C19", "0xe6EcB12EC9a52364f94C8a86aD7274f4b2eDC102", "0xC65267Eb245E32dDAB67d2e9eE172ccb1C65B33e", "0xe86F917DeC14F5bdC2E43DAB57d6fD57a29894Bf", "0xF50e790c7061eb704cDA1Dc10b3Ce5AB66dF8499", "0xf8AbA22dC7BbF6B7f5AC2c7EB868543e9D26aA8c", "0x6C7DFE3c255a098Ea031f334436DD50345cFC737", "0x7f3EaB3491Ed282197038F1B89CA33D7e5ADffBa", "0xE885b22c7365170097D76eE951788040C148791C", "0x9A929aD23801a568147b56924012c6693F8EFD74", "0xa0F3fD8B953aFd6cBE7fd3d4fc1C172e492fA78B", "0x2194598273bFf7F3329de61F9D66296E093cB9F4", "0x907e272d23B018A947E24aA54cE3aDA7C67c5901", "0x724d5aaC1E4348A4c76a66d43fDEf13a0664682E", "0xA88854B6dC33F0F3B495A12C1463BBa763bD93f5", "0x00e695c5d7B2f6a2E83E1B34db1390f89E2741eF", "0x34855ef0B9D89bc6664D520B85AA13db27e95E0b", "0x4ddD987e2BED1069c75b9a1A6598824917815729", "0xfC164e97Df905733Bc076015722CABDfdE0bDf61", "0x83DA070858f10CeF26f25FBf8Eb14A94C9fcb4bf", "0x26Ef1f5C2A4E107bF773f63D93600F3e9860eD5C", "0x833362cff67F8eFd57Cb1bc2793dCE3F1Cf0606B", "0xa18E8b52d4A989527567c77566C0e91c792AbaDE", "0xF6BfB9d185d24B43058904Af58C47A7A0D13D171", "0x21cDbe59C11b3909e0A9bbC2f4F42697a9a3Dc82", "0x9Ce143C1F248Dc731a636E933b804E9e6fa3B273", "0x9974e44E8747b615187378Bd35BaE7acb832ebDf", "0x537B8adCb07E9353d05149b42c84EaDa3c49dcc5", "0x21756f6Fe9CD0AdAc8CdfF57D7b1683f4e371A1d", "0x0832c3B801319b62aB1D3535615d1fe9aFc3397A", "0x357885dEc2beD57974e27F53019A61F8B9DE09b8", "0x55A72Ef1dce9C06B7B37e4465ff27DF758eD0410", "0x0dBb74Cd877E3D9d98ad1298f571CD246114c502", "0x00048dA2440e53FB45Fe36fcedC389262F35963B", "0x9275C3FF46E9e0eC80a21e87b33C9aa3822dD838", "0xFf190c5F451b218456db6272952236b6C29F7033", "0xaE1911fC6CBDC9560Cbcd5D5147bcddEf74019f4", "0xa45ae9007b190fb42555976CE7464d614755d1A5", "0x20c61D2DFc6cb4E1735C77505efc0C342Aa652BA", "0x00260008a7373283c27fC9C36DA04eE7f0D72266", "0x0819743FE98dfc6b5604672bba5473c9Ad660B97", "0x16A23A3EfB88af5262Db610fc70D4253FEE57fCc", "0x0ee1f25db20dE733AC34bfFc642aD2c610Eb89c9", "0xda462107Ac0DC4222104EbC055D3D0DA31158E57", "0xC7EF92c6001Cfb326b69C00c1c5d4bEe6c215672", "0x84f01B473e903F661017632839d1bD28eF44cDdC", "0x9cD2C1A0Cec4ad21564aB538Cad7F856daacBcBf", "0x7C4922462CB592B87658a403A0F5c65dff3a6Ff1", "0x0Bef682299D37372AcC26111fbA266E11eb26c7A", "0x61F20a468952000657453FE3579AaeB445eFf87c", "0xd540b55E0010684b2CaCc819aB82a616b938Dc70", "0xe6235bD7eb9376e3BC38956CBd20E605eCAaC241", "0x9D14a29D7367c4B24685aC010A5E6794d43f1Ac9", "0xaf4e95D5EDc9258B15ACaA1d4488A7d13CDA57F5", "0xfcfE293d86ce3a138AbE1e50e217D84C55EFbb32", "0x1960f48D9690640828359a3D64B9F12666DC9dE8", "0x98ca9C5F410B530f87C4Bfd7Becea177d9b889C9", "0x6A140A89d50f891F4fA21bD315F5Bd26B890FB6e", "0x5c5Acfe5Ad29Fc0732384af304CAB2E4Cf8E5074", "0x99226A1EF791699e863CeF8b2A7622d7a97EB120", "0x817b43d93D1706add8fc28502446DF74bb5b3b1B", "0xED9f942c41d71a3658a8Ad5572EEEA551Ccc893f", "0x94AE196506182630120C2B13Afdb76bf9BB04715", "0x210510845BdeBA73eeF16c158dBA800cC14FD054", "0x97fbE749544656b826892c9296c4e46668532e0e", "0x45d9eE2cB1C8eF0C947A9b62d877C034d3bFBbC2", "0x564755A019940966E6cad2DC27efC2e5b29f1d10", "0x86d61Ef8212A938C66560c5A03780a44b85B5404", "0xAF3eF2434F5081c6E86f53f9B38d0188581da23D", "0x309Dc0Df4d19DB22E1616422bD109F9712c92D26", "0x3F8860b846635417A5bD35B5E01D105d677cc119", "0xdd26CE271A9C94adC51388F840431600a6c73370", "0x00ba72Ec3944495C21f16F9E29320850F67353Fd", "0x2dD853C6E6093Bdf0a386fb7f6A4c90cE456Eb9b", "0xB845E487D68eC6C9f74752776C74846cAd78735e", "0x48e9346cbaaD16731d0cd9Ddb660F6056cEE928d", "0x84EAA9a6a8E42696790289480314e2Fca8f38581", "0x915d7915f2b469bb654A7D903A5d4417Cb8eA7Df", "0xCb6a4FeFE2A1eE270D4124599C021De6f58E15Dc", "0x779959CfB3859F12ec80Da6E7ce12305Bc594Dd8", "0x6D0AcdD986b7589295A43C91B95fd1F26Fbc59F6", "0xb0978E34a808E7A457bDB436Eaf3a6e5917025aa", "0x156e4E29Dcb7877c89225aE969cda06e4534f545", "0x8Cb1AB736459BA518Ac391fb8E3b4855F1AAee05", "0xe19133A469c87FcF3c1B43A2686b27b4bD2188B2", "0xF6D44482c95190cAeBb37b31CaF57cf6b5315Bd1", "0x463Ea350609fd0970A6Db09E7e27a3BEEe4F2717", "0x01bFaE6659C4aCD4a077B07c53a61008E6028BA5", "0x58E90F6e19563CE82C4A0010CEcE699B3e1a6723", "0x8d9DF8EA8c6730dE05a36E8a082D471Bd51cd9ff", "0x8c30c6c7d386a7d87683F087ff839d10aB55f121", "0x9222E68CaAF97b66201c03526b3257410b2fBdD8", "0xBfaD148cB4282635026723B366E5d1AaDB3064D6", "0xaa5e57a1A92Cb025bdfa6B31E63D6BF090172490", "0xc5554bB95185773a047388f3b47056BC48Bc00e1", "0xD6Ee0260C1202eCDc6C89CDE12F1745E035F1B85", "0x27ADDe789bFCcAA06c4f97D241BE6CC7AF257986", "0x6fF37dd1402a1ed9E7356F48371F1eA16e8854d8", "0xF3AbE885Bb5583BFC4AEA54a0c38ACad582636a7", "0x3c7a29cB8D87bBBEe9E04Ca56148Ca0246D158F0", "0xf1AC6A2A16a3210f74B03DE2588FE672A93844Aa", "0xf340f3375CBDcfC1CA4139b098dB30734413FA38", "0xFD5D7E73Ae98652Deeb48935B87A9e04fF2BC00E", "0x3E01Ab3CA9e3Cffa877dd3C098582892bE107C72", "0xc65f4ceA1F643dd675388b04d51C999C6730Aa80", "0x93DC2FB3A037e103B8a01304a62c2697F00a3677", "0x1FcFD25B25CcEaD63665CF867f4F7CBa3e75dE64", "0x0B0eFad4aE088a88fFDC50BCe5Fb63c6936b9220", "0x0E546196b921528e20e770fc39f1cca104796d39", "0x2F145AA0a439Fa15e02415e035aaF9fDbDeCaBD5", "0x6235dC1C5D929C1841d6545Af877EF83Fecd976d", "0x6c5D0d9eb1243903775ffDbc8f5d29B04CE3670D", "0x096012EB44CE0eF1DC2d9833757cB32D2C50E0B6", "0xAd97B225134339a51cD25e53af031dceF596eF7c", "0xC2aD849ae4bA0b05aeE73bbE3ea6787e01a530aE", "0x63D58Cdad68A67493DaE909ed7a93d2008Dcc833", "0x221287cb305A0A4C2Bcbb00ecAA308990bE3792C", "0xF1aa56EaFcA468184f871941ADF43C78017eA0e5", "0x065604edDD94350df7aF9E45B5376e10F0A0eea0", "0x56db1BEC835F62035467ceF4112BFdDb816c1064", "0x740dcedE05469dccBABb0B0258A5532Af10c2CDe", "0xdc07442fFC911Bb499145baC53aAac78543fED4B", "0x707dd79bcfE97689f987Fb7d17e29B76Bb51eEf8", "0x65d52727C5f7C596FB375EcF1bFDd5156a5aCBf8", "0x4523E948188C09abc65EE730F1517bfBBDBCFa76", "0x0d54899389483e03d170bB190b16Bdae832CB38C", "0x1529d2e640F7febD3e9DC40728cAc060a2739d70", "0x1de07b8c3999c355B4dD160B39044118616A4F9d", "0x1768F5c8BF5000377aF023e7E2630bC17c978AdC", "0x18c52Bb439e58549333A2a65ba3C69209142E331", "0xe6786f0066B38af62f0aA4b2fd8568AFd6555dc0", "0x1B87C2a6058BC88548Bc9bB18b0717f939B2CCB3", "0xE0Fb8097BAE257a9f58cf2fd85fDC671399f6dD6", "0x538D74f89Ca2BF84221275DD530862B33a9dBfdE", "0x65B7A73A85B87439ae353638C75b4585163B92f6", "0x85f94Ce524e9AD88d62eb370A7c37b4F808DC3a8", "0x08b41B878177618aD88738c67A48D64Db8422BC2", "0x2615A4447515D97640E43ccbbF47E003F55eB18C", "0xAdcc19C8873193223460F67552ddec01C16CE32E", "0xA6BA44E4CD560CEa455236310446273148aB76D5", "0x12B2398405f49dEc00D7ceEF9C0925e6fc96c51F", "0x7406047D76c57e5B6E67D2fa54f264AF46EC354c", "0xAd685e9CD97b0e2b81C32a8B4e5Ef48Eb183afa2", "0xa42015Da9E346E4c9F2CA5bB71b9D1a885810713", "0xcB88EaA745843Fc36b95cf561fbc37d35F1249D9", "0x3490Ae3a80d122c759F77FFD78C35c25d9701059", "0xB74D5f0a81Ce99aC1857133E489bC2b4954935fF", "0x10aAa246861B94Fc22B3595E89a91da6e752113d", "0xaBE6970e7E21709A3FE21888C65f3F542d3fdEf2", "0x2d0d94b819f1a8DFf358AB3B858CCDB6f40EacBB", "0x09475262c6a1ffBeDd480d2a15f35F978AaaAc38", "0x780e57D8e8dc688f00a68f966538b2fbE1c898F7", "0x3E2686364FF660AdB98B869B4D786D8f06eC1134", "0x21B67fc23f0CbeF46f9c7612D361Cc42c580f9a7", "0x0dF3Dc2eB13aB4784a17D7bfA19aD61585117554", "0x8470A1f8dFDE074EEF6178D559a4412F088848c8", "0xd806c99545a0774CC83F8B1B7E0547fc86c12c75", "0xaa5f9414628E7A4D8e0829477fa0905C394A4Dae", "0x863A492D7DEdB65775452177f0D0594e75947289", "0x3E02d9233e9D6F1FC9c5fD247673526E1AeA56B3", "0xD6b273Bc1A91b8043d3ff526e85e33e5aBcF4Ee0", "0x0d68C987EDb915cC729cD754788205D5BFA5F9da", "0xCa2DE788045117f1a86378A339Ead08e33A896EC", "0x9ddDE2f8a72B0511d68fd45083AC3BC004Fb61eE", "0xA7c05879B3240dBC1eE89fb45Da508e8C6c4d42F", "0x3B58236269a2474A31DBA3AfCA95D8cb9CbD7f42", "0x8feDBaa4Ac2b5489C475F0f2894633D302e8863a", "0xbf7ae4fd867c45EE890b59caae8B8FBdF2eE0141", "0xD079f70a23F61FA6696Ec55C2fdDA1a93a99bCd3", "0x1d6ac538FB080cbCF4cBac176bED49801825263d", "0x76929fd49547660cF33580105faaBdB656F921e9", "0xCDafd58ABfD612a2522578D6422b774a5906607D", "0xe793CDd15AeDEFE3B8AE875D8103cf433B43c228", "0x8891dF7757aDE4334ACD9a3B1a834fcDFDE6866e", "0xc380A543A0376ff32baC8e2AcA3d100838F16AFF", "0x5dc93865F311B60FBBF9eA1Bdabe0991A84704Be", "0x40aee50293Fb801d5E80990cB9f6a049935358C9", "0xe88DB5c82Ebe225290e98B5D0bbB7bFC59e265ca", "0x5BFEF649a100D3Fc56518f4fF86eF15904354d28", "0x4474b406b9Ae231Cf0dBD150724b00411328a8eE", "0x42980c931C7c001B2766Cc0f1061542F29e3133E", "0x467e45a86793373a4c1D107C4A4d66f2854D82aa", "0x4C3EB0AA279A5029b131f976e2ae8a5AddF2eb73", "0x390F523604b11e6E71F23B9F8A2055d0316F48CD", "0x0EE2289f611A43205796E10Ee00b5415dF2FCbdc", "0x26976E2722C24d66F87b717efe552cDAaA5b5cB9", "0x0e124d607618CDe134792218577f74Ea2DC1f84a", "0xf500fBaa9b1db9502fccAeF8BBd328A3f95FB4f5", "0xD0CA0fE6C4fA002a05F8890eFC700c084d7c3D90", "0xb464e62733760D3Efa8deD234cF3cBFBB93f99FA", "0x448A380e3ed48dE270972fa9B37fa6F687210bfC", "0xdEbC63e1439cB047F40e1221f693247BF3CC9Da8", "0x24172298409301B930dB14313872610bd753d289", "0x8c070C3c66F62E34bAe561951450f15f3256f67c", "0x3eFAdeDBb2e003096FD3df28cceAf83c6fb4575D", "0x384764c63f0Cb05ff28D561185aD488e4b92F0f5", "0x6696FeE394bB224D0154EA6b58737dCa827e1960", "0x9eFaF68852540264c38C5b080C1C8A8dc88E2438", "0x938d724cdB7193b2c52c1F5aA302162d28386B39", "0x7E31a2e6ed37DE31C23DB014977b1Aba0B8A8Dd8", "0x18E3C1AC5DfA88442784492d3647A887A870b570", "0x0f7981ae60708d4d64040999E463F106B13F07C5", "0x4Ff135b36C5C2c545BEcD3385465D187B1c6dB16", "0xcb1F38892d4e2255023D382C2deDc8c00f7A4561", "0x3EfF47E197AcA394A2C238F62ed7477CAD76874a", "0x58B256ca58cb4763E0dB53A546C29e1A72c3C553", "0x581704DA7A14795Ed6a9B729cd768B5d51040194", "0xAE8FA113945a1c94BeC32710349Ee5979dD78dCa", "0x14d5AfC53F204c8fC3A79Bf262cCdef500Df10D8", "0xBf2E12Ed9C22b29CfA9ea18C4bF44C22164B298c", "0xE1a2CABFc6412BEC651FCD7DBBAD0266b6d78d1b", "0x0fB72c9b937a6C5f5dF77B3BC2e26bF1fEF34A8F", "0x6B00fC495373E9317d62767E66Bdf813699f348b", "0xdB856e59b077f9d2548719a71e549a7B61cB78E3", "0x7Ef5d02356f779170B49Ba2bcbac3a9105FB10d1", "0x5346C93f25e5c7318EE3c661803C15B50Ae336FF", "0x33878bE6ef5eb13f8e5B74d2A820818432573d02", "0x7859a4Fe801Ee2473a5f2f0E6ad37Ed266910357", "0x459bda693fD135934C608Ddc8e40FaA6Ac9a50a9", "0xD410568A668477071515F83FF1782E5CD44A39B6", "0x67361ADEaE382a4f578048c2955042e82C1764f3", "0x03e48b45542b60685e460A7580D3baFc3bF5A1b3", "0x4D89f686432C3BDB233F8734dc2E4fFE635fCe02", "0xCc13d110aD46E470C3B83CEbe4681cdca16A0f8f", "0xD68799d443d7ab8037546B42F0162C084e1f0698", "0xCB6B5F12f152f41D8a6140726AfD928C8b6955f9", "0xDC3AC3eB514a765F6EF5e22afA09740832759758", "0x479857E049b20c5884C81E4dcedF4ba6F2b82b48", "0x2B9c9F432e9894F824Cb2626aF6f772460bC0DcC", "0x65258528ff01daB7d56f248D5e45D6ef535dC8d3", "0x8167e7B57F88EE5B85EE0B10AAa18788D00DFEE9", "0x986dA653865f9C70A76d395F0605bcc32837d971", "0xC83a458484228dC417C20Cc8616787481359EE97", "0x41fb25057A38916eD8B6b3f15dDec6a68862033E"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = [] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = [] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 23 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6586103 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6745743 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "airPort", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
}

contract( "airPort", function( accounts ) {

	it( "TEST: airPort(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6586103", blockHash: "0x74959c440d35d20344ee7c2357a642e7e88265af0e2c977c67d03fd6ca07a205", timeStamp: "1540544404", hash: "0x2ed5cab62fd732f01ff03d232b5ca94dcea752e1b66bb7247efe337c35121197", nonce: "228", transactionIndex: "54", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: 0, value: "0", gas: "208921", gasPrice: "12000000000", input: "0x7ae9d98f", contractAddress: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", cumulativeGasUsed: "2349409", txreceipt_status: "1", gasUsed: "208921", confirmations: "1150596", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "airPort", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = airPort.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540544404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = airPort.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], addressList[5], [address... )", async function( ) {
		const txOriginal = {blockNumber: "6586218", blockHash: "0x5736c23ae60680bfd8e64c4714d42e82b9f33d1670a81bb8f401823490b6f944", timeStamp: "1540546087", hash: "0x1b86bc6751bac1ee18517e79ccce1aeb59ab92c41348deb72486c6b05c527e15", nonce: "61", transactionIndex: "105", from: "0x5d07dd9fc10c2cb223dfa0f1ddaa889e4ceff2b5", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "226312", gasPrice: "10000000000", input: "0x1561ae310000000000000000000000005d07dd9fc10c2cb223dfa0f1ddaa889e4ceff2b5000000000000000000000000ef266e135e0e11ec49c37f910c0a12dc9975832300000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000400000000000000000000000081aa82c94be994fd72355cc239d0e91d6186e2ea000000000000000000000000d320928dc84091b16fa9a52ba15eec1b9e76cfbb000000000000000000000000b8f87887f4ccc557865c6a16fca4ece4d2084dc20000000000000000000000002b5006d3dce09dafec33bfd08ebec9327f1612d8", contractAddress: "", cumulativeGasUsed: "4725290", txreceipt_status: "1", gasUsed: "176976", confirmations: "1150481", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "caddress", value: addressList[5]}, {type: "address[]", name: "_tos", value: [addressList[6],addressList[7],addressList[8],addressList[9]]}, {type: "uint256", name: "v", value: "20"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[4], addressList[5], [addressList[6],addressList[7],addressList[8],addressList[9]], "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540546087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "601393963468424231" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], addressList[5], [address... )", async function( ) {
		const txOriginal = {blockNumber: "6586226", blockHash: "0x18d8eee46dadbd0f8d8cbcbd66f0c3e866c3f62f0a9b1e09663aa8155687f75c", timeStamp: "1540546172", hash: "0x83ac808b9d9c067c363c2502afe064d6ea64c33a31d2463d450ff8b1c7c3856f", nonce: "62", transactionIndex: "40", from: "0x5d07dd9fc10c2cb223dfa0f1ddaa889e4ceff2b5", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "259004", gasPrice: "10000000000", input: "0x1561ae310000000000000000000000005d07dd9fc10c2cb223dfa0f1ddaa889e4ceff2b5000000000000000000000000ef266e135e0e11ec49c37f910c0a12dc9975832300000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000077359400000000000000000000000000000000000000000000000000000000000000000400000000000000000000000081aa82c94be994fd72355cc239d0e91d6186e2ea000000000000000000000000d320928dc84091b16fa9a52ba15eec1b9e76cfbb000000000000000000000000b8f87887f4ccc557865c6a16fca4ece4d2084dc20000000000000000000000002b5006d3dce09dafec33bfd08ebec9327f1612d8", contractAddress: "", cumulativeGasUsed: "4172996", txreceipt_status: "1", gasUsed: "117104", confirmations: "1150473", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[4]}, {type: "address", name: "caddress", value: addressList[5]}, {type: "address[]", name: "_tos", value: [addressList[6],addressList[7],addressList[8],addressList[9]]}, {type: "uint256", name: "v", value: "2000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[4], addressList[5], [addressList[6],addressList[7],addressList[8],addressList[9]], "2000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540546172 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "601393963468424231" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616470", blockHash: "0x7334738a26648f0056e10930a1068a8b2c9a85dc518cbdd5b9b857ac1e2b23ac", timeStamp: "1540973482", hash: "0xbf2c35c46a15e4d29624ae062bfd6535a5e538896d932b6bff6b65d0df883703", nonce: "302", transactionIndex: "155", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "163210", gasPrice: "5000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000040000000000000000000000002819c144d5946404c0516b6f817a960db37d49290000000000000000000000003734ac31544d081b78503c6348d6dc310c7dadc7000000000000000000000000b96b78d32dae7bb0ae3a847758841a9f1b513a9f0000000000000000000000000bd5d9b6f8e0a380e0a060e3c541f98b61ab827f", contractAddress: "", cumulativeGasUsed: "7174967", txreceipt_status: "1", gasUsed: "42140", confirmations: "1120229", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[11],addressList[12],addressList[13],addressList[14]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[11],addressList[12],addressList[13],addressList[14]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540973482 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616483", blockHash: "0x376acfff0d241d51b1ea39a4fee2be1e3bccf1f538ff1ebd9ab3bf21b9145d5b", timeStamp: "1540973614", hash: "0x8c25ce27d56db8a5f61d222ac283637231a7542dbf57e1703b2ded1d7eafc2d3", nonce: "303", transactionIndex: "71", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "50767", gasPrice: "6000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000020000000000000000000000002819c144d5946404c0516b6f817a960db37d49290000000000000000000000003734ac31544d081b78503c6348d6dc310c7dadc7", contractAddress: "", cumulativeGasUsed: "6133254", txreceipt_status: "1", gasUsed: "33838", confirmations: "1120216", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[11],addressList[12]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[11],addressList[12]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540973614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616503", blockHash: "0xd783f9c914cb7c94cd0f4fc9f3b514c8b1240e870203cb178ad303a37faf4b73", timeStamp: "1540973894", hash: "0xc74f782703fad2480425e299bcb5b16903052343cf9bda24175087d65dc985d0", nonce: "305", transactionIndex: "154", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "226600", gasPrice: "8000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000040000000000000000000000002819c144d5946404c0516b6f817a960db37d49290000000000000000000000003734ac31544d081b78503c6348d6dc310c7dadc7000000000000000000000000b96b78d32dae7bb0ae3a847758841a9f1b513a9f0000000000000000000000000bd5d9b6f8e0a380e0a060e3c541f98b61ab827f", contractAddress: "", cumulativeGasUsed: "6066993", txreceipt_status: "1", gasUsed: "177168", confirmations: "1120196", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[11],addressList[12],addressList[13],addressList[14]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[11],addressList[12],addressList[13],addressList[14]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540973894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616541", blockHash: "0x0e7c4fc52f971be4c50a2fe8fe019cd81b66306979cdda0ee55456b072e08bf3", timeStamp: "1540974401", hash: "0xe8b7bec553711a6abd786ebbd82199355b167372f000acff29d32ebe54fb0552", nonce: "306", transactionIndex: "27", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "567676", gasPrice: "5000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000091adf14f4c0782634e04dfc6e9be16d950aa4daa000000000000000000000000d3273eba07248020bf98a8b560ec1576a612102f0000000000000000000000005bcbdfb6cc624b959c39a2d16110d1f2d9204f72000000000000000000000000532017b238c7baab39c6b789a27bbca687b66c7b0000000000000000000000000c9d732967c472f5de12aa82fa2641b0e9fb0734000000000000000000000000457f6120ff2c2344ddd8e747107ab4e38e242363000000000000000000000000008024771614f4290696b63ba3dd3a1ceb34d4d900000000000000000000000022ef069b693b8e4ca65c73f8a88178d816f5eef9000000000000000000000000e2d185a469777a5cd55edc2a78e75dbd84970437000000000000000000000000aeec6f5aca72f3a005af1b3420ab8c8c7009bac8", contractAddress: "", cumulativeGasUsed: "6250058", txreceipt_status: "1", gasUsed: "404552", confirmations: "1120158", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540974401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616554", blockHash: "0x68d576def9ba60a48702e857fdc0f5e301e3993fa871faf65628ef20dd99874b", timeStamp: "1540974540", hash: "0xf25a585f68cc10ca8307e9a0741004b4a94f6f4a2340b47389d73e565d97929d", nonce: "307", transactionIndex: "94", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "636496", gasPrice: "10000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000003052cd6bf951449a984fe4b5a38b46aef9455c8e000000000000000000000000e70296fbdb7b18adefb88f3fef504d2fa1a16a09000000000000000000000000f646cbe3b030fb6c2569215f0117dba58badb95e000000000000000000000000e8613be0178c625e7f2325348d98dfb8a7be5c59000000000000000000000000aeec6f5aca72f3a005af1b3420ab8c8c7009bac8000000000000000000000000f4a2eff88a408ff4c4550148151c33c93442619e000000000000000000000000356439d46a046a7e8ae767a92d51c2ea4f1f723b000000000000000000000000e8613be0178c625e7f2325348d98dfb8a7be5c59000000000000000000000000073903b967e40ff9f1190df3adad3929a5d3903f000000000000000000000000b3aaaae47070264f3595c5032ee94b620a583a39000000000000000000000000b6aac3b56ff818496b747ea57fcbe42a9aae62180000000000000000000000008271b2e8cbe29396e9563229030c89679b9470db", contractAddress: "", cumulativeGasUsed: "4461742", txreceipt_status: "1", gasUsed: "450432", confirmations: "1120145", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[25],addressList[26],addressList[27],addressList[28],addressList[24],addressList[29],addressList[30],addressList[28],addressList[31],addressList[32],addressList[33],addressList[34]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[25],addressList[26],addressList[27],addressList[28],addressList[24],addressList[29],addressList[30],addressList[28],addressList[31],addressList[32],addressList[33],addressList[34]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540974540 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616568", blockHash: "0x405f9ed4aa779b5289c4e2010a3bc45f0d1d25a906cd51344a1b6a5c557611bf", timeStamp: "1540974743", hash: "0xe4f552c5b156aeb6a94d593869c3a7360bd21abf956d2ab223be41675cf71984", nonce: "308", transactionIndex: "26", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "1022670", gasPrice: "10000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000001200000000000000000000000019df7d24370a98d819cc4daa80192a8a227a08a9000000000000000000000000b9760f9755bbe8310482c9efde8de5ecf6939ceb00000000000000000000000062600d264c2f76b40469b6d55f357361b0229469000000000000000000000000fb3fefec0e025d5e6883f750929aa5fd0582dbf30000000000000000000000003695627c5620b707f6f050d8be2f4d86ad332765000000000000000000000000070f3492cd778cfc3dbad6d25bfb3bcbb498298b00000000000000000000000011e52c75998fe2e7928b191bfc5b25937ca1674100000000000000000000000022f14cb872871a37b1d981b342b865f8a31fbaf90000000000000000000000005768e444cab65831ff16eff46a85237c92ef5ddf000000000000000000000000825d5d0df3b2d59f69cc673f041ca91a296b8183000000000000000000000000ebd5fd8a5a81b2e7128c69f1a8511184da6b6f94000000000000000000000000bb1b61089321ad51369c8327fe23d04ada2ed746000000000000000000000000c951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f000000000000000000000000d7053daa42729d66cf4f7921298550f95123a965000000000000000000000000eb645819ee33ade920c7ee775a77062e92ef9116000000000000000000000000ef764bac8a438e7e498c2e5fccf0f174c3e3f8db000000000000000000000000faeb12396529a30e7f4e74ada8d01fcca0c8ffd0000000000000000000000000fbf9320b5c7e08199008a926a3f911877327dabf", contractAddress: "", cumulativeGasUsed: "1824869", txreceipt_status: "1", gasUsed: "707881", confirmations: "1120131", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540974743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616581", blockHash: "0xde1d412de7852c61bc95cfad2b424d16a085c6de963e8fcc8e3a04df38a8b4ae", timeStamp: "1540974937", hash: "0xfe16c8e280093f82779320e8a55257e82cfed067e7163477a11cc3e37556541f", nonce: "309", transactionIndex: "154", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "681496", gasPrice: "8000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000fd26f25d6588b752a90e600aff038a654d64a42c0000000000000000000000001c870c98ef9eca9abde6ebea1f542e685e76c95a000000000000000000000000da2101021a7937e4c12036205f16694ef1e7a3c0000000000000000000000000e3314bbf3334228b257779e28228cfb86fa4261b000000000000000000000000e4fbbfec7c8c5718ccd8c1ced82c72acb05bedbf00000000000000000000000073957709695e73fd175582105c44743cf0fb6f2f000000000000000000000000994a109e48861d5241c30d745efdd25791f9878800000000000000000000000057b9b843b7e8a09cffbdac5b86be0649d4880f33000000000000000000000000f1e9f20839ef5fa8bf093833937c54a9b930cbe00000000000000000000000005ad4864d36f7fe63f657a6e862117f688d263f3d000000000000000000000000c837f51a0efa33f8eca03570e3d01a4b2cf97ffd000000000000000000000000f9c9ef9a9a494adff0ab70cf29d7a48dec3c6169", contractAddress: "", cumulativeGasUsed: "6633945", txreceipt_status: "1", gasUsed: "480432", confirmations: "1120118", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540974937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616594", blockHash: "0x4b54ed3110bcc517d5ff34777e2d899ab7c3ee82a53d444ee8056d9ebd49c18e", timeStamp: "1540975146", hash: "0x2a040fb1598035115fa42f8fc4471c1efa209d5f877619b3f1759fd1cc49e602", nonce: "310", transactionIndex: "179", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "852084", gasPrice: "8000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000c78bd238dcb0fe7d928033973bc42b5e3a11c841000000000000000000000000fc61863066783137904a760caa2c654e389626ce0000000000000000000000001a6db538813dbfa63e1f19f8804447187b7d401d0000000000000000000000008f0da283b796b3f72391120c76cd04c0cebaa8950000000000000000000000008f7131da7c374566ad3084049d4e1806ed183a27000000000000000000000000d839f75fdf7a6db762a1c46f7a33305f850bab22000000000000000000000000db59f29f7242989a3eda271483b89e1f74353ffa000000000000000000000000f389695d89f3782e1b588b4d46061ae1356b17a90000000000000000000000001d1e7abffe36d3ccc84866fbcec8ac050ae19d1a0000000000000000000000004f86602783ad7a81584dae05187136b2e4fdcfaa000000000000000000000000af898fc38e04824985bdd9b461b71cc4e0363646000000000000000000000000bd575402e18dda5a97ff4875a40344d9498e0936000000000000000000000000c91ea14b75b6735aaaf9b4bc5a927793a0a0cb55000000000000000000000000ecbb3b7aeefa9f1bb932e29cc5fb2aa6c350f0a1000000000000000000000000f8fd7ce0fe9d279fb6f79fecb3e56ddc49cdecd1", contractAddress: "", cumulativeGasUsed: "6380324", txreceipt_status: "1", gasUsed: "594157", confirmations: "1120105", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540975146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[3], addressList[10], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6616624", blockHash: "0x981b2c2976bf6fe886da70cd9e69750ee6a62d587f3c4e82956a6c8c943e52bd", timeStamp: "1540975609", hash: "0x2f598fb9ebad111a60df58e7bf5c4d1f7bc88ee5ef78dcf62d0dcd18fa135e5d", nonce: "311", transactionIndex: "117", from: "0xad8bc819bacee51760c01501e7760cd6913de9ae", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "1022670", gasPrice: "10000000000", input: "0x1561ae31000000000000000000000000ad8bc819bacee51760c01501e7760cd6913de9ae000000000000000000000000ad83a37c7b7993a3443fde7164199a1e0a62613d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000120000000000000000000000004cc34cc03fb09119bef8e9c49e6a95b3f70608be000000000000000000000000d635519df9a25cdfdaee3ffffb4e11efa759f702000000000000000000000000d6dafce429cb878549ec8e357c2aa2606fb4fcb1000000000000000000000000136d0159be4313a5bdd38c5c8b5cef8dcff15fc80000000000000000000000008da4f82dc4d03c5421bb2087f858750c650d857100000000000000000000000093811dabfbee9736035025cba91491d7747cfd4700000000000000000000000001796395624b9ebaa46fc4fcc9f5f0c02175f81b0000000000000000000000000e70fd4ea2a0063396fed52a999d64f661774be2000000000000000000000000ea1c2d9b52c61f4e716eb028f7bc38f78e473eab000000000000000000000000fbe00d5fd051a5b1753a673e268277552f8d9d9200000000000000000000000044aaf38296a6e28e3a92a70b034586abab0de5a2000000000000000000000000a43d3cfaf7a968d008e693d193d892c3474622cc000000000000000000000000cc48857242141cc7f4f8555f8a3d5bed03556c19000000000000000000000000e6ecb12ec9a52364f94c8a86ad7274f4b2edc102000000000000000000000000c65267eb245e32ddab67d2e9ee172ccb1c65b33e000000000000000000000000e86f917dec14f5bdc2e43dab57d6fd57a29894bf000000000000000000000000f50e790c7061eb704cda1dc10b3ce5ab66df8499000000000000000000000000f8aba22dc7bbf6b7f5ac2c7eb868543e9d26aa8c", contractAddress: "", cumulativeGasUsed: "5157623", txreceipt_status: "1", gasUsed: "707881", confirmations: "1120075", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "caddress", value: addressList[10]}, {type: "address[]", name: "_tos", value: [addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[3], addressList[10], [addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540975609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2855425974666440" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745349", blockHash: "0xc1fa536e6ed45717c000f7d79bc8a80fab772bb00c2989f2745ae89f08fc1160", timeStamp: "1542800326", hash: "0x3a40c5aa6adbd70367acbb9d98bdbd38dea4fae0ea1e2ebe0d0341aa2eaf81c3", nonce: "27", transactionIndex: "90", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "55822", gasPrice: "12700000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000003b9aca000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e885b22c7365170097d76ee951788040c148791c", contractAddress: "", cumulativeGasUsed: "6065943", txreceipt_status: "1", gasUsed: "55532", confirmations: "991350", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[100]]}, {type: "uint256", name: "v", value: "1000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[100]], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542800326 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[2], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6745476", blockHash: "0x1fdefd8ecf7c026fca4a69292bffd4564ebc5884b46f03987282bea849f273a2", timeStamp: "1542801971", hash: "0xc8ab4b6ddfec6d3924ce2822c6b5b530d89feb1515c646b0dd965f5748cf9031", nonce: "29", transactionIndex: "34", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "500000", gasPrice: "16000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000004b71ad9c1a84b9b643aa54fdd66e2dec96e8b15200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000005f5e1000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e885b22c7365170097d76ee951788040c148791c", contractAddress: "", cumulativeGasUsed: "1785802", txreceipt_status: "1", gasUsed: "28105", confirmations: "991223", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[2]}, {type: "address[]", name: "_tos", value: [addressList[100]]}, {type: "uint256", name: "v", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[2], [addressList[100]], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542801971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745486", blockHash: "0x67c65be37f5cbbf4edb6dade898034098dea1a98c3c1b5ca673d71e08150977b", timeStamp: "1542802138", hash: "0xbd2b0f38a97ce185f56356fa03084e929febfb22426bc20343c9afea5143420e", nonce: "30", transactionIndex: "82", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "500000", gasPrice: "16000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000005f5e1000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e885b22c7365170097d76ee951788040c148791c", contractAddress: "", cumulativeGasUsed: "4947182", txreceipt_status: "1", gasUsed: "63340", confirmations: "991213", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[100]]}, {type: "uint256", name: "v", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[100]], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542802138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745665", blockHash: "0xeeb487bdb64b6e2b30bf68ef7ca1ea0550ae291380ac2601013a62da4dbc9de8", timeStamp: "1542804602", hash: "0x1d45b2ca948b1df1e824ac435a896ce4487ad0a9cd579aa1189ee0c8ae705124", nonce: "31", transactionIndex: "35", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "7000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000005f5e10000000000000000000000000000000000000000000000000000000000000000190000000000000000000000009a929ad23801a568147b56924012c6693f8efd74000000000000000000000000a0f3fd8b953afd6cbe7fd3d4fc1c172e492fa78b0000000000000000000000002194598273bff7f3329de61f9d66296e093cb9f4000000000000000000000000907e272d23b018a947e24aa54ce3ada7c67c5901000000000000000000000000724d5aac1e4348a4c76a66d43fdef13a0664682e000000000000000000000000a88854b6dc33f0f3b495a12c1463bba763bd93f500000000000000000000000000e695c5d7b2f6a2e83e1b34db1390f89e2741ef00000000000000000000000034855ef0b9d89bc6664d520b85aa13db27e95e0b0000000000000000000000004ddd987e2bed1069c75b9a1a6598824917815729000000000000000000000000fc164e97df905733bc076015722cabdfde0bdf6100000000000000000000000083da070858f10cef26f25fbf8eb14a94c9fcb4bf00000000000000000000000026ef1f5c2a4e107bf773f63d93600f3e9860ed5c000000000000000000000000833362cff67f8efd57cb1bc2793dce3f1cf0606b000000000000000000000000a18e8b52d4a989527567c77566c0e91c792abade000000000000000000000000f6bfb9d185d24b43058904af58c47a7a0d13d17100000000000000000000000021cdbe59c11b3909e0a9bbc2f4f42697a9a3dc820000000000000000000000009ce143c1f248dc731a636e933b804e9e6fa3b2730000000000000000000000009974e44e8747b615187378bd35bae7acb832ebdf000000000000000000000000537b8adcb07e9353d05149b42c84eada3c49dcc500000000000000000000000021756f6fe9cd0adac8cdff57d7b1683f4e371a1d0000000000000000000000000832c3b801319b62ab1d3535615d1fe9afc3397a000000000000000000000000357885dec2bed57974e27f53019a61f8b9de09b800000000000000000000000055a72ef1dce9c06b7b37e4465ff27df758ed04100000000000000000000000000dbb74cd877e3d9d98ad1298f571cd246114c50200000000000000000000000000048da2440e53fb45fe36fcedc389262f35963b", contractAddress: "", cumulativeGasUsed: "3225147", txreceipt_status: "1", gasUsed: "973646", confirmations: "991034", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125]]}, {type: "uint256", name: "v", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125]], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542804602 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745674", blockHash: "0x02ae065e38d423fa1d235c07157062f0cc1a6a4e0234ff792a59e93b236008ab", timeStamp: "1542804720", hash: "0x3cb3089f28ce75ebd4fa5de0425f15734ac021e18730708f3f12ccddf1a84eb7", nonce: "32", transactionIndex: "87", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "7000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000002540be400000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000048da2440e53fb45fe36fcedc389262f35963b000000000000000000000000a0f3fd8b953afd6cbe7fd3d4fc1c172e492fa78b0000000000000000000000009a929ad23801a568147b56924012c6693f8efd7400000000000000000000000055a72ef1dce9c06b7b37e4465ff27df758ed041000000000000000000000000083da070858f10cef26f25fbf8eb14a94c9fcb4bf000000000000000000000000a18e8b52d4a989527567c77566c0e91c792abade000000000000000000000000724d5aac1e4348a4c76a66d43fdef13a0664682e00000000000000000000000034855ef0b9d89bc6664d520b85aa13db27e95e0b0000000000000000000000009974e44e8747b615187378bd35bae7acb832ebdf000000000000000000000000fc164e97df905733bc076015722cabdfde0bdf61000000000000000000000000f6bfb9d185d24b43058904af58c47a7a0d13d17100000000000000000000000021756f6fe9cd0adac8cdff57d7b1683f4e371a1d00000000000000000000000000e695c5d7b2f6a2e83e1b34db1390f89e2741ef000000000000000000000000537b8adcb07e9353d05149b42c84eada3c49dcc50000000000000000000000000832c3b801319b62ab1d3535615d1fe9afc3397a000000000000000000000000357885dec2bed57974e27f53019a61f8b9de09b800000000000000000000000021cdbe59c11b3909e0a9bbc2f4f42697a9a3dc82000000000000000000000000907e272d23b018a947e24aa54ce3ada7c67c59010000000000000000000000004ddd987e2bed1069c75b9a1a6598824917815729000000000000000000000000a88854b6dc33f0f3b495a12c1463bba763bd93f50000000000000000000000002194598273bff7f3329de61f9d66296e093cb9f400000000000000000000000026ef1f5c2a4e107bf773f63d93600f3e9860ed5c0000000000000000000000009ce143c1f248dc731a636e933b804e9e6fa3b2730000000000000000000000000dbb74cd877e3d9d98ad1298f571cd246114c502000000000000000000000000833362cff67f8efd57cb1bc2793dce3f1cf0606b", contractAddress: "", cumulativeGasUsed: "5027461", txreceipt_status: "1", gasUsed: "598710", confirmations: "991025", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[125],addressList[102],addressList[101],addressList[123],addressList[111],addressList[114],addressList[105],addressList[108],addressList[118],addressList[110],addressList[115],addressList[120],addressList[107],addressList[119],addressList[121],addressList[122],addressList[116],addressList[104],addressList[109],addressList[106],addressList[103],addressList[112],addressList[117],addressList[124],addressList[113]]}, {type: "uint256", name: "v", value: "10000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[125],addressList[102],addressList[101],addressList[123],addressList[111],addressList[114],addressList[105],addressList[108],addressList[118],addressList[110],addressList[115],addressList[120],addressList[107],addressList[119],addressList[121],addressList[122],addressList[116],addressList[104],addressList[109],addressList[106],addressList[103],addressList[112],addressList[117],addressList[124],addressList[113]], "10000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542804720 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745677", blockHash: "0x3023334282cf9a75a0c8838ea497bd140eeb97d51670edf882638f982cd5fcd2", timeStamp: "1542804794", hash: "0x90db6d43770880732eb8b7aba0eaa650d02418cfc953f90f8290a677eae07697", nonce: "33", transactionIndex: "96", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "10000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000832c3b801319b62ab1d3535615d1fe9afc3397a0000000000000000000000002194598273bff7f3329de61f9d66296e093cb9f4000000000000000000000000907e272d23b018a947e24aa54ce3ada7c67c590100000000000000000000000034855ef0b9d89bc6664d520b85aa13db27e95e0b00000000000000000000000000e695c5d7b2f6a2e83e1b34db1390f89e2741ef0000000000000000000000004ddd987e2bed1069c75b9a1a65988249178157290000000000000000000000009974e44e8747b615187378bd35bae7acb832ebdf00000000000000000000000021cdbe59c11b3909e0a9bbc2f4f42697a9a3dc82000000000000000000000000724d5aac1e4348a4c76a66d43fdef13a0664682e000000000000000000000000537b8adcb07e9353d05149b42c84eada3c49dcc5000000000000000000000000a88854b6dc33f0f3b495a12c1463bba763bd93f500000000000000000000000055a72ef1dce9c06b7b37e4465ff27df758ed04100000000000000000000000009ce143c1f248dc731a636e933b804e9e6fa3b273000000000000000000000000fc164e97df905733bc076015722cabdfde0bdf61000000000000000000000000f6bfb9d185d24b43058904af58c47a7a0d13d17100000000000000000000000083da070858f10cef26f25fbf8eb14a94c9fcb4bf000000000000000000000000357885dec2bed57974e27f53019a61f8b9de09b800000000000000000000000026ef1f5c2a4e107bf773f63d93600f3e9860ed5c000000000000000000000000a18e8b52d4a989527567c77566c0e91c792abade000000000000000000000000a0f3fd8b953afd6cbe7fd3d4fc1c172e492fa78b00000000000000000000000021756f6fe9cd0adac8cdff57d7b1683f4e371a1d0000000000000000000000009a929ad23801a568147b56924012c6693f8efd740000000000000000000000000dbb74cd877e3d9d98ad1298f571cd246114c502000000000000000000000000833362cff67f8efd57cb1bc2793dce3f1cf0606b00000000000000000000000000048da2440e53fb45fe36fcedc389262f35963b", contractAddress: "", cumulativeGasUsed: "4440917", txreceipt_status: "1", gasUsed: "598710", confirmations: "991022", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[121],addressList[103],addressList[104],addressList[108],addressList[107],addressList[109],addressList[118],addressList[116],addressList[105],addressList[119],addressList[106],addressList[123],addressList[117],addressList[110],addressList[115],addressList[111],addressList[122],addressList[112],addressList[114],addressList[102],addressList[120],addressList[101],addressList[124],addressList[113],addressList[125]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[121],addressList[103],addressList[104],addressList[108],addressList[107],addressList[109],addressList[118],addressList[116],addressList[105],addressList[119],addressList[106],addressList[123],addressList[117],addressList[110],addressList[115],addressList[111],addressList[122],addressList[112],addressList[114],addressList[102],addressList[120],addressList[101],addressList[124],addressList[113],addressList[125]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542804794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745683", blockHash: "0x11800dd3b129ea43206c6c0e79b63f983c1137ed65d50d466b2d15f7cefbb05d", timeStamp: "1542804914", hash: "0x44ec10aa0e3dcf041a8b64b6741993c5dff213a0234fab5e890200eb778f213f", nonce: "34", transactionIndex: "81", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "10000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e80000000000000000000000000000000000000000000000000000000000000000170000000000000000000000009275c3ff46e9e0ec80a21e87b33c9aa3822dd838000000000000000000000000ff190c5f451b218456db6272952236b6c29f703300000000000000000000000000e695c5d7b2f6a2e83e1b34db1390f89e2741ef00000000000000000000000034855ef0b9d89bc6664d520b85aa13db27e95e0b000000000000000000000000ae1911fc6cbdc9560cbcd5d5147bcddef74019f4000000000000000000000000a45ae9007b190fb42555976ce7464d614755d1a500000000000000000000000020c61d2dfc6cb4e1735c77505efc0c342aa652ba00000000000000000000000000260008a7373283c27fc9c36da04ee7f0d722660000000000000000000000000819743fe98dfc6b5604672bba5473c9ad660b9700000000000000000000000016a23a3efb88af5262db610fc70d4253fee57fcc0000000000000000000000000ee1f25db20de733ac34bffc642ad2c610eb89c90000000000000000000000009ce143c1f248dc731a636e933b804e9e6fa3b273000000000000000000000000da462107ac0dc4222104ebc055d3d0da31158e57000000000000000000000000c7ef92c6001cfb326b69c00c1c5d4bee6c21567200000000000000000000000084f01b473e903f661017632839d1bd28ef44cddc0000000000000000000000009cd2c1a0cec4ad21564ab538cad7f856daacbcbf000000000000000000000000a88854b6dc33f0f3b495a12c1463bba763bd93f50000000000000000000000007c4922462cb592b87658a403a0f5c65dff3a6ff100000000000000000000000083da070858f10cef26f25fbf8eb14a94c9fcb4bf0000000000000000000000000bef682299d37372acc26111fba266e11eb26c7a00000000000000000000000061f20a468952000657453fe3579aaeb445eff87c000000000000000000000000d540b55e0010684b2cacc819ab82a616b938dc700000000000000000000000000832c3b801319b62ab1d3535615d1fe9afc3397a", contractAddress: "", cumulativeGasUsed: "4186970", txreceipt_status: "1", gasUsed: "807526", confirmations: "991016", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[126],addressList[127],addressList[107],addressList[108],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[117],addressList[135],addressList[136],addressList[137],addressList[138],addressList[106],addressList[139],addressList[111],addressList[140],addressList[141],addressList[142],addressList[121]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[126],addressList[127],addressList[107],addressList[108],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[117],addressList[135],addressList[136],addressList[137],addressList[138],addressList[106],addressList[139],addressList[111],addressList[140],addressList[141],addressList[142],addressList[121]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542804914 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745688", blockHash: "0x9c1e2fefc9b96c8de88e86ef905ddff95e87e6ccfa7755544576d81814a6d054", timeStamp: "1542804983", hash: "0x4d32f34144e83bc47f710343590be7d9dbe7fcc48ab5fb28d331242f92b6c701", nonce: "35", transactionIndex: "19", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "13350000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e800000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000e6235bd7eb9376e3bc38956cbd20e605ecaac2410000000000000000000000009d14a29d7367c4b24685ac010a5e6794d43f1ac9000000000000000000000000af4e95d5edc9258b15acaa1d4488a7d13cda57f5000000000000000000000000fcfe293d86ce3a138abe1e50e217d84c55efbb320000000000000000000000001960f48d9690640828359a3d64b9f12666dc9de800000000000000000000000084f01b473e903f661017632839d1bd28ef44cddc0000000000000000000000009275c3ff46e9e0ec80a21e87b33c9aa3822dd83800000000000000000000000098ca9c5f410b530f87c4bfd7becea177d9b889c90000000000000000000000007c4922462cb592b87658a403a0f5c65dff3a6ff1000000000000000000000000d540b55e0010684b2cacc819ab82a616b938dc7000000000000000000000000000e695c5d7b2f6a2e83e1b34db1390f89e2741ef0000000000000000000000009cd2c1a0cec4ad21564ab538cad7f856daacbcbf000000000000000000000000c7ef92c6001cfb326b69c00c1c5d4bee6c2156720000000000000000000000006a140a89d50f891f4fa21bd315f5bd26b890fb6e0000000000000000000000005c5acfe5ad29fc0732384af304cab2e4cf8e507400000000000000000000000099226a1ef791699e863cef8b2a7622d7a97eb120000000000000000000000000817b43d93d1706add8fc28502446df74bb5b3b1b0000000000000000000000000bef682299d37372acc26111fba266e11eb26c7a000000000000000000000000ed9f942c41d71a3658a8ad5572eeea551ccc893f00000000000000000000000094ae196506182630120c2b13afdb76bf9bb047150000000000000000000000000ee1f25db20de733ac34bffc642ad2c610eb89c9000000000000000000000000210510845bdeba73eef16c158dba800cc14fd05400000000000000000000000097fbe749544656b826892c9296c4e46668532e0e00000000000000000000000055a72ef1dce9c06b7b37e4465ff27df758ed041000000000000000000000000045d9ee2cb1c8ef0c947a9b62d877c034d3bfbbc200000000000000000000000016a23a3efb88af5262db610fc70d4253fee57fcc00000000000000000000000061f20a468952000657453fe3579aaeb445eff87c000000000000000000000000ff190c5f451b218456db6272952236b6c29f703300000000000000000000000034855ef0b9d89bc6664d520b85aa13db27e95e0b000000000000000000000000564755a019940966e6cad2dc27efc2e5b29f1d10000000000000000000000000a88854b6dc33f0f3b495a12c1463bba763bd93f50000000000000000000000009ce143c1f248dc731a636e933b804e9e6fa3b27300000000000000000000000086d61ef8212a938c66560c5a03780a44b85b5404000000000000000000000000af3ef2434f5081c6e86f53f9b38d0188581da23d000000000000000000000000309dc0df4d19db22e1616422bd109f9712c92d260000000000000000000000003f8860b846635417a5bd35b5e01d105d677cc119000000000000000000000000dd26ce271a9c94adc51388f840431600a6c73370000000000000000000000000a18e8b52d4a989527567c77566c0e91c792abade00000000000000000000000083da070858f10cef26f25fbf8eb14a94c9fcb4bf00000000000000000000000000ba72ec3944495c21f16f9e29320850f67353fd0000000000000000000000002dd853c6e6093bdf0a386fb7f6a4c90ce456eb9b000000000000000000000000907e272d23b018a947e24aa54ce3ada7c67c5901", contractAddress: "", cumulativeGasUsed: "2384305", txreceipt_status: "1", gasUsed: "1333301", confirmations: "991011", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[137],addressList[126],addressList[148],addressList[139],addressList[142],addressList[107],addressList[138],addressList[136],addressList[149],addressList[150],addressList[151],addressList[152],addressList[140],addressList[153],addressList[154],addressList[134],addressList[155],addressList[156],addressList[123],addressList[157],addressList[133],addressList[141],addressList[127],addressList[108],addressList[158],addressList[106],addressList[117],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[114],addressList[111],addressList[164],addressList[165],addressList[104]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[137],addressList[126],addressList[148],addressList[139],addressList[142],addressList[107],addressList[138],addressList[136],addressList[149],addressList[150],addressList[151],addressList[152],addressList[140],addressList[153],addressList[154],addressList[134],addressList[155],addressList[156],addressList[123],addressList[157],addressList[133],addressList[141],addressList[127],addressList[108],addressList[158],addressList[106],addressList[117],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[114],addressList[111],addressList[164],addressList[165],addressList[104]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542804983 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745727", blockHash: "0xc41a35f86d949735ae1de30ebbc0ec39eeef35d4bee35dac76db549a7b972f32", timeStamp: "1542805416", hash: "0x9d1c0e0553cb5c907c9babc6e22342ad2e0a421024318f23e97f4ca08e8e2f5c", nonce: "36", transactionIndex: "50", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "8000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e8000000000000000000000000000000000000000000000000000000000000000091000000000000000000000000b845e487d68ec6c9f74752776c74846cad78735e00000000000000000000000048e9346cbaad16731d0cd9ddb660f6056cee928d00000000000000000000000084eaa9a6a8e42696790289480314e2fca8f38581000000000000000000000000915d7915f2b469bb654a7d903a5d4417cb8ea7df000000000000000000000000cb6a4fefe2a1ee270d4124599c021de6f58e15dc000000000000000000000000779959cfb3859f12ec80da6e7ce12305bc594dd80000000000000000000000006d0acdd986b7589295a43c91b95fd1f26fbc59f6000000000000000000000000b0978e34a808e7a457bdb436eaf3a6e5917025aa000000000000000000000000156e4e29dcb7877c89225ae969cda06e4534f5450000000000000000000000008cb1ab736459ba518ac391fb8e3b4855f1aaee05000000000000000000000000e19133a469c87fcf3c1b43a2686b27b4bd2188b2000000000000000000000000f6d44482c95190caebb37b31caf57cf6b5315bd1000000000000000000000000463ea350609fd0970a6db09e7e27a3beee4f271700000000000000000000000001bfae6659c4acd4a077b07c53a61008e6028ba500000000000000000000000058e90f6e19563ce82c4a0010cece699b3e1a67230000000000000000000000008d9df8ea8c6730de05a36e8a082d471bd51cd9ff0000000000000000000000008c30c6c7d386a7d87683f087ff839d10ab55f1210000000000000000000000009222e68caaf97b66201c03526b3257410b2fbdd8000000000000000000000000bfad148cb4282635026723b366e5d1aadb3064d6000000000000000000000000aa5e57a1a92cb025bdfa6b31e63d6bf090172490000000000000000000000000c5554bb95185773a047388f3b47056bc48bc00e1000000000000000000000000d6ee0260c1202ecdc6c89cde12f1745e035f1b8500000000000000000000000027adde789bfccaa06c4f97d241be6cc7af2579860000000000000000000000006ff37dd1402a1ed9e7356f48371f1ea16e8854d8000000000000000000000000f3abe885bb5583bfc4aea54a0c38acad582636a70000000000000000000000003c7a29cb8d87bbbee9e04ca56148ca0246d158f0000000000000000000000000f1ac6a2a16a3210f74b03de2588fe672a93844aa000000000000000000000000f340f3375cbdcfc1ca4139b098db30734413fa38000000000000000000000000fd5d7e73ae98652deeb48935b87a9e04ff2bc00e0000000000000000000000003e01ab3ca9e3cffa877dd3c098582892be107c72000000000000000000000000c65f4cea1f643dd675388b04d51c999c6730aa8000000000000000000000000093dc2fb3a037e103b8a01304a62c2697f00a36770000000000000000000000001fcfd25b25ccead63665cf867f4f7cba3e75de640000000000000000000000000b0efad4ae088a88ffdc50bce5fb63c6936b92200000000000000000000000000e546196b921528e20e770fc39f1cca104796d390000000000000000000000002f145aa0a439fa15e02415e035aaf9fdbdecabd50000000000000000000000006235dc1c5d929c1841d6545af877ef83fecd976d0000000000000000000000006c5d0d9eb1243903775ffdbc8f5d29b04ce3670d000000000000000000000000096012eb44ce0ef1dc2d9833757cb32d2c50e0b6000000000000000000000000ad97b225134339a51cd25e53af031dcef596ef7c000000000000000000000000c2ad849ae4ba0b05aee73bbe3ea6787e01a530ae00000000000000000000000063d58cdad68a67493dae909ed7a93d2008dcc833000000000000000000000000221287cb305a0a4c2bcbb00ecaa308990be3792c000000000000000000000000f1aa56eafca468184f871941adf43c78017ea0e5000000000000000000000000065604eddd94350df7af9e45b5376e10f0a0eea000000000000000000000000056db1bec835f62035467cef4112bfddb816c1064000000000000000000000000740dcede05469dccbabb0b0258a5532af10c2cde000000000000000000000000dc07442ffc911bb499145bac53aaac78543fed4b000000000000000000000000707dd79bcfe97689f987fb7d17e29b76bb51eef800000000000000000000000065d52727c5f7c596fb375ecf1bfdd5156a5acbf80000000000000000000000004523e948188c09abc65ee730f1517bfbbdbcfa760000000000000000000000000d54899389483e03d170bb190b16bdae832cb38c0000000000000000000000001529d2e640f7febd3e9dc40728cac060a2739d700000000000000000000000001de07b8c3999c355b4dd160b39044118616a4f9d0000000000000000000000001768f5c8bf5000377af023e7e2630bc17c978adc00000000000000000000000018c52bb439e58549333a2a65ba3c69209142e331000000000000000000000000e6786f0066b38af62f0aa4b2fd8568afd6555dc00000000000000000000000001b87c2a6058bc88548bc9bb18b0717f939b2ccb3000000000000000000000000e0fb8097bae257a9f58cf2fd85fdc671399f6dd6000000000000000000000000538d74f89ca2bf84221275dd530862b33a9dbfde00000000000000000000000065b7a73a85b87439ae353638c75b4585163b92f600000000000000000000000085f94ce524e9ad88d62eb370a7c37b4f808dc3a800000000000000000000000008b41b878177618ad88738c67a48d64db8422bc20000000000000000000000002615a4447515d97640e43ccbbf47e003f55eb18c000000000000000000000000adcc19c8873193223460f67552ddec01c16ce32e000000000000000000000000a6ba44e4cd560cea455236310446273148ab76d500000000000000000000000012b2398405f49dec00d7ceef9c0925e6fc96c51f0000000000000000000000007406047d76c57e5b6e67d2fa54f264af46ec354c000000000000000000000000ad685e9cd97b0e2b81c32a8b4e5ef48eb183afa2000000000000000000000000a42015da9e346e4c9f2ca5bb71b9d1a885810713000000000000000000000000cb88eaa745843fc36b95cf561fbc37d35f1249d90000000000000000000000003490ae3a80d122c759f77ffd78c35c25d9701059000000000000000000000000b74d5f0a81ce99ac1857133e489bc2b4954935ff00000000000000000000000010aaa246861b94fc22b3595e89a91da6e752113d000000000000000000000000abe6970e7e21709a3fe21888c65f3f542d3fdef20000000000000000000000002d0d94b819f1a8dff358ab3b858ccdb6f40eacbb00000000000000000000000009475262c6a1ffbedd480d2a15f35f978aaaac38000000000000000000000000780e57d8e8dc688f00a68f966538b2fbe1c898f70000000000000000000000003e2686364ff660adb98b869b4d786d8f06ec113400000000000000000000000021b67fc23f0cbef46f9c7612d361cc42c580f9a70000000000000000000000000df3dc2eb13ab4784a17d7bfa19ad615851175540000000000000000000000008470a1f8dfde074eef6178d559a4412f088848c8000000000000000000000000d806c99545a0774cc83f8b1b7e0547fc86c12c75000000000000000000000000aa5f9414628e7a4d8e0829477fa0905c394a4dae000000000000000000000000863a492d7dedb65775452177f0d0594e759472890000000000000000000000003e02d9233e9d6f1fc9c5fd247673526e1aea56b3000000000000000000000000d6b273bc1a91b8043d3ff526e85e33e5abcf4ee00000000000000000000000000d68c987edb915cc729cd754788205d5bfa5f9da000000000000000000000000ca2de788045117f1a86378a339ead08e33a896ec0000000000000000000000009ddde2f8a72b0511d68fd45083ac3bc004fb61ee000000000000000000000000a7c05879b3240dbc1ee89fb45da508e8c6c4d42f0000000000000000000000003b58236269a2474a31dba3afca95d8cb9cbd7f420000000000000000000000008fedbaa4ac2b5489c475f0f2894633d302e8863a000000000000000000000000bf7ae4fd867c45ee890b59caae8b8fbdf2ee0141000000000000000000000000d079f70a23f61fa6696ec55c2fdda1a93a99bcd30000000000000000000000001d6ac538fb080cbcf4cbac176bed49801825263d00000000000000000000000076929fd49547660cf33580105faabdb656f921e9000000000000000000000000cdafd58abfd612a2522578d6422b774a5906607d000000000000000000000000e793cdd15aedefe3b8ae875d8103cf433b43c2280000000000000000000000008891df7757ade4334acd9a3b1a834fcdfde6866e000000000000000000000000c380a543a0376ff32bac8e2aca3d100838f16aff0000000000000000000000005dc93865f311b60fbbf9ea1bdabe0991a84704be00000000000000000000000040aee50293fb801d5e80990cb9f6a049935358c9000000000000000000000000e88db5c82ebe225290e98b5d0bbb7bfc59e265ca0000000000000000000000005bfef649a100d3fc56518f4ff86ef15904354d280000000000000000000000004474b406b9ae231cf0dbd150724b00411328a8ee00000000000000000000000042980c931c7c001b2766cc0f1061542f29e3133e000000000000000000000000467e45a86793373a4c1d107c4a4d66f2854d82aa0000000000000000000000004c3eb0aa279a5029b131f976e2ae8a5addf2eb73000000000000000000000000390f523604b11e6e71f23b9f8a2055d0316f48cd0000000000000000000000000ee2289f611a43205796e10ee00b5415df2fcbdc00000000000000000000000026976e2722c24d66f87b717efe552cdaaa5b5cb90000000000000000000000000e124d607618cde134792218577f74ea2dc1f84a000000000000000000000000f500fbaa9b1db9502fccaef8bbd328a3f95fb4f5000000000000000000000000d0ca0fe6c4fa002a05f8890efc700c084d7c3d90000000000000000000000000b464e62733760d3efa8ded234cf3cbfbb93f99fa000000000000000000000000448a380e3ed48de270972fa9b37fa6f687210bfc000000000000000000000000debc63e1439cb047f40e1221f693247bf3cc9da800000000000000000000000024172298409301b930db14313872610bd753d2890000000000000000000000008c070c3c66f62e34bae561951450f15f3256f67c0000000000000000000000003efadedbb2e003096fd3df28cceaf83c6fb4575d000000000000000000000000384764c63f0cb05ff28d561185ad488e4b92f0f50000000000000000000000006696fee394bb224d0154ea6b58737dca827e19600000000000000000000000009efaf68852540264c38c5b080c1c8a8dc88e2438000000000000000000000000938d724cdb7193b2c52c1f5aa302162d28386b390000000000000000000000007e31a2e6ed37de31c23db014977b1aba0b8a8dd800000000000000000000000018e3c1ac5dfa88442784492d3647a887a870b5700000000000000000000000000f7981ae60708d4d64040999e463f106b13f07c50000000000000000000000004ff135b36c5c2c545becd3385465d187b1c6db16000000000000000000000000cb1f38892d4e2255023d382c2dedc8c00f7a456100000000000000000000000022f14cb872871a37b1d981b342b865f8a31fbaf90000000000000000000000003eff47e197aca394a2c238f62ed7477cad76874a00000000000000000000000058b256ca58cb4763e0db53a546c29e1a72c3c553000000000000000000000000581704da7a14795ed6a9b729cd768b5d51040194000000000000000000000000ae8fa113945a1c94bec32710349ee5979dd78dca00000000000000000000000014d5afc53f204c8fc3a79bf262ccdef500df10d8000000000000000000000000bf2e12ed9c22b29cfa9ea18c4bf44c22164b298c000000000000000000000000e1a2cabfc6412bec651fcd7dbbad0266b6d78d1b0000000000000000000000000fb72c9b937a6c5f5df77b3bc2e26bf1fef34a8f0000000000000000000000006b00fc495373e9317d62767e66bdf813699f348b000000000000000000000000db856e59b077f9d2548719a71e549a7b61cb78e30000000000000000000000007ef5d02356f779170b49ba2bcbac3a9105fb10d10000000000000000000000005346c93f25e5c7318ee3c661803c15b50ae336ff00000000000000000000000033878be6ef5eb13f8e5b74d2a820818432573d020000000000000000000000007859a4fe801ee2473a5f2f0e6ad37ed266910357", contractAddress: "", cumulativeGasUsed: "5833958", txreceipt_status: "0", gasUsed: "2000000", confirmations: "990972", isError: "1"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287],addressList[288],addressList[289],addressList[290],addressList[291],addressList[292],addressList[293],addressList[294],addressList[295],addressList[42],addressList[296],addressList[297],addressList[298],addressList[299],addressList[300],addressList[301],addressList[302],addressList[303],addressList[304],addressList[305],addressList[306],addressList[307],addressList[308],addressList[309]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745734", blockHash: "0xa16f310e18d6ae548f9c0442075bc5d4ea76ad99657dad943b1a0af82da65aa8", timeStamp: "1542805534", hash: "0xe723e205f1caf9bab90ac0c3b45a64c17138dcb7b9206bf2fe71a2d3ff3c5fb4", nonce: "37", transactionIndex: "88", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "7000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e8000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000459bda693fd135934c608ddc8e40faa6ac9a50a9000000000000000000000000d410568a668477071515f83ff1782e5cd44a39b600000000000000000000000067361adeae382a4f578048c2955042e82c1764f300000000000000000000000003e48b45542b60685e460a7580d3bafc3bf5a1b30000000000000000000000004d89f686432c3bdb233f8734dc2e4ffe635fce02000000000000000000000000cc13d110ad46e470c3b83cebe4681cdca16a0f8f000000000000000000000000d68799d443d7ab8037546b42f0162c084e1f0698000000000000000000000000cb6b5f12f152f41d8a6140726afd928c8b6955f9", contractAddress: "", cumulativeGasUsed: "5078628", txreceipt_status: "1", gasUsed: "328992", confirmations: "990965", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[310],addressList[311],addressList[312],addressList[313],addressList[314],addressList[315],addressList[316],addressList[317]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[310],addressList[311],addressList[312],addressList[313],addressList[314],addressList[315],addressList[316],addressList[317]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542805534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[98], addressList[99], [addre... )", async function( ) {
		const txOriginal = {blockNumber: "6745743", blockHash: "0xdab5c9ca5f8e89bf9c7d0c4ebaef330ce6b812490d4ad2d89120443513445e2a", timeStamp: "1542805623", hash: "0x1e5f11cf7dac274e3a9d9a264fcdc710ba4f43511054d20c267d830e43e3f70d", nonce: "38", transactionIndex: "92", from: "0x6c7dfe3c255a098ea031f334436dd50345cfc737", to: "0x4b71ad9c1a84b9b643aa54fdd66e2dec96e8b152", value: "0", gas: "2000000", gasPrice: "7000000000", input: "0x1561ae310000000000000000000000006c7dfe3c255a098ea031f334436dd50345cfc7370000000000000000000000007f3eab3491ed282197038f1b89ca33d7e5adffba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000174876e8000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000dc3ac3eb514a765f6ef5e22afa09740832759758000000000000000000000000479857e049b20c5884c81e4dcedf4ba6f2b82b480000000000000000000000002b9c9f432e9894f824cb2626af6f772460bc0dcc00000000000000000000000065258528ff01dab7d56f248d5e45d6ef535dc8d30000000000000000000000008167e7b57f88ee5b85ee0b10aaa18788d00dfee9000000000000000000000000986da653865f9c70a76d395f0605bcc32837d971000000000000000000000000c83a458484228dc417c20cc8616787481359ee9700000000000000000000000041fb25057a38916ed8b6b3f15ddec6a68862033e", contractAddress: "", cumulativeGasUsed: "3091296", txreceipt_status: "1", gasUsed: "328992", confirmations: "990956", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[98]}, {type: "address", name: "caddress", value: addressList[99]}, {type: "address[]", name: "_tos", value: [addressList[318],addressList[319],addressList[320],addressList[321],addressList[322],addressList[323],addressList[324],addressList[325]]}, {type: "uint256", name: "v", value: "100000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,address[],uint256)" ]( addressList[98], addressList[99], [addressList[318],addressList[319],addressList[320],addressList[321],addressList[322],addressList[323],addressList[324],addressList[325]], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542805623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "4128744081509440" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
