const AmbrosusSale = artifacts.require( "./AmbrosusSale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "AmbrosusSale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x89F4f1910718B4208ca9bA2EB39E07BAfC70B535", "0x7b1Ab331546F021A40bd4D09fFb802261CaACcc9", "0x11bF17B890a80080A8F9C1673D2951296a6F3D91", "0x00C269e9D02188E39C9922386De631c6AED5b4d4", "0xB47aD434C6e401473F1d3442001Ac69cda1dcFDd", "0x53B3D4f98fcb6f0920096fe1cCCa0E4327Da7a1D", "0x642fDd12b1Dd27b9E19758F0AefC072dae7Ab996", "0x64175446A1e3459c3E9D650ec26420BA90060d28", "0xB17C2f9a057a2640309e41358a22Cf00f8B51626", "0x36f548fAB37Fcd39cA8725B8fA214fcd784FE0A3", "0x877Da872D223AB3D073Ab6f9B4bb27540E387C5F", "0xCcC088ec38A4dbc15Ba269A176883F6ba302eD8d", "0xFd80F7507f3dC1575927a6b5358b3bfa3F1a9434", "0xC203F2019054fcE9635b4581C00fef50b91C9851", "0x4e77414D136673A39F94174B98705A1Cf1a5eEFB", "0x6Df24F6685a62f791bA337Bf3fF67E91F3D4BC3A", "0x3423cA8af938FABc3F072dE6e308B03367a19057", "0x007568660B72Fb8A66F2A3CCa3b7b2F92167dCC1", "0xaC4d6b2BC4331D756193Bd0FD5018F4292fE6FD0", "0xaba31A41B4Fea558749e13F6Aa12046AA109A5B5", "0x003101F131F32671a8b10Dd5abE5fffcd6b1D727", "0xa8F76F25B85d31077a067D3A053A59bA65ad3fCC", "0x10FBCaa2bA4D4d89F40dd0FfCd3d86326533d1FA", "0xC9505B49ED8E40bd81f87c12C94938579abCDA93", "0xf37dfE5fdA3b1c882a5afb810DddE67885952729", "0x7065caAA38ce67810a1eC067440Ba1c2B3b03AA5", "0xDcf10969d931F57eF95A8996cb7B2E7E5311e88A", "0x5A41F2149A4339C54D78139786A5C20FCb69fd9B", "0x001dF30Cb66F209C889575099E5e482E432b3DAf", "0x007f56414307d6299a759D097c9140207dbf4b1a", "0x6a00b74B720c22BF83Dca604cbFCd7cf17875519", "0x288341eAfD48Cc1DBb57005c84E84640F81e48ca", "0x50Bc386B06acaf228d980E19AFeDB7C37201B420", "0xD412943172e67F877C2D215be6BEde1D99b30644", "0x416b495ed145C858db6b307Df5FF06E838fe1818", "0x4d163E5fB6a19148d178436D19180b98148465Eb", "0x6B4574f5Cc17c5DE1b69b236EAD89fF3F1A50921", "0xb57E171Ad7eDa0a3EEbaBCa5CB935d717519cC59", "0xFED93eE80526b14f4b2F1940986C8B802cB9BDa9", "0x303c8BeC9763B6c15ABBC3b4041ddad99E896e09", "0x04d757B21eAB8A905B68Fc4350A0a1987Ac0e588", "0x6e931201bcf7eBB18A72b0bcf4F237F85804074D", "0xDA7807a16a7edaD0Fad53B1E4B0010FeC7e37D24", "0xEed78d297fdCF061D0F8c26cB7461f3069b803C5", "0x1D3EE04E08Dc28757909a644dDa36c2fffe33361", "0xCE9450F366bB61874f90484d05f30CC44c1d72dd", "0x3B015942a9F81a04111b8828e1335E3A78eDE5a7", "0x0e2551AD0664cD0BbC0e29fE9a57d94a8d0e2fFa", "0xBa61C6657E928D2c3dE8C011f7F32beB5Ceb6581", "0x8f98b2e6d73f1f754ad0EBB7c74eB6eD7Fb6fdd4", "0x91CF2FF178f49914EE827fcE528433300591A3DA", "0x4682FFdfA1250a76726f0Aef31aAC8D5c078A20a", "0xE9061D25c4Aa4F8a19713526347e8aDa5Bbc05bB", "0x51026C641548b4e4080C5BE4fC0AfA20EB0727E3", "0x7a725FA605F320d885DFb4545335c72f2C84dc07", "0xf65bd56D081F2973758955836E6c3C5fdcBeF4b2", "0x8d60B70c188Bc3DCac68CdA765f069CD19ed2CBA", "0x2669f428f2489425aD2a08880494801a32312ab2", "0xe905154aBDA61B7e19D0d94Af3fCfDe5b7B42725", "0x5423AB37D667562BEC0E1206a6E4913ad014862F", "0x79DbDc13E0Aa0E2915C4ba60b41aF8156F514A42"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "TIER_3_BUYIN", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CHINESE_EXCHANGE_BUYIN", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "DURATION", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MIN_BUYIN_VALUE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "TREASURY", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CHINESE_EXCHANGE_3", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BTC_SUISSE_TIER_4", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "END_TIME", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "TIER_2_BUYIN", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "ADMINISTRATOR", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_who", type: "address"}], name: "buyinReturn", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_REVENUE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "LIQUID_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "SALES_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "LOCKED_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CHINESE_EXCHANGE_2", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "allocationsInitialised", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BTC_SUISSE_TIER_1", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokens", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CHINESE_EXCHANGE_1", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "STANDARD_BUYIN", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isPaused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BTC_SUISSE_TIER_2", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "saleRevenue", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "PREPURCHASER", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "lockedAllocatable", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CERTIFIER", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "liquidAllocatable", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BEGIN_TIME", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "TIER_4_BUYIN", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CHINESE_EXCHANGE_4", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_BUYIN_GAS_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BTC_SUISSE_TIER_3", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Purchased", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "SpecialPurchased", type: "event"}, {anonymous: false, inputs: [], name: "Paused", type: "event"}, {anonymous: false, inputs: [], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "liquid", type: "bool"}], name: "Allocated", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Prepurchased(address,uint256,uint256)", "Purchased(address,uint256)", "SpecialPurchased(address,uint256,uint256)", "Paused()", "Unpaused()", "Allocated(address,uint256,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9547b44d2ea475e7d41d024ad83f8bf25d3b9d6a6840b626ae6e3b264fb8fe5e", "0xa512fb2532ca8587f236380171326ebb69670e86a2ba0c4412a3fcca4c3ada9b", "0x83955bb22926704dd95ca18aa707bda6cb1a42dadff1bce6da1afc262a08cbdb", "0x9e87fac88ff661f02d44f95383c817fece4bce600a3dab7a54406878b965e752", "0xa45f47fdea8a1efdd9029a5691c7f759c32b7c698632b563573e155625d16933", "0x3f6ddb7506487dd99221443e2e5c06c3c0fc784eb266ec9e72dd519102c461d8"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4298571 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4298676 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "AmbrosusSale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "TIER_3_BUYIN", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TIER_3_BUYIN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CHINESE_EXCHANGE_BUYIN", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CHINESE_EXCHANGE_BUYIN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DURATION", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DURATION()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MIN_BUYIN_VALUE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_BUYIN_VALUE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TREASURY", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TREASURY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CHINESE_EXCHANGE_3", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CHINESE_EXCHANGE_3()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BTC_SUISSE_TIER_4", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BTC_SUISSE_TIER_4()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "END_TIME", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "END_TIME()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TIER_2_BUYIN", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TIER_2_BUYIN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ADMINISTRATOR", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ADMINISTRATOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_who", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "buyinReturn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyinReturn(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_REVENUE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_REVENUE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "LIQUID_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "LIQUID_ALLOCATION_PPM()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "SALES_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "SALES_ALLOCATION_PPM()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "LOCKED_ALLOCATION_PPM", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "LOCKED_ALLOCATION_PPM()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CHINESE_EXCHANGE_2", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CHINESE_EXCHANGE_2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "allocationsInitialised", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allocationsInitialised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BTC_SUISSE_TIER_1", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BTC_SUISSE_TIER_1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokens", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CHINESE_EXCHANGE_1", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CHINESE_EXCHANGE_1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "STANDARD_BUYIN", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "STANDARD_BUYIN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BTC_SUISSE_TIER_2", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BTC_SUISSE_TIER_2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleRevenue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleRevenue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PREPURCHASER", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PREPURCHASER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockedAllocatable", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedAllocatable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CERTIFIER", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CERTIFIER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "liquidAllocatable", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "liquidAllocatable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BEGIN_TIME", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BEGIN_TIME()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TIER_4_BUYIN", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TIER_4_BUYIN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CHINESE_EXCHANGE_4", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CHINESE_EXCHANGE_4()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_BUYIN_GAS_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_BUYIN_GAS_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BTC_SUISSE_TIER_3", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BTC_SUISSE_TIER_3()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "AmbrosusSale", function( accounts ) {

	it( "TEST: AmbrosusSale(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4298571", timeStamp: "1506003502", hash: "0x3150b0de54adff63f5ab391123cc46c19bad3c9280e571494cd8dd2ed9f5f50d", nonce: "171", blockHash: "0x381f81763ca8aa7dc0998f98cb3c565f40c8467a19f08a55f2c2601985b0cc00", transactionIndex: "1", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: 0, value: "0", gas: "4712388", gasPrice: "100000000000", isError: "0", txreceipt_status: "", input: "0x6199ca26", contractAddress: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", cumulativeGasUsed: "2380569", gasUsed: "2359569", confirmations: "3407961"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "AmbrosusSale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = AmbrosusSale.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1506003502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = AmbrosusSale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[14], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298623", timeStamp: "1506004641", hash: "0x3e57dec63eb7e7c3c2ca19a83a1d70fea5b2458a515ab35ce12121eea7ad3023", nonce: "172", blockHash: "0xf70ff9cf5171b5d96016f4931061b9323e7205e84e152d230fbeace919f3c753", transactionIndex: "127", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000fd80f7507f3dc1575927a6b5358b3bfa3f1a94340000000000000000000000000000000000000000000000d8d726b7177a80000000000000000000000000000000000000000000000004ba0c1094c73810f80000", contractAddress: "", cumulativeGasUsed: "5183203", gasUsed: "111514", confirmations: "3407909"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[14]}, {type: "uint256", name: "_etherPaid", value: "4000000000000000000000"}, {type: "uint256", name: "_amberSold", value: "5714286000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[14], "4000000000000000000000", "5714286000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1506004641 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xfd80f7507f3dc1575927a6b5358b3bfa3f1a9434"}, {name: "etherPaid", type: "uint256", value: "4000000000000000000000"}, {name: "amberSold", type: "uint256", value: "5714286000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[15], \"550000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298625", timeStamp: "1506004695", hash: "0xb5a6469090867cbb696339d9eed4e07a6aabd8c7a56a18aa47a7dee4ee94f840", nonce: "173", blockHash: "0xffb160053418ee5bc57c9cfe9aa16fdbeb91b6c6a70d16526fb31cece94031d9", transactionIndex: "16", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000c203f2019054fce9635b4581c00fef50b91c985100000000000000000000000000000000000000000000012a27d53bc04870000000000000000000000000000000000000000000000009195731e2ce35eb000000", contractAddress: "", cumulativeGasUsed: "641137", gasUsed: "66514", confirmations: "3407907"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[15]}, {type: "uint256", name: "_etherPaid", value: "5500000000000000000000"}, {type: "uint256", name: "_amberSold", value: "11000000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[15], "5500000000000000000000", "11000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1506004695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xc203f2019054fce9635b4581c00fef50b91c9851"}, {name: "etherPaid", type: "uint256", value: "5500000000000000000000"}, {name: "amberSold", type: "uint256", value: "11000000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[16], \"181422000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298635", timeStamp: "1506004975", hash: "0x10a23c5a567da52b999f87b9d441bfd3f67408fb1ec8f0bcdf96533f12a25c06", nonce: "174", blockHash: "0x53603b7a920be2afe8d1837c4f01e00f5b6a499065641727282d644ca219f946", transactionIndex: "106", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000004e77414d136673a39f94174b98705a1cf1a5eefb000000000000000000000000000000000000000000000062595c35d9b92e000000000000000000000000000000000000000000000002003c159878a47a400000", contractAddress: "", cumulativeGasUsed: "5320054", gasUsed: "66450", confirmations: "3407897"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[16]}, {type: "uint256", name: "_etherPaid", value: "1814220000000000000000"}, {type: "uint256", name: "_amberSold", value: "2418960000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[16], "1814220000000000000000", "2418960000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1506004975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x4e77414d136673a39f94174b98705a1cf1a5eefb"}, {name: "etherPaid", type: "uint256", value: "1814220000000000000000"}, {name: "amberSold", type: "uint256", value: "2418960000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[17], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298636", timeStamp: "1506004987", hash: "0xecadfe8d6dbcea5166cd6ef336429feab6e19a7fa5f4d9767e122ab1803b846f", nonce: "175", blockHash: "0x703bd2a5a1566a65609f45167d5008f5fbe7b3d58d16070601e3239d59365369", transactionIndex: "49", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000006df24f6685a62f791ba337bf3ff67e91f3d4bc3a00000000000000000000000000000000000000000000006c6b935b8bbd4000000000000000000000000000000000000000000000000211654585005212800000", contractAddress: "", cumulativeGasUsed: "3159110", gasUsed: "66450", confirmations: "3407896"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[17]}, {type: "uint256", name: "_etherPaid", value: "2000000000000000000000"}, {type: "uint256", name: "_amberSold", value: "2500000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[17], "2000000000000000000000", "2500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1506004987 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x6df24f6685a62f791ba337bf3ff67e91f3d4bc3a"}, {name: "etherPaid", type: "uint256", value: "2000000000000000000000"}, {name: "amberSold", type: "uint256", value: "2500000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[18], \"840000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298637", timeStamp: "1506004994", hash: "0x4fa7a120e514d8e3ede8c9cec8c298bfa1def0661ce2e2e7685ec64d71d5203f", nonce: "176", blockHash: "0x727778d273136293c4534261a45d1ac2077f60f41da42f281a726cd588863593", transactionIndex: "10", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000003423ca8af938fabc3f072de6e308b03367a1905700000000000000000000000000000000000000000000002d89577d7d4020000000000000000000000000000000000000000000000000c5a41553f9d51a340000", contractAddress: "", cumulativeGasUsed: "414821", gasUsed: "66450", confirmations: "3407895"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[18]}, {type: "uint256", name: "_etherPaid", value: "840000000000000000000"}, {type: "uint256", name: "_amberSold", value: "933333000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[18], "840000000000000000000", "933333000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1506004994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x3423ca8af938fabc3f072de6e308b03367a19057"}, {name: "etherPaid", type: "uint256", value: "840000000000000000000"}, {name: "amberSold", type: "uint256", value: "933333000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[19], \"339443000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298637", timeStamp: "1506004994", hash: "0xd3668e8f47d7908ebe7fe06314dc38558e5ee2759b34e80f5a759bb007fe536f", nonce: "177", blockHash: "0x727778d273136293c4534261a45d1ac2077f60f41da42f281a726cd588863593", transactionIndex: "42", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000007568660b72fb8a66f2a3cca3b7b2f92167dcc100000000000000000000000000000000000000000000001266b7ca0dcceb8000000000000000000000000000000000000000000000004fddd49261f9d0bc0000", contractAddress: "", cumulativeGasUsed: "5006284", gasUsed: "66450", confirmations: "3407895"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[19]}, {type: "uint256", name: "_etherPaid", value: "339443000000000000000"}, {type: "uint256", name: "_amberSold", value: "377159000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[19], "339443000000000000000", "377159000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1506004994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x007568660b72fb8a66f2a3cca3b7b2f92167dcc1"}, {name: "etherPaid", type: "uint256", value: "339443000000000000000"}, {name: "amberSold", type: "uint256", value: "377159000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[20], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298637", timeStamp: "1506004994", hash: "0x202bb73e76cc2415fa7ef34e8e4f5672311312fd8e5a00d1df410a3cde9dd010", nonce: "178", blockHash: "0x727778d273136293c4534261a45d1ac2077f60f41da42f281a726cd588863593", transactionIndex: "51", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000ac4d6b2bc4331d756193bd0fd5018f4292fe6fd000000000000000000000000000000000000000000000017b7883c06916600000000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "5644243", gasUsed: "66514", confirmations: "3407895"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[20]}, {type: "uint256", name: "_etherPaid", value: "7000000000000000000000"}, {type: "uint256", name: "_amberSold", value: "10000000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[20], "7000000000000000000000", "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1506004994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xac4d6b2bc4331d756193bd0fd5018f4292fe6fd0"}, {name: "etherPaid", type: "uint256", value: "7000000000000000000000"}, {name: "amberSold", type: "uint256", value: "10000000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[21], \"362295600000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298639", timeStamp: "1506005089", hash: "0x3ce360992c4a036df140224ef54830b96983a55c40040119e6efbed459718f32", nonce: "179", blockHash: "0x41c685f2b41dc47b50dbb4dbecce2b4af2cdc26badd2d6928265f81416a3a00c", transactionIndex: "53", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000aba31a41b4fea558749e13f6aa12046aa109a5b5000000000000000000000000000000000000000000000013a3dc88acf703000000000000000000000000000000000000000000000000553e555c1d64df7c0000", contractAddress: "", cumulativeGasUsed: "2292604", gasUsed: "66450", confirmations: "3407893"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[21]}, {type: "uint256", name: "_etherPaid", value: "362295600000000000000"}, {type: "uint256", name: "_amberSold", value: "402551000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[21], "362295600000000000000", "402551000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1506005089 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xaba31a41b4fea558749e13f6aa12046aa109a5b5"}, {name: "etherPaid", type: "uint256", value: "362295600000000000000"}, {name: "amberSold", type: "uint256", value: "402551000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[22], \"702740000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298640", timeStamp: "1506005121", hash: "0xb4e84a491d808cb190effef60960bf83b3b6ddc028c383e346a6b2a7fb2fd71b", nonce: "180", blockHash: "0x699e875f680b50f14de080a0a428702acad3ee37aadc9f8ad04cf46ca6f848e2", transactionIndex: "19", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000003101f131f32671a8b10dd5abe5fffcd6b1d727000000000000000000000000000000000000000000000026187a02b95202000000000000000000000000000000000000000000000000a5587fe8d27171fc0000", contractAddress: "", cumulativeGasUsed: "1022374", gasUsed: "66386", confirmations: "3407892"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[22]}, {type: "uint256", name: "_etherPaid", value: "702740000000000000000"}, {type: "uint256", name: "_amberSold", value: "780823000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[22], "702740000000000000000", "780823000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1506005121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x003101f131f32671a8b10dd5abe5fffcd6b1d727"}, {name: "etherPaid", type: "uint256", value: "702740000000000000000"}, {name: "amberSold", type: "uint256", value: "780823000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[23], \"552437000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0xd1a30309f29be91b39b2f742ab44b8025f5a0ac0af08d021a6ce690da19eb747", nonce: "181", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "44", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000a8f76f25b85d31077a067d3a053a59ba65ad3fcc00000000000000000000000000000000000000000000001df29a7c90367880000000000000000000000000000000000000000000000081fb31d59b8e9a0c0000", contractAddress: "", cumulativeGasUsed: "1475633", gasUsed: "66514", confirmations: "3407885"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[23]}, {type: "uint256", name: "_etherPaid", value: "552437000000000000000"}, {type: "uint256", name: "_amberSold", value: "613819000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[23], "552437000000000000000", "613819000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xa8f76f25b85d31077a067d3a053a59ba65ad3fcc"}, {name: "etherPaid", type: "uint256", value: "552437000000000000000"}, {name: "amberSold", type: "uint256", value: "613819000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[24], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0xadd1c2ecc187535c42ab8ea9ad484172637456db0e450c5bee79118f6b357c2f", nonce: "182", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "74", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000010fbcaa2ba4d4d89f40dd0ffcd3d86326533d1fa00000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000bc3ac4ed3c3c85440000", contractAddress: "", cumulativeGasUsed: "3043449", gasUsed: "66450", confirmations: "3407885"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[24]}, {type: "uint256", name: "_etherPaid", value: "800000000000000000000"}, {type: "uint256", name: "_amberSold", value: "888889000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[24], "800000000000000000000", "888889000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x10fbcaa2ba4d4d89f40dd0ffcd3d86326533d1fa"}, {name: "etherPaid", type: "uint256", value: "800000000000000000000"}, {name: "amberSold", type: "uint256", value: "888889000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[25], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x77cad558f51db62d25714be8ae004054d9c0b30f94815632e51812c59195d2e2", nonce: "183", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "84", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000c9505b49ed8e40bd81f87c12c94938579abcda93000000000000000000000000000000000000000000000015af1d78b58c400000000000000000000000000000000000000000000000004bff3fc1547aa7d80000", contractAddress: "", cumulativeGasUsed: "3445933", gasUsed: "66450", confirmations: "3407885"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[25]}, {type: "uint256", name: "_etherPaid", value: "400000000000000000000"}, {type: "uint256", name: "_amberSold", value: "358886000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[25], "400000000000000000000", "358886000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xc9505b49ed8e40bd81f87c12c94938579abcda93"}, {name: "etherPaid", type: "uint256", value: "400000000000000000000"}, {name: "amberSold", type: "uint256", value: "358886000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[26], \"321336760000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x8ccec49a8c8cd1d27dabf8b60daed461c4af58eb87f8ca4d2a344473a87c5dbd", nonce: "184", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "90", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000f37dfe5fda3b1c882a5afb810ddde678859527290000000000000000000000000000000000000000000000116b7180b472f38000000000000000000000000000000000000000000000004b9b3b3c97b544240000", contractAddress: "", cumulativeGasUsed: "3812985", gasUsed: "66514", confirmations: "3407885"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[26]}, {type: "uint256", name: "_etherPaid", value: "321336760000000000000"}, {type: "uint256", name: "_amberSold", value: "357041000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[26], "321336760000000000000", "357041000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xf37dfe5fda3b1c882a5afb810ddde67885952729"}, {name: "etherPaid", type: "uint256", value: "321336760000000000000"}, {name: "amberSold", type: "uint256", value: "357041000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[27], \"339443300000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x15398f34ae6c1ffc45068ca24381994590b9332ce29778798113fda8ff07e773", nonce: "185", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "93", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000007065caaa38ce67810a1ec067440ba1c2b3b03aa500000000000000000000000000000000000000000000001266b8dae6fe5a4000000000000000000000000000000000000000000000004fddd49261f9d0bc0000", contractAddress: "", cumulativeGasUsed: "4058141", gasUsed: "66514", confirmations: "3407885"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[27]}, {type: "uint256", name: "_etherPaid", value: "339443300000000000000"}, {type: "uint256", name: "_amberSold", value: "377159000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[27], "339443300000000000000", "377159000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x7065caaa38ce67810a1ec067440ba1c2b3b03aa5"}, {name: "etherPaid", type: "uint256", value: "339443300000000000000"}, {name: "amberSold", type: "uint256", value: "377159000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[28], \"660500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x07bbd075ef9f89ef872bc7881d47e0623e621054691212032577dbaa05447bb1", nonce: "186", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "98", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000dcf10969d931f57ef95a8996cb7b2e7e5311e88a000000000000000000000000000000000000000000000023ce47628561820000000000000000000000000000000000000000000000009b6833d1056eba640000", contractAddress: "", cumulativeGasUsed: "4407439", gasUsed: "66450", confirmations: "3407885"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[28]}, {type: "uint256", name: "_etherPaid", value: "660500000000000000000"}, {type: "uint256", name: "_amberSold", value: "733889000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[28], "660500000000000000000", "733889000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xdcf10969d931f57ef95a8996cb7b2e7e5311e88a"}, {name: "etherPaid", type: "uint256", value: "660500000000000000000"}, {name: "amberSold", type: "uint256", value: "733889000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[29], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x2c2c191851acbe9d9c9ac68ed857dc0b0dfc348d3d7e5c88a6c578306b6d635f", nonce: "187", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "102", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000005a41f2149a4339c54d78139786a5c20fcb69fd9b00000000000000000000000000000000000000000000001043561a8829300000000000000000000000000000000000000000000000004696128568c6fa980000", contractAddress: "", cumulativeGasUsed: "4598483", gasUsed: "66450", confirmations: "3407885"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[29]}, {type: "uint256", name: "_etherPaid", value: "300000000000000000000"}, {type: "uint256", name: "_amberSold", value: "333334000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[29], "300000000000000000000", "333334000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x5a41f2149a4339c54d78139786a5c20fcb69fd9b"}, {name: "etherPaid", type: "uint256", value: "300000000000000000000"}, {name: "amberSold", type: "uint256", value: "333334000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[30], \"161498700000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x36daa442fe36e8c3f597df38aaa731c8a47d0868c686f56ebecdb16a8ba073ee", nonce: "188", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "106", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000001df30cb66f209c889575099e5e482e432b3daf0000000000000000000000000000000000000000000000578c7267eea1c7800000000000000000000000000000000000000000000001ab7bca17a8ded9f80000", contractAddress: "", cumulativeGasUsed: "4774591", gasUsed: "66514", confirmations: "3407885"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[30]}, {type: "uint256", name: "_etherPaid", value: "1614987000000000000000"}, {type: "uint256", name: "_amberSold", value: "2018734000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[30], "1614987000000000000000", "2018734000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x001df30cb66f209c889575099e5e482e432b3daf"}, {name: "etherPaid", type: "uint256", value: "1614987000000000000000"}, {name: "amberSold", type: "uint256", value: "2018734000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[31], \"322372660000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0xc44271366d975189dfaf2d2c1353f31a88bdf94185522e79c1dbac6358434e10", nonce: "189", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "112", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000007f56414307d6299a759d097c9140207dbf4b1a0000000000000000000000000000000000000000000000aec23196aa19c8800000000000000000000000000000000000000000000003cf3762a5ad37c3a40000", contractAddress: "", cumulativeGasUsed: "5054293", gasUsed: "66514", confirmations: "3407885"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[31]}, {type: "uint256", name: "_etherPaid", value: "3223726600000000000000"}, {type: "uint256", name: "_amberSold", value: "4605329000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[31], "3223726600000000000000", "4605329000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x007f56414307d6299a759d097c9140207dbf4b1a"}, {name: "etherPaid", type: "uint256", value: "3223726600000000000000"}, {name: "amberSold", type: "uint256", value: "4605329000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[32], \"389650800000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298647", timeStamp: "1506005223", hash: "0x10f47acc81b63399e170b000189487adb393ca3d0f64e8f5a0b66401e761d80c", nonce: "190", blockHash: "0xfb6e04a11b757d2bc1428e22d63d105854fbaa905842cfbfae5f1f8c77defc15", transactionIndex: "114", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000006a00b74b720c22bf83dca604cbfcd7cf178755190000000000000000000000000000000000000000000000151f7dba243ec70000000000000000000000000000000000000000000000005bae0cb861c83d880000", contractAddress: "", cumulativeGasUsed: "5160191", gasUsed: "66386", confirmations: "3407885"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[32]}, {type: "uint256", name: "_etherPaid", value: "389650800000000000000"}, {type: "uint256", name: "_amberSold", value: "432946000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[32], "389650800000000000000", "432946000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1506005223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x6a00b74b720c22bf83dca604cbfcd7cf17875519"}, {name: "etherPaid", type: "uint256", value: "389650800000000000000"}, {name: "amberSold", type: "uint256", value: "432946000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[33], \"335064500000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298651", timeStamp: "1506005342", hash: "0x9f973b9a71a173ed93d576e37b61c6cba85864a542400514e7ac1609f35cafec", nonce: "191", blockHash: "0x1245aee9deeccf869f6dc67686599829d5311676b253df99ed536bc29d7b3bac", transactionIndex: "103", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000288341eafd48cc1dbb57005c84e84640f81e48ca00000000000000000000000000000000000000000000001229f43b808fdf4000000000000000000000000000000000000000000000004ed6192255d9bd580000", contractAddress: "", cumulativeGasUsed: "3639349", gasUsed: "66450", confirmations: "3407881"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[33]}, {type: "uint256", name: "_etherPaid", value: "335064500000000000000"}, {type: "uint256", name: "_amberSold", value: "372294000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[33], "335064500000000000000", "372294000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1506005342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x288341eafd48cc1dbb57005c84e84640f81e48ca"}, {name: "etherPaid", type: "uint256", value: "335064500000000000000"}, {name: "amberSold", type: "uint256", value: "372294000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[34], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298653", timeStamp: "1506005516", hash: "0x9f8b8fb0f247953313789cf5ab698a678e2de53fec6e2710f4c932dfb64bdd44", nonce: "192", blockHash: "0xd1fd61752d557cefe53eceb64e2850fd6ef9c11c9c6c2519bdcb04cdba213eb5", transactionIndex: "77", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000050bc386b06acaf228d980e19afedb7c37201b42000000000000000000000000000000000000000000000001043561a8829300000000000000000000000000000000000000000000000004696128568c6fa980000", contractAddress: "", cumulativeGasUsed: "3240550", gasUsed: "66450", confirmations: "3407879"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[34]}, {type: "uint256", name: "_etherPaid", value: "300000000000000000000"}, {type: "uint256", name: "_amberSold", value: "333334000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[34], "300000000000000000000", "333334000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1506005516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x50bc386b06acaf228d980e19afedb7c37201b420"}, {name: "etherPaid", type: "uint256", value: "300000000000000000000"}, {name: "amberSold", type: "uint256", value: "333334000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[35], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298655", timeStamp: "1506005607", hash: "0x949924053320af2db5421444f8db858f3cc39b4b18e0811a4106f8f249463021", nonce: "193", blockHash: "0x1984f61e42b55b64c3133c6a17bf57b7f28ef66dae9d653d02d2004a53b4f2ed", transactionIndex: "59", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000d412943172e67f877c2d215be6bede1d99b3064400000000000000000000000000000000000000000000001b1ae4d6e2ef5000000000000000000000000000000000000000000000000075a4c0488a2932100000", contractAddress: "", cumulativeGasUsed: "2437263", gasUsed: "66450", confirmations: "3407877"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[35]}, {type: "uint256", name: "_etherPaid", value: "500000000000000000000"}, {type: "uint256", name: "_amberSold", value: "555556000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[35], "500000000000000000000", "555556000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1506005607 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xd412943172e67f877c2d215be6bede1d99b30644"}, {name: "etherPaid", type: "uint256", value: "500000000000000000000"}, {name: "amberSold", type: "uint256", value: "555556000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[36], \"315000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298656", timeStamp: "1506005642", hash: "0x12d61a5c205648a649c1a00e36d0294087b31c2c87904b3bd84458dc0beecbef", nonce: "194", blockHash: "0x75680ff3fbb59c30563ca65cf5169e93585494394e5f35b4e74ea6e35302119f", transactionIndex: "33", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000416b495ed145c858db6b307df5ff06e838fe18180000000000000000000000000000000000000000000000111380cf0ef80c0000000000000000000000000000000000000000000000004a1d89bb94865ec00000", contractAddress: "", cumulativeGasUsed: "1750167", gasUsed: "66450", confirmations: "3407876"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[36]}, {type: "uint256", name: "_etherPaid", value: "315000000000000000000"}, {type: "uint256", name: "_amberSold", value: "350000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[36], "315000000000000000000", "350000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1506005642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x416b495ed145c858db6b307df5ff06e838fe1818"}, {name: "etherPaid", type: "uint256", value: "315000000000000000000"}, {name: "amberSold", type: "uint256", value: "350000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[37], \"525000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x24dd9b056e434b92b998afbc15fd51684e20d1d19eb23cbea332043c6333e94f", nonce: "195", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "100", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000004d163e5fb6a19148d178436d19180b98148465eb00000000000000000000000000000000000000000000001c75d6ae6e48140000000000000000000000000000000000000000000000007b8699791c0262d80000", contractAddress: "", cumulativeGasUsed: "4183453", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[37]}, {type: "uint256", name: "_etherPaid", value: "525000000000000000000"}, {type: "uint256", name: "_amberSold", value: "583334000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[37], "525000000000000000000", "583334000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x4d163e5fb6a19148d178436d19180b98148465eb"}, {name: "etherPaid", type: "uint256", value: "525000000000000000000"}, {name: "amberSold", type: "uint256", value: "583334000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[38], \"725000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x19113c37fe53b9814afa4b4034ea6b48b0d2e48626f559fb2d36fb28f7ed063b", nonce: "196", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "101", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000006b4574f5cc17c5de1b69b236ead89ff3f1a509210000000000000000000000000000000000000000000000274d656ac90e34000000000000000000000000000000000000000000000000aa95473c3d649a500000", contractAddress: "", cumulativeGasUsed: "4249903", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[38]}, {type: "uint256", name: "_etherPaid", value: "725000000000000000000"}, {type: "uint256", name: "_amberSold", value: "805556000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[38], "725000000000000000000", "805556000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x6b4574f5cc17c5de1b69b236ead89ff3f1a50921"}, {name: "etherPaid", type: "uint256", value: "725000000000000000000"}, {name: "amberSold", type: "uint256", value: "805556000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[39], \"322372600000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x983859a3a84494e5cda2a1a3d0186edac7ea1eca20f98e5556ffeeffe369f45b", nonce: "197", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "102", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000b57e171ad7eda0a3eebabca5cb935d717519cc5900000000000000000000000000000000000000000000001179d18bb25f178000000000000000000000000000000000000000000000004bd9a0920972dec00000", contractAddress: "", cumulativeGasUsed: "4316417", gasUsed: "66514", confirmations: "3407869"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[39]}, {type: "uint256", name: "_etherPaid", value: "322372600000000000000"}, {type: "uint256", name: "_amberSold", value: "358192000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[39], "322372600000000000000", "358192000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xb57e171ad7eda0a3eebabca5cb935d717519cc59"}, {name: "etherPaid", type: "uint256", value: "322372600000000000000"}, {name: "amberSold", type: "uint256", value: "358192000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[40], \"160100000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xc6815c281976f3c8b238488361699ac9056ed05481d68a863ad196ff0a6f2835", nonce: "198", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "103", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000fed93ee80526b14f4b2f1940986c8b802cb9bda9000000000000000000000000000000000000000000000056ca569989d864000000000000000000000000000000000000000000000001a7c7fad9b31298480000", contractAddress: "", cumulativeGasUsed: "4382931", gasUsed: "66514", confirmations: "3407869"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[40]}, {type: "uint256", name: "_etherPaid", value: "1601000000000000000000"}, {type: "uint256", name: "_amberSold", value: "2001250000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[40], "1601000000000000000000", "2001250000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xfed93ee80526b14f4b2f1940986c8b802cb9bda9"}, {name: "etherPaid", type: "uint256", value: "1601000000000000000000"}, {name: "amberSold", type: "uint256", value: "2001250000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[41], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x0f43fb805e7afeabb4fc8d447c2b3b9a39e58225e821481453e56cc1501e06f4", nonce: "199", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "104", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000303c8bec9763b6c15abbc3b4041ddad99e896e09000000000000000000000000000000000000000000000015af1d78b58c400000000000000000000000000000000000000000000000005e1d6966f97816540000", contractAddress: "", cumulativeGasUsed: "4449381", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[41]}, {type: "uint256", name: "_etherPaid", value: "400000000000000000000"}, {type: "uint256", name: "_amberSold", value: "444445000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[41], "400000000000000000000", "444445000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x303c8bec9763b6c15abbc3b4041ddad99e896e09"}, {name: "etherPaid", type: "uint256", value: "400000000000000000000"}, {name: "amberSold", type: "uint256", value: "444445000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[42], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x0b1c09f13e1b0bf6c983d9219a8444d493d9a7edf1aa61b74b39f59b1d5cdc3a", nonce: "200", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "105", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000004d757b21eab8a905b68fc4350a0a1987ac0e588000000000000000000000000000000000000000000000015af1d78b58c400000000000000000000000000000000000000000000000005e1d6966f97816540000", contractAddress: "", cumulativeGasUsed: "4515831", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[42]}, {type: "uint256", name: "_etherPaid", value: "400000000000000000000"}, {type: "uint256", name: "_amberSold", value: "444445000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[42], "400000000000000000000", "444445000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x04d757b21eab8a905b68fc4350a0a1987ac0e588"}, {name: "etherPaid", type: "uint256", value: "400000000000000000000"}, {name: "amberSold", type: "uint256", value: "444445000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[43], \"322372600000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x15bb79a5d86d74585666d610daaba5027416ec0540f7e61963edf087b7a7bf4f", nonce: "201", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "106", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000006e931201bcf7ebb18a72b0bcf4f237f85804074d00000000000000000000000000000000000000000000001179d18bb25f178000000000000000000000000000000000000000000000004bd9a0920972dec00000", contractAddress: "", cumulativeGasUsed: "4582345", gasUsed: "66514", confirmations: "3407869"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[43]}, {type: "uint256", name: "_etherPaid", value: "322372600000000000000"}, {type: "uint256", name: "_amberSold", value: "358192000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[43], "322372600000000000000", "358192000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x6e931201bcf7ebb18a72b0bcf4f237f85804074d"}, {name: "etherPaid", type: "uint256", value: "322372600000000000000"}, {name: "amberSold", type: "uint256", value: "358192000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[44], \"900000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x32094cb2b66cc833a74f100435ed162946ba3c3b7510d108405b332aa7d1656a", nonce: "202", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "107", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000da7807a16a7edad0fad53b1e4b0010fec7e37d24000000000000000000000000000000000000000000000030ca024f987b9000000000000000000000000000000000000000000000000122b30a72682808b40000", contractAddress: "", cumulativeGasUsed: "4648795", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[44]}, {type: "uint256", name: "_etherPaid", value: "900000000000000000000"}, {type: "uint256", name: "_amberSold", value: "1372789000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[44], "900000000000000000000", "1372789000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xda7807a16a7edad0fad53b1e4b0010fec7e37d24"}, {name: "etherPaid", type: "uint256", value: "900000000000000000000"}, {name: "amberSold", type: "uint256", value: "1372789000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[45], \"506380000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xce389c7beda006a969772fbca333fe364e27cbe95a45a726528eed5130ce1cc8", nonce: "203", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "108", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000eed78d297fdcf061d0f8c26cb7461f3069b803c5000000000000000000000000000000000000000000000112825786d6770c000000000000000000000000000000000000000000000005a79b59910ef7c9480000", contractAddress: "", cumulativeGasUsed: "4715373", gasUsed: "66578", confirmations: "3407869"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[45]}, {type: "uint256", name: "_etherPaid", value: "5063800000000000000000"}, {type: "uint256", name: "_amberSold", value: "6836130000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[45], "5063800000000000000000", "6836130000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xeed78d297fdcf061d0f8c26cb7461f3069b803c5"}, {name: "etherPaid", type: "uint256", value: "5063800000000000000000"}, {name: "amberSold", type: "uint256", value: "6836130000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[46], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x28a7d47dbb12c994be6d8b9a5a6e2491bba07b04851dacfbe3533b9b2571462e", nonce: "204", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "109", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000001d3ee04e08dc28757909a644dda36c2fffe333610000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000017046c0607e903600000", contractAddress: "", cumulativeGasUsed: "4781823", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[46]}, {type: "uint256", name: "_etherPaid", value: "100000000000000000000"}, {type: "uint256", name: "_amberSold", value: "108696000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[46], "100000000000000000000", "108696000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x1d3ee04e08dc28757909a644dda36c2fffe33361"}, {name: "etherPaid", type: "uint256", value: "100000000000000000000"}, {name: "amberSold", type: "uint256", value: "108696000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[47], \"270000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xebeb604ca8a4ddcae57efedc35befcf912d70bcb7f1c2ef5e5e33b878ac1e74d", nonce: "205", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "110", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000ce9450f366bb61874f90484d05f30cc44c1d72dd00000000000000000000000000000000000000000000000ea300b17a8b780000000000000000000000000000000000000000000000003f870857a3e0e3800000", contractAddress: "", cumulativeGasUsed: "4848209", gasUsed: "66386", confirmations: "3407869"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[47]}, {type: "uint256", name: "_etherPaid", value: "270000000000000000000"}, {type: "uint256", name: "_amberSold", value: "300000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[47], "270000000000000000000", "300000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xce9450f366bb61874f90484d05f30cc44c1d72dd"}, {name: "etherPaid", type: "uint256", value: "270000000000000000000"}, {name: "amberSold", type: "uint256", value: "300000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[48], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0x7cd4e6b33f8203a7781b3920436f92d7d758aeaf1f71cf52f6e54b894094d4b6", nonce: "206", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "111", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000003b015942a9f81a04111b8828e1335e3a78ede5a700000000000000000000000000000000000000000000000821ab0d441498000000000000000000000000000000000000000000000000234b0942b4637d4c0000", contractAddress: "", cumulativeGasUsed: "4914659", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[48]}, {type: "uint256", name: "_etherPaid", value: "150000000000000000000"}, {type: "uint256", name: "_amberSold", value: "166667000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[48], "150000000000000000000", "166667000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x3b015942a9f81a04111b8828e1335e3a78ede5a7"}, {name: "etherPaid", type: "uint256", value: "150000000000000000000"}, {name: "amberSold", type: "uint256", value: "166667000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[49], \"342900000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xa9f58e302baedf04410d93a490a73b0061285bcfc58133b5ce72fbf54b3f54ce", nonce: "207", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "112", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000000e2551ad0664cd0bbc0e29fe9a57d94a8d0e2ffa0000000000000000000000000000000000000000000000b9e2ef34611e740000000000000000000000000000000000000000000000045d1b31a2706108440000", contractAddress: "", cumulativeGasUsed: "4981173", gasUsed: "66514", confirmations: "3407869"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[49]}, {type: "uint256", name: "_etherPaid", value: "3429000000000000000000"}, {type: "uint256", name: "_amberSold", value: "5275385000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[49], "3429000000000000000000", "5275385000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x0e2551ad0664cd0bbc0e29fe9a57d94a8d0e2ffa"}, {name: "etherPaid", type: "uint256", value: "3429000000000000000000"}, {name: "amberSold", type: "uint256", value: "5275385000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[50], \"468100000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xe98c6ff462c86eaa8ebec7d0b923159bf7a3860fedcd77f8cea85483c8042285", nonce: "208", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "113", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000ba61c6657e928d2c3de8c011f7f32beb5ceb65810000000000000000000000000000000000000000000000fdc1ecbaffc384000000000000000000000000000000000000000000000005f4fc3621b71ca22c0000", contractAddress: "", cumulativeGasUsed: "5047687", gasUsed: "66514", confirmations: "3407869"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[50]}, {type: "uint256", name: "_etherPaid", value: "4681000000000000000000"}, {type: "uint256", name: "_amberSold", value: "7201539000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[50], "4681000000000000000000", "7201539000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xba61c6657e928d2c3de8c011f7f32beb5ceb6581"}, {name: "etherPaid", type: "uint256", value: "4681000000000000000000"}, {name: "amberSold", type: "uint256", value: "7201539000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[51], \"280000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298663", timeStamp: "1506005766", hash: "0xb3ec7fbd11c584d9dc2b421aec609f8fae64248282c203111d27e87ac95090b7", nonce: "209", blockHash: "0x2f6b2465c0a79b5b0e6841ad65495da39cd808dd5f82e5af527b77ba625bb2f0", transactionIndex: "114", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000008f98b2e6d73f1f754ad0ebb7c74eb6ed7fb6fdd400000000000000000000000000000000000000000000000f2dc7d47f156000000000000000000000000000000000000000000000000041e16a5209fab0200000", contractAddress: "", cumulativeGasUsed: "5114137", gasUsed: "66450", confirmations: "3407869"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[51]}, {type: "uint256", name: "_etherPaid", value: "280000000000000000000"}, {type: "uint256", name: "_amberSold", value: "311112000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[51], "280000000000000000000", "311112000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1506005766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x8f98b2e6d73f1f754ad0ebb7c74eb6ed7fb6fdd4"}, {name: "etherPaid", type: "uint256", value: "280000000000000000000"}, {name: "amberSold", type: "uint256", value: "311112000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[52], \"240000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298672", timeStamp: "1506006059", hash: "0xdfe420526d3746c84ef302d4e1417c04c484beecd4e7f80c35633a591dafc264", nonce: "210", blockHash: "0xb20b8b93adaa43e89875b0ca53adbd68fedaafaf0d9cc9ea61f0c7dd7f7d0a75", transactionIndex: "28", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000091cf2ff178f49914ee827fce528433300591a3da00000000000000000000000000000000000000000000000d02ab486cedc000000000000000000000000000000000000000000000000038780c0a95ae73cc0000", contractAddress: "", cumulativeGasUsed: "945083", gasUsed: "66450", confirmations: "3407860"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[52]}, {type: "uint256", name: "_etherPaid", value: "240000000000000000000"}, {type: "uint256", name: "_amberSold", value: "266667000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[52], "240000000000000000000", "266667000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1506006059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x91cf2ff178f49914ee827fce528433300591a3da"}, {name: "etherPaid", type: "uint256", value: "240000000000000000000"}, {name: "amberSold", type: "uint256", value: "266667000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[53], \"45000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0x988b7f95083412bdaa23ca43f4b3366b24e00eaf018a5f2c20ef72bfb0276f43", nonce: "211", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "158", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000004682ffdfa1250a76726f0aef31aac8d5c078a20a00000000000000000000000000000000000000000000000270801d946c940000000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "5377096", gasUsed: "66450", confirmations: "3407859"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[53]}, {type: "uint256", name: "_etherPaid", value: "45000000000000000000"}, {type: "uint256", name: "_amberSold", value: "50000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[53], "45000000000000000000", "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x4682ffdfa1250a76726f0aef31aac8d5c078a20a"}, {name: "etherPaid", type: "uint256", value: "45000000000000000000"}, {name: "amberSold", type: "uint256", value: "50000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[54], \"307377000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0xf1e8223260b74733beb2407956c0c23289ff8f4cf24979221cabbef3210a0c53", nonce: "212", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "159", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000e9061d25c4aa4f8a19713526347e8ada5bbc05bb000000000000000000000000000000000000000000000010a9b678f2653e800000000000000000000000000000000000000000000000485260deb88218280000", contractAddress: "", cumulativeGasUsed: "5443610", gasUsed: "66514", confirmations: "3407859"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[54]}, {type: "uint256", name: "_etherPaid", value: "307377000000000000000"}, {type: "uint256", name: "_amberSold", value: "341530000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[54], "307377000000000000000", "341530000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xe9061d25c4aa4f8a19713526347e8ada5bbc05bb"}, {name: "etherPaid", type: "uint256", value: "307377000000000000000"}, {name: "amberSold", type: "uint256", value: "341530000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[55], \"310000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0xf46962abbc298c126c251ca17248d2c040a492ce0af9f91b2c654117f4197b67", nonce: "213", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "160", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000051026c641548b4e4080c5be4fc0afa20eb0727e3000000000000000000000000000000000000000000000010ce1d3d8cb31800000000000000000000000000000000000000000000000048f0669f182d1fd40000", contractAddress: "", cumulativeGasUsed: "5510060", gasUsed: "66450", confirmations: "3407859"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[55]}, {type: "uint256", name: "_etherPaid", value: "310000000000000000000"}, {type: "uint256", name: "_amberSold", value: "344445000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[55], "310000000000000000000", "344445000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x51026c641548b4e4080c5be4fc0afa20eb0727e3"}, {name: "etherPaid", type: "uint256", value: "310000000000000000000"}, {name: "amberSold", type: "uint256", value: "344445000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[56], \"166235700000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0x75c5d1b5882d1c2f8a52fa9314411754505f475e5825b3dac72475a695961e31", nonce: "214", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "161", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000007a725fa605f320d885dfb4545335c72f2c84dc0700000000000000000000000000000000000000000000005a1dd673f48408800000000000000000000000000000000000000000000001b805bb8ab8f36f0c0000", contractAddress: "", cumulativeGasUsed: "5576638", gasUsed: "66578", confirmations: "3407859"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[56]}, {type: "uint256", name: "_etherPaid", value: "1662357000000000000000"}, {type: "uint256", name: "_amberSold", value: "2077947000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[56], "1662357000000000000000", "2077947000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x7a725fa605f320d885dfb4545335c72f2c84dc07"}, {name: "etherPaid", type: "uint256", value: "1662357000000000000000"}, {name: "amberSold", type: "uint256", value: "2077947000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[57], \"345803000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0x0a5fa9a701c58241e35e3742c9b910f85f0de7594062682ba76863db4d0b49d8", nonce: "215", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "162", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000f65bd56d081f2973758955836e6c3c5fdcbef4b2000000000000000000000000000000000000000000000012befb0c5b7067800000000000000000000000000000000000000000000000515ceee5f367b6480000", contractAddress: "", cumulativeGasUsed: "5643152", gasUsed: "66514", confirmations: "3407859"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[57]}, {type: "uint256", name: "_etherPaid", value: "345803000000000000000"}, {type: "uint256", name: "_amberSold", value: "384226000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[57], "345803000000000000000", "384226000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xf65bd56d081f2973758955836e6c3c5fdcbef4b2"}, {name: "etherPaid", type: "uint256", value: "345803000000000000000"}, {name: "amberSold", type: "uint256", value: "384226000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[58], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0x0e2c4ac4bf4e6a20ce6ad3fa9a761ceaf8a8b547c7098d4c8d1497c94fa918e0", nonce: "216", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "163", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000008d60b70c188bc3dcac68cda765f069cd19ed2cba0000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000017046c0607e903600000", contractAddress: "", cumulativeGasUsed: "5709602", gasUsed: "66450", confirmations: "3407859"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[58]}, {type: "uint256", name: "_etherPaid", value: "100000000000000000000"}, {type: "uint256", name: "_amberSold", value: "108696000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[58], "100000000000000000000", "108696000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x8d60b70c188bc3dcac68cda765f069cd19ed2cba"}, {name: "etherPaid", type: "uint256", value: "100000000000000000000"}, {name: "amberSold", type: "uint256", value: "108696000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[59], \"314366000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298673", timeStamp: "1506006107", hash: "0xd074533cdd8366765d1f676fb540785f9940bc97d5b1f5285fb064f25f251621", nonce: "217", blockHash: "0x5af5067c7af209b5a55e1d1269aaf05b283529b2fbb8515c8bc917456193da2d", transactionIndex: "164", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000002669f428f2489425ad2a08880494801a32312ab20000000000000000000000000000000000000000000000110ab4636ae47300000000000000000000000000000000000000000000000049f75fc5267a0bc00000", contractAddress: "", cumulativeGasUsed: "5776052", gasUsed: "66450", confirmations: "3407859"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[59]}, {type: "uint256", name: "_etherPaid", value: "314366000000000000000"}, {type: "uint256", name: "_amberSold", value: "349296000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[59], "314366000000000000000", "349296000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1506006107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x2669f428f2489425ad2a08880494801a32312ab2"}, {name: "etherPaid", type: "uint256", value: "314366000000000000000"}, {name: "amberSold", type: "uint256", value: "349296000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[60], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298675", timeStamp: "1506006128", hash: "0x4a4faaad9980556184c9e08828f2a26ec236308773146d7a2887d26842aea634", nonce: "218", blockHash: "0x6b53111c27388e43e8f8873da93a43601db94d7ff6523cbdaab48de6890ccd5b", transactionIndex: "14", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b4000000000000000000000000e905154abda61b7e19d0d94af3fcfde5b7b42725000000000000000000000000000000000000000000000012f939c99edab80000000000000000000000000000000000000000000000005259b705d5c5b4c40000", contractAddress: "", cumulativeGasUsed: "532208", gasUsed: "66450", confirmations: "3407857"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[60]}, {type: "uint256", name: "_etherPaid", value: "350000000000000000000"}, {type: "uint256", name: "_amberSold", value: "388889000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[60], "350000000000000000000", "388889000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1506006128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0xe905154abda61b7e19d0d94af3fcfde5b7b42725"}, {name: "etherPaid", type: "uint256", value: "350000000000000000000"}, {name: "amberSold", type: "uint256", value: "388889000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[61], \"590000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298676", timeStamp: "1506006151", hash: "0xca223080c75dc01fd20d79f350bf222d58188dd890d36b25d5bf4da5892b4ac0", nonce: "219", blockHash: "0x513ac058f33b1255cbaf72084e0ddb7e60ccc58e08af4fa5426c84e20b0ed7a6", transactionIndex: "38", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b40000000000000000000000005423ab37d667562bec0e1206a6e4913ad014862f00000000000000000000000000000000000000000000001ffbe5120bc8780000000000000000000000000000000000000000000000008ad1c3106b7428900000", contractAddress: "", cumulativeGasUsed: "1562308", gasUsed: "66450", confirmations: "3407856"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[61]}, {type: "uint256", name: "_etherPaid", value: "590000000000000000000"}, {type: "uint256", name: "_amberSold", value: "655556000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[61], "590000000000000000000", "655556000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1506006151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x5423ab37d667562bec0e1206a6e4913ad014862f"}, {name: "etherPaid", type: "uint256", value: "590000000000000000000"}, {name: "amberSold", type: "uint256", value: "655556000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: notePrepurchase( addressList[62], \"450000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298676", timeStamp: "1506006151", hash: "0xae261facd332e56146eef6891666a707334cc8a4f9f2b126b8c8ee7f62ecb82f", nonce: "220", blockHash: "0x513ac058f33b1255cbaf72084e0ddb7e60ccc58e08af4fa5426c84e20b0ed7a6", transactionIndex: "39", from: "0x00c269e9d02188e39c9922386de631c6aed5b4d4", to: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535", value: "0", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x572f37b400000000000000000000000079dbdc13e0aa0e2915c4ba60b41af8156f514a42000000000000000000000000000000000000000000000018650127cc3dc800000000000000000000000000000000000000000000000069e10de76676d0800000", contractAddress: "", cumulativeGasUsed: "1628758", gasUsed: "66450", confirmations: "3407856"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[62]}, {type: "uint256", name: "_etherPaid", value: "450000000000000000000"}, {type: "uint256", name: "_amberSold", value: "500000000000000000000000"}], name: "notePrepurchase", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "notePrepurchase(address,uint256,uint256)" ]( addressList[62], "450000000000000000000", "500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1506006151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "etherPaid", type: "uint256"}, {indexed: false, name: "amberSold", type: "uint256"}], name: "Prepurchased", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Prepurchased", events: [{name: "recipient", type: "address", value: "0x79dbdc13e0aa0e2915c4ba60b41af8156f514a42"}, {name: "etherPaid", type: "uint256", value: "450000000000000000000"}, {name: "amberSold", type: "uint256", value: "500000000000000000000000"}], address: "0x89f4f1910718b4208ca9ba2eb39e07bafc70b535"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "10522854711874137554" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
