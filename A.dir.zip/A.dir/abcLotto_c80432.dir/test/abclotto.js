const abcLotto = artifacts.require( "./abcLotto.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "abcLotto" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xaD4769638175F3737Ce994D9DF9636Df8Ac80432", "0xdE4413799C73a356d83AcE2Dc9055957c0A5C335", "0x15ebb02F39563675Fd255d34b8c03650373A8F0F", "0xf4b91F89B38Ce4463b8C209C26FEeD31Ddb25c79", "0x434A19c342BB0a437113b45450dF3A47eA430680", "0xACC9bD563B8181f1049F9547F335Be2dE1E8C65e", "0x956b078d57d9F0D34782048AfbB719d133d922a4", "0xb672862d9B9CDa5881018C5d877b8cd350817D8A", "0xB669613C57Db4b86C516c8691e9250A3EF2Cfe30", "0xce466959E80742b366Fed630D6204508C38678a6", "0x8D20ada5B704f4678445190d5B2D478aaa363C17", "0x63eb39172dDB51ff6e0158e3DCd07Dd9b656a442", "0xe1e3ECe279bF7E77B2c9D82E12d15AFAcf44C170", "0x10D9159dE465E7fA4D0af3660Dd001409305456D", "0xD5c489c0E4E450d9ECb996EaF9D420D9e8A7444F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "resolver", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "book", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentState", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "addrs", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "amounts", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "round", type: "uint32"}], name: "getDailyJackpot", outputs: [{name: "jackpot", type: "uint8[5]"}, {name: "amount", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "round", type: "uint32"}, {name: "index", type: "uint32"}], name: "getSingleBet", outputs: [{name: "nums", type: "uint8[5]"}, {name: "payed1", type: "bool"}, {name: "payed2", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentRound", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rollover", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "drawed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "week", type: "uint32"}], name: "getWeeklyJackpot", outputs: [{name: "jackpot", type: "uint8[5]"}, {name: "amount", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "round", type: "uint32"}, {name: "nums", type: "uint8[5]"}], name: "getAmountDailybyNum", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "poolUsed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "controller", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "week", type: "uint32"}, {name: "nums", type: "uint8[5]"}], name: "getAmountWeeklybyNum", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "reward", type: "uint256"}], name: "OnRewardDaily", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "reward", type: "uint256"}], name: "OnRewardWeekly", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}], name: "OnRewardDailyFailed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}], name: "OnRewardWeeklyFailed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "round", type: "uint32"}], name: "OnNewRound", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "round", type: "uint32"}], name: "OnFreeze", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "round", type: "uint32"}], name: "OnUnFreeze", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "round", type: "uint32"}], name: "OnDrawStart", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "jackpot", type: "uint8[5]"}], name: "OnDrawFinished", type: "event"}, {anonymous: false, inputs: [], name: "BalanceNotEnough", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["OnBuy(address,uint32,uint32,uint8[5])", "OnRewardDaily(address,uint32,uint32,uint256)", "OnRewardWeekly(address,uint32,uint32,uint256)", "OnRewardDailyFailed(address,uint32,uint32)", "OnRewardWeeklyFailed(address,uint32,uint32)", "OnNewRound(uint32)", "OnFreeze(uint32)", "OnUnFreeze(uint32)", "OnDrawStart(uint32)", "OnDrawFinished(uint32,uint8[5])", "BalanceNotEnough()"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x211bea642b90261164523a55e2a2138e059507beabbe5d9c6eff94da3d281af2", "0xab6cc4ece396ea892948c36aee98741f205e1d466bbb46b9a7873552c2591397", "0xbb01ef9c107bdd9d5e635566fa2ca9480b4e6c2ab8632c33aca62b9e129371cd", "0xafc65e2b6e2bbc70130b594b9ca7b274cdf492b598197aa1886ddb133dddd4f3", "0x2a3f8fdcf389229c0cbbe8b6b34a40afb1d323cbe950093026433ef8aee9a738", "0xcee08990aeacdcc467ad07e1de54fa3b93cb27b4a8c8a723f1739822127b9c27", "0x71c1019f62a6111025deb2e2b4b72da1563999b1932e9a1536a6204b5c8e790e", "0xeca3a38c5228a5d760b0b750463923c0f4fc35fa39595c70edbe0e59c5187389", "0xdfe2773cd0b6e5587e27b40c368eb0426a6ccc940a1ca42c3e09b84a54e49966", "0x59cc8149edae3e14da2e99d320d7277af320cc73c2a45a59227b55f62a732788", "0x98828835a58082f719bee4d7f39a7a905afe45161e553d71af9275957ce87c45"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6554408 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6587078 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "abcLotto", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "resolver", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "resolver()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "book", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "book()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "addrs", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addrs(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "amounts", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "amounts(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "round", value: random.range( maxRandom )}], name: "getDailyJackpot", outputs: [{name: "jackpot", type: "uint8[5]"}, {name: "amount", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDailyJackpot(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "round", value: random.range( maxRandom )}, {type: "uint32", name: "index", value: random.range( maxRandom )}], name: "getSingleBet", outputs: [{name: "nums", type: "uint8[5]"}, {name: "payed1", type: "bool"}, {name: "payed2", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSingleBet(uint32,uint32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentRound", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentRound()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rollover", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rollover()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "drawed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "drawed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "week", value: random.range( maxRandom )}], name: "getWeeklyJackpot", outputs: [{name: "jackpot", type: "uint8[5]"}, {name: "amount", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getWeeklyJackpot(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "round", value: random.range( maxRandom )}, {type: "uint8[5]", name: "nums", value: [random.range( maxRandom )]}], name: "getAmountDailybyNum", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAmountDailybyNum(uint32,uint8[5])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "poolUsed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "poolUsed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "controller", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "controller()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "week", value: random.range( maxRandom )}, {type: "uint8[5]", name: "nums", value: [random.range( maxRandom )]}], name: "getAmountWeeklybyNum", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAmountWeeklybyNum(uint32,uint8[5])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "abcLotto", function( accounts ) {

	it( "TEST: abcLotto(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6554408", timeStamp: "1540096884", hash: "0x15dc91de8a4d3e849e20eec4ef34d34f996423ba44a48b50d8871d3820cae3db", nonce: "2", blockHash: "0x305015434aa5861359ff0113e8c9368f96cf0c0917ca7886950eacf7467f0294", transactionIndex: "33", from: "0x15ebb02f39563675fd255d34b8c03650373a8f0f", to: 0, value: "0", gas: "5445011", gasPrice: "3300000000", isError: "0", txreceipt_status: "1", input: "0xbc30e4ac", contractAddress: "0xad4769638175f3737ce994d9df9636df8ac80432", cumulativeGasUsed: "6989656", gasUsed: "5445011", confirmations: "1182179"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "abcLotto", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = abcLotto.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540096884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = abcLotto.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "499614418816861101" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"14\",\"6\",\"16\",\"2\",\"12\"], `Ron... )", async function( ) {
		const txOriginal = {blockNumber: "6559641", timeStamp: "1540171354", hash: "0x0153a296fe7401640104acb9ed09d3d49822b64769878a1ba2ff5e2728f871cc", nonce: "1", blockHash: "0xcbf59e19070f9de9cbdbf76be7550865f03e03906e037c31f6d195ac4e31eb41", transactionIndex: "15", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "661617", gasPrice: "2510000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6718082", gasUsed: "441078", confirmations: "1176946"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["14","6","16","2","12"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["14","6","16","2","12"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540171354 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [12]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"7\",\"15\",\"13\",\"4\",\"2\"], `Rode... )", async function( ) {
		const txOriginal = {blockNumber: "6559878", timeStamp: "1540174305", hash: "0xd5c814634d4d0e1b27b0aa45b0a13b9a53ce5844209790ad133997d5d6cdd3cd", nonce: "1", blockHash: "0xcf03e202cdc830d150c9c40aa0c57fcc2472a8d934bdf546460e94aaa521c911", transactionIndex: "67", from: "0x434a19c342bb0a437113b45450df3a47ea430680", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "635767", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008526f64657269636b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4193464", gasUsed: "423845", confirmations: "1176709"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["7","15","13","4","2"]}, {type: "string", name: "inviter", value: `Roderick`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["7","15","13","4","2"], `Roderick`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540174305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x434a19c342bb0a437113b45450df3a47ea430680"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 0, c: [2]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"4\",\"12\",\"8\",\"5\",\"10\"], `Andy... )", async function( ) {
		const txOriginal = {blockNumber: "6560045", timeStamp: "1540176411", hash: "0x96657aefa25c9e36eb5c93e07d18cac9aca852b70986290cea3d7b1888db0d19", nonce: "1", blockHash: "0x9ee8aae063e7ffcf4ca6db8033078ac4adcf6ece29af6577b6a31508d24c2c61", transactionIndex: "105", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "615615", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004416e647900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5623703", gasUsed: "410410", confirmations: "1176542"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["4","12","8","5","10"]}, {type: "string", name: "inviter", value: `Andy`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["4","12","8","5","10"], `Andy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540176411 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [10]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"10\",\"15\",\"7\",\"4\",\"13\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6560865", timeStamp: "1540188233", hash: "0x614870b6d55fe217c1faec529baf74832d50b702bdbadba6b090392eee5d731c", nonce: "1", blockHash: "0xf530b192f73f2a78c5fb0753fcdcda12183564380269566a617908442cf2893e", transactionIndex: "80", from: "0x956b078d57d9f0d34782048afbb719d133d922a4", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "524551", gasPrice: "4500000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6865885", gasUsed: "349701", confirmations: "1175722"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["10","15","7","4","13"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["10","15","7","4","13"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540188233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x956b078d57d9f0d34782048afbb719d133d922a4"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [13]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "201573978029134432" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"6\",\"14\",\"4\",\"11\",\"9\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6560907", timeStamp: "1540188877", hash: "0xb0c811b77ae441c9ae86bb37930ac993b40a102c585fde89d65ed26563650f42", nonce: "27", blockHash: "0xc8d4793e4a6e6d004b709735173bd856588293db9985ac809c114e674f965c7b", transactionIndex: "48", from: "0x15ebb02f39563675fd255d34b8c03650373a8f0f", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "524146", gasPrice: "3343750000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7381495", gasUsed: "349431", confirmations: "1175680"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["6","14","4","11","9"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["6","14","4","11","9"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540188877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x15ebb02f39563675fd255d34b8c03650373a8f0f"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [6]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [9]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "499614418816861101" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"4\",\"12\",\"14\",\"6\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6560925", timeStamp: "1540189088", hash: "0x83d6ed39cdf20ceed66f654fd7a201aad71baef2d5bb2298681868bed74f69f8", nonce: "0", blockHash: "0x548a6318f23296057064f6ae2b02a8147399aa29f9b48e3a0e97a213e5412ff9", transactionIndex: "72", from: "0xb672862d9b9cda5881018c5d877b8cd350817d8a", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "523741", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6940158", gasUsed: "349161", confirmations: "1175662"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","4","12","14","6"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","4","12","14","6"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540189088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xb672862d9b9cda5881018c5d877b8cd350817d8a"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [6]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "376663685776352000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"15\",\"12\",\"1\",\"13\",\"3\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6560954", timeStamp: "1540189471", hash: "0xce8881464e44f98dafb69fd7427110f2ef75133724b9705f8d3a76fd9fdb7488", nonce: "2", blockHash: "0xacf6b72e6edbae915c8ec93a9f6b004449f086a6563aa26f0da24274e59b02e0", transactionIndex: "106", from: "0xb669613c57db4b86c516c8691e9250a3ef2cfe30", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "524956", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7807274", gasUsed: "349971", confirmations: "1175633"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["15","12","1","13","3"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["15","12","1","13","3"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540189471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xb669613c57db4b86c516c8691e9250a3ef2cfe30"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [3]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"10\",\"5\",\"13\",\"4\",\"1\"], `Rode... )", async function( ) {
		const txOriginal = {blockNumber: "6561292", timeStamp: "1540194401", hash: "0x0b2dd61b09afb281378c5183f066b2308cd6b2d4c4f386dccf83a39a26f67737", nonce: "2", blockHash: "0xca0088161e976557c60db134334eed814cef296bc5500edce3bd62c1a9fc6710", transactionIndex: "60", from: "0x434a19c342bb0a437113b45450df3a47ea430680", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "527206", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008526f64657269636b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6119919", gasUsed: "351471", confirmations: "1175295"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["10","5","13","4","1"]}, {type: "string", name: "inviter", value: `Roderick`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["10","5","13","4","1"], `Roderick`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540194401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x434a19c342bb0a437113b45450df3a47ea430680"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"4\",\"7\",\"8\",\"13\",\"11\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6561351", timeStamp: "1540195306", hash: "0x9875fb28bb53ce9fd23c182819df5eea4951be1074aebc8e03d3e1b87cf770ec", nonce: "0", blockHash: "0x1d1e23d7ee291e11dedbacaa507f32abe8f8c473ce8b9fec924c18a116c1b1a8", transactionIndex: "133", from: "0xce466959e80742b366fed630d6204508c38678a6", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "522526", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5252522", gasUsed: "348351", confirmations: "1175236"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["4","7","8","13","11"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["4","7","8","13","11"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540195306 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xce466959e80742b366fed630d6204508c38678a6"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [4]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [11]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "26706789500000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"5\",\"13\",\"10\",\"8\",\"1\"], `` )", async function( ) {
		const txOriginal = {blockNumber: "6562613", timeStamp: "1540212921", hash: "0x89c1160354503e29326acd1c8732b976c1a2aaefbbd37f0e5b6e343ba0b49b1f", nonce: "2", blockHash: "0xa458873bef1dcd319e23a0a512a8e657d23f5a25e8f3cd7899a4ee87e95d2234", transactionIndex: "60", from: "0xb672862d9b9cda5881018c5d877b8cd350817d8a", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "493584", gasPrice: "3333333000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7445599", gasUsed: "329056", confirmations: "1173974"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["5","13","10","8","1"]}, {type: "string", name: "inviter", value: ``}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["5","13","10","8","1"], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540212921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xb672862d9b9cda5881018c5d877b8cd350817d8a"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "376663685776352000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"15\",\"12\",\"7\",\"6\"], `Rode... )", async function( ) {
		const txOriginal = {blockNumber: "6578060", timeStamp: "1540430921", hash: "0x09860a9187ac458fb337254bfe67ff877cfe6c1a2530070e6b8b47ff5f6e2720", nonce: "5", blockHash: "0x7dfa7a16a3ee6cd328179debe450514a4246e70e8ca431751ecd20d424e1cf00", transactionIndex: "72", from: "0x434a19c342bb0a437113b45450df3a47ea430680", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "584425", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008526f64657269636b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5174557", gasUsed: "389617", confirmations: "1158527"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","15","12","7","6"]}, {type: "string", name: "inviter", value: `Roderick`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","15","12","7","6"], `Roderick`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540430921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x434a19c342bb0a437113b45450df3a47ea430680"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 0, c: [6]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"3\",\"1\",\"4\",\"10\",\"9\"], `Ronal... )", async function( ) {
		const txOriginal = {blockNumber: "6579920", timeStamp: "1540457369", hash: "0xf4298142ca2a42602450d8d67067c0529962c635c9a533cc671f05f31af5e89e", nonce: "6", blockHash: "0x1bec517f3a81a43643a10cafb9fe8fca3ee479d6225a446bbabfcc3a6a22c668", transactionIndex: "181", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "507097", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5578420", gasUsed: "338065", confirmations: "1156667"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["3","1","4","10","9"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["3","1","4","10","9"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540457369 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [9]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"11\",\"12\",\"15\",\"2\"], `Ron... )", async function( ) {
		const txOriginal = {blockNumber: "6580003", timeStamp: "1540458732", hash: "0xe701780974b0191e32d21c6198367c08d977fc04389ee649611cee564ce57325", nonce: "7", blockHash: "0x683a2b74632dca4f8e97c35efd40b3c981d7ca170c51733bbf3c59f6a786672e", transactionIndex: "20", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "507907", gasPrice: "8380000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7370485", gasUsed: "338605", confirmations: "1156584"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","11","12","15","2"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","11","12","15","2"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540458732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [2]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"14\",\"2\",\"16\",\"1\",\"7\"], `mars... )", async function( ) {
		const txOriginal = {blockNumber: "6580030", timeStamp: "1540459257", hash: "0x2cff34404590aa86cb025fe1edc58534805a5fcc9bb61cefb456fc4179ccdef6", nonce: "0", blockHash: "0x89798de016bd13fe708ca720c3e8d8fd38f6ed20726942c19d5086a27fefd657", transactionIndex: "153", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "619792", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6462813", gasUsed: "413195", confirmations: "1156557"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["14","2","16","1","7"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["14","2","16","1","7"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540459257 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [7]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"10\",\"14\",\"8\",\"9\",\"16\"], `mar... )", async function( ) {
		const txOriginal = {blockNumber: "6580081", timeStamp: "1540459909", hash: "0xc0a8d3b2aac0a49e740b6090ef1bcc0426a4117e715fe0797a385f5845858cad", nonce: "1", blockHash: "0x4424fe745242c49a4922e0da1fa70cd159dbf16e5b22e099e9b375ad741f3567", transactionIndex: "100", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "507811", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5881273", gasUsed: "338541", confirmations: "1156506"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["10","14","8","9","16"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["10","14","8","9","16"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540459909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [16]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"5\",\"15\",\"10\",\"11\",\"8\"], `roo... )", async function( ) {
		const txOriginal = {blockNumber: "6580289", timeStamp: "1540462904", hash: "0x55b07fdbb6d7957b788c85223ddfb6443844de1d8df69198f6889e7ead4801cb", nonce: "4", blockHash: "0x28c4d331821e76f1f91241920303b5873589d9176861cea5d6e881eede9504e7", transactionIndex: "47", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "353747", gasPrice: "8840000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3537011", gasUsed: "353747", confirmations: "1156298"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["5","15","10","11","8"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["5","15","10","11","8"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540462904 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [8]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"13\",\"11\",\"3\",\"6\",\"15\"], `jac... )", async function( ) {
		const txOriginal = {blockNumber: "6580290", timeStamp: "1540462910", hash: "0xc6f77ec6adeeeef361495eb3b5bbc04f61df0e5733484acccb05979b58a4c0fe", nonce: "0", blockHash: "0x6569d3685c5df83d3cc8ae8a6dc9be0875bb4c5474a9a13e771fe292ec693685", transactionIndex: "52", from: "0x63eb39172ddb51ff6e0158e3dcd07dd9b656a442", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "619291", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000046a61636b00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7441850", gasUsed: "412861", confirmations: "1156297"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["13","11","3","6","15"]}, {type: "string", name: "inviter", value: `jack`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["13","11","3","6","15"], `jack`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540462910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x63eb39172ddb51ff6e0158e3dcd07dd9b656a442"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 1, c: [15]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "15924650376314850" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"10\",\"3\",\"8\",\"14\"], `root... )", async function( ) {
		const txOriginal = {blockNumber: "6580294", timeStamp: "1540462980", hash: "0x55880b71cc4f1e1d0b7d801df6c4544e7bc186e5609718131d131cafdcb39b89", nonce: "5", blockHash: "0xfb004df66b21a08f4d09e808ce83df2adf846b470b3f959b9cab4ef57a7b66c5", transactionIndex: "76", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "338477", gasPrice: "8400000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7285869", gasUsed: "338477", confirmations: "1156293"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","10","3","8","14"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","10","3","8","14"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540462980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 1, c: [14]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"8\",\"15\",\"3\",\"9\",\"5\"], `root` )", async function( ) {
		const txOriginal = {blockNumber: "6584217", timeStamp: "1540517749", hash: "0xedef62f38d54e8ea6e3384b2ee2f2d28a58151739912ad60231299e84a7c109f", nonce: "0", blockHash: "0x72946db0925e7a60234cb4accd7b8c03650041a6eda0b19337517fa7b1a775c5", transactionIndex: "71", from: "0xe1e3ece279bf7e77b2c9d82e12d15afacf44c170", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "619696", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4644211", gasUsed: "413131", confirmations: "1152370"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["8","15","3","9","5"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["8","15","3","9","5"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540517749 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xe1e3ece279bf7e77b2c9d82e12d15afacf44c170"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [8]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 0, c: [5]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"15\",\"10\",\"11\",\"6\",\"7\"], `roo... )", async function( ) {
		const txOriginal = {blockNumber: "6584247", timeStamp: "1540518213", hash: "0x2a3d64b3b1b260b99b81d06c84db9588c153023866b726c363fda79660d758a7", nonce: "2", blockHash: "0x502040e181a20c48d17985e582e2fa0d5a64ce7c3a9a341529a033b20745b7c5", transactionIndex: "62", from: "0xe1e3ece279bf7e77b2c9d82e12d15afacf44c170", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "509335", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4163529", gasUsed: "339557", confirmations: "1152340"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["15","10","11","6","7"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["15","10","11","6","7"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540518213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xe1e3ece279bf7e77b2c9d82e12d15afacf44c170"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [7]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"1\",\"16\",\"10\",\"6\",\"3\"], `mars... )", async function( ) {
		const txOriginal = {blockNumber: "6585221", timeStamp: "1540531550", hash: "0x50bad328c3c6b10e7ce0fa5ef1b5f90fa41643bfe1a6bc67662adadefa07c039", nonce: "2", blockHash: "0x88ee177abde096c70bfa2731d583b06191375b5366bdd9da9dba6dda1645453c", transactionIndex: "109", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508621", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5699095", gasUsed: "339081", confirmations: "1151366"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["1","16","10","6","3"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["1","16","10","6","3"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540531550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [1]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [3]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"2\",\"8\",\"13\",\"1\"], `marsh... )", async function( ) {
		const txOriginal = {blockNumber: "6585227", timeStamp: "1540531611", hash: "0xe2ddb5d64f501dfd41086346a3a782dd6a1a19c112393c5e9b63bbe81ca89b5e", nonce: "3", blockHash: "0x35a383d27dba3214e4e1ebb4dc9a6e00d6ff4aac938cb3704a1a39a63c30c170", transactionIndex: "41", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508621", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2803459", gasUsed: "339081", confirmations: "1151360"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","2","8","13","1"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","2","8","13","1"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540531611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"2\",\"5\",\"7\",\"12\",\"10\"], `Edwa... )", async function( ) {
		const txOriginal = {blockNumber: "6586073", timeStamp: "1540543947", hash: "0xa1b7bd9f1c838d32ea4085770b7d4bfcd31dccf652826f98acc17938b7d290b3", nonce: "2", blockHash: "0x14dd52ddbf809fd4e9ef09063f8f3246d25e07350ab679e4dc117dae10252c4a", transactionIndex: "90", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "578313", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7077056", gasUsed: "385542", confirmations: "1150514"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["2","5","7","12","10"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["2","5","7","12","10"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540543947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 1, c: [10]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"15\",\"3\",\"8\",\"6\",\"9\"], `Ronal... )", async function( ) {
		const txOriginal = {blockNumber: "6586131", timeStamp: "1540544935", hash: "0x4f2b3fb0aad82464a737c80bd6cd7062073afdbd011540808ba2d216dc90db2d", nonce: "8", blockHash: "0x0b2dac205cb02d78c71732a41cfe72e84a5df12d1486c95042cf53963d18ccbe", transactionIndex: "27", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508312", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2020982", gasUsed: "338875", confirmations: "1150456"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["15","3","8","6","9"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["15","3","8","6","9"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540544935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [9]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"15\",\"7\",\"16\",\"13\",\"1\"], `Edw... )", async function( ) {
		const txOriginal = {blockNumber: "6586141", timeStamp: "1540545023", hash: "0x585c580daea347fea911582858f5268e0cda1326363983450da1535687d79f24", nonce: "4", blockHash: "0x29ea8a4d3bb75d08226cee9ad941b0c7a587742e77ccfb77a290aec23da68c43", transactionIndex: "61", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3236408", gasUsed: "351247", confirmations: "1150446"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["15","7","16","13","1"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["15","7","16","13","1"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540545023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"14\",\"11\",\"13\",\"3\",\"15\"], `Ed... )", async function( ) {
		const txOriginal = {blockNumber: "6586172", timeStamp: "1540545410", hash: "0xad64cf00ae9e018f140f37173dcfd6d68b5a149ddabbd63c8a18ca593c4be593", nonce: "5", blockHash: "0x6b9543306c89a8d6b74da8ecf78c59a4fca5d4206b3cfb8b02f719dd43b10df0", transactionIndex: "47", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526060", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2984391", gasUsed: "350707", confirmations: "1150415"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["14","11","13","3","15"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["14","11","13","3","15"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540545410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [14]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [3]}, {s: 1, e: 1, c: [15]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"13\",\"10\",\"6\",\"4\",\"3\"], `jack... )", async function( ) {
		const txOriginal = {blockNumber: "6586186", timeStamp: "1540545561", hash: "0xff20422414fb0c94048965ce185d6cb244a24e43cc438b4b989b96d99ba4e49b", nonce: "0", blockHash: "0xa34794cd13613fc38483702400935fc1555719d47ed0ba31da36d8d027a37778", transactionIndex: "160", from: "0xd5c489c0e4e450d9ecb996eaf9d420d9e8a7444f", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "598816", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000046a61636b00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7300467", gasUsed: "399211", confirmations: "1150401"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["13","10","6","4","3"]}, {type: "string", name: "inviter", value: `jack`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["13","10","6","4","3"], `jack`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540545561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xd5c489c0e4e450d9ecb996eaf9d420d9e8a7444f"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 0, c: [3]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "6338136000000001" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"1\",\"4\",\"14\",\"5\",\"13\"], `Edwa... )", async function( ) {
		const txOriginal = {blockNumber: "6586249", timeStamp: "1540546463", hash: "0xad7c5026f3970c8a334478555ffcdf5b16758b07fa8a1a3ad7cd6afcd4d99aa4", nonce: "6", blockHash: "0xaaa30ab0a41cc8985a2ff3622c17718b22f26548cc02871290aa518da9898b11", transactionIndex: "152", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "524845", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7434081", gasUsed: "349897", confirmations: "1150338"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["1","4","14","5","13"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["1","4","14","5","13"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540546463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [13]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"14\",\"13\",\"5\",\"1\",\"8\"], `Edwa... )", async function( ) {
		const txOriginal = {blockNumber: "6586249", timeStamp: "1540546463", hash: "0x53057b7a052398d6207d8edd948705f192b2aada770a4cf2c24c2f522f470915", nonce: "7", blockHash: "0xaaa30ab0a41cc8985a2ff3622c17718b22f26548cc02871290aa518da9898b11", transactionIndex: "153", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "527275", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7785598", gasUsed: "351517", confirmations: "1150338"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["14","13","5","1","8"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["14","13","5","1","8"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540546463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [14]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [8]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"16\",\"10\",\"13\",\"2\",\"8\"], `Edw... )", async function( ) {
		const txOriginal = {blockNumber: "6586252", timeStamp: "1540546490", hash: "0x68b9828b1caa8a568b785f63ff40ea79212d16526d2505d301b352955d13b1df", nonce: "8", blockHash: "0x22857b36d10f02ed91021e2eaa7f2e3631f17018fb51d41cc113a633c07d2f0d", transactionIndex: "105", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "527275", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7721802", gasUsed: "351517", confirmations: "1150335"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["16","10","13","2","8"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["16","10","13","2","8"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540546490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [8]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"16\",\"6\",\"4\",\"14\",\"9\"], `Rona... )", async function( ) {
		const txOriginal = {blockNumber: "6586426", timeStamp: "1540548945", hash: "0xebdb58b2b687dcc6a285a9ac955c0f119c8d493d1804a4fc66f5a158c912d6bd", nonce: "9", blockHash: "0x32ebea6ae3c70802c63cdda9c8c0247bf74b3109b7f7285e30f9d0315be94634", transactionIndex: "77", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508717", gasPrice: "9035992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4918706", gasUsed: "339145", confirmations: "1150161"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["16","6","4","14","9"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["16","6","4","14","9"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540548945 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [9]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"6\",\"9\",\"13\",\"12\",\"4\"], `Andy... )", async function( ) {
		const txOriginal = {blockNumber: "6586488", timeStamp: "1540549948", hash: "0xb997c7474e482598cca8679b1bff52931fb6bd0ce106c6371067c331880e2893", nonce: "6", blockHash: "0x7143b3b4b6382f1d9a40b91993b5741de991a3b81010defb2b78f5d707dfa19d", transactionIndex: "64", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508120", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004416e647900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7117882", gasUsed: "338747", confirmations: "1150099"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["6","9","13","12","4"]}, {type: "string", name: "inviter", value: `Andy`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["6","9","13","12","4"], `Andy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540549948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 0, c: [4]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"13\",\"5\",\"11\",\"8\",\"1\"], `Andy... )", async function( ) {
		const txOriginal = {blockNumber: "6586493", timeStamp: "1540549984", hash: "0xe85db02a43655c642a0ac2678e4204907b420832c340d7b00c110eb4c0b943b8", nonce: "7", blockHash: "0xac90fd6353e1d0fb1e80ec56a5b42f680f1a673060dad1e2e596ea033468406a", transactionIndex: "33", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "509335", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004416e647900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4278748", gasUsed: "339557", confirmations: "1150094"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["13","5","11","8","1"]}, {type: "string", name: "inviter", value: `Andy`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["13","5","11","8","1"], `Andy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540549984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"16\",\"8\",\"2\",\"14\",\"1\"], `Rode... )", async function( ) {
		const txOriginal = {blockNumber: "6586787", timeStamp: "1540554259", hash: "0x96e3a02e69c1da0ab959d8092066ce46e757320f449ff5d1986acedb30320c07", nonce: "6", blockHash: "0x3d63a1c2118f951fa94905b3ee343628072a350077dc12f9578f6640a4f8d9aa", transactionIndex: "123", from: "0x434a19c342bb0a437113b45450df3a47ea430680", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "527467", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008526f64657269636b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7596694", gasUsed: "351645", confirmations: "1149800"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["16","8","2","14","1"]}, {type: "string", name: "inviter", value: `Roderick`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["16","8","2","14","1"], `Roderick`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540554259 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x434a19c342bb0a437113b45450df3a47ea430680"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 0, c: [1]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"3\",\"16\",\"6\",\"2\",\"9\"], `Roder... )", async function( ) {
		const txOriginal = {blockNumber: "6586789", timeStamp: "1540554280", hash: "0x60f1ad4b8d4c35f3a1bd4812d5351fa3a7e5114cfce6b80dbecbf2524828db7b", nonce: "7", blockHash: "0xdc67b6af44bbfdd6193220e832dd6c3b12250d9fb0761555d83cb93de81d1002", transactionIndex: "61", from: "0x434a19c342bb0a437113b45450df3a47ea430680", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526252", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008526f64657269636b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7661619", gasUsed: "350835", confirmations: "1149798"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["3","16","6","2","9"]}, {type: "string", name: "inviter", value: `Roderick`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["3","16","6","2","9"], `Roderick`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540554280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x434a19c342bb0a437113b45450df3a47ea430680"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [3]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [9]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"1\",\"15\",\"2\",\"7\",\"11\"], `Edwa... )", async function( ) {
		const txOriginal = {blockNumber: "6586803", timeStamp: "1540554489", hash: "0x51e49eb99750453a98f464fda73eea68c52d30cf2408f4df0eea2c8012520374", nonce: "9", blockHash: "0x5c7bc77d4897a47b4457b675686f78306df3add3c78a31d2e92479ec625cfa66", transactionIndex: "142", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "525250", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7719469", gasUsed: "350167", confirmations: "1149784"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["1","15","2","7","11"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["1","15","2","7","11"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540554489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [7]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [1]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [11]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"11\",\"6\",\"2\",\"16\"], `Edwa... )", async function( ) {
		const txOriginal = {blockNumber: "6586805", timeStamp: "1540554545", hash: "0xa1e88cb7a41b8960c1d9eb2dd1717dd91c7aaddfab493ddfa28c91784c9f15bb", nonce: "10", blockHash: "0x177acbbd3ac48f7bb6295a05a12829199af225ec5c921a1a1b1ca323490141c4", transactionIndex: "98", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526060", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4675635", gasUsed: "350707", confirmations: "1149782"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","11","6","2","16"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","11","6","2","16"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540554545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [8]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [16]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"6\",\"16\",\"10\",\"15\",\"7\"], `Edw... )", async function( ) {
		const txOriginal = {blockNumber: "6586807", timeStamp: "1540554607", hash: "0x672ac02babfd8b40aa8b082590ef55f4a9150b4e995b0f476871cc7dd62ac94b", nonce: "11", blockHash: "0xafe5d06a04001a212bb38f04f72898025c3832b3b14dfcd7d2f012884bf29522", transactionIndex: "125", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526060", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5368773", gasUsed: "350707", confirmations: "1149780"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["6","16","10","15","7"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["6","16","10","15","7"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540554607 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [9]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [6]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [7]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"6\",\"15\",\"9\",\"7\",\"4\"], `Edwar... )", async function( ) {
		const txOriginal = {blockNumber: "6586810", timeStamp: "1540554624", hash: "0xe78a57cfb6dcf704248a3926686b2ba1ab83f8b8132adb2b17ef3dc5a90946d3", nonce: "12", blockHash: "0xb5da826f33ed639699794edfd1d430dceb5fa13bef4635ebf5da2075ca234c93", transactionIndex: "37", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "526870", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4785600", gasUsed: "351247", confirmations: "1149777"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["6","15","9","7","4"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["6","15","9","7","4"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540554624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 1, c: [10]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [6]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 0, c: [4]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"8\",\"9\",\"11\",\"14\",\"15\"], `Edw... )", async function( ) {
		const txOriginal = {blockNumber: "6586841", timeStamp: "1540555147", hash: "0xbc85bebddd534b1ea5681e23a288ede951e73db70db3d9e1fed0b378053aa457", nonce: "13", blockHash: "0x1ea44ea4a6b79cc9a8db9794c11bd7891ef51be9c79b2464577c4904acf65d0b", transactionIndex: "118", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "524035", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6767587", gasUsed: "349357", confirmations: "1149746"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["8","9","11","14","15"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["8","9","11","14","15"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540555147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 1, c: [11]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 1, c: [15]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"2\",\"11\",\"13\",\"8\",\"5\"], `Rona... )", async function( ) {
		const txOriginal = {blockNumber: "6586846", timeStamp: "1540555185", hash: "0xd08f586933b97147c97d2af7948f17565780b8df55c856c8c75d6caa541ed6b5", nonce: "14", blockHash: "0x0bec38be997cbd88a52b3d4143b2d951c73e3391bccbc6ae9ccfacbf3af71c5a", transactionIndex: "45", from: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508312", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000006526f6e616c640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3298127", gasUsed: "338875", confirmations: "1149741"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["2","11","13","8","5"]}, {type: "string", name: "inviter", value: `Ronald`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["2","11","13","8","5"], `Ronald`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540555185 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xf4b91f89b38ce4463b8c209c26feed31ddb25c79"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [5]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"10\",\"4\",\"1\",\"11\",\"15\"], `Edw... )", async function( ) {
		const txOriginal = {blockNumber: "6586866", timeStamp: "1540555389", hash: "0x46c5bc7ab17c44e58ca63515656d65db5e1fb68c15643168a41f0881024a15a4", nonce: "14", blockHash: "0x7fc6490dfd82a11ada6b10e30e28a3b7bb041132da7f5d846fa88177c847a7bd", transactionIndex: "26", from: "0x10d9159de465e7fa4d0af3660dd001409305456d", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "525250", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000064564776172640000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4580463", gasUsed: "350167", confirmations: "1149721"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["10","4","1","11","15"]}, {type: "string", name: "inviter", value: `Edward`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["10","4","1","11","15"], `Edward`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540555389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x10d9159de465e7fa4d0af3660dd001409305456d"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 1, c: [12]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [15]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "6977681382904" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"3\",\"5\",\"10\",\"7\",\"14\"], `root... )", async function( ) {
		const txOriginal = {blockNumber: "6586896", timeStamp: "1540555894", hash: "0x1761ee6cb320cde9a48f7fff1b2b316b2fdb632721e83ccea801c57adaa16030", nonce: "8", blockHash: "0x82b8881d93213245c6359a2ac0afcc3fdb58c1cddad1673dab60587b30efa091", transactionIndex: "78", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "337667", gasPrice: "8840000000", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6814423", gasUsed: "337667", confirmations: "1149691"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["3","5","10","7","14"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["3","5","10","7","14"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540555894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [5]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [14]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"10\",\"16\",\"8\",\"2\",\"4\"], `root... )", async function( ) {
		const txOriginal = {blockNumber: "6586903", timeStamp: "1540555986", hash: "0x551b9ea6a5ed2348c182a9d8d6d4cf9a80a7418ab43f6ed817b00443b6848a05", nonce: "9", blockHash: "0xe763375f21c5ff6d877a46c47827804af0aeffe5a852d22b7f848dcfaed9ab2f", transactionIndex: "61", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "339557", gasPrice: "8840000000", isError: "0", txreceipt_status: "1", input: "0x6cc93648000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3502596", gasUsed: "339557", confirmations: "1149684"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["10","16","8","2","4"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["10","16","8","2","4"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540555986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [7]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 0, c: [4]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"1\",\"4\",\"11\",\"7\",\"14\"], `root... )", async function( ) {
		const txOriginal = {blockNumber: "6586908", timeStamp: "1540556067", hash: "0x78a875fc07684575a370ac8c67c895b4dac6984978efde236bf9ee9531b3935d", nonce: "10", blockHash: "0x2294d225d366502e8b02d7b3ecdc790cc8a8f914b839875288d5ac36f4a07d1a", transactionIndex: "200", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "337667", gasPrice: "8840000000", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7805818", gasUsed: "337667", confirmations: "1149679"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["1","4","11","7","14"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["1","4","11","7","14"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540556067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [8]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [14]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"1\",\"8\",\"4\",\"14\"], `root` )", async function( ) {
		const txOriginal = {blockNumber: "6586932", timeStamp: "1540556477", hash: "0xde6c509897f8015d2ca5a1a082c13e66660934be6e7d41c070bc1c68b5ddedc1", nonce: "11", blockHash: "0x343cef799e10a3b9a78bdfe3bc0785af70bb19b09364b454ddf47e7403659273", transactionIndex: "98", from: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "338477", gasPrice: "8840000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000004726f6f7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6900494", gasUsed: "338477", confirmations: "1149655"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","1","8","4","14"]}, {type: "string", name: "inviter", value: `root`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","1","8","4","14"], `root`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540556477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0xacc9bd563b8181f1049f9547f335be2de1e8c65e"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [9]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 0, c: [1]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [4]}, {s: 1, e: 1, c: [14]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3919789410738397" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"9\",\"10\",\"16\",\"2\",\"14\"], `mar... )", async function( ) {
		const txOriginal = {blockNumber: "6587058", timeStamp: "1540558226", hash: "0xc42ec01e4515d7c5eb496223a6a48ab9d73a07c689d6d8d64907449ec86345be", nonce: "4", blockHash: "0x84113bce5f3bd2e591d020628f7c6d05388a9f8331db366d050eda7036aa8d02", transactionIndex: "39", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "507811", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2558330", gasUsed: "338541", confirmations: "1149529"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["9","10","16","2","14"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["9","10","16","2","14"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540558226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [14]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"2\",\"16\",\"11\",\"15\",\"4\"], `mar... )", async function( ) {
		const txOriginal = {blockNumber: "6587076", timeStamp: "1540558465", hash: "0x1a2d3c86a2b8bd97e592aa0a9241da457891ebdcacef7f274cbdf3ceb948d710", nonce: "5", blockHash: "0xce38b1cde6271362b55e5a15c207c8b6e4a165c18f58217f6c41be33c3dc0e98", transactionIndex: "92", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "508216", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x6cc9364800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7743742", gasUsed: "338811", confirmations: "1149511"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["2","16","11","15","4"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["2","16","11","15","4"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540558465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [2]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 0, c: [4]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buy( [\"3\",\"13\",\"10\",\"7\",\"15\"], `mar... )", async function( ) {
		const txOriginal = {blockNumber: "6587078", timeStamp: "1540558476", hash: "0x8ecdb6178caf5f95c34568b6cbc0272fdc389aa7c00c9d0beed1f65a0c62bb15", nonce: "6", blockHash: "0xc845484f67f99f1e423907a808d6370f3233bba0157a3f1f1a0985eda786f82e", transactionIndex: "143", from: "0x8d20ada5b704f4678445190d5b2d478aaa363c17", to: "0xad4769638175f3737ce994d9df9636df8ac80432", value: "50000000000000000", gas: "507406", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6cc936480000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000056d61727368000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3691826", gasUsed: "338271", confirmations: "1149509"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8[5]", name: "nums", value: ["3","13","10","7","15"]}, {type: "string", name: "inviter", value: `marsh`}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint8[5],string)" ]( ["3","13","10","7","15"], `marsh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540558476 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "round", type: "uint32"}, {indexed: false, name: "index", type: "uint32"}, {indexed: false, name: "nums", type: "uint8[5]"}], name: "OnBuy", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "OnBuy", events: [{name: "user", type: "address", value: "0x8d20ada5b704f4678445190d5b2d478aaa363c17"}, {name: "round", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "index", type: "uint32", value: {s: 1, e: 0, c: [7]}}, {name: "nums", type: "uint8[5]", value: [{s: 1, e: 0, c: [3]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 1, c: [15]}]}], address: "0xad4769638175f3737ce994d9df9636df8ac80432"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "750418055504555800" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "286551764820000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
