var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "abcLotto"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xaD4769638175F3737Ce994D9DF9636Df8Ac80432","0xdE4413799C73a356d83AcE2Dc9055957c0A5C335","0x15ebb02F39563675Fd255d34b8c03650373A8F0F","0xf4b91F89B38Ce4463b8C209C26FEeD31Ddb25c79","0x434A19c342BB0a437113b45450dF3A47eA430680","0xACC9bD563B8181f1049F9547F335Be2dE1E8C65e","0x956b078d57d9F0D34782048AfbB719d133d922a4","0xb672862d9B9CDa5881018C5d877b8cd350817D8A","0xB669613C57Db4b86C516c8691e9250A3EF2Cfe30","0xce466959E80742b366Fed630D6204508C38678a6","0x8D20ada5B704f4678445190d5B2D478aaa363C17","0x63eb39172dDB51ff6e0158e3DCd07Dd9b656a442","0xe1e3ECe279bF7E77B2c9D82E12d15AFAcf44C170","0x10D9159dE465E7fA4D0af3660Dd001409305456D","0xD5c489c0E4E450d9ECb996EaF9D420D9e8A7444F"]
addressListOriginal.length = 17
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"resolver","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"book","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"currentState","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"addrs","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"amounts","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"round","type":"uint32"}],"name":"getDailyJackpot","outputs":[{"name":"jackpot","type":"uint8[5]"},{"name":"amount","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"wallet","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"round","type":"uint32"},{"name":"index","type":"uint32"}],"name":"getSingleBet","outputs":[{"name":"nums","type":"uint8[5]"},{"name":"payed1","type":"bool"},{"name":"payed2","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"currentRound","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"rollover","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"drawed","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"week","type":"uint32"}],"name":"getWeeklyJackpot","outputs":[{"name":"jackpot","type":"uint8[5]"},{"name":"amount","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"round","type":"uint32"},{"name":"nums","type":"uint8[5]"}],"name":"getAmountDailybyNum","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"poolUsed","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"controller","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"week","type":"uint32"},{"name":"nums","type":"uint8[5]"}],"name":"getAmountWeeklybyNum","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":false,"name":"user","type":"address"},{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"index","type":"uint32"},{"indexed":false,"name":"nums","type":"uint8[5]"}],"name":"OnBuy","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"user","type":"address"},{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"index","type":"uint32"},{"indexed":false,"name":"reward","type":"uint256"}],"name":"OnRewardDaily","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"user","type":"address"},{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"index","type":"uint32"},{"indexed":false,"name":"reward","type":"uint256"}],"name":"OnRewardWeekly","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"user","type":"address"},{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"index","type":"uint32"}],"name":"OnRewardDailyFailed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"user","type":"address"},{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"index","type":"uint32"}],"name":"OnRewardWeeklyFailed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"round","type":"uint32"}],"name":"OnNewRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"round","type":"uint32"}],"name":"OnFreeze","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"round","type":"uint32"}],"name":"OnUnFreeze","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"round","type":"uint32"}],"name":"OnDrawStart","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"round","type":"uint32"},{"indexed":false,"name":"jackpot","type":"uint8[5]"}],"name":"OnDrawFinished","type":"event"},{"anonymous":false,"inputs":[],"name":"BalanceNotEnough","type":"event"}]
eventSignatureListOriginal = ["OnBuy(address,uint32,uint32,uint8[5])","OnRewardDaily(address,uint32,uint32,uint256)","OnRewardWeekly(address,uint32,uint32,uint256)","OnRewardDailyFailed(address,uint32,uint32)","OnRewardWeeklyFailed(address,uint32,uint32)","OnNewRound(uint32)","OnFreeze(uint32)","OnUnFreeze(uint32)","OnDrawStart(uint32)","OnDrawFinished(uint32,uint8[5])","BalanceNotEnough()"]
topicListOriginal = ["0x211bea642b90261164523a55e2a2138e059507beabbe5d9c6eff94da3d281af2","0xab6cc4ece396ea892948c36aee98741f205e1d466bbb46b9a7873552c2591397","0xbb01ef9c107bdd9d5e635566fa2ca9480b4e6c2ab8632c33aca62b9e129371cd","0xafc65e2b6e2bbc70130b594b9ca7b274cdf492b598197aa1886ddb133dddd4f3","0x2a3f8fdcf389229c0cbbe8b6b34a40afb1d323cbe950093026433ef8aee9a738","0xcee08990aeacdcc467ad07e1de54fa3b93cb27b4a8c8a723f1739822127b9c27","0x71c1019f62a6111025deb2e2b4b72da1563999b1932e9a1536a6204b5c8e790e","0xeca3a38c5228a5d760b0b750463923c0f4fc35fa39595c70edbe0e59c5187389","0xdfe2773cd0b6e5587e27b40c368eb0426a6ccc940a1ca42c3e09b84a54e49966","0x59cc8149edae3e14da2e99d320d7277af320cc73c2a45a59227b55f62a732788","0x98828835a58082f719bee4d7f39a7a905afe45161e553d71af9275957ce87c45"]
nBlocksOriginal = 50
fromBlockOriginal = 6554408
toBlockOriginal = 6587078
constructorPrototypeOriginal = {"inputs":[],"name":"abcLotto","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6554408","timeStamp":"1540096884","hash":"0x15dc91de8a4d3e849e20eec4ef34d34f996423ba44a48b50d8871d3820cae3db","nonce":"2","blockHash":"0x305015434aa5861359ff0113e8c9368f96cf0c0917ca7886950eacf7467f0294","transactionIndex":"33","from":"0x15ebb02f39563675fd255d34b8c03650373a8f0f","to":0,"value":"0","gas":"5445011","gasPrice":"3300000000","isError":"0","txreceipt_status":"1","input":"0xbc30e4ac","contractAddress":"0xad4769638175f3737ce994d9df9636df8ac80432","cumulativeGasUsed":"6989656","gasUsed":"5445011","confirmations":"1182179"}
txOptions[0] = {"from":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"abcLotto","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
