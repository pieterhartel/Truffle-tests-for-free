const Amber = artifacts.require( "./Amber.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Amber" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE467B8D9B0C69F7d497B8f002a9e7f4B61C84c67", "0x461eefeB4F384b5c7177732e0068f0CAA43D3152", "0xae5AC19F938f8338920E630Cc9A8eCd6Ce89bCA1", "0x1Ce75BFD524489e7dd8678D4905Cbd8f47f22083", "0x27D3eb139DD95fe4e0D657BA31f8e9C6ecA56b06", "0x56CbAf0035b7f7F221A9C8ce3fbe9527E2430406", "0x57Fcc23Ad10Fa6196559Aea71D580a89740C9133", "0x360bBAD1120B0ABF63573e2e21B6727e07D1Bf18", "0x6c4fF1459cc4d95b9A7A7b20A3Bc09BC2404B9a7", "0xE138aC394a8B8a81570c70083ab3492c1AD37De5", "0x4Fc5831B399369119eeD6C81fd4BC67016f23d71", "0xd0205b4f442A2A4c4fb01cC94f8B5bf1DfD29458", "0x12CfF2A28d4FE53fcf46ad642668Cf6651Fa8cf7", "0x3F67dfeeE1d3326D6f8Bc086dAdE8915ecf4c92C", "0x9A0cf297C8143D8E08296F5257ba81081B1A2e5B", "0x087B961c29efd8dC93ABe9C8fa392739A3ad8cF6", "0x7DbbC284F202b06b8386ff8Af96A07A7f30f387f", "0x9B233800D7F352b886A353Fd56Bac3121f804f59", "0xcB0C3b15505f8048849C1D4F32835Bb98807A055", "0x14eEFe5199839480D6Fd58c2d720ACdff959bCb0", "0x2375aa99a4539069134627b1921e92078DCBB8dA", "0x9d7007416E7cCB2c352463d42640ACc6c95EdA6E", "0x6d2a3e19741Ecd3001c46a8cdE043F8aB675a141", "0x4b80B7460083Ed857445D92eab9972419Ce5cb39", "0x5BA3E11aBf8c93186637847eC590fCd3aa588BD2", "0x55ea8a1613DE642d17329A9C6b2D8aFda69E62A1", "0xA7cF0d8511d269DA2E06a5665f0d8A67f4fe7f2e", "0x52AF787439a82f36d6eF6B0dA0f0E5eCCe29fF90", "0x6eccB16F3361D07655e60be79fB70aBEF14D5E3c", "0xB9E9cBd1A17cB4e6b08B8AD5bE521534e6178690", "0x3C39b94c292d47f269c7AB016985cBB3B5fE4B21", "0xc6F827796A2E1937Fd7f97C4E0a4906c476794f6", "0xe9beb23b9F8fD24EdADDC9389B56D7227Ad5C1b0", "0xa24E91f2684A69ffE0A10A5cc384F9e0B163DD8b", "0xaF87A86920b508a532223C516e9a33471356E245", "0xAb72A297D971F5d035738f39dDbE81f658D8796E", "0x137017B8389fF246CE2C19459B92D0516F87e742", "0x96759150BEC4F31C440928ea7437566988f82A34", "0xfF107821CB2a1671531f284313EbCd0a569c3148", "0x5a5Ffa288320072D7398c6D54a875313b4F60A64", "0x68c3110b0e3d592680D5f575fDf712D66D5853db", "0x34c9B3D0C89232bF257eF4D211DD202947b677C0", "0x8c345B473aa663F92f7D3d057cce3c39Fb7d768B", "0x90B298f5fF8A52D15C2709087f327Af698Fe9729", "0x7bE01BEc1ABAbC771290C8fCa44d9789aF8aE0f3", "0x9A164541fD8018d280Ff69001951D5ccdE9b3493", "0x1F6fA14d9707BC52196a95aE82a80487Fa099821", "0x509dcCd9AD4F204151809Fc6C7843b42c1e542f3", "0x940B99Ca07524598923cFF6AfF035c71fc9f57Ca", "0xfb22Bfa1Dd43c3F27b088c328D5f7F82f7D3eE80", "0x2845a83D2A6cb264A5E35103EF10472746f43c4d", "0x832Bf16Cd52868b76E2df375A7a49ADaFB6427cD", "0xE7ce0dce6d1E4664D2c0C7FF524b019bD00F65C4", "0xA48C69294518A2E8abaDaE36af12E9eF7820cA5d", "0xFBaae0f8fF8541194DAf1221aC39E78eBB3B3CAD", "0x40FACd6c48456026f748D176CE7c233dA64Cc733", "0x1C2890768064A657ffcAF9c0c92d2B99ED7C18e2", "0xBB879A0e0cC18548b132A33CC4C973da45E9Ee63", "0x8acCF804e82c211c4cE7D6B1D23C12ba3F6425df", "0x2503425d6f84c32795384E3Ee8186d05fDd13Ec4", "0x388acf06405F04885018Aa941264Ba232f5DFA9B", "0x600d797B923206f2f03125ea81FD5d47c6ceD772", "0xFb45597d51280e094c1D3520f1C22E2652AA72e4", "0xE291CD23875d3CF4C8ceb4e04d7F0a6fd2511b53", "0x2e6D72f09cB04425A29d420b5869B06D95352908", "0x36F84534671906bbC4A0BeD28cF84fa66dC52303", "0x0C6830feBF62F153d6F9466f1D9fE2B1D09A475d", "0xd99D24482696EF880ABe7A076aa754c4fCc80636", "0x778F7434956b899303708fA3c5Fad85bf9D93e06", "0x78bF7a9B7C7a769C1C4325eEC472704F214877A5", "0x33497F64e2997669057710ccADd583d70798954a", "0xE0EB76c368b483AFD6DEDe2dA53224eDF700b953", "0x516B88e8c700E364c2F969F2c059feD3bFB2fA29", "0x911dADB65524423FB43Bf853b22e44Bbf9ffde0e", "0x5DE90F22DEC06afed2d1848636878d08faD012bC", "0xC24f97Bb1d7a75D9f986c99DFcfa2A558058904C", "0x8908fDE0F1a8AdB6a421B2f0cAC6199fbCD2C359", "0x91b3646948aE6b4Ea91Cf68A3357e25D66b043C6", "0x94C1fB7795E22930d756ac10e447d17b2B7c1539", "0x8C18f331A8f0Ee18D204490aa0B8D44B7E3e4A02", "0x888EE3068453a36Dbf325a23eBD9690B45545f72", "0x3130259deEdb3052E24FAD9d5E1f490CB8CCcaa0", "0x6B42BcA7A9608Ff5b1Bf28533CF59B40EF4475B9", "0xE8F9B8Caa5291240Ae66C9718815A9F47Aa90ED8", "0x9b3319caA84A3DBa6bE70Df1eB7AF3ca413F8EB1", "0x05E31fa582856eB330Ad65F79cE313c3B58306D2", "0xef6103de90208F3dfAce661EadB120Cf8075f9D2", "0x42bDd4F4E88Ac64FCBD6c01Aeac676E64dB33AA9", "0x62EB3e90696D302f80c48D859943f0E244823436", "0x51bd4c735927f958a90dB80398826Ff47a9832f1", "0x5441Bf9aA27E79C7AA4a8D1b340D16973695dEE1", "0xc4d31B4dC713DC4aC3D3F7BE63447ef1D2abe2eF", "0x233A5180A19717d047999508a34C2dFBfDb25E78", "0x5029f7897183d6ba6Af44D4BEe34421181e15455", "0x6556D0Efc03602F88e6cBBA508BA340F106220BC", "0xec18c3B8A4CAAC7dfCe048Bc9Ab8225a554DacFC", "0x297683B64a416F2B105E776B88E8DC31e1114Fa6", "0xD8F2Ce72F19834f5E0072ea870A18Ef6f57F8CCD", "0x93989aB2Eb319694915C77Cf248F8155366dC8A3", "0xd74293d7AD3371ec42D6Bc49ED43f4270360A771", "0x41a21b264F9ebF6cF571D4543a5b3AB1c6bEd98C", "0x8e2E5ECe3b1f6F33851D62130Ea90cF5Bf523c21", "0xB5a28B0752ce06C41d8965Cf431C759D888a162A", "0x52F2cC12b89A3Fb4d4f2230487297fd402e6A711", "0x0d84597a0Cf27e73e52BC6CCcFA3a5E3CcCaE3da", "0x5632CA98e5788edDB2397757Aa82d1Ed6171e5aD", "0xB04B473418b6f09e5A1f809Ae2d01f14211e03fF", "0x5409e9e2f6cc8340d307FA15E0728AdAd54D6e8C", "0xD1692f1c6B50D299993363bE1c869e3e64842732", "0xaD565956Ae5Bd43117F6B0a650Ec18c621Ff8E0d", "0x7AAB41a2b1E8d9195b50143e32BEF20b5EaCfd91", "0x55C073036C755B6898134D62001Ba2B00F60F96F", "0x43501e11aCF3DfDaE4bd2cA40c5ea1303Fc51941", "0xF546160c85c90B97Aa125dE9C14D6C2cc10AD588", "0x9969C05A2204177841E47454C2A289Aa4442cb99", "0xDe67AdF51408aCCA6beE2aBE20dBffF2dDdfeD33", "0xC69325FE2449fbDC064018B0C0Ca246E7067db54", "0xb3f98326ea56088f3e01995F2AAC89355fA5AF15", "0xC97b6F9da34bCA5d3c7d505E475bd25B73eaaD6E", "0xF2B31e5768871B3AD8435edB2c54b8683A3D1a5E", "0x04a1dd3a7d57C1944A503a03e43e92a4B092c018", "0x694CCab8fBe06350147fcd3F12D885E34f79EA85", "0x32Ff0b2Ac0C39dDc90b49e4cB00B568267D45610", "0xd881ab474d10b9036fF7F697B18DEC7b701140e3", "0x83c90BA85dC313a23020aB37D223653C389A91f0", "0x58F267627207bdEd598f495fcD10D82bB2AA7141", "0x8aE87CeB42F78D7C5659084753016d781fBCce6C", "0x85eA854451B301d1b04d039f17fC3a11e7f32acD", "0x376D0974EdCb2F732cf0796Fd9639c791E8387Be", "0xC1b442F93ea518B0939EE4fa25b3Ea321A07E17A", "0xfBf13497056F33300Ad82511c6A1349dd3d2Ae26", "0x6b144673640835E1eBd476a6f5C19E2E30452c2d", "0x06C71dC79d7E7c47792Dad78c525D9B270520b29", "0xe25b8Fa6E21f67F8dcccf1222D23Faf6f2e84A2f", "0xD05468778C4BBFd26Fb6966D755ed1CE4932bEE9", "0x7c0D2f1EB3dC2Cc21d6118789D26f2Db09311b1d", "0xf9CF9329FF00E14F441E411aA946eF2B7E102ec1", "0x407DBc332F834e51737E428Fe22CE10fCDB4214f"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "user_", type: "address"}], name: "getWaypointProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "address_", type: "address"}], name: "addressNotSet", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "msgSender_", type: "address"}, {name: "currentReferer_", type: "address"}, {name: "newReferer_", type: "address"}], name: "refererAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "address_", type: "address"}], name: "isAddress", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "getBalanceContract", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user_", type: "address"}], name: "getReferer", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "msgSender_", type: "address"}, {name: "compare_", type: "address"}], name: "isNotSelf", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "badgeID_", type: "uint256"}], name: "getTotalDivis", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "badgeID_", type: "uint256"}], name: "isFirstBadgeEle", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "getChainLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "msgValue_", type: "uint256"}, {name: "ratio_", type: "uint256"}], name: "calcShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_from", type: "uint256"}, {name: "_to", type: "uint256"}], name: "getBadges", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user_", type: "address"}], name: "getFlipProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "price_", type: "uint256"}, {name: "msgValue_", type: "uint256"}], name: "isValidBuy", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "badgeID_", type: "uint256"}], name: "getOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "badgeID_", type: "uint256"}, {name: "badgeLength_", type: "uint256"}], name: "isLastBadgeEle", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "getStartTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getAllBadges", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user_", type: "address"}], name: "getSplitProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "badgeID_", type: "uint256"}], name: "getPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "startTime_", type: "uint256"}], name: "onContractStart", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user_", type: "address"}, {indexed: true, name: "referer_", type: "address"}], name: "onRefererSet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "receiver_", type: "address"}, {indexed: false, name: "splitProfit_", type: "uint256"}, {indexed: false, name: "flipProfit_", type: "uint256"}, {indexed: false, name: "waypointProfit_", type: "uint256"}], name: "onWithdraw", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onContractStart(uint256)", "onRefererSet(address,address)", "onBadgeBuy(uint256,address,address,address,uint256,uint256)", "onWithdraw(address,uint256,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc95500414a933625aebaf804d96decf560ff6c63826e9ff60c61408e05bb004f", "0xb3f1c8ed4ff0777d22e70236169841472c2775e96f5349e766a140ab2a579ec8", "0x23f65a3d59ea178d3257eb66489f5a564e18748b46ac164e45d2f4561b0984d5", "0x90ebb005d68efee044927e1e77e1fd0cecc508368aa72c39250a787eed5f0a70"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6729643 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6741220 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "admin_", value: 4}, {type: "address", name: "teamAmberAddress_", value: 5}], name: "Amber", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "user_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getWaypointProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getWaypointProfit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "address_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "addressNotSet", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressNotSet(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "msgSender_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "currentReferer_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "newReferer_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "refererAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "refererAllowed(address,address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "address_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isAddress", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBalanceContract", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBalanceContract()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getReferer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReferer(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "msgSender_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "compare_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isNotSelf", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isNotSelf(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "badgeID_", value: random.range( maxRandom )}], name: "getTotalDivis", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalDivis(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "badgeID_", value: random.range( maxRandom )}], name: "isFirstBadgeEle", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFirstBadgeEle(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getChainLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getChainLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "msgValue_", value: random.range( maxRandom )}, {type: "uint256", name: "ratio_", value: random.range( maxRandom )}], name: "calcShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcShare(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_from", value: random.range( maxRandom )}, {type: "uint256", name: "_to", value: random.range( maxRandom )}], name: "getBadges", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBadges(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getFlipProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFlipProfit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "price_", value: random.range( maxRandom )}, {type: "uint256", name: "msgValue_", value: random.range( maxRandom )}], name: "isValidBuy", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isValidBuy(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "badgeID_", value: random.range( maxRandom )}], name: "getOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOwner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "badgeID_", value: random.range( maxRandom )}, {type: "uint256", name: "badgeLength_", value: random.range( maxRandom )}], name: "isLastBadgeEle", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isLastBadgeEle(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getStartTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStartTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getAllBadges", outputs: [{name: "", type: "address[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAllBadges()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user_", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getSplitProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSplitProfit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "badgeID_", value: random.range( maxRandom )}], name: "getPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPrice(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Amber", function( accounts ) {

	it( "TEST: Amber( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6729643", blockHash: "0x14b9f5b8c4505ca5b71547ac0bc90c38ee428709601471ff90d68f797870e62e", timeStamp: "1542575097", hash: "0xe176823b685bf7d478a19ee35b7ad207982cdd7db06040ef991277c55a3e1661", nonce: "9", transactionIndex: "116", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: 0, value: "0", gas: "1674411", gasPrice: "3000000000", input: "0xfa531bbe000000000000000000000000ae5ac19f938f8338920e630cc9a8ecd6ce89bca10000000000000000000000001ce75bfd524489e7dd8678d4905cbd8f47f22083", contractAddress: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", cumulativeGasUsed: "7662314", txreceipt_status: "1", gasUsed: "1674411", confirmations: "977735", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin_", value: addressList[4]}, {type: "address", name: "teamAmberAddress_", value: addressList[5]}], name: "Amber", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Amber.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542575097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Amber.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[7],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6729663", blockHash: "0xd88baf181be7fe1b03edf6c5d96850159f18f1891d18323aed7f84dfe746fd39", timeStamp: "1542575334", hash: "0xc9df619a9f3d519d7ea5c9fd160abe92d4917f2ef136d0f7002540a3b71817c3", nonce: "11", transactionIndex: "106", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1778903", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000001900000000000000000000000056cbaf0035b7f7f221a9c8ce3fbe9527e2430406000000000000000000000000ae5ac19f938f8338920e630cc9a8ecd6ce89bca1000000000000000000000000ae5ac19f938f8338920e630cc9a8ecd6ce89bca100000000000000000000000057fcc23ad10fa6196559aea71d580a89740c9133000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf180000000000000000000000006c4ff1459cc4d95b9a7a7b20a3bc09bc2404b9a7000000000000000000000000e138ac394a8b8a81570c70083ab3492c1ad37de50000000000000000000000004fc5831b399369119eed6c81fd4bc67016f23d71000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd2945800000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf70000000000000000000000003f67dfeee1d3326d6f8bc086dade8915ecf4c92c0000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b000000000000000000000000087b961c29efd8dc93abe9c8fa392739a3ad8cf60000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000087b961c29efd8dc93abe9c8fa392739a3ad8cf60000000000000000000000009b233800d7f352b886a353fd56bac3121f804f59000000000000000000000000cb0c3b15505f8048849c1d4f32835bb98807a055000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf1800000000000000000000000014eefe5199839480d6fd58c2d720acdff959bcb00000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b0000000000000000000000002375aa99a4539069134627b1921e92078dcbb8da000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf180000000000000000000000002375aa99a4539069134627b1921e92078dcbb8da000000000000000000000000cb0c3b15505f8048849c1d4f32835bb98807a055000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf1800000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000382d628d82c800000000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000058d15e17628000000000000000000000000000000000000000000000000000005b09cd3e5e90000000000000000000000000000000000000000000000000000035bc1b7c3a500000000000000000000000000000000000000000000000000000554b4332592200000000000000000000000000000000000000000000000000004ae4d50bc39e8800000000000000000000000000000000000000000000000000264b2bee7d5cb800000000000000000000000000000000000000000000000000275baabe6089a2000000000000000000000000000000000000000000000000002f20c69dc7b44800000000000000000000000000000000000000000000000000195758a198e2ba000000000000000000000000000000000000000000000000001b6bc2135fd4240000000000000000000000000000000000000000000000000025ef2a4ae54aa0000000000000000000000000000000000000000000000000001f68e991c2b75a000000000000000000000000000000000000000000000000001fd00838b63994000000000000000000000000000000000000000000000000001bd89b49bd09a60000000000000000000000000000000000000000000000000014030be2efa876000000000000000000000000000000000000000000000000000dbed3d3def13e000000000000000000000000000000000000000000000000001e6f3ff750ee7e000000000000000000000000000000000000000000000000000c87a2e9b77436000000000000000000000000000000000000000000000000001355839e259aa6000000000000000000000000000000000000000000000000001df98e1ca63b5c000000000000000000000000000000000000000000000000000cbebee18ea1140000000000000000000000000000000000000000000000000011316ebbb64c7200000000000000000000000000000000000000000000000000095e5bfa5c4302000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000bf8d71590ed7a7d2c000000000000000000000000000000000000000000000001fae2e622a57a7d2c000000000000000000000000000000000000000000000001fae2e622a57a7d2c000000000000000000000000000000000000000000000001904e0ed3627a7d2c00000000000000000000000000000000000000000000000168563e15a95a7d2c00000000000000000000000000000000000000000000000136231516fc3a7d2c000000000000000000000000000000000000000000000000f78d6c789f3a7d2c000000000000000000000000000000000000000000000000dc74d669de8cc652000000000000000000000000000000000000000000000000c445a55fd4b8ae52000000000000000000000000000000000000000000000000aaacfc405e8b0e520000000000000000000000000000000000000000000000009ed3e71c12a1da520000000000000000000000000000000000000000000000008ff60c58e644d30f0000000000000000000000000000000000000000000000007db34485f20c770f00000000000000000000000000000000000000000000000070648827794b08ec0000000000000000000000000000000000000000000000006786cfba93f630f00000000000000000000000000000000000000000000000005bff0d547d0cb0f000000000000000000000000000000000000000000000000056cfe7da7db8c8f0000000000000000000000000000000000000000000000000537ab6220371b4400000000000000000000000000000000000000000000000004982bdfdcd497c4000000000000000000000000000000000000000000000000046b9b69ec3c175f200000000000000000000000000000000000000000000000041ec57a494cd0ff20000000000000000000000000000000000000000000000003efbcdc2b441c3620000000000000000000000000000000000000000000000003c614bd22d4f8192000000000000000000000000000000000000000000000000389b71dce6bd119600000000000000000000000000000000000000000000000036b7a7891b07c396", contractAddress: "", cumulativeGasUsed: "7360074", txreceipt_status: "1", gasUsed: "1778903", confirmations: "977715", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[7],addressList[4],addressList[4],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[17],addressList[19],addressList[20],addressList[9],addressList[21],addressList[16],addressList[22],addressList[9],addressList[22],addressList[20],addressList[9]]}, {type: "uint256[]", name: "price_", value: ["1036288000000000000000","204800000000000000000","102400000000000000000","104960000000000000000","61952000000000000000","98337280000000000000","86346760000000000000","44149560000000000000","45376770000000000000","54334920000000000000","29216410000000000000","31614180000000000000","43735200000000000000","36213050000000000000","36677460000000000000","32104390000000000000","23072150000000000000","15847390000000000000","35088670000000000000","14445910000000000000","22290630000000000000","34558620000000000000","14694100000000000000","19822290000000000000","10801250000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["220845008964407688492","36525008964407688492","36525008964407688492","28845008964407688492","25965008964407688492","22347728964407688492","17838032964407688492","15885557535836259922","14142892035836259922","12298482035836259922","11444745185836259922","10373492367654441743","9057658617654441743","8098747733039057132","7459878233039057136","6629031833039057136","6255473333039057136","6015320509509645376","5297005009509645376","5096305246351750642","4750268071351750642","4538447285637464930","4350842081092010386","4078979081092010390","3942804206092010390"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[7],addressList[4],addressList[4],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[17],addressList[19],addressList[20],addressList[9],addressList[21],addressList[16],addressList[22],addressList[9],addressList[22],addressList[20],addressList[9]], ["1036288000000000000000","204800000000000000000","102400000000000000000","104960000000000000000","61952000000000000000","98337280000000000000","86346760000000000000","44149560000000000000","45376770000000000000","54334920000000000000","29216410000000000000","31614180000000000000","43735200000000000000","36213050000000000000","36677460000000000000","32104390000000000000","23072150000000000000","15847390000000000000","35088670000000000000","14445910000000000000","22290630000000000000","34558620000000000000","14694100000000000000","19822290000000000000","10801250000000000000"], ["220845008964407688492","36525008964407688492","36525008964407688492","28845008964407688492","25965008964407688492","22347728964407688492","17838032964407688492","15885557535836259922","14142892035836259922","12298482035836259922","11444745185836259922","10373492367654441743","9057658617654441743","8098747733039057132","7459878233039057136","6629031833039057136","6255473333039057136","6015320509509645376","5297005009509645376","5096305246351750642","4750268071351750642","4538447285637464930","4350842081092010386","4078979081092010390","3942804206092010390"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542575334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[16],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729667", blockHash: "0xd3b1d4fcdcc0920a710b38e3586e7d3d872cc98966489b800a916fd6ae11f1d5", timeStamp: "1542575433", hash: "0xf7acdb08981dd9f812ec9ef38316f8549dae1643b6b2b780dffe0f87206c9cf6", nonce: "12", transactionIndex: "76", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742644", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000000190000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b0000000000000000000000009d7007416e7ccb2c352463d42640acc6c95eda6e0000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a1410000000000000000000000004b80b7460083ed857445d92eab9972419ce5cb390000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd200000000000000000000000055ea8a1613de642d17329a9c6b2d8afda69e62a1000000000000000000000000087b961c29efd8dc93abe9c8fa392739a3ad8cf6000000000000000000000000a7cf0d8511d269da2e06a5665f0d8a67f4fe7f2e0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd200000000000000000000000052af787439a82f36d6ef6b0da0f0e5ecce29ff90000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf1800000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf70000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b00000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf7000000000000000000000000087b961c29efd8dc93abe9c8fa392739a3ad8cf60000000000000000000000006eccb16f3361d07655e60be79fb70abef14d5e3c000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd29458000000000000000000000000b9e9cbd1a17cb4e6b08b8ad5be521534e61786900000000000000000000000003c39b94c292d47f269c7ab016985cbb3b5fe4b21000000000000000000000000c6f827796a2e1937fd7f97c4e0a4906c476794f600000000000000000000000014eefe5199839480d6fd58c2d720acdff959bcb00000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a141000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd29458000000000000000000000000e9beb23b9f8fd24edaddc9389b56d7227ad5c1b0000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd29458000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000094ed8e59002de000000000000000000000000000000000000000000000000000c3acb1c69dd800000000000000000000000000000000000000000000000000009a7a88f18afe000000000000000000000000000000000000000000000000000278ea9f8bf62a8000000000000000000000000000000000000000000000000000b5c2b54afb96e000000000000000000000000000000000000000000000000000e8b1f2efef1fa0000000000000000000000000000000000000000000000000025a076b60fe7980000000000000000000000000000000000000000000000000009b1442c77e6c60000000000000000000000000000000000000000000000000014525f32a6c8980000000000000000000000000000000000000000000000000007a622373a87fa000000000000000000000000000000000000000000000000000bfcbfec42ab440000000000000000000000000000000000000000000000000008739b690604d40000000000000000000000000000000000000000000000000009baee915697f00000000000000000000000000000000000000000000000000007c1bd8ed956c400000000000000000000000000000000000000000000000000088c28964a51de000000000000000000000000000000000000000000000000000a294c96cd71aa000000000000000000000000000000000000000000000000000d661d2d2dff740000000000000000000000000000000000000000000000000009beec9cc628ec0000000000000000000000000000000000000000000000000008e71a83bac38a00000000000000000000000000000000000000000000000000079db86b291f58000000000000000000000000000000000000000000000000000a8d17ba10482000000000000000000000000000000000000000000000000000090e0a9395808a000000000000000000000000000000000000000000000000000c702a9046e8120000000000000000000000000000000000000000000000000009b4663bfe03440000000000000000000000000000000000000000000000000006d0b606de5bc8000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000034c965f5aa70db96000000000000000000000000000000000000000000000000325cbe75a533b1230000000000000000000000000000000000000000000000003083aa4bf104b3d10000000000000000000000000000000000000000000000002d02b5a64ac74ab00000000000000000000000000000000000000000000000002b02e4b0e382f69000000000000000000000000000000000000000000000000028cd8b63ad344a90000000000000000000000000000000000000000000000000270a3608841f598b00000000000000000000000000000000000000000000000025bd2d2cfa2b030b00000000000000000000000000000000000000000000000024ba11dde41b70e100000000000000000000000000000000000000000000000023958608a68e3ca8000000000000000000000000000000000000000000000000231222b9541e893d00000000000000000000000000000000000000000000000021cde141960ccb3d000000000000000000000000000000000000000000000000207ed8debd178d330000000000000000000000000000000000000000000000001f43493db3b706430000000000000000000000000000000000000000000000001ebfe6cc3570aee20000000000000000000000000000000000000000000000001d6e3bd121790de20000000000000000000000000000000000000000000000001bc67e68d96b722f0000000000000000000000000000000000000000000000001a8dfff00e75be3200000000000000000000000000000000000000000000000019747214ab12fc5900000000000000000000000000000000000000000000000018eef106ddc0611500000000000000000000000000000000000000000000000017eddd14a928d11500000000000000000000000000000000000000000000000016ee9b5e87889ea800000000000000000000000000000000000000000000000015b595721219a29700000000000000000000000000000000000000000000000014dd2206b0d64a9700000000000000000000000000000000000000000000000014390545fa31c4b9", contractAddress: "", cumulativeGasUsed: "6123127", txreceipt_status: "1", gasUsed: "1742644", confirmations: "977711", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[16],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[17],addressList[28],addressList[26],addressList[29],addressList[9],addressList[14],addressList[16],addressList[14],addressList[17],addressList[30],addressList[13],addressList[31],addressList[32],addressList[33],addressList[21],addressList[24],addressList[13],addressList[34],addressList[13]]}, {type: "uint256[]", name: "price_", value: ["10731390000000000000","14099840000000000000","11131360000000000000","45606440000000000000","13097230000000000000","16767450000000000000","43380760000000000000","11174630000000000000","23429400000000000000","8818650000000000000","13820420000000000000","9744020000000000000","11218160000000000000","8942980000000000000","9854590000000000000","11715210000000000000","15447860000000000000","11236140000000000000","10264170000000000000","8780760000000000000","12164640000000000000","10439530000000000000","14340210000000000000","11188740000000000000","7857480000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["3803683466092010390","3628984812245856547","3495824978912523217","3243354407483951792","3099290941966710416","2940159391966710416","2813120327450581387","2719379421200581387","2646447375746035937","2564102934569565352","2527120520283851069","2435850645283851069","2341547307446013235","2252724767972329027","2215743306433867490","2120698243933867490","2001426073202160175","1913466823202160178","1834216381341695065","1796638313159876885","1724277313159876885","1652428943594659496","1564320762743595671","1503395262743595671","1457201752539514041"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[16],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[17],addressList[28],addressList[26],addressList[29],addressList[9],addressList[14],addressList[16],addressList[14],addressList[17],addressList[30],addressList[13],addressList[31],addressList[32],addressList[33],addressList[21],addressList[24],addressList[13],addressList[34],addressList[13]], ["10731390000000000000","14099840000000000000","11131360000000000000","45606440000000000000","13097230000000000000","16767450000000000000","43380760000000000000","11174630000000000000","23429400000000000000","8818650000000000000","13820420000000000000","9744020000000000000","11218160000000000000","8942980000000000000","9854590000000000000","11715210000000000000","15447860000000000000","11236140000000000000","10264170000000000000","8780760000000000000","12164640000000000000","10439530000000000000","14340210000000000000","11188740000000000000","7857480000000000000"], ["3803683466092010390","3628984812245856547","3495824978912523217","3243354407483951792","3099290941966710416","2940159391966710416","2813120327450581387","2719379421200581387","2646447375746035937","2564102934569565352","2527120520283851069","2435850645283851069","2341547307446013235","2252724767972329027","2215743306433867490","2120698243933867490","2001426073202160175","1913466823202160178","1834216381341695065","1796638313159876885","1724277313159876885","1652428943594659496","1564320762743595671","1503395262743595671","1457201752539514041"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542575433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[19],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729670", blockHash: "0x195d40c67b50d36a75202d087508bf27049ce94aa729391dd4f57e90a29e4779", timeStamp: "1542575464", hash: "0x236caaf56a0798f7874fe21dfbaaec10959699b2c7667d6e63fee0cb8dc51383", nonce: "13", transactionIndex: "27", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742644", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000000190000000000000000000000009b233800d7f352b886a353fd56bac3121f804f59000000000000000000000000a24e91f2684a69ffe0a10a5cc384f9e0b163dd8b000000000000000000000000af87a86920b508a532223c516e9a33471356e24500000000000000000000000014eefe5199839480d6fd58c2d720acdff959bcb0000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd294580000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2000000000000000000000000b9e9cbd1a17cb4e6b08b8ad5be521534e61786900000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b0000000000000000000000006eccb16f3361d07655e60be79fb70abef14d5e3c000000000000000000000000ab72a297d971f5d035738f39ddbe81f658d8796e0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd20000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000137017b8389ff246ce2c19459b92d0516f87e74200000000000000000000000096759150bec4f31c440928ea7437566988f82a34000000000000000000000000ff107821cb2a1671531f284313ebcd0a569c31480000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a6400000000000000000000000068c3110b0e3d592680d5f575fdf712d66d5853db00000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c00000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000ff107821cb2a1671531f284313ebcd0a569c314800000000000000000000000068c3110b0e3d592680d5f575fdf712d66d5853db000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd2945800000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf70000000000000000000000008c345b473aa663f92f7d3d057cce3c39fb7d768b000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000059777e104832800000000000000000000000000000000000000000000000000067f9dac638de400000000000000000000000000000000000000000000000000053ad8371969740000000000000000000000000000000000000000000000000009e66913dbef7200000000000000000000000000000000000000000000000000074ceb1935831c0000000000000000000000000000000000000000000000000008d4c33f881c6200000000000000000000000000000000000000000000000000093d91e909e34c0000000000000000000000000000000000000000000000000009ed7e61f474ce0000000000000000000000000000000000000000000000000007abecb12d83da0000000000000000000000000000000000000000000000000007d8a34058ea94000000000000000000000000000000000000000000000000000485e5f1dc4ad600000000000000000000000000000000000000000000000000039241ef5b66ea0000000000000000000000000000000000000000000000000004d2453d1a72c4000000000000000000000000000000000000000000000000000485e837efe77e000000000000000000000000000000000000000000000000000479e8f7f514100000000000000000000000000000000000000000000000000003295c891581700000000000000000000000000000000000000000000000000006076fbdca6a2c00000000000000000000000000000000000000000000000000045df21bc0e3dc000000000000000000000000000000000000000000000000000474772afef5c800000000000000000000000000000000000000000000000000050d9786c695dc0000000000000000000000000000000000000000000000000004b8e895588ed80000000000000000000000000000000000000000000000000003b1e3d9335226000000000000000000000000000000000000000000000000000519211c4a7e540000000000000000000000000000000000000000000000000005b8ddb2964dd2000000000000000000000000000000000000000000000000000655fe5fe11b8a000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000013b4f429b79708b900000000000000000000000000000000000000000000000013875d3b91f9fc08000000000000000000000000000000000000000000000000131b8ffaef3c040b0000000000000000000000000000000000000000000000001214eed64b2d5fd4000000000000000000000000000000000000000000000000117d0e1715230280000000000000000000000000000000000000000000000000111a7109fd98979a000000000000000000000000000000000000000000000000101c7f274f1d859c0000000000000000000000000000000000000000000000000f4b071b49b9b74f0000000000000000000000000000000000000000000000000e8ba974ece46a140000000000000000000000000000000000000000000000000e05994fd975b4ce0000000000000000000000000000000000000000000000000dabb546e75a54ce0000000000000000000000000000000000000000000000000d752aa3c7226a960000000000000000000000000000000000000000000000000d298e067f65bd700000000000000000000000000000000000000000000000000ccd54528eb94b290000000000000000000000000000000000000000000000000c7bd9ef7b2378890000000000000000000000000000000000000000000000000c371f9edc0366150000000000000000000000000000000000000000000000000bbd6e887d504d5d0000000000000000000000000000000000000000000000000b685ee8a41a798d0000000000000000000000000000000000000000000000000b1cf057e73a09550000000000000000000000000000000000000000000000000ab96b1f7f74c1590000000000000000000000000000000000000000000000000a572d343059aa800000000000000000000000000000000000000000000000000a095c76ecd298b400000000000000000000000000000000000000000000000009acd35e1df881b400000000000000000000000000000000000000000000000009645adf2cbe3f160000000000000000000000000000000000000000000000000906e43dd891b5cc", contractAddress: "", cumulativeGasUsed: "3442571", txreceipt_status: "1", gasUsed: "1742644", confirmations: "977708", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[19],addressList[35],addressList[36],addressList[21],addressList[13],addressList[18],addressList[26],addressList[31],addressList[16],addressList[30],addressList[37],addressList[26],addressList[18],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[18],addressList[40],addressList[42],addressList[13],addressList[14],addressList[44]]}, {type: "uint256[]", name: "price_", value: ["6446760000000000000","7492260000000000000","6029620000000000000","11413970000000000000","8416860000000000000","10181570000000000000","10653580000000000000","11445870000000000000","8844730000000000000","9046100000000000000","5214710000000000000","4117450000000000000","5558660000000000000","5214750000000000000","5160720000000000000","3645040000000000000","6951020000000000000","5034780000000000000","5136200000000000000","5825820000000000000","5444440000000000000","4259910000000000000","5877780000000000000","6597170000000000000","7304810000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["1420028242539514041","1407195919010102280","1376852419010102283","1302928796368592852","1260178963035259520","1232421735762532250","1160942610762532252","1101982347604637519","1048117657949465108","1010382259644380366","985080259644380366","969728177677167254","948445355096522096","922486212239379241","899552173176879241","880207019330725397","845953837512543581","822011285273737613","800779094097267029","772766594097267033","745113965525838464","723210881018796212","697164443518796212","676765758587289366","650458150479181260"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[19],addressList[35],addressList[36],addressList[21],addressList[13],addressList[18],addressList[26],addressList[31],addressList[16],addressList[30],addressList[37],addressList[26],addressList[18],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[18],addressList[40],addressList[42],addressList[13],addressList[14],addressList[44]], ["6446760000000000000","7492260000000000000","6029620000000000000","11413970000000000000","8416860000000000000","10181570000000000000","10653580000000000000","11445870000000000000","8844730000000000000","9046100000000000000","5214710000000000000","4117450000000000000","5558660000000000000","5214750000000000000","5160720000000000000","3645040000000000000","6951020000000000000","5034780000000000000","5136200000000000000","5825820000000000000","5444440000000000000","4259910000000000000","5877780000000000000","6597170000000000000","7304810000000000000"], ["1420028242539514041","1407195919010102280","1376852419010102283","1302928796368592852","1260178963035259520","1232421735762532250","1160942610762532252","1101982347604637519","1048117657949465108","1010382259644380366","985080259644380366","969728177677167254","948445355096522096","922486212239379241","899552173176879241","880207019330725397","845953837512543581","822011285273737613","800779094097267029","772766594097267033","745113965525838464","723210881018796212","697164443518796212","676765758587289366","650458150479181260"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542575464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[45],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729675", blockHash: "0xf398008c57f27ff90339169b0d8abed89bd1c768e7ee391897ec8a552725aedd", timeStamp: "1542575516", hash: "0x3f90ea2a6da672785c6f802df5f21f7d8652b215088cc43c11563e36a692aa0d", nonce: "14", transactionIndex: "11", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742580", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000001900000000000000000000000090b298f5ff8a52d15c2709087f327af698fe97290000000000000000000000007be01bec1ababc771290c8fca44d9789af8ae0f30000000000000000000000009a164541fd8018d280ff69001951d5ccde9b34930000000000000000000000001f6fa14d9707bc52196a95ae82a80487fa099821000000000000000000000000509dccd9ad4f204151809fc6c7843b42c1e542f3000000000000000000000000940b99ca07524598923cff6aff035c71fc9f57ca000000000000000000000000fb22bfa1dd43c3f27b088c328d5f7f82f7d3ee80000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd2945800000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c000000000000000000000000052af787439a82f36d6ef6b0da0f0e5ecce29ff900000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000a24e91f2684a69ffe0a10a5cc384f9e0b163dd8b0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd200000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c00000000000000000000000009a164541fd8018d280ff69001951d5ccde9b349300000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c000000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c00000000000000000000000002845a83d2a6cb264a5e35103ef10472746f43c4d00000000000000000000000055ea8a1613de642d17329a9c6b2d8afda69e62a1000000000000000000000000832bf16cd52868b76e2df375a7a49adafb6427cd00000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf700000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c00000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000e7ce0dce6d1e4664d2c0c7ff524b019bd00f65c40000000000000000000000007be01bec1ababc771290c8fca44d9789af8ae0f30000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000393d2ae5c0194000000000000000000000000000000000000000000000000000ba1cb2739b5c60000000000000000000000000000000000000000000000000003682cf862099a0000000000000000000000000000000000000000000000000003608502588bea00000000000000000000000000000000000000000000000000075db07b5dc14600000000000000000000000000000000000000000000000000022cbeea2ac06000000000000000000000000000000000000000000000000000037c6f5d20de820000000000000000000000000000000000000000000000000003bfa151b6fd5e00000000000000000000000000000000000000000000000000024fe262c07baa000000000000000000000000000000000000000000000000000296e57ac2d58c000000000000000000000000000000000000000000000000000266cdc371171e0000000000000000000000000000000000000000000000000001f35fb64f6f54000000000000000000000000000000000000000000000000000252824663cf9600000000000000000000000000000000000000000000000000020690b057ee52000000000000000000000000000000000000000000000000000224e6a30081be0000000000000000000000000000000000000000000000000002ab62fd7f93840000000000000000000000000000000000000000000000000002c67dddca4f3a000000000000000000000000000000000000000000000000000386849f9952840000000000000000000000000000000000000000000000000003c020147c5af400000000000000000000000000000000000000000000000000026b0e509e4e4c0000000000000000000000000000000000000000000000000001988fe4052b8000000000000000000000000000000000000000000000000000024837039992fe00000000000000000000000000000000000000000000000000019da8727985060000000000000000000000000000000000000000000000000001881fc5bc5ff2000000000000000000000000000000000000000000000000000353f5f20543fa000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000008c25bded9bcb5cc0000000000000000000000000000000000000000000000000885d53d767a592c0000000000000000000000000000000000000000000000000852547f06a2d85a00000000000000000000000000000000000000000000000008139a5ecb4416d200000000000000000000000000000000000000000000000007a376cc26973cce0000000000000000000000000000000000000000000000000780bbc258320cce000000000000000000000000000000000000000000000000074fc7874b9ed77b0000000000000000000000000000000000000000000000000716a990c73cd6d000000000000000000000000000000000000000000000000006f1c8498e012c0700000000000000000000000000000000000000000000000006e00b367760dc9c00000000000000000000000000000000000000000000000006ba5086027bd86300000000000000000000000000000000000000000000000006a10c415cc422590000000000000000000000000000000000000000000000000686c5be05abdfdf00000000000000000000000000000000000000000000000006684fefad36f08400000000000000000000000000000000000000000000000006498105e374702a0000000000000000000000000000000000000000000000000626e83a27ef742a0000000000000000000000000000000000000000000000000607b3454bb5f4f700000000000000000000000000000000000000000000000005cde97d3b0dbfc300000000000000000000000000000000000000000000000005950ebe27280df8000000000000000000000000000000000000000000000000056b2fce4f541268000000000000000000000000000000000000000000000000055136d9618657e40000000000000000000000000000000000000000000000000538795012809f24000000000000000000000000000000000000000000000000052973e14ed2e2dd00000000000000000000000000000000000000000000000005175651fa0f8d7d00000000000000000000000000000000000000000000000004ed9875d415a297", contractAddress: "", cumulativeGasUsed: "2104234", txreceipt_status: "1", gasUsed: "1742580", confirmations: "977703", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[13],addressList[43],addressList[29],addressList[18],addressList[35],addressList[26],addressList[43],addressList[47],addressList[43],addressList[43],addressList[52],addressList[27],addressList[53],addressList[14],addressList[43],addressList[18],addressList[54],addressList[46]]}, {type: "uint256[]", name: "price_", value: ["4124500000000000000","13410790000000000000","3927930000000000000","3893450000000000000","8492390000000000000","2507360000000000000","4019170000000000000","4321790000000000000","2665610000000000000","2985420000000000000","2768830000000000000","2248980000000000000","2677430000000000000","2335410000000000000","2472030000000000000","3077700000000000000","3199770000000000000","4064580000000000000","4324020000000000000","2787980000000000000","1840000000000000000","2631070000000000000","1862950000000000000","1765970000000000000","3836890000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["631167910479181260","614131384163391788","599634604942612570","581978508788766418","550414198662184142","540638398662184142","526859065328850811","510782047036167888","500401251855444999","495408287569730716","484788446393260131","477676510346748505","470280631036403679","461706852627312772","453035099818324010","443296949818324010","434512999268873463","418247064486264771","402243951583038968","390458355838358120","383147750575200228","376183953700200228","371955855762055901","366856804741647741","355107577468920471"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[13],addressList[43],addressList[29],addressList[18],addressList[35],addressList[26],addressList[43],addressList[47],addressList[43],addressList[43],addressList[52],addressList[27],addressList[53],addressList[14],addressList[43],addressList[18],addressList[54],addressList[46]], ["4124500000000000000","13410790000000000000","3927930000000000000","3893450000000000000","8492390000000000000","2507360000000000000","4019170000000000000","4321790000000000000","2665610000000000000","2985420000000000000","2768830000000000000","2248980000000000000","2677430000000000000","2335410000000000000","2472030000000000000","3077700000000000000","3199770000000000000","4064580000000000000","4324020000000000000","2787980000000000000","1840000000000000000","2631070000000000000","1862950000000000000","1765970000000000000","3836890000000000000"], ["631167910479181260","614131384163391788","599634604942612570","581978508788766418","550414198662184142","540638398662184142","526859065328850811","510782047036167888","500401251855444999","495408287569730716","484788446393260131","477676510346748505","470280631036403679","461706852627312772","453035099818324010","443296949818324010","434512999268873463","418247064486264771","402243951583038968","390458355838358120","383147750575200228","376183953700200228","371955855762055901","366856804741647741","355107577468920471"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542575516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[13],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729676", blockHash: "0x3eeaf4cfca0c045ecd28d39deebbc71d71143c6d13f5d99bea1226fa95ab56dc", timeStamp: "1542575537", hash: "0x7e337421c87c21403a54c0d409fa3d9b15c93a5c2bc07aad7f28d18f75861459", nonce: "15", transactionIndex: "46", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742708", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000019000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd29458000000000000000000000000a24e91f2684a69ffe0a10a5cc384f9e0b163dd8b0000000000000000000000003f67dfeee1d3326d6f8bc086dade8915ecf4c92c00000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c0000000000000000000000000a24e91f2684a69ffe0a10a5cc384f9e0b163dd8b000000000000000000000000ab72a297d971f5d035738f39ddbe81f658d8796e0000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a14100000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c0000000000000000000000000a48c69294518a2e8abadae36af12e9ef7820ca5d00000000000000000000000096759150bec4f31c440928ea7437566988f82a34000000000000000000000000fbaae0f8ff8541194daf1221ac39e78ebb3b3cad000000000000000000000000cb0c3b15505f8048849c1d4f32835bb98807a0550000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f0000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a6400000000000000000000000040facd6c48456026f748d176ce7c233da64cc7330000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a64000000000000000000000000509dccd9ad4f204151809fc6c7843b42c1e542f30000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000001c2890768064a657ffcaf9c0c92d2b99ed7c18e2000000000000000000000000e9beb23b9f8fd24edaddc9389b56d7227ad5c1b0000000000000000000000000b9e9cbd1a17cb4e6b08b8ad5be521534e6178690000000000000000000000000bb879a0e0cc18548b132a33cc4c973da45e9ee63000000000000000000000000af87a86920b508a532223c516e9a33471356e2450000000000000000000000001c2890768064a657ffcaf9c0c92d2b99ed7c18e2000000000000000000000000fb22bfa1dd43c3f27b088c328d5f7f82f7d3ee8000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000003732c6cbe85340000000000000000000000000000000000000000000000000001cfbaa35bd2a200000000000000000000000000000000000000000000000000015179785c1e0a0000000000000000000000000000000000000000000000000001b4e63f710f44000000000000000000000000000000000000000000000000000135382525a3580000000000000000000000000000000000000000000000000001807bca553468000000000000000000000000000000000000000000000000000118fda429fe9e00000000000000000000000000000000000000000000000000013b0a02d85c5a0000000000000000000000000000000000000000000000000001696930d24aa20000000000000000000000000000000000000000000000000001c57d050741fa0000000000000000000000000000000000000000000000000001d3f063abe1b20000000000000000000000000000000000000000000000000001a649f36b6bbc0000000000000000000000000000000000000000000000000002117d62929d82000000000000000000000000000000000000000000000000000194815c876ac20000000000000000000000000000000000000000000000000001dc61937d07760000000000000000000000000000000000000000000000000001840a6c03c93c00000000000000000000000000000000000000000000000000033c16b59d4724000000000000000000000000000000000000000000000000000193eab9f420480000000000000000000000000000000000000000000000000001f058efb4aab600000000000000000000000000000000000000000000000000016354d161eb6e000000000000000000000000000000000000000000000000000186c99334c72e0000000000000000000000000000000000000000000000000002ee1d931011ec000000000000000000000000000000000000000000000000000140a0310845220000000000000000000000000000000000000000000000000001f0cf2bb07cd600000000000000000000000000000000000000000000000000012cf228c91e0c000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000004c681beabf17a9700000000000000000000000000000000000000000000000004bc931159804fd300000000000000000000000000000000000000000000000004b40e727d57504e000000000000000000000000000000000000000000000000049fd169dcd55e380000000000000000000000000000000000000000000000000493e90a781282b100000000000000000000000000000000000000000000000004822f56846114fc0000000000000000000000000000000000000000000000000473ebd0be25ce920000000000000000000000000000000000000000000000000461d33b5d092b25000000000000000000000000000000000000000000000000044e09282c00a7d20000000000000000000000000000000000000000000000000436b8e92cd9647600000000000000000000000000000000000000000000000004249ae27dcb53040000000000000000000000000000000000000000000000000411044cb68c43e400000000000000000000000000000000000000000000000003fa76a1e517007900000000000000000000000000000000000000000000000003e86f03e463d51500000000000000000000000000000000000000000000000003d4215c55f181ef00000000000000000000000000000000000000000000000003c41e439cca424b00000000000000000000000000000000000000000000000003a0b5cb02782345000000000000000000000000000000000000000000000000038e9ed225b4665c000000000000000000000000000000000000000000000000037b988bcf0ca86700000000000000000000000000000000000000000000000003696854a786cd8500000000000000000000000000000000000000000000000003578646817813850000000000000000000000000000000000000000000000000348e04a29f40947000000000000000000000000000000000000000000000000033cd8bf834e73e8000000000000000000000000000000000000000000000000032a72f3b41be229000000000000000000000000000000000000000000000000031dd47012e4025e", contractAddress: "", cumulativeGasUsed: "3780888", txreceipt_status: "1", gasUsed: "1742708", confirmations: "977702", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[13],addressList[35],addressList[15],addressList[43],addressList[35],addressList[37],addressList[24],addressList[43],addressList[55],addressList[39],addressList[56],addressList[20],addressList[18],addressList[41],addressList[57],addressList[41],addressList[49],addressList[41],addressList[58],addressList[34],addressList[31],addressList[59],addressList[36],addressList[58],addressList[51]]}, {type: "uint256[]", name: "price_", value: ["3977460000000000000","2088450000000000000","1519850000000000000","1967620000000000000","1392600000000000000","1731560000000000000","1265470000000000000","1418810000000000000","1627650000000000000","2042330000000000000","2107410000000000000","1901820000000000000","2384610000000000000","1821730000000000000","2145430000000000000","1747580000000000000","3729380000000000000","1819080000000000000","2235350000000000000","1600270000000000000","1759950000000000000","3378220000000000000","1443970000000000000","2237430000000000000","1355340000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["344105077468920471","341309374498623443","338911756851564622","333215150055448120","329863428901601969","324874171758744828","320859280249310866","315765700810058533","310195492476725202","303633336513422454","298533772877058820","293020178282464228","286671963996749945","281597039217988885","275882157639041519","271375153291215435","261408661911905093","256316854219597404","250961930490783847","245842367465573765","240808742465573765","236685589573011783","233299597769733096","228121122159977001","224569134256751198"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[13],addressList[35],addressList[15],addressList[43],addressList[35],addressList[37],addressList[24],addressList[43],addressList[55],addressList[39],addressList[56],addressList[20],addressList[18],addressList[41],addressList[57],addressList[41],addressList[49],addressList[41],addressList[58],addressList[34],addressList[31],addressList[59],addressList[36],addressList[58],addressList[51]], ["3977460000000000000","2088450000000000000","1519850000000000000","1967620000000000000","1392600000000000000","1731560000000000000","1265470000000000000","1418810000000000000","1627650000000000000","2042330000000000000","2107410000000000000","1901820000000000000","2384610000000000000","1821730000000000000","2145430000000000000","1747580000000000000","3729380000000000000","1819080000000000000","2235350000000000000","1600270000000000000","1759950000000000000","3378220000000000000","1443970000000000000","2237430000000000000","1355340000000000000"], ["344105077468920471","341309374498623443","338911756851564622","333215150055448120","329863428901601969","324874171758744828","320859280249310866","315765700810058533","310195492476725202","303633336513422454","298533772877058820","293020178282464228","286671963996749945","281597039217988885","275882157639041519","271375153291215435","261408661911905093","256316854219597404","250961930490783847","245842367465573765","240808742465573765","236685589573011783","233299597769733096","228121122159977001","224569134256751198"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542575537 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[31],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729680", blockHash: "0x5bb61eb6d49ab6dbef2b77e3fb293cc39a2bab7f3d92ddf32c6eced26720ff49", timeStamp: "1542575623", hash: "0xfa4265617fca2b954b43ffe87f4f0de8c695337cc844810367437f1374fcbfc1", nonce: "16", transactionIndex: "109", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742516", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000019000000000000000000000000b9e9cbd1a17cb4e6b08b8ad5be521534e61786900000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a1410000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000009d7007416e7ccb2c352463d42640acc6c95eda6e0000000000000000000000008accf804e82c211c4ce7d6b1d23c12ba3f6425df0000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b00000000000000000000000014eefe5199839480d6fd58c2d720acdff959bcb00000000000000000000000002845a83d2a6cb264a5e35103ef10472746f43c4d0000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a64000000000000000000000000b9e9cbd1a17cb4e6b08b8ad5be521534e61786900000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000002503425d6f84c32795384e3ee8186d05fdd13ec40000000000000000000000002503425d6f84c32795384e3ee8186d05fdd13ec40000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a64000000000000000000000000388acf06405f04885018aa941264ba232f5dfa9b00000000000000000000000096759150bec4f31c440928ea7437566988f82a34000000000000000000000000509dccd9ad4f204151809fc6c7843b42c1e542f3000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000016bf2e93667280000000000000000000000000000000000000000000000000001be4232ab23ca00000000000000000000000000000000000000000000000000012ed4c28bc056000000000000000000000000000000000000000000000000000127fa9271240a00000000000000000000000000000000000000000000000000016fa8c3b74a4e00000000000000000000000000000000000000000000000000015141c37b9ff60000000000000000000000000000000000000000000000000001c625d83771b400000000000000000000000000000000000000000000000000013187f9d5c7d6000000000000000000000000000000000000000000000000000279642043f97c00000000000000000000000000000000000000000000000000018af9a453ce9a0000000000000000000000000000000000000000000000000001e0d8b280ee6400000000000000000000000000000000000000000000000000015c3cabb0e2400000000000000000000000000000000000000000000000000001b5b64b738d500000000000000000000000000000000000000000000000000000e30f82fe4dde000000000000000000000000000000000000000000000000000179094318982400000000000000000000000000000000000000000000000000010e2ba955c0240000000000000000000000000000000000000000000000000002022ce4fabaf800000000000000000000000000000000000000000000000000013d02c7da360a0000000000000000000000000000000000000000000000000001ade1feeba0d40000000000000000000000000000000000000000000000000000bf7f78401a3e0000000000000000000000000000000000000000000000000001be213a8ec446000000000000000000000000000000000000000000000000000157b5a223b2ba0000000000000000000000000000000000000000000000000000c705e4a851400000000000000000000000000000000000000000000000000001ea1b115e608800000000000000000000000000000000000000000000000000030e768612bffc00000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000311b5984184ea5e000000000000000000000000000000000000000000000000030134ed4910193c00000000000000000000000000000000000000000000000002f6cc142a8f312e00000000000000000000000000000000000000000000000002e92891546758de00000000000000000000000000000000000000000000000002d9ed5781a108b100000000000000000000000000000000000000000000000002cf0cef2d65241600000000000000000000000000000000000000000000000002bbe6e91bfefe7a00000000000000000000000000000000000000000000000002b3040976406a7c00000000000000000000000000000000000000000000000002a581ce734988070000000000000000000000000000000000000000000000000293e380034082c70000000000000000000000000000000000000000000000000282338ce46a8d730000000000000000000000000000000000000000000000000272aa05bc6b3bcf0000000000000000000000000000000000000000000000000264832edb5d3646000000000000000000000000000000000000000000000000025e0210f8ae9f8000000000000000000000000000000000000000000000000002500b33d6a448b800000000000000000000000000000000000000000000000002478e7db97ed39500000000000000000000000000000000000000000000000002382014debac577000000000000000000000000000000000000000000000000022bb64f6bc286e1000000000000000000000000000000000000000000000000021c09c753673e0d0000000000000000000000000000000000000000000000000217b7dc8a00668d00000000000000000000000000000000000000000000000002099d0122838c14000000000000000000000000000000000000000000000000020076ed891267de00000000000000000000000000000000000000000000000001fa6ae0058ebd1a00000000000000000000000000000000000000000000000001ea75b9db325e1500000000000000000000000000000000000000000000000001d3e610bafcaf70", contractAddress: "", cumulativeGasUsed: "4843525", txreceipt_status: "1", gasUsed: "1742516", confirmations: "977698", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[31],addressList[24],addressList[41],addressList[41],addressList[41],addressList[41],addressList[23],addressList[60],addressList[41],addressList[16],addressList[21],addressList[52],addressList[41],addressList[31],addressList[41],addressList[41],addressList[41],addressList[41],addressList[61],addressList[61],addressList[41],addressList[41],addressList[62],addressList[39],addressList[49]]}, {type: "uint256[]", name: "price_", value: ["1639080000000000000","2009770000000000000","1363830000000000000","1332970000000000000","1655790000000000000","1518870000000000000","2045300000000000000","1375990000000000000","2852540000000000000","1778810000000000000","2165540000000000000","1568320000000000000","1971280000000000000","1022590000000000000","1698020000000000000","1216740000000000000","2315640000000000000","1427690000000000000","1936020000000000000","862430000000000000","2009190000000000000","1547930000000000000","896320000000000000","2207240000000000000","3523900000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["221157522256751198","216512450828179772","213582419332116782","209743462300866782","205456218114820273","202394729653281814","197004897592213114","194503647592213116","190701282930558983","185742148602200775","180763615268867443","176390277033573327","172406923018974790","170576107801583488","166645503485036728","164256582056465301","159913060779869559","156419064300996321","152007239126171149","150791270376171149","146821091065826324","144245950654867422","142543848614051098","138052179695132181","131701773654863728"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[31],addressList[24],addressList[41],addressList[41],addressList[41],addressList[41],addressList[23],addressList[60],addressList[41],addressList[16],addressList[21],addressList[52],addressList[41],addressList[31],addressList[41],addressList[41],addressList[41],addressList[41],addressList[61],addressList[61],addressList[41],addressList[41],addressList[62],addressList[39],addressList[49]], ["1639080000000000000","2009770000000000000","1363830000000000000","1332970000000000000","1655790000000000000","1518870000000000000","2045300000000000000","1375990000000000000","2852540000000000000","1778810000000000000","2165540000000000000","1568320000000000000","1971280000000000000","1022590000000000000","1698020000000000000","1216740000000000000","2315640000000000000","1427690000000000000","1936020000000000000","862430000000000000","2009190000000000000","1547930000000000000","896320000000000000","2207240000000000000","3523900000000000000"], ["221157522256751198","216512450828179772","213582419332116782","209743462300866782","205456218114820273","202394729653281814","197004897592213114","194503647592213116","190701282930558983","185742148602200775","180763615268867443","176390277033573327","172406923018974790","170576107801583488","166645503485036728","164256582056465301","159913060779869559","156419064300996321","152007239126171149","150791270376171149","146821091065826324","144245950654867422","142543848614051098","138052179695132181","131701773654863728"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542575623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[41],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729686", blockHash: "0xd19fddeb418c9c56586d8c67daa34cdc1a2e5ed7d382b105154c0cfe5af46e79", timeStamp: "1542575740", hash: "0xa16bada266533b1c3232be9e9e9e3307c759c22f5072ff1eb58f0775dbdc9b32", nonce: "17", transactionIndex: "92", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1742516", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000000190000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a64000000000000000000000000600d797b923206f2f03125ea81fd5d47c6ced7720000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a6400000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000ef4677d99f600000000000000000000000000000000000000000000000000000c271c82a5cf40000000000000000000000000000000000000000000000000002e97745f538600000000000000000000000000000000000000000000000000000ceab949e3248000000000000000000000000000000000000000000000000000146902f3ed9d60000000000000000000000000000000000000000000000000001502222cab6f20000000000000000000000000000000000000000000000000002008defff8d340000000000000000000000000000000000000000000000000000d92a0021b3a4000000000000000000000000000000000000000000000000000127500ab23ed20000000000000000000000000000000000000000000000000000c0d3f638fd8400000000000000000000000000000000000000000000000000014b63645d09580000000000000000000000000000000000000000000000000001836b42a6f34c0000000000000000000000000000000000000000000000000000c6b927926a1a0000000000000000000000000000000000000000000000000000e0d682526aa40000000000000000000000000000000000000000000000000000bede9a548ed00000000000000000000000000000000000000000000000000000b2cdbb41bd4c0000000000000000000000000000000000000000000000000000e38132d2e6ae0000000000000000000000000000000000000000000000000000df1572310f080000000000000000000000000000000000000000000000000000a8574502e03c000000000000000000000000000000000000000000000000000183ff9f26a11e00000000000000000000000000000000000000000000000000018bea16edc5000000000000000000000000000000000000000000000000000000af38d8dd39aa0000000000000000000000000000000000000000000000000001a6c02f673ddc00000000000000000000000000000000000000000000000000014b0fd50c4c3a0000000000000000000000000000000000000000000000000000a39d12bc6bf2000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000001cc9596ac46eb7000000000000000000000000000000000000000000000000001c5a4737337c0b000000000000000000000000000000000000000000000000001b20fbfff1016a400000000000000000000000000000000000000000000000001aaa72f9feda3d3000000000000000000000000000000000000000000000000019e1c486c8b82d8000000000000000000000000000000000000000000000000019269ba4386ba1400000000000000000000000000000000000000000000000001805d540ec1d729000000000000000000000000000000000000000000000000017a43f7630bb4f90000000000000000000000000000000000000000000000000172c2b7636751a4000000000000000000000000000000000000000000000000016d854e59bf5faf0000000000000000000000000000000000000000000000000161a78171ff6eef00000000000000000000000000000000000000000000000001555de704a17c8f000000000000000000000000000000000000000000000000014fadfa6e232fac000000000000000000000000000000000000000000000000014a14ff2e8c94a30000000000000000000000000000000000000000000000000144d6aeb4d578be000000000000000000000000000000000000000000000000013f88f06bf362ee000000000000000000000000000000000000000000000000013a3a797de8598a0000000000000000000000000000000000000000000000000134924965b92167000000000000000000000000000000000000000000000000012f0480bc68cd2000000000000000000000000000000000000000000000000001250e4c6edff9c6000000000000000000000000000000000000000000000000011b8b89289435c800000000000000000000000000000000000000000000000001160fec13b6e2d7000000000000000000000000000000000000000000000000010f4733cf79de3d0000000000000000000000000000000000000000000000000106908c601d7f72000000000000000000000000000000000000000000000000010214cc21bdc350", contractAddress: "", cumulativeGasUsed: "7466060", txreceipt_status: "1", gasUsed: "1742516", confirmations: "977692", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[63],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41]]}, {type: "uint256[]", name: "price_", value: ["1077600000000000000","875700000000000000","3357280000000000000","930760000000000000","1470710000000000000","1513810000000000000","2308340000000000000","978020000000000000","1329970000000000000","868420000000000000","1492440000000000000","1744780000000000000","894970000000000000","1012580000000000000","859600000000000000","805260000000000000","1024590000000000000","1004680000000000000","758140000000000000","1747390000000000000","1783040000000000000","789130000000000000","1903900000000000000","1490970000000000000","736850000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["129642963654863728","127688980211155120","122177457184839332","120092163067192275","116561737742516952","113269189355420180","108189006663112489","106472270994322681","104359834285461924","102884938059046831","99544841184046831","96086213854854287","94485408299298732","92909828544697507","91433938300795070","89941083755340526","88447436164979082","86855136763781479","85291868906638624","82487889616697798","79810839616697800","78267550143013591","76358006538362429","73905376480558962","72643410963317584"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[63],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41]], ["1077600000000000000","875700000000000000","3357280000000000000","930760000000000000","1470710000000000000","1513810000000000000","2308340000000000000","978020000000000000","1329970000000000000","868420000000000000","1492440000000000000","1744780000000000000","894970000000000000","1012580000000000000","859600000000000000","805260000000000000","1024590000000000000","1004680000000000000","758140000000000000","1747390000000000000","1783040000000000000","789130000000000000","1903900000000000000","1490970000000000000","736850000000000000"], ["129642963654863728","127688980211155120","122177457184839332","120092163067192275","116561737742516952","113269189355420180","108189006663112489","106472270994322681","104359834285461924","102884938059046831","99544841184046831","96086213854854287","94485408299298732","92909828544697507","91433938300795070","89941083755340526","88447436164979082","86855136763781479","85291868906638624","82487889616697798","79810839616697800","78267550143013591","76358006538362429","73905376480558962","72643410963317584"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542575740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[41],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729688", blockHash: "0x1d1093a5520e07d5ebc84ec395c6bb9c35e7a196f50076d83f2eb4e7a26641c1", timeStamp: "1542575790", hash: "0x05455bbe9fa2317371b2db9e87a7d0742de0947894cda037b4ef69fc6640dfe1", nonce: "18", transactionIndex: "43", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1740916", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000000190000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a640000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b000000000000000000000000fb45597d51280e094c1d3520f1c22e2652aa72e40000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a6400000000000000000000000096759150bec4f31c440928ea7437566988f82a34000000000000000000000000832bf16cd52868b76e2df375a7a49adafb6427cd0000000000000000000000008accf804e82c211c4ce7d6b1d23c12ba3f6425df0000000000000000000000009a164541fd8018d280ff69001951d5ccde9b3493000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b530000000000000000000000002e6d72f09cb04425a29d420b5869b06d9535290800000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c000000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000b325d6b9b3ba000000000000000000000000000000000000000000000000000217237b4bcee20000000000000000000000000000000000000000000000000000a504e45c02cc000000000000000000000000000000000000000000000000000123c045f9dbaa000000000000000000000000000000000000000000000000000087388155f51400000000000000000000000000000000000000000000000000017132b07d0f000000000000000000000000000000000000000000000000000000c56418149faa0000000000000000000000000000000000000000000000000002246a264ec0d00000000000000000000000000000000000000000000000000000aae0fd66fcc20000000000000000000000000000000000000000000000000001d09853d3fc9e0000000000000000000000000000000000000000000000000000b922e7e10d340000000000000000000000000000000000000000000000000000a9ae9a9447540000000000000000000000000000000000000000000000000000a6e26072849c0000000000000000000000000000000000000000000000000000badc9442abae0000000000000000000000000000000000000000000000000000efac37c741be0000000000000000000000000000000000000000000000000000f240bd0886620000000000000000000000000000000000000000000000000000bb28bfd3abaa0000000000000000000000000000000000000000000000000000b2cdbb41bd4c0000000000000000000000000000000000000000000000000000feb1acd7f2a000000000000000000000000000000000000000000000000000009e4bac5dc6040000000000000000000000000000000000000000000000000000a54b60bbfb240000000000000000000000000000000000000000000000000000815ab3bc45a00000000000000000000000000000000000000000000000000000c1238ae7687c00000000000000000000000000000000000000000000000000009c02c1289a320000000000000000000000000000000000000000000000000000ab04cd1be018000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000fd1d4ae8c1e7e300000000000000000000000000000000000000000000000000f3bf777818f0e500000000000000000000000000000000000000000000000000ef2bb8b389ccf800000000000000000000000000000000000000000000000000e60f6b5e4e2aa300000000000000000000000000000000000000000000000000e15659b14e857600000000000000000000000000000000000000000000000000d64fea5b2cdd7600000000000000000000000000000000000000000000000000d0b95c55dcc8df00000000000000000000000000000000000000000000000000c8f2a1b6e37b9a00000000000000000000000000000000000000000000000000c4437682c0939c00000000000000000000000000000000000000000000000000b8ad0f38e5b53800000000000000000000000000000000000000000000000000b3feff30e57fd200000000000000000000000000000000000000000000000000afc0fe80e41eab00000000000000000000000000000000000000000000000000ab8ee222c8356500000000000000000000000000000000000000000000000000a669da4f5d975d00000000000000000000000000000000000000000000000000a0e1bf744ac6fd0000000000000000000000000000000000000000000000000099c23e977a60af00000000000000000000000000000000000000000000000000947130249ad208000000000000000000000000000000000000000000000000008fb4c8297d7b28000000000000000000000000000000000000000000000000008a6c2012acd73a00000000000000000000000000000000000000000000000000864efc96e916930000000000000000000000000000000000000000000000000083044e0b0a2df7000000000000000000000000000000000000000000000000007ef1493f612eb4000000000000000000000000000000000000000000000000007a58cdcf2f3c7a0000000000000000000000000000000000000000000000000075acd1834e0c7c000000000000000000000000000000000000000000000000007132e02abb4aed", contractAddress: "", cumulativeGasUsed: "3563409", txreceipt_status: "1", gasUsed: "1740916", confirmations: "977690", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[16],addressList[64],addressList[41],addressList[39],addressList[53],addressList[60],addressList[47],addressList[65],addressList[66],addressList[43],addressList[67]]}, {type: "uint256[]", name: "price_", value: ["806810000000000000","2410050000000000000","743180000000000000","1313930000000000000","608980000000000000","1662720000000000000","888970000000000000","2469840000000000000","769570000000000000","2092350000000000000","833780000000000000","764180000000000000","751580000000000000","841550000000000000","1079390000000000000","1091010000000000000","842890000000000000","805260000000000000","1147040000000000000","712900000000000000","744420000000000000","582560000000000000","869820000000000000","702610000000000000","770200000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["71245376677603299","68608939177603301","67320591719976184","64756198461549219","63426812986688886","60323512986688886","58750601384478943","56561771714149274","55243271714149276","51981676605453624","50664392821669842","49470320241024683","48289322914821477","46841232489289565","45284208679765757","43279245521871023","41782748139672072","40449693452172072","38962431794140986","37804493649811091","36877955188272631","35731143963782836","34437588126219386","33122588126219388","31862610739284717"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[41],addressList[16],addressList[64],addressList[41],addressList[39],addressList[53],addressList[60],addressList[47],addressList[65],addressList[66],addressList[43],addressList[67]], ["806810000000000000","2410050000000000000","743180000000000000","1313930000000000000","608980000000000000","1662720000000000000","888970000000000000","2469840000000000000","769570000000000000","2092350000000000000","833780000000000000","764180000000000000","751580000000000000","841550000000000000","1079390000000000000","1091010000000000000","842890000000000000","805260000000000000","1147040000000000000","712900000000000000","744420000000000000","582560000000000000","869820000000000000","702610000000000000","770200000000000000"], ["71245376677603299","68608939177603301","67320591719976184","64756198461549219","63426812986688886","60323512986688886","58750601384478943","56561771714149274","55243271714149276","51981676605453624","50664392821669842","49470320241024683","48289322914821477","46841232489289565","45284208679765757","43279245521871023","41782748139672072","40449693452172072","38962431794140986","37804493649811091","36877955188272631","35731143963782836","34437588126219386","33122588126219388","31862610739284717"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542575790 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[68],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729692", blockHash: "0x3c35cd80707ec13c03eb5972e55bea3b82db99d32b36f5be7204d42ba636e67f", timeStamp: "1542575833", hash: "0x79932fcc49b4e0eacd85787c97032ce31053a3db7df6aaacdb852c2ef7e7c968", nonce: "19", transactionIndex: "38", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1740788", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000c6830febf62f153d6f9466f1d9fe2b1d09a475d00000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc52303000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b530000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a141000000000000000000000000d99d24482696ef880abe7a076aa754c4fcc80636000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b53000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b53000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e0600000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a500000000000000000000000033497f64e2997669057710ccadd583d70798954a000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b95300000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c0000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a141000000000000000000000000516b88e8c700e364c2f969f2c059fed3bfb2fa29000000000000000000000000911dadb65524423fb43bf853b22e44bbf9ffde0e0000000000000000000000005de90f22dec06afed2d1848636878d08fad012bc000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a1410000000000000000000000008908fde0f1a8adb6a421b2f0cac6199fbcd2c35900000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000ac85100e4b000000000000000000000000000000000000000000000000000000974ad4f5c29000000000000000000000000000000000000000000000000000009487219d8b4e0000000000000000000000000000000000000000000000000000c90a999121620000000000000000000000000000000000000000000000000000bcf928f968b40000000000000000000000000000000000000000000000000000b3732554820a00000000000000000000000000000000000000000000000000004fc8fa2e0b1800000000000000000000000000000000000000000000000000008152be77a1540000000000000000000000000000000000000000000000000000b950f2ee317e0000000000000000000000000000000000000000000000000000416e0cdc3f6e000000000000000000000000000000000000000000000000000052a24740929600000000000000000000000000000000000000000000000000004bd7702a57b800000000000000000000000000000000000000000000000000004f86787064e600000000000000000000000000000000000000000000000000003fd558970078000000000000000000000000000000000000000000000000000050b32c1212b00000000000000000000000000000000000000000000000000000441677491ed000000000000000000000000000000000000000000000000000008741081f808a00000000000000000000000000000000000000000000000000006bc067e722760000000000000000000000000000000000000000000000000000683ffc3320bc00000000000000000000000000000000000000000000000000004402921d841200000000000000000000000000000000000000000000000000003df4736313ac000000000000000000000000000000000000000000000000000080636ee77942000000000000000000000000000000000000000000000000000042d9d91e286e00000000000000000000000000000000000000000000000000005682c3b12f0a000000000000000000000000000000000000000000000000000062e0f15ecede0000000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000006caad55669daed0000000000000000000000000000000000000000000000000068869d189ab4d8000000000000000000000000000000000000000000000000006440d7bc982d40000000000000000000000000000000000000000000000000005f1009906f7ffa000000000000000000000000000000000000000000000000005a884a8ab0441a00000000000000000000000000000000000000000000000000560b12d9f1eb550000000000000000000000000000000000000000000000000054268ae41cc4a90000000000000000000000000000000000000000000000000050c5cf90766347000000000000000000000000000000000000000000000000004cae725ea101dd000000000000000000000000000000000000000000000000004af1bfe1d353700000000000000000000000000000000000000000000000000048f8e6eb016edf0000000000000000000000000000000000000000000000000047447458eb18d90000000000000000000000000000000000000000000000000045839b21427e360000000000000000000000000000000000000000000000000043ebdedb5b02460000000000000000000000000000000000000000000000000041e33bd346620500000000000000000000000000000000000000000000000000403358acb3f0e9000000000000000000000000000000000000000000000000003cbb6ee87a3c95000000000000000000000000000000000000000000000000003a823942791ef300000000000000000000000000000000000000000000000000381b3ea018baaa000000000000000000000000000000000000000000000000003668680fe0cae40000000000000000000000000000000000000000000000000034ce68897a7bcf0000000000000000000000000000000000000000000000000031749a4265a740000000000000000000000000000000000000000000000000002ff7a5aeeafce1000000000000000000000000000000000000000000000000002e54b88c38993a000000000000000000000000000000000000000000000000002c988cebebcb4e", contractAddress: "", cumulativeGasUsed: "4485184", txreceipt_status: "1", gasUsed: "1740788", confirmations: "977686", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[68],addressList[67],addressList[67],addressList[67],addressList[67],addressList[67],addressList[65],addressList[24],addressList[69],addressList[65],addressList[70],addressList[65],addressList[70],addressList[71],addressList[72],addressList[73],addressList[43],addressList[70],addressList[24],addressList[74],addressList[75],addressList[76],addressList[77],addressList[24],addressList[78]]}, {type: "uint256[]", name: "price_", value: ["776960000000000000","681360000000000000","668910000000000000","905410000000000000","851060000000000000","808170000000000000","359320000000000000","582420000000000000","834590000000000000","294670000000000000","372150000000000000","341560000000000000","358150000000000000","287480000000000000","363440000000000000","306640000000000000","609130000000000000","485270000000000000","469500000000000000","306290000000000000","279020000000000000","578210000000000000","301070000000000000","389610000000000000","445310000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["30587130739284717","29421406858687704","28218792997301568","26757756051488762","25482601639724058","24219023590943573","23686276018128041","22735493409432391","21583904467124701","21094954706359152","20539868992073439","20059989845154009","19566475694210614","19118165835055686","18545719573373445","18070854457094377","17094583623761045","16468731089198835","15792554483694250","15314444894653156","14863647167380431","13920479746565952","13501614881701089","13041000531925306","12552629996211022"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[68],addressList[67],addressList[67],addressList[67],addressList[67],addressList[67],addressList[65],addressList[24],addressList[69],addressList[65],addressList[70],addressList[65],addressList[70],addressList[71],addressList[72],addressList[73],addressList[43],addressList[70],addressList[24],addressList[74],addressList[75],addressList[76],addressList[77],addressList[24],addressList[78]], ["776960000000000000","681360000000000000","668910000000000000","905410000000000000","851060000000000000","808170000000000000","359320000000000000","582420000000000000","834590000000000000","294670000000000000","372150000000000000","341560000000000000","358150000000000000","287480000000000000","363440000000000000","306640000000000000","609130000000000000","485270000000000000","469500000000000000","306290000000000000","279020000000000000","578210000000000000","301070000000000000","389610000000000000","445310000000000000"], ["30587130739284717","29421406858687704","28218792997301568","26757756051488762","25482601639724058","24219023590943573","23686276018128041","22735493409432391","21583904467124701","21094954706359152","20539868992073439","20059989845154009","19566475694210614","19118165835055686","18545719573373445","18070854457094377","17094583623761045","16468731089198835","15792554483694250","15314444894653156","14863647167380431","13920479746565952","13501614881701089","13041000531925306","12552629996211022"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542575833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[79],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729696", blockHash: "0x6d2a51b0d34357bf8e0191147b7752af84820f7c6417e55f70c8b2d91f1930dd", timeStamp: "1542575878", hash: "0x21de92bdf772e68f43da7596186f993bca11177f3fb22c0daad63565defe3fb6", nonce: "20", transactionIndex: "35", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1740852", gasPrice: "3000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000001900000000000000000000000091b3646948ae6b4ea91cf68a3357e25d66b043c600000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c0000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a14100000000000000000000000094c1fb7795e22930d756ac10e447d17b2b7c15390000000000000000000000006d2a3e19741ecd3001c46a8cde043f8ab675a1410000000000000000000000008c18f331a8f0ee18d204490aa0b8d44b7e3e4a0200000000000000000000000055ea8a1613de642d17329a9c6b2d8afda69e62a1000000000000000000000000888ee3068453a36dbf325a23ebd9690b45545f720000000000000000000000003130259deedb3052e24fad9d5e1f490cb8cccaa0000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b9530000000000000000000000006b42bca7a9608ff5b1bf28533cf59b40ef4475b9000000000000000000000000e8f9b8caa5291240ae66c9718815a9f47aa90ed80000000000000000000000001c2890768064a657ffcaf9c0c92d2b99ed7c18e2000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000009b3319caa84a3dba6be70df1eb7af3ca413f8eb1000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000006eccb16f3361d07655e60be79fb70abef14d5e3c000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000001c2890768064a657ffcaf9c0c92d2b99ed7c18e2000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000009b3319caa84a3dba6be70df1eb7af3ca413f8eb10000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000047348c2ce9280000000000000000000000000000000000000000000000000000ee4bc9e7680600000000000000000000000000000000000000000000000000006e4748b2bb2a0000000000000000000000000000000000000000000000000000482744da7c3600000000000000000000000000000000000000000000000000006130eed08a2e00000000000000000000000000000000000000000000000000003d2e1133ef6a000000000000000000000000000000000000000000000000000055d4d2d4ded600000000000000000000000000000000000000000000000000004c966e99bed80000000000000000000000000000000000000000000000000000491b2091dd9800000000000000000000000000000000000000000000000000002019da6272da000000000000000000000000000000000000000000000000000020743bee05f000000000000000000000000000000000000000000000000000003f643a474ed200000000000000000000000000000000000000000000000000001db3602e52800000000000000000000000000000000000000000000000000000341259a3e46e000000000000000000000000000000000000000000000000000021ccb4893b5c00000000000000000000000000000000000000000000000000001cab9f4b566000000000000000000000000000000000000000000000000000001d4f54cf65a000000000000000000000000000000000000000000000000000001ef63f0f37b0000000000000000000000000000000000000000000000000000029504958ee8c000000000000000000000000000000000000000000000000000033c3e7ff47ca00000000000000000000000000000000000000000000000000001c984ba4a2cc00000000000000000000000000000000000000000000000000002dda2a7ea1e40000000000000000000000000000000000000000000000000000213e073a952e00000000000000000000000000000000000000000000000000001f2df3efb5c400000000000000000000000000000000000000000000000000001a41bbf9cb0a0000000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000002bf806501e434e000000000000000000000000000000000000000000000000002a4b07e90183d80000000000000000000000000000000000000000000000000029bd0c2cbeb87700000000000000000000000000000000000000000000000000284a0ba74e765e00000000000000000000000000000000000000000000000000269d41a9fa06dd000000000000000000000000000000000000000000000000002532446c5ec7be0000000000000000000000000000000000000000000000000023b132590a97550000000000000000000000000000000000000000000000000021fa5285dade07000000000000000000000000000000000000000000000000002054431d48c19a000000000000000000000000000000000000000000000000001fbdd882086b73000000000000000000000000000000000000000000000000001f2d4b4c10bdd6000000000000000000000000000000000000000000000000001dd5c858cee5fb000000000000000000000000000000000000000000000000001d506165800a8b000000000000000000000000000000000000000000000000001c10d69991d157000000000000000000000000000000000000000000000000001b77933a0db770000000000000000000000000000000000000000000000000001af06e0c5e75f0000000000000000000000000000000000000000000000000001a68925dfab38d0000000000000000000000000000000000000000000000000019d50384f7016800000000000000000000000000000000000000000000000000193ff529f5c33000000000000000000000000000000000000000000000000000186a83ea3daed40000000000000000000000000000000000000000000000000017ec647b5bbaea0000000000000000000000000000000000000000000000000017c2ccbd304f9900000000000000000000000000000000000000000000000000172eea318dce670000000000000000000000000000000000000000000000000016a3770f41d92e000000000000000000000000000000000000000000000000001626f51b035bc9", contractAddress: "", cumulativeGasUsed: "3084301", txreceipt_status: "1", gasUsed: "1740852", confirmations: "977682", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[79],addressList[43],addressList[77],addressList[24],addressList[80],addressList[24],addressList[81],addressList[27],addressList[82],addressList[83],addressList[73],addressList[84],addressList[85],addressList[58],addressList[77],addressList[86],addressList[70],addressList[30],addressList[77],addressList[58],addressList[77],addressList[70],addressList[77],addressList[77],addressList[86]]}, {type: "uint256[]", name: "price_", value: ["320680000000000000","1073190000000000000","496650000000000000","324950000000000000","437710000000000000","275530000000000000","386550000000000000","344920000000000000","329240000000000000","144570000000000000","146160000000000000","285490000000000000","133760000000000000","234510000000000000","152220000000000000","129120000000000000","132000000000000000","139440000000000000","186060000000000000","233130000000000000","128780000000000000","206500000000000000","149710000000000000","140420000000000000","118250000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["12376129996211022","11904446367892440","11748334033090679","11340412980459102","10868954465175261","10469843595610046","10046453985220437","9563906571427335","9099846485590426","8934461870205811","8775525699993046","8397830784738811","8251153569548939","7899813233414487","7731298589063024","7582704839063024","7433327245702029","7271085510164840","7107196621275952","6872514244226772","6733840774839018","6688109067521945","6525507852947047","6372181240043822","6235283649682377"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[79],addressList[43],addressList[77],addressList[24],addressList[80],addressList[24],addressList[81],addressList[27],addressList[82],addressList[83],addressList[73],addressList[84],addressList[85],addressList[58],addressList[77],addressList[86],addressList[70],addressList[30],addressList[77],addressList[58],addressList[77],addressList[70],addressList[77],addressList[77],addressList[86]], ["320680000000000000","1073190000000000000","496650000000000000","324950000000000000","437710000000000000","275530000000000000","386550000000000000","344920000000000000","329240000000000000","144570000000000000","146160000000000000","285490000000000000","133760000000000000","234510000000000000","152220000000000000","129120000000000000","132000000000000000","139440000000000000","186060000000000000","233130000000000000","128780000000000000","206500000000000000","149710000000000000","140420000000000000","118250000000000000"], ["12376129996211022","11904446367892440","11748334033090679","11340412980459102","10868954465175261","10469843595610046","10046453985220437","9563906571427335","9099846485590426","8934461870205811","8775525699993046","8397830784738811","8251153569548939","7899813233414487","7731298589063024","7582704839063024","7433327245702029","7271085510164840","7107196621275952","6872514244226772","6733840774839018","6688109067521945","6525507852947047","6372181240043822","6235283649682377"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542575878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[77],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729700", blockHash: "0x1b93e6383a34e1fdfebb1df69c34eccf996845f34605c1cc87c23728c6024368", timeStamp: "1542575986", hash: "0xdf4e41c276a20558d5b3816836a0733f16c6b8ed2ccd08622943dc174e3bdeb5", nonce: "21", transactionIndex: "20", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1740532", gasPrice: "4500000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000019000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000000c6830febf62f153d6f9466f1d9fe2b1d09a475d000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c00000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a500000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a5000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b95300000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a500000000000000000000000005e31fa582856eb330ad65f79ce313c3b58306d2000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b95300000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a500000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a500000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a50000000000000000000000006b42bca7a9608ff5b1bf28533cf59b40ef4475b9000000000000000000000000ef6103de90208f3dface661eadb120cf8075f9d2000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b95300000000000000000000000042bdd4f4e88ac64fcbd6c01aeac676e64db33aa9000000000000000000000000e0eb76c368b483afd6dede2da53224edf700b953000000000000000000000000c24f97bb1d7a75d9f986c99dfcfa2a558058904c0000000000000000000000004b80b7460083ed857445d92eab9972419ce5cb3900000000000000000000000062eb3e90696d302f80c48d859943f0e24482343600000000000000000000000051bd4c735927f958a90db80398826ff47a9832f10000000000000000000000005441bf9aa27e79c7aa4a8d1b340d16973695dee100000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000347541f902fa00000000000000000000000000000000000000000000000000001a3ae9bef51200000000000000000000000000000000000000000000000000001f40248c9b0400000000000000000000000000000000000000000000000000003dabb0ef7eac000000000000000000000000000000000000000000000000000035e07cb604d000000000000000000000000000000000000000000000000000001f5bfefcda0e00000000000000000000000000000000000000000000000000001c7f48cce794000000000000000000000000000000000000000000000000000029c7a85e8f0000000000000000000000000000000000000000000000000000001bba9b2c78d0000000000000000000000000000000000000000000000000000045c9516fe75200000000000000000000000000000000000000000000000000001aaf712c11b4000000000000000000000000000000000000000000000000000024921c70281c00000000000000000000000000000000000000000000000000001f83c9540f8a000000000000000000000000000000000000000000000000000021ce6917f0da00000000000000000000000000000000000000000000000000001e1a4325c332000000000000000000000000000000000000000000000000000024f35036912a00000000000000000000000000000000000000000000000000001cd1238eef3400000000000000000000000000000000000000000000000000001bba9b2c78d00000000000000000000000000000000000000000000000000000249c57c8691000000000000000000000000000000000000000000000000000001d586d1dd84000000000000000000000000000000000000000000000000000001f7075ad5bf60000000000000000000000000000000000000000000000000000405ca225e98400000000000000000000000000000000000000000000000000001753f836c1a400000000000000000000000000000000000000000000000000001b7541d64ecc00000000000000000000000000000000000000000000000000001c2d6e0adff4000000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000158f86cda873c900000000000000000000000000000000000000000000000000151128549899d8000000000000000000000000000000000000000000000000001483dc6d486422000000000000000000000000000000000000000000000000001361dc1f18d6010000000000000000000000000000000000000000000000000012dae9a54331c100000000000000000000000000000000000000000000000000125e86a18cf0d10000000000000000000000000000000000000000000000000011d63c23fbbea90000000000000000000000000000000000000000000000000011395fa631dd3c0000000000000000000000000000000000000000000000000010b2eead77337900000000000000000000000000000000000000000000000000102d02970e4f0f000000000000000000000000000000000000000000000000000fb368af6cd3d5000000000000000000000000000000000000000000000000000f225c363fedc4000000000000000000000000000000000000000000000000000ea2446a4789dd000000000000000000000000000000000000000000000000000e29aa026bfff3000000000000000000000000000000000000000000000000000dabb449c8823a000000000000000000000000000000000000000000000000000d21179488e12c000000000000000000000000000000000000000000000000000c99b1931a19f5000000000000000000000000000000000000000000000000000c17c8b9c4a6d0000000000000000000000000000000000000000000000000000b934e13519fcd000000000000000000000000000000000000000000000000000b13809c0baac0000000000000000000000000000000000000000000000000000a948d550bb16c0000000000000000000000000000000000000000000000000009717c3932fcf80000000000000000000000000000000000000000000000000008ff817e505ee20000000000000000000000000000000000000000000000000008891256923b5e00000000000000000000000000000000000000000000000000080bf980b97f9b", contractAddress: "", cumulativeGasUsed: "2818427", txreceipt_status: "1", gasUsed: "1740532", confirmations: "977678", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[77],addressList[77],addressList[77],addressList[68],addressList[77],addressList[77],addressList[71],addressList[71],addressList[73],addressList[71],addressList[87],addressList[73],addressList[71],addressList[71],addressList[71],addressList[84],addressList[88],addressList[73],addressList[89],addressList[73],addressList[77],addressList[25],addressList[90],addressList[91],addressList[92]]}, {type: "uint256[]", name: "price_", value: ["236250000000000000","118130000000000000","140740000000000000","277740000000000000","242640000000000000","141230000000000000","128340000000000000","188160000000000000","124880000000000000","314290000000000000","120180000000000000","164700000000000000","141930000000000000","152250000000000000","135570000000000000","166410000000000000","129780000000000000","124880000000000000","164880000000000000","132160000000000000","141590000000000000","289860000000000000","105060000000000000","123660000000000000","126900000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["6068783649682377","5929839426574808","5774482283717666","5455622599923201","5307246615671233","5170481909788881","5020628394163881","4848157577043260","4700337809601401","4553088774852367","4419386851775445","4259904093154756","4119064398498269","3986459835760627","3847965517578810","3695559857201452","3546687676750325","3403850598098640","3258188284665805","3117667838569152","2978084505235820","2658053139922168","2532731448745698","2402511668525918","2264966048087963"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[77],addressList[77],addressList[77],addressList[68],addressList[77],addressList[77],addressList[71],addressList[71],addressList[73],addressList[71],addressList[87],addressList[73],addressList[71],addressList[71],addressList[71],addressList[84],addressList[88],addressList[73],addressList[89],addressList[73],addressList[77],addressList[25],addressList[90],addressList[91],addressList[92]], ["236250000000000000","118130000000000000","140740000000000000","277740000000000000","242640000000000000","141230000000000000","128340000000000000","188160000000000000","124880000000000000","314290000000000000","120180000000000000","164700000000000000","141930000000000000","152250000000000000","135570000000000000","166410000000000000","129780000000000000","124880000000000000","164880000000000000","132160000000000000","141590000000000000","289860000000000000","105060000000000000","123660000000000000","126900000000000000"], ["6068783649682377","5929839426574808","5774482283717666","5455622599923201","5307246615671233","5170481909788881","5020628394163881","4848157577043260","4700337809601401","4553088774852367","4419386851775445","4259904093154756","4119064398498269","3986459835760627","3847965517578810","3695559857201452","3546687676750325","3403850598098640","3258188284665805","3117667838569152","2978084505235820","2658053139922168","2532731448745698","2402511668525918","2264966048087963"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542575986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: initGame( addressList[6], [addressList[66],address... )", async function( ) {
		const txOriginal = {blockNumber: "6729705", blockHash: "0xf857217a34b2658a83023febbb52f8bf0885a7050fcd9bbb241f916d3bf88a4d", timeStamp: "1542576022", hash: "0x040d252b19f661afb9ececd7145d32b37d288b4ba0d035f235656496331c5411", nonce: "22", transactionIndex: "27", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1229316", gasPrice: "4000000000", input: "0x14ae1ad000000000000000000000000027d3eb139dd95fe4e0d657ba31f8e9c6eca56b06000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000054000000000000000000000000000000000000000000000000000000000000000120000000000000000000000002e6d72f09cb04425a29d420b5869b06d95352908000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b53000000000000000000000000c4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef000000000000000000000000e291cd23875d3cf4c8ceb4e04d7f0a6fd2511b53000000000000000000000000233a5180a19717d047999508a34c2dfbfdb25e780000000000000000000000005029f7897183d6ba6af44d4bee34421181e154550000000000000000000000006556d0efc03602f88e6cbba508ba340f106220bc000000000000000000000000c4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef000000000000000000000000233a5180a19717d047999508a34c2dfbfdb25e78000000000000000000000000c4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef000000000000000000000000ec18c3b8a4caac7dfce048bc9ab8225a554dacfc000000000000000000000000297683b64a416f2b105e776b88e8dc31e1114fa6000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000d8f2ce72f19834f5e0072ea870a18ef6f57f8ccd000000000000000000000000d8f2ce72f19834f5e0072ea870a18ef6f57f8ccd00000000000000000000000093989ab2eb319694915c77cf248f8155366dc8a3000000000000000000000000d74293d7ad3371ec42d6bc49ed43f4270360a771000000000000000000000000d74293d7ad3371ec42d6bc49ed43f4270360a771000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000002e715e96d38800000000000000000000000000000000000000000000000000001d3d24328060000000000000000000000000000000000000000000000000000021d263ba4300000000000000000000000000000000000000000000000000000020f0b89fc6de000000000000000000000000000000000000000000000000000017c9a2adac9a000000000000000000000000000000000000000000000000000025bc89fe393e000000000000000000000000000000000000000000000000000021709e6ef2c80000000000000000000000000000000000000000000000000000201afd6c412e00000000000000000000000000000000000000000000000000001dd3c6c5cada000000000000000000000000000000000000000000000000000021a57bb6ed0a00000000000000000000000000000000000000000000000000003f113c7b78de000000000000000000000000000000000000000000000000000040b7953663c400000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000023bcf2c1899600000000000000000000000000000000000000000000000000000e0b58a360b200000000000000000000000000000000000000000000000000000da7dec95afc00000000000000000000000000000000000000000000000000002ae8fd9e2d820000000000000000000000000000000000000000000000000000058d15e17628000000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000078a1fa3082a850000000000000000000000000000000000000000000000000007102849cdf6c90000000000000000000000000000000000000000000000000006934e9bd97043000000000000000000000000000000000000000000000000000619d9aae8d45a0000000000000000000000000000000000000000000000000005a9437cb497b6000000000000000000000000000000000000000000000000000529bb39d424250000000000000000000000000000000000000000000000000004a9ecb86cad49000000000000000000000000000000000000000000000000000437a2151469cd0000000000000000000000000000000000000000000000000003b34e7530cb1b00000000000000000000000000000000000000000000000000033d7f19dff5ba00000000000000000000000000000000000000000000000000020ff863e13e920000000000000000000000000000000000000000000000000000fa910234289e0000000000000000000000000000000000000000000000000000d6ea5f33837d000000000000000000000000000000000000000000000000000069d8e270e8bd00000000000000000000000000000000000000000000000000004671686d9c73000000000000000000000000000000000000000000000000000023292f4703a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3022609", txreceipt_status: "1", gasUsed: "1229316", confirmations: "977673", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "badgesFactoryAddress_", value: addressList[6]}, {type: "address[]", name: "owner_", value: [addressList[66],addressList[65],addressList[93],addressList[65],addressList[94],addressList[95],addressList[96],addressList[93],addressList[94],addressList[93],addressList[97],addressList[98],addressList[70],addressList[99],addressList[99],addressList[100],addressList[101],addressList[101]]}, {type: "uint256[]", name: "price_", value: ["209160000000000000","131680000000000000","152320000000000000","148350000000000000","107130000000000000","169950000000000000","150600000000000000","144590000000000000","134330000000000000","151530000000000000","284030000000000000","291460000000000000","62500000000000000","160950000000000000","63250000000000000","61500000000000000","193250000000000000","25000000000000000"]}, {type: "uint256[]", name: "totalDivis_", value: ["2122193320815237","1988090059945673","1850815691714627","1717272526247002","1593482203666358","1453258989380645","1312734078348617","1187069184731597","1041574485084955","912041034380730","580509455433362","275500714174622","236302107902845","116380232902845","77452897262707","38659793814432","0","0"]}], name: "initGame", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initGame(address,address[],uint256[],uint256[])" ]( addressList[6], [addressList[66],addressList[65],addressList[93],addressList[65],addressList[94],addressList[95],addressList[96],addressList[93],addressList[94],addressList[93],addressList[97],addressList[98],addressList[70],addressList[99],addressList[99],addressList[100],addressList[101],addressList[101]], ["209160000000000000","131680000000000000","152320000000000000","148350000000000000","107130000000000000","169950000000000000","150600000000000000","144590000000000000","134330000000000000","151530000000000000","284030000000000000","291460000000000000","62500000000000000","160950000000000000","63250000000000000","61500000000000000","193250000000000000","25000000000000000"], ["2122193320815237","1988090059945673","1850815691714627","1717272526247002","1593482203666358","1453258989380645","1312734078348617","1187069184731597","1041574485084955","912041034380730","580509455433362","275500714174622","236302107902845","116380232902845","77452897262707","38659793814432","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542576022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: initReferrals( [addressList[102],addressList[103],addre... )", async function( ) {
		const txOriginal = {blockNumber: "6729708", blockHash: "0xe9d4ffeb4614362adba7ff1fbe3478fd34b4dcd6672ad7011d89741455b73dcb", timeStamp: "1542576092", hash: "0x5785aa841b7fcbe0d70a8cff70878e3f10165bebd5949037d239b977f9b8b10a", nonce: "23", transactionIndex: "88", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "1211777", gasPrice: "3300000000", input: "0x131762c20000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000005c00000000000000000000000041a21b264f9ebf6cf571d4543a5b3ab1c6bed98c0000000000000000000000008e2e5ece3b1f6f33851d62130ea90cf5bf523c21000000000000000000000000b5a28b0752ce06c41d8965cf431c759d888a162a0000000000000000000000008e2e5ece3b1f6f33851d62130ea90cf5bf523c2100000000000000000000000052f2cc12b89a3fb4d4f2230487297fd402e6a7110000000000000000000000008e2e5ece3b1f6f33851d62130ea90cf5bf523c210000000000000000000000000d84597a0cf27e73e52bc6cccfa3a5e3cccae3da0000000000000000000000005632ca98e5788eddb2397757aa82d1ed6171e5ad000000000000000000000000b04b473418b6f09e5a1f809ae2d01f14211e03ff0000000000000000000000005409e9e2f6cc8340d307fa15e0728adad54d6e8c000000000000000000000000360bbad1120b0abf63573e2e21b6727e07d1bf18000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732000000000000000000000000ad565956ae5bd43117f6b0a650ec18c621ff8e0d0000000000000000000000003130259deedb3052e24fad9d5e1f490cb8cccaa00000000000000000000000007aab41a2b1e8d9195b50143e32bef20b5eacfd91000000000000000000000000b04b473418b6f09e5a1f809ae2d01f14211e03ff00000000000000000000000055c073036c755b6898134d62001ba2b00f60f96f000000000000000000000000fb45597d51280e094c1d3520f1c22e2652aa72e400000000000000000000000043501e11acf3dfdae4bd2ca40c5ea1303fc51941000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000009a0cf297c8143d8e08296f5257ba81081b1a2e5b000000000000000000000000f546160c85c90b97aa125de9c14d6c2cc10ad5880000000000000000000000009969c05a2204177841e47454c2a289aa4442cb99000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000de67adf51408acca6bee2abe20dbfff2dddfed33000000000000000000000000c69325fe2449fbdc064018b0c0ca246e7067db54000000000000000000000000b3f98326ea56088f3e01995f2aac89355fa5af15000000000000000000000000c69325fe2449fbdc064018b0c0ca246e7067db5400000000000000000000000033497f64e2997669057710ccadd583d70798954a000000000000000000000000c69325fe2449fbdc064018b0c0ca246e7067db54000000000000000000000000c97b6f9da34bca5d3c7d505e475bd25b73eaad6e0000000000000000000000004fc5831b399369119eed6c81fd4bc67016f23d71000000000000000000000000f2b31e5768871b3ad8435edb2c54b8683a3d1a5e000000000000000000000000a7cf0d8511d269da2e06a5665f0d8a67f4fe7f2e00000000000000000000000052af787439a82f36d6ef6b0da0f0e5ecce29ff9000000000000000000000000004a1dd3a7d57c1944a503a03e43e92a4b092c018000000000000000000000000694ccab8fbe06350147fcd3f12d885e34f79ea85000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000ab72a297d971f5d035738f39ddbe81f658d8796e0000000000000000000000004fc5831b399369119eed6c81fd4bc67016f23d7100000000000000000000000032ff0b2ac0c39ddc90b49e4cb00b568267d45610000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000003f67dfeee1d3326d6f8bc086dade8915ecf4c92c000000000000000000000000d881ab474d10b9036ff7f697b18dec7b701140e3000000000000000000000000a24e91f2684a69ffe0a10a5cc384f9e0b163dd8b00000000000000000000000083c90ba85dc313a23020ab37d223653c389a91f00000000000000000000000002845a83d2a6cb264a5e35103ef10472746f43c4d000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e06000000000000000000000000ef6103de90208f3dface661eadb120cf8075f9d2000000000000000000000000c69325fe2449fbdc064018b0c0ca246e7067db5400000000000000000000000058f267627207bded598f495fcd10d82bb2aa7141000000000000000000000000c69325fe2449fbdc064018b0c0ca246e7067db540000000000000000000000003c39b94c292d47f269c7ab016985cbb3b5fe4b2100000000000000000000000032ff0b2ac0c39ddc90b49e4cb00b568267d456100000000000000000000000008ae87ceb42f78d7c5659084753016d781fbcce6c00000000000000000000000032ff0b2ac0c39ddc90b49e4cb00b568267d4561000000000000000000000000085ea854451b301d1b04d039f17fc3a11e7f32acd000000000000000000000000376d0974edcb2f732cf0796fd9639c791e8387be000000000000000000000000087b961c29efd8dc93abe9c8fa392739a3ad8cf6000000000000000000000000cb0c3b15505f8048849c1d4f32835bb98807a055000000000000000000000000c1b442f93ea518b0939ee4fa25b3ea321a07e17a000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732000000000000000000000000fbf13497056f33300ad82511c6a1349dd3d2ae26000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000007be01bec1ababc771290c8fca44d9789af8ae0f3000000000000000000000000cb0c3b15505f8048849c1d4f32835bb98807a055000000000000000000000000a48c69294518a2e8abadae36af12e9ef7820ca5d0000000000000000000000006b144673640835e1ebd476a6f5c19e2e30452c2d00000000000000000000000006c71dc79d7e7c47792dad78c525d9b270520b29000000000000000000000000e25b8fa6e21f67f8dcccf1222d23faf6f2e84a2f00000000000000000000000012cff2a28d4fe53fcf46ad642668cf6651fa8cf7000000000000000000000000d0205b4f442a2a4c4fb01cc94f8b5bf1dfd2945800000000000000000000000057fcc23ad10fa6196559aea71d580a89740c9133000000000000000000000000d881ab474d10b9036ff7f697b18dec7b701140e30000000000000000000000007dbbc284f202b06b8386ff8af96a07a7f30f387f000000000000000000000000d05468778c4bbfd26fb6966d755ed1ce4932bee900000000000000000000000096759150bec4f31c440928ea7437566988f82a3400000000000000000000000034c9b3d0c89232bf257ef4d211dd202947b677c00000000000000000000000007c0d2f1eb3dc2cc21d6118789d26f2db09311b1d000000000000000000000000778f7434956b899303708fa3c5fad85bf9d93e060000000000000000000000005a5ffa288320072d7398c6d54a875313b4f60a6400000000000000000000000036f84534671906bbc4a0bed28cf84fa66dc5230300000000000000000000000014eefe5199839480d6fd58c2d720acdff959bcb0000000000000000000000000f9cf9329ff00e14f441e411aa946ef2b7e102ec100000000000000000000000078bf7a9b7c7a769c1c4325eec472704f214877a5000000000000000000000000a48c69294518a2e8abadae36af12e9ef7820ca5d000000000000000000000000c4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef000000000000000000000000233a5180a19717d047999508a34c2dfbfdb25e78000000000000000000000000233a5180a19717d047999508a34c2dfbfdb25e78000000000000000000000000c4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef0000000000000000000000005de90f22dec06afed2d1848636878d08fad012bc000000000000000000000000af87a86920b508a532223c516e9a33471356e245", contractAddress: "", cumulativeGasUsed: "5846871", txreceipt_status: "1", gasUsed: "1211777", confirmations: "977670", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "refArray_", value: [addressList[102],addressList[103],addressList[104],addressList[103],addressList[105],addressList[103],addressList[106],addressList[107],addressList[108],addressList[109],addressList[9],addressList[110],addressList[111],addressList[83],addressList[112],addressList[108],addressList[113],addressList[64],addressList[114],addressList[70],addressList[16],addressList[115],addressList[116],addressList[70],addressList[117],addressList[118],addressList[119],addressList[118],addressList[72],addressList[118],addressList[120],addressList[12],addressList[121],addressList[28],addressList[29],addressList[122],addressList[123],addressList[70],addressList[37],addressList[12],addressList[124],addressList[70],addressList[15],addressList[125],addressList[35],addressList[126],addressList[52],addressList[70],addressList[88],addressList[118],addressList[127],addressList[118],addressList[32],addressList[124],addressList[128],addressList[124],addressList[129],addressList[130],addressList[17],addressList[20],addressList[131],addressList[110],addressList[132],addressList[70],addressList[46],addressList[20],addressList[55],addressList[133],addressList[134],addressList[135],addressList[14],addressList[13],addressList[8],addressList[125],addressList[18],addressList[136],addressList[39],addressList[43],addressList[137],addressList[70],addressList[41],addressList[67],addressList[21],addressList[138],addressList[71],addressList[55],addressList[93],addressList[94],addressList[94],addressList[93],addressList[76],addressList[36]]}], name: "initReferrals", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initReferrals(address[])" ]( [addressList[102],addressList[103],addressList[104],addressList[103],addressList[105],addressList[103],addressList[106],addressList[107],addressList[108],addressList[109],addressList[9],addressList[110],addressList[111],addressList[83],addressList[112],addressList[108],addressList[113],addressList[64],addressList[114],addressList[70],addressList[16],addressList[115],addressList[116],addressList[70],addressList[117],addressList[118],addressList[119],addressList[118],addressList[72],addressList[118],addressList[120],addressList[12],addressList[121],addressList[28],addressList[29],addressList[122],addressList[123],addressList[70],addressList[37],addressList[12],addressList[124],addressList[70],addressList[15],addressList[125],addressList[35],addressList[126],addressList[52],addressList[70],addressList[88],addressList[118],addressList[127],addressList[118],addressList[32],addressList[124],addressList[128],addressList[124],addressList[129],addressList[130],addressList[17],addressList[20],addressList[131],addressList[110],addressList[132],addressList[70],addressList[46],addressList[20],addressList[55],addressList[133],addressList[134],addressList[135],addressList[14],addressList[13],addressList[8],addressList[125],addressList[18],addressList[136],addressList[39],addressList[43],addressList[137],addressList[70],addressList[41],addressList[67],addressList[21],addressList[138],addressList[71],addressList[55],addressList[93],addressList[94],addressList[94],addressList[93],addressList[76],addressList[36]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542576092 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user_", type: "address"}, {indexed: true, name: "referer_", type: "address"}], name: "onRefererSet", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c"}, {name: "referer_", type: "address", value: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xb5a28b0752ce06c41d8965cf431c759d888a162a"}, {name: "referer_", type: "address", value: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x52f2cc12b89a3fb4d4f2230487297fd402e6a711"}, {name: "referer_", type: "address", value: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x0d84597a0cf27e73e52bc6cccfa3a5e3cccae3da"}, {name: "referer_", type: "address", value: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xb04b473418b6f09e5a1f809ae2d01f14211e03ff"}, {name: "referer_", type: "address", value: "0x5409e9e2f6cc8340d307fa15e0728adad54d6e8c"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xad565956ae5bd43117f6b0a650ec18c621ff8e0d"}, {name: "referer_", type: "address", value: "0x3130259deedb3052e24fad9d5e1f490cb8cccaa0"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x7aab41a2b1e8d9195b50143e32bef20b5eacfd91"}, {name: "referer_", type: "address", value: "0xb04b473418b6f09e5a1f809ae2d01f14211e03ff"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x55c073036c755b6898134d62001ba2b00f60f96f"}, {name: "referer_", type: "address", value: "0xfb45597d51280e094c1d3520f1c22e2652aa72e4"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x43501e11acf3dfdae4bd2ca40c5ea1303fc51941"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0xf546160c85c90b97aa125de9c14d6c2cc10ad588"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x9969c05a2204177841e47454c2a289aa4442cb99"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xde67adf51408acca6bee2abe20dbfff2dddfed33"}, {name: "referer_", type: "address", value: "0xc69325fe2449fbdc064018b0c0ca246e7067db54"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xb3f98326ea56088f3e01995f2aac89355fa5af15"}, {name: "referer_", type: "address", value: "0xc69325fe2449fbdc064018b0c0ca246e7067db54"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x33497f64e2997669057710ccadd583d70798954a"}, {name: "referer_", type: "address", value: "0xc69325fe2449fbdc064018b0c0ca246e7067db54"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xc97b6f9da34bca5d3c7d505e475bd25b73eaad6e"}, {name: "referer_", type: "address", value: "0x4fc5831b399369119eed6c81fd4bc67016f23d71"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xf2b31e5768871b3ad8435edb2c54b8683a3d1a5e"}, {name: "referer_", type: "address", value: "0xa7cf0d8511d269da2e06a5665f0d8a67f4fe7f2e"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x52af787439a82f36d6ef6b0da0f0e5ecce29ff90"}, {name: "referer_", type: "address", value: "0x04a1dd3a7d57c1944a503a03e43e92a4b092c018"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x694ccab8fbe06350147fcd3f12d885e34f79ea85"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xab72a297d971f5d035738f39ddbe81f658d8796e"}, {name: "referer_", type: "address", value: "0x4fc5831b399369119eed6c81fd4bc67016f23d71"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x32ff0b2ac0c39ddc90b49e4cb00b568267d45610"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x3f67dfeee1d3326d6f8bc086dade8915ecf4c92c"}, {name: "referer_", type: "address", value: "0xd881ab474d10b9036ff7f697b18dec7b701140e3"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xa24e91f2684a69ffe0a10a5cc384f9e0b163dd8b"}, {name: "referer_", type: "address", value: "0x83c90ba85dc313a23020ab37d223653c389a91f0"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x2845a83d2a6cb264a5e35103ef10472746f43c4d"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xef6103de90208f3dface661eadb120cf8075f9d2"}, {name: "referer_", type: "address", value: "0xc69325fe2449fbdc064018b0c0ca246e7067db54"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x58f267627207bded598f495fcd10d82bb2aa7141"}, {name: "referer_", type: "address", value: "0xc69325fe2449fbdc064018b0c0ca246e7067db54"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x3c39b94c292d47f269c7ab016985cbb3b5fe4b21"}, {name: "referer_", type: "address", value: "0x32ff0b2ac0c39ddc90b49e4cb00b568267d45610"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x8ae87ceb42f78d7c5659084753016d781fbcce6c"}, {name: "referer_", type: "address", value: "0x32ff0b2ac0c39ddc90b49e4cb00b568267d45610"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x85ea854451b301d1b04d039f17fc3a11e7f32acd"}, {name: "referer_", type: "address", value: "0x376d0974edcb2f732cf0796fd9639c791e8387be"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x087b961c29efd8dc93abe9c8fa392739a3ad8cf6"}, {name: "referer_", type: "address", value: "0xcb0c3b15505f8048849c1d4f32835bb98807a055"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xc1b442f93ea518b0939ee4fa25b3ea321a07e17a"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xfbf13497056f33300ad82511c6a1349dd3d2ae26"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x7be01bec1ababc771290c8fca44d9789af8ae0f3"}, {name: "referer_", type: "address", value: "0xcb0c3b15505f8048849c1d4f32835bb98807a055"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xa48c69294518a2e8abadae36af12e9ef7820ca5d"}, {name: "referer_", type: "address", value: "0x6b144673640835e1ebd476a6f5c19e2e30452c2d"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x06c71dc79d7e7c47792dad78c525d9b270520b29"}, {name: "referer_", type: "address", value: "0xe25b8fa6e21f67f8dcccf1222d23faf6f2e84a2f"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x12cff2a28d4fe53fcf46ad642668cf6651fa8cf7"}, {name: "referer_", type: "address", value: "0xd0205b4f442a2a4c4fb01cc94f8b5bf1dfd29458"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x57fcc23ad10fa6196559aea71d580a89740c9133"}, {name: "referer_", type: "address", value: "0xd881ab474d10b9036ff7f697b18dec7b701140e3"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x7dbbc284f202b06b8386ff8af96a07a7f30f387f"}, {name: "referer_", type: "address", value: "0xd05468778c4bbfd26fb6966d755ed1ce4932bee9"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x96759150bec4f31c440928ea7437566988f82a34"}, {name: "referer_", type: "address", value: "0x34c9b3d0c89232bf257ef4d211dd202947b677c0"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x7c0d2f1eb3dc2cc21d6118789d26f2db09311b1d"}, {name: "referer_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x5a5ffa288320072d7398c6d54a875313b4f60a64"}, {name: "referer_", type: "address", value: "0x36f84534671906bbc4a0bed28cf84fa66dc52303"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x14eefe5199839480d6fd58c2d720acdff959bcb0"}, {name: "referer_", type: "address", value: "0xf9cf9329ff00e14f441e411aa946ef2b7e102ec1"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x78bf7a9b7c7a769c1c4325eec472704f214877a5"}, {name: "referer_", type: "address", value: "0xa48c69294518a2e8abadae36af12e9ef7820ca5d"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0xc4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef"}, {name: "referer_", type: "address", value: "0x233a5180a19717d047999508a34c2dfbfdb25e78"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x233a5180a19717d047999508a34c2dfbfdb25e78"}, {name: "referer_", type: "address", value: "0xc4d31b4dc713dc4ac3d3f7be63447ef1d2abe2ef"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}, {name: "onRefererSet", events: [{name: "user_", type: "address", value: "0x5de90f22dec06afed2d1848636878d08fad012bc"}, {name: "referer_", type: "address", value: "0xaf87a86920b508a532223c516e9a33471356e245"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: _startContract( \"163740\" )", async function( ) {
		const txOriginal = {blockNumber: "6729753", blockHash: "0x6f53a7bd109c01d4ded0e1e9f476fa5cac420246cbb8e6002f98e294ff14c80b", timeStamp: "1542576664", hash: "0x341bd4305c484865647b541e1f55a4ba6c6e3597d78b7128704278d8f6d2a5d9", nonce: "24", transactionIndex: "98", from: "0x461eefeb4f384b5c7177732e0068f0caa43d3152", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "43912", gasPrice: "5000000000", input: "0xf08ea4cc0000000000000000000000000000000000000000000000000000000000027f9c", contractAddress: "", cumulativeGasUsed: "5677442", txreceipt_status: "1", gasUsed: "43912", confirmations: "977625", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "delay_", value: "163740"}], name: "_startContract", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "_startContract(uint256)" ]( "163740", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542576664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "startTime_", type: "uint256"}], name: "onContractStart", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onContractStart", events: [{name: "startTime_", type: "uint256", value: "1542740404"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "74240075800000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"249\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741141", blockHash: "0x4eb6444236dbd4b312f5eecced31b0ab5adcba0ac4327bff9a37377a3ddd2cd0", timeStamp: "1542740582", hash: "0x3dcc7b8182ea1263b8cbf8aad7e2b16a4f2f2f9550017e3d67fdc383ae6ddde6", nonce: "2052", transactionIndex: "67", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "118250000000000000", gas: "430360", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000f90000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "5704091", txreceipt_status: "1", gasUsed: "286907", confirmations: "966237", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "118250000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "249"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "249", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542740582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "249"}, {name: "previousOwner_", type: "address", value: "0x9b3319caa84a3dba6be70df1eb7af3ca413f8eb1"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "118250000000000000"}, {name: "newPrice_", type: "uint256", value: "300360000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"248\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741141", blockHash: "0x4eb6444236dbd4b312f5eecced31b0ab5adcba0ac4327bff9a37377a3ddd2cd0", timeStamp: "1542740582", hash: "0x5d96e8c5a42d2924798c6748deb3febfb7498d7e240502c533a80055f76a6027", nonce: "2053", transactionIndex: "68", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "140420000000000000", gas: "430360", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000f80000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "5945998", txreceipt_status: "1", gasUsed: "241907", confirmations: "966237", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "140420000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "248"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "248", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542740582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "248"}, {name: "previousOwner_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "140420000000000000"}, {name: "newPrice_", type: "uint256", value: "334200000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"290\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741141", blockHash: "0x4eb6444236dbd4b312f5eecced31b0ab5adcba0ac4327bff9a37377a3ddd2cd0", timeStamp: "1542740582", hash: "0x4dde0645a6a8c7db74a0ed1349c460fec2c142c09453bcc8db47b9e2332d1323", nonce: "306", transactionIndex: "78", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "61500000000000000", gas: "382861", gasPrice: "3300000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001220000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6861039", txreceipt_status: "1", gasUsed: "255287", confirmations: "966237", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "61500000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "290"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "290", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542740582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "290"}, {name: "previousOwner_", type: "address", value: "0x93989ab2eb319694915c77cf248f8155366dc8a3"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "61500000000000000"}, {name: "newPrice_", type: "uint256", value: "282290000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"247\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741143", blockHash: "0x49e30eeb75f7818eeb9fbd3fd1a59e9f7aed542bbc2f6bb1dcd276aa8714827d", timeStamp: "1542740668", hash: "0x8743dd4a80d3c0cd7d60ef238f9eb75361a1ebc120193a05e7c47436a6e098f3", nonce: "2054", transactionIndex: "135", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "149710000000000000", gas: "430371", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000f70000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "7061828", txreceipt_status: "1", gasUsed: "196907", confirmations: "966235", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "149710000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "247"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "247", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542740668 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "247"}, {name: "previousOwner_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "149710000000000000"}, {name: "newPrice_", type: "uint256", value: "371290000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"289\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741144", blockHash: "0x2f5779548583dcb3876d08be45e98b4316ff9ee7fc9d76e393cbceb885ff5bd8", timeStamp: "1542740670", hash: "0x857141e68c046b6dccc4a82682e46273770fcc84835ad53687be84a076bbf9de", nonce: "307", transactionIndex: "27", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "63250000000000000", gas: "427861", gasPrice: "3300000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001210000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5048805", txreceipt_status: "1", gasUsed: "225241", confirmations: "966234", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "63250000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "289"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "289", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542740670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "289"}, {name: "previousOwner_", type: "address", value: "0xd8f2ce72f19834f5e0072ea870a18ef6f57f8ccd"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "63250000000000000"}, {name: "newPrice_", type: "uint256", value: "126500000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"287\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741144", blockHash: "0x2f5779548583dcb3876d08be45e98b4316ff9ee7fc9d76e393cbceb885ff5bd8", timeStamp: "1542740670", hash: "0x9b26023aacacc91e264923e04272547dd4d65f3b93dfe70f8da4a19680d67fd5", nonce: "308", transactionIndex: "28", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "62500000000000000", gas: "405361", gasPrice: "3400000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000011f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5259046", txreceipt_status: "1", gasUsed: "210241", confirmations: "966234", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "62500000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "287"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "287", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542740670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "287"}, {name: "previousOwner_", type: "address", value: "0x778f7434956b899303708fa3c5fad85bf9d93e06"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "62500000000000000"}, {name: "newPrice_", type: "uint256", value: "135630000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"240\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741145", blockHash: "0x087513ceb1c46335e4878da0f010707e82667c80b86fe45f6248521516aa3802", timeStamp: "1542740674", hash: "0x6fb0ebc056da11f000d6d6408b25128971eb261ded87403a076816f25361057c", nonce: "2055", transactionIndex: "26", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "129120000000000000", gas: "430360", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000f00000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "6388667", txreceipt_status: "1", gasUsed: "166907", confirmations: "966233", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "129120000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "240"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "240", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542740674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "240"}, {name: "previousOwner_", type: "address", value: "0x9b3319caa84a3dba6be70df1eb7af3ca413f8eb1"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "129120000000000000"}, {name: "newPrice_", type: "uint256", value: "282780000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"292\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741146", blockHash: "0xee4003dd05853efb3906c21081e05d2995e42f800b02937d23351367655adb5a", timeStamp: "1542740692", hash: "0xdebcc0497a620cc8c98d1de43ccc3b0d3761b54c589ad7fa41313f920747bfe4", nonce: "309", transactionIndex: "45", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "391426", gasPrice: "8000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001240000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2278557", txreceipt_status: "1", gasUsed: "305951", confirmations: "966232", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "292"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "292", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542740692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "292"}, {name: "previousOwner_", type: "address", value: "0xd74293d7ad3371ec42d6bc49ed43f4270360a771"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "60250000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"242\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741150", blockHash: "0x575b68b7c89af813d12e0e32a49f05dd89007012e8cf60551433b6565570084e", timeStamp: "1542740767", hash: "0x95efd746f078a1f1e2a96e666363c143002a677c7f2e34a32a8ee964548591eb", nonce: "2056", transactionIndex: "60", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "139440000000000000", gas: "385360", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000f20000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "5735061", txreceipt_status: "1", gasUsed: "226907", confirmations: "966228", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "139440000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "242"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "242", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542740767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "242"}, {name: "previousOwner_", type: "address", value: "0x6eccb16f3361d07655e60be79fb70abef14d5e3c"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "139440000000000000"}, {name: "newPrice_", type: "uint256", value: "336060000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"234\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741150", blockHash: "0x575b68b7c89af813d12e0e32a49f05dd89007012e8cf60551433b6565570084e", timeStamp: "1542740767", hash: "0x99d6a77aa897eea362f3e7d3f5617bda60e6b847e15ba6d2d300d8d6ae6fc731", nonce: "2057", transactionIndex: "61", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "144570000000000000", gas: "430360", gasPrice: "5000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000ea0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "5946968", txreceipt_status: "1", gasUsed: "211907", confirmations: "966228", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "144570000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "234"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "234", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542740767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "234"}, {name: "previousOwner_", type: "address", value: "0x3130259deedb3052e24fad9d5e1f490cb8cccaa0"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "144570000000000000"}, {name: "newPrice_", type: "uint256", value: "361430000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"293\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741150", blockHash: "0x575b68b7c89af813d12e0e32a49f05dd89007012e8cf60551433b6565570084e", timeStamp: "1542740767", hash: "0x225ebeae213fe8c9e46de3e9f76cac44a5cf96ba28f8dd27b9278f10f6f10f69", nonce: "421", transactionIndex: "85", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "313528", gasPrice: "3720000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001250000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7244640", txreceipt_status: "1", gasUsed: "276320", confirmations: "966228", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "293"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "293", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542740767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "293"}, {name: "previousOwner_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "buyer_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "103750000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"293\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741151", blockHash: "0x1bf9b47ae8db6b90d0cd1f822151eff244324f3ac90b56f0e25d69c3ca0cd87c", timeStamp: "1542740791", hash: "0x8a84bc14860d9e56450d1a0ae32b060442bc033dede06a27481aab002e06c83a", nonce: "2385", transactionIndex: "100", from: "0x51bd4c735927f958a90db80398826ff47a9832f1", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "391911", gasPrice: "3000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001250000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6776747", txreceipt_status: "0", gasUsed: "25523", confirmations: "966227", isError: "1"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[91], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "293"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "293", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542740791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[91], balance: "13028641612856614" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[91], balance: ( await web3.eth.getBalance( addressList[91], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"235\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741152", blockHash: "0x6696fe6d4db08cd391a56f1cac45c021484d38b5c9bd1342255c3e3125ee125f", timeStamp: "1542740798", hash: "0xf0e58904e8a1dc9b8194bee189eb546809a2e34950f6829ea279f67c8488eb78", nonce: "2058", transactionIndex: "39", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "146160000000000000", gas: "430360", gasPrice: "5000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000eb0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "3404209", txreceipt_status: "1", gasUsed: "196907", confirmations: "966226", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "146160000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "235"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "235", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542740798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "235"}, {name: "previousOwner_", type: "address", value: "0xe0eb76c368b483afd6dede2da53224edf700b953"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "146160000000000000"}, {name: "newPrice_", type: "uint256", value: "361020000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"292\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741152", blockHash: "0x6696fe6d4db08cd391a56f1cac45c021484d38b5c9bd1342255c3e3125ee125f", timeStamp: "1542740798", hash: "0xabe2677f738b4abbf397f3c70b0a34e552f543e1c12c64c1343c193f9f8a01d3", nonce: "422", transactionIndex: "46", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "60250000000000000", gas: "252676", gasPrice: "3720000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001240000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6403011", txreceipt_status: "1", gasUsed: "165564", confirmations: "966226", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "60250000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "292"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "292", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542740798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "292"}, {name: "previousOwner_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "buyer_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "60250000000000000"}, {name: "newPrice_", type: "uint256", value: "140990000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"237\", addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6741154", blockHash: "0xfc145684e4e2f929a1d59f5e8ad440b7f52681454d3e543fb466a87eeaecd8e5", timeStamp: "1542740833", hash: "0x45670706ecfa68a56b342bb0cf40c03b8ba5dd93c7cb7077d51028a9f38d0a9a", nonce: "2059", transactionIndex: "28", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "133760000000000000", gas: "430360", gasPrice: "5000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000000ed0000000000000000000000005ba3e11abf8c93186637847ec590fcd3aa588bd2", contractAddress: "", cumulativeGasUsed: "3629332", txreceipt_status: "1", gasUsed: "196907", confirmations: "966224", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "133760000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "237"}, {type: "address", name: "newReferer_", value: addressList[26]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "237", addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542740833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "237"}, {name: "previousOwner_", type: "address", value: "0xe8f9b8caa5291240ae66c9718815a9f47aa90ed8"}, {name: "buyer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "referer_", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "price_", type: "uint256", value: "133760000000000000"}, {name: "newPrice_", type: "uint256", value: "345110000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50568708822660810" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"289\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741155", blockHash: "0x322716c9c74f9cf474151117f6b1d32f3cd516adbfb4bc1043137b6866c483a4", timeStamp: "1542740844", hash: "0x87c5de8c94a4e744fc7d5c414b756d0861f18231a410a361e9aff33dfd9aaadb", nonce: "423", transactionIndex: "67", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "126500000000000000", gas: "252676", gasPrice: "3720000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001210000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3210758", txreceipt_status: "1", gasUsed: "195564", confirmations: "966223", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "126500000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "289"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "289", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542740844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "289"}, {name: "previousOwner_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "buyer_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "126500000000000000"}, {name: "newPrice_", type: "uint256", value: "261860000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"294\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741158", blockHash: "0x1a7a14ad52a5e337b13caedeea567aaa1fbc13ec4828c132deea65f962337ad1", timeStamp: "1542740901", hash: "0xef1dabb4d2d488aa676fa04a504372a749a92041bb23e9fa34977dd0db343035", nonce: "1453", transactionIndex: "50", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "415846", gasPrice: "4000000000", input: "0x7deb60250000000000000000000000000000000000000000000000000000000000000126000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "3763312", txreceipt_status: "1", gasUsed: "262231", confirmations: "966220", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "294"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "294", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542740901 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "294"}, {name: "previousOwner_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "buyer_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "60250000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"294\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741158", blockHash: "0x1a7a14ad52a5e337b13caedeea567aaa1fbc13ec4828c132deea65f962337ad1", timeStamp: "1542740901", hash: "0x8bbbd47e5eb24c809ba0ca202a922940acd354e3ab0d0b865b0da9a6fc755f9f", nonce: "311", transactionIndex: "58", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "414168", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001260000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4108110", txreceipt_status: "0", gasUsed: "25411", confirmations: "966220", isError: "1"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "294"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "294", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542740901 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"295\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741161", blockHash: "0xc514923a8a5fcf593aaf4bf9c8f3abd9edab8888864d9dbbe72d5caa856bcaf6", timeStamp: "1542740967", hash: "0x46dce9eb8b3959231f9c08f0e9dd5fac7efe94849537a1200e415c32f7a140f8", nonce: "2387", transactionIndex: "34", from: "0x51bd4c735927f958a90db80398826ff47a9832f1", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "436980", gasPrice: "5000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001270000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2469807", txreceipt_status: "1", gasUsed: "261274", confirmations: "966217", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[91], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "295"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "295", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542740967 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "295"}, {name: "previousOwner_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "buyer_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "58000000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[91], balance: "13028641612856614" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[91], balance: ( await web3.eth.getBalance( addressList[91], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"296\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741163", blockHash: "0x12c0798fb6e4828710111acb2c178dfd1e10eb59fa2e9a4924bff9cc21ebd92e", timeStamp: "1542740980", hash: "0x80d78ed8d1459ca6676002e50d8ee305240b7880a7d77683f52830241d12fcec", nonce: "424", transactionIndex: "70", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "277528", gasPrice: "6900000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001280000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3106333", txreceipt_status: "0", gasUsed: "277491", confirmations: "966215", isError: "1"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "296"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "296", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542740980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"296\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741165", blockHash: "0xe03652120274e7ffcc8d3aa8fc47d9d0adb05366b37acc4abd39da131f7d9621", timeStamp: "1542741005", hash: "0xfa5ee2591b2aa62731e33d2973d16abb29fcef272a8fa478df6326eca6c9ba6f", nonce: "1454", transactionIndex: "13", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "415846", gasPrice: "4000000000", input: "0x7deb60250000000000000000000000000000000000000000000000000000000000000128000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "712133", txreceipt_status: "1", gasUsed: "247231", confirmations: "966213", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "296"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "296", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542741005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "296"}, {name: "previousOwner_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "buyer_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "55500000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"294\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741165", blockHash: "0xe03652120274e7ffcc8d3aa8fc47d9d0adb05366b37acc4abd39da131f7d9621", timeStamp: "1542741005", hash: "0xef30b6cd7438f50acd661f2779e8c0065ad3b2c04173ea64d8e13c58880df0d6", nonce: "312", transactionIndex: "29", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "60250000000000000", gas: "270441", gasPrice: "3200000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001260000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7721706", txreceipt_status: "1", gasUsed: "225241", confirmations: "966213", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "60250000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "294"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "294", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542741005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "294"}, {name: "previousOwner_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "60250000000000000"}, {name: "newPrice_", type: "uint256", value: "150030000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"297\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741171", blockHash: "0x92988f543f3fd1bc28b5ac00316783b172c8b1420e703de8860f720b27ead016", timeStamp: "1542741119", hash: "0xc2b5e88c6da42fa7d7323d4a27cda650d00c564ce492f879c14a77f322886e16", nonce: "2388", transactionIndex: "4", from: "0x51bd4c735927f958a90db80398826ff47a9832f1", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "324411", gasPrice: "4000000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001290000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6167554", txreceipt_status: "1", gasUsed: "216274", confirmations: "966207", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[91], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "297"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "297", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542741119 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "297"}, {name: "previousOwner_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "buyer_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "59000000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[91], balance: "13028641612856614" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[91], balance: ( await web3.eth.getBalance( addressList[91], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"298\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741175", blockHash: "0xf351f989bf341ea1fa336b8dd3bf0addfa1980d6707004b6f5ce45c415eb4215", timeStamp: "1542741169", hash: "0x666ef344fbb52d4eda11cffd2871d1d56338ac60c3e9845080f4750360c55026", nonce: "425", transactionIndex: "24", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "295528", gasPrice: "6000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012a0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1496723", txreceipt_status: "1", gasUsed: "246274", confirmations: "966203", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "298"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "298", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542741169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "298"}, {name: "previousOwner_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "buyer_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "63750000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"298\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741175", blockHash: "0xf351f989bf341ea1fa336b8dd3bf0addfa1980d6707004b6f5ce45c415eb4215", timeStamp: "1542741169", hash: "0xbba1e3d45b7b8f53cc1328818292b4134c6bcadb78f20eb5a4ec1827ddc7b1dc", nonce: "1455", transactionIndex: "41", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "393346", gasPrice: "4000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012a000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "7512510", txreceipt_status: "0", gasUsed: "26691", confirmations: "966203", isError: "1"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "298"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "298", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542741169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"299\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741181", blockHash: "0xc8289b9b3e2b4f3a5bc37022b9881fdfe0073b7265ef988d21b6094361a3358e", timeStamp: "1542741249", hash: "0x74a3226ccc6e7055409cceb6a35da4e48e7d05f411f108ea57091c92faacb931", nonce: "2389", transactionIndex: "110", from: "0x51bd4c735927f958a90db80398826ff47a9832f1", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "414411", gasPrice: "5000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012b0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7458596", txreceipt_status: "1", gasUsed: "261274", confirmations: "966197", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[91], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "299"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "299", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542741249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "299"}, {name: "previousOwner_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "buyer_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "54250000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[91], balance: "13028641612856614" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[91], balance: ( await web3.eth.getBalance( addressList[91], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"299\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741181", blockHash: "0xc8289b9b3e2b4f3a5bc37022b9881fdfe0073b7265ef988d21b6094361a3358e", timeStamp: "1542741249", hash: "0x2d31091869ba6ee180b7cf87641402ea5f883aa4b5c04df5f88015fbe38d2cfb", nonce: "1456", transactionIndex: "111", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "348346", gasPrice: "5000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012b000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "7485287", txreceipt_status: "0", gasUsed: "26691", confirmations: "966197", isError: "1"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "299"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "299", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542741249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"300\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741193", blockHash: "0xe9f6f8e429ee408760e1a05217307fa6fa783ba2e0289e662f49a29446f9134d", timeStamp: "1542741337", hash: "0x2f30a5346914269d567d659e330a519d9062d70d7e12316a0fa88f8f47973bd8", nonce: "426", transactionIndex: "71", from: "0x1f6fa14d9707bc52196a95ae82a80487fa099821", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "277528", gasPrice: "4800000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4462741", txreceipt_status: "1", gasUsed: "216274", confirmations: "966185", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "300"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "300", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542741337 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "300"}, {name: "previousOwner_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "buyer_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "56500000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"301\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741198", blockHash: "0xa680bacba586f79f75ad6bb0b0ed04ed1d1d4343490c4630676df46500777e6e", timeStamp: "1542741418", hash: "0x1dc41191426b5b6530464cc7672f1b591788fbc4aee489cac238eaea70e00fa1", nonce: "1457", transactionIndex: "67", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "325846", gasPrice: "5000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012d000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "4814467", txreceipt_status: "1", gasUsed: "247231", confirmations: "966180", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "301"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "301", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542741418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "301"}, {name: "previousOwner_", type: "address", value: "0x1f6fa14d9707bc52196a95ae82a80487fa099821"}, {name: "buyer_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "58250000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawAll(  )", async function( ) {
		const txOriginal = {blockNumber: "6741199", blockHash: "0x4ca3cfe33290cc444360ad7475242bd2dd8896c0dea793a9c3f4b92a52363766", timeStamp: "1542741420", hash: "0x8c19aaa40727936d30c973032dc3ffc548533bdc8cf41e6fe9b79593d39786d5", nonce: "2390", transactionIndex: "12", from: "0x51bd4c735927f958a90db80398826ff47a9832f1", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "72253", gasPrice: "4000000000", input: "0x853828b6", contractAddress: "", cumulativeGasUsed: "5819834", txreceipt_status: "1", gasUsed: "32930", confirmations: "966179", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[91], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawAll", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542741420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "receiver_", type: "address"}, {indexed: false, name: "splitProfit_", type: "uint256"}, {indexed: false, name: "flipProfit_", type: "uint256"}, {indexed: false, name: "waypointProfit_", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "receiver_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "splitProfit_", type: "uint256", value: "0"}, {name: "flipProfit_", type: "uint256", value: "37500000000000000"}, {name: "waypointProfit_", type: "uint256", value: "0"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[91], balance: "13028641612856614" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[91], balance: ( await web3.eth.getBalance( addressList[91], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"302\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741213", blockHash: "0x7c91bb87c3005a90a84e7a93d0dbd00052ba47d7aa9c393a84cec35421bd1e70", timeStamp: "1542741589", hash: "0x9ecb1b3dde19ec303808552a15de33e0a1c0d9a28207d852edd45f907105cf89", nonce: "1559", transactionIndex: "25", from: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "346921", gasPrice: "4000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012e0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5081183", txreceipt_status: "1", gasUsed: "231274", confirmations: "966165", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "302"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "302", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542741589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "302"}, {name: "previousOwner_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "buyer_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "51750000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "330109966327723938" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"297\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741213", blockHash: "0x7c91bb87c3005a90a84e7a93d0dbd00052ba47d7aa9c393a84cec35421bd1e70", timeStamp: "1542741589", hash: "0x0d0fb2f26c10f99fc643bc282eccbad18f0f6c63def74997a30eb425c94de349", nonce: "313", transactionIndex: "64", from: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "59000000000000000", gas: "292896", gasPrice: "3200000000", input: "0x7deb602500000000000000000000000000000000000000000000000000000000000001290000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6954626", txreceipt_status: "1", gasUsed: "180241", confirmations: "966165", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "59000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "297"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "297", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542741589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "297"}, {name: "previousOwner_", type: "address", value: "0x51bd4c735927f958a90db80398826ff47a9832f1"}, {name: "buyer_", type: "address", value: "0x9a0cf297c8143d8e08296f5257ba81081b1a2e5b"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "59000000000000000"}, {name: "newPrice_", type: "uint256", value: "150450000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "621904392174034402" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawAll(  )", async function( ) {
		const txOriginal = {blockNumber: "6741216", blockHash: "0x09e7d9cd5bc856ce4e3221ebadbacddd913bb508dda88ed395d35f6ddb50a33d", timeStamp: "1542741622", hash: "0x8bbf90893d3e660411c10a86feef17a98b02603b4d7769789b9c0db09ee89dea", nonce: "1560", transactionIndex: "78", from: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "0", gas: "72253", gasPrice: "4000000000", input: "0x853828b6", contractAddress: "", cumulativeGasUsed: "5653393", txreceipt_status: "1", gasUsed: "23965", confirmations: "966162", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawAll", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542741622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "receiver_", type: "address"}, {indexed: false, name: "splitProfit_", type: "uint256"}, {indexed: false, name: "flipProfit_", type: "uint256"}, {indexed: false, name: "waypointProfit_", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "receiver_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "splitProfit_", type: "uint256", value: "17482500000000000"}, {name: "flipProfit_", type: "uint256", value: "145065000000000000"}, {name: "waypointProfit_", type: "uint256", value: "0"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "330109966327723938" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"303\", addressList[110] )", async function( ) {
		const txOriginal = {blockNumber: "6741217", blockHash: "0x91615cac892c4740e9f5a9ef4b488ef520bd539d00f6143b606685196b130a32", timeStamp: "1542741641", hash: "0xce0850930e142be7dbbda98b560d5bb24c6d3c6ef31e0d4c8e3300987a75e893", nonce: "1458", transactionIndex: "51", from: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "25000000000000000", gas: "438381", gasPrice: "5000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012f000000000000000000000000d1692f1c6b50d299993363be1c869e3e64842732", contractAddress: "", cumulativeGasUsed: "2389333", txreceipt_status: "1", gasUsed: "247231", confirmations: "966161", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "303"}, {type: "address", name: "newReferer_", value: addressList[110]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "303", addressList[110], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542741641 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "303"}, {name: "previousOwner_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "buyer_", type: "address", value: "0x360bbad1120b0abf63573e2e21b6727e07d1bf18"}, {name: "referer_", type: "address", value: "0xd1692f1c6b50d299993363be1c869e3e64842732"}, {name: "price_", type: "uint256", value: "25000000000000000"}, {name: "newPrice_", type: "uint256", value: "62000000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "75379681936658651" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"302\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6741220", blockHash: "0xfe0aa3763ca01ae0ae2a7732ba5a31c22a5515b529578b18a6c9e2f1d13c8e78", timeStamp: "1542741692", hash: "0x2cccfe84fefbb935f18edd30b716c5e642d6473c643b6cf2ae7c31196c6826e2", nonce: "325", transactionIndex: "77", from: "0x407dbc332f834e51737e428fe22ce10fcdb4214f", to: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67", value: "51750000000000000", gas: "293346", gasPrice: "6000000000", input: "0x7deb6025000000000000000000000000000000000000000000000000000000000000012e0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5921995", txreceipt_status: "1", gasUsed: "180564", confirmations: "966158", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[139], to: addressList[2], value: "51750000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "badgeID_", value: "302"}, {type: "address", name: "newReferer_", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,address)" ]( "302", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542741692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "badgeID_", type: "uint256"}, {indexed: false, name: "previousOwner_", type: "address"}, {indexed: true, name: "buyer_", type: "address"}, {indexed: true, name: "referer_", type: "address"}, {indexed: false, name: "price_", type: "uint256"}, {indexed: false, name: "newPrice_", type: "uint256"}], name: "onBadgeBuy", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBadgeBuy", events: [{name: "badgeID_", type: "uint256", value: "302"}, {name: "previousOwner_", type: "address", value: "0xc24f97bb1d7a75d9f986c99dfcfa2a558058904c"}, {name: "buyer_", type: "address", value: "0x407dbc332f834e51737e428fe22ce10fcdb4214f"}, {name: "referer_", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "price_", type: "uint256", value: "51750000000000000"}, {name: "newPrice_", type: "uint256", value: "124200000000000000"}], address: "0xe467b8d9b0c69f7d497b8f002a9e7f4b61c84c67"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[139], balance: "1687123682974014024" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1695374100000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[139], balance: ( await web3.eth.getBalance( addressList[139], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
