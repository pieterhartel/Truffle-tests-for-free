const AceDice = artifacts.require( "./AceDice.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "AceDice" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xc06b5A46C0028f4B79F25D70E185155A0B471596", "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", "0xAe113B2FA9DF869e45f9578EA8b02E0BC30Ed7ac", "0xf187f13777f0b245976A257B98E6D4fe9124Da74", "0x22E76212fF057427D67eBa88c690612353D49457", "0x5E2E95ba53d6fce42b991ebF397E055fA89BF800"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "thisBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "secretSigner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "jackpotSize", outputs: [{name: "", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "croupier", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMyAccuAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getSecretSigner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "todaysRewardSize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getProfile", outputs: [{name: "", type: "uint256"}, {name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lockedInBets", outputs: [{name: "", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "FailedPayment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "JackpotPayment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "VIPPayback", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TodaysRankingPayment", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["FailedPayment(address,uint256)", "Payment(address,uint256,uint256,uint256,uint256)", "JackpotPayment(address,uint256,uint256,uint256,uint256)", "VIPPayback(address,uint256)", "Commit(uint256)", "TodaysRankingPayment(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xac464fe4d3a86b9121261ac0a01dd981bfe0777c7c9d9c8f4473d31a9c0f9d2d", "0x9620cef3a3d39af2426e8362381d59ca9ea0f5ae59621986a897d764f66f953e", "0x1bb05166a98fd97ba6a9f1f04f57b119557528458c1378d421b97451e195fd2c", "0x63c4a815575db8089483aeea967a8e1205c076ec5ff1eefca70ddb8d93be7eff", "0x5bdd2fc99022530157777690475b670d3872f32262eb1d47d9ba8000dad58f87", "0x875de2816b17269ce10ae748fd72a0243bad5ee5ed409961ac7aea9fc4db80af"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6836199 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6841936 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "AceDice", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "thisBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "thisBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "secretSigner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secretSigner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "jackpotSize", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "jackpotSize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "croupier", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "croupier()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMyAccuAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMyAccuAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getSecretSigner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSecretSigner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "todaysRewardSize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "todaysRewardSize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getProfile", outputs: [{name: "", type: "uint256"}, {name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getProfile()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockedInBets", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedInBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "AceDice", function( accounts ) {

	it( "TEST: AceDice(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6836199", timeStamp: "1544093754", hash: "0x61a9ccb261e2b1b02bafe3c5eaafe082a6ebf2662ee464c5ec9376399a9b07d7", nonce: "71", blockHash: "0x165130b75ec793ad66219dda3a9b221781d362fb1546ab6ef928124e8a867d83", transactionIndex: "1", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: 0, value: "0", gas: "5168085", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x48315d54", contractAddress: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", cumulativeGasUsed: "5196884", gasUsed: "5168085", confirmations: "847520"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "AceDice", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = AceDice.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544093754 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = AceDice.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setCroupier( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6839972", timeStamp: "1544147736", hash: "0x14c76301614ce648dc2c586907153fda24541cee87c99d3665bbba689c37a797", nonce: "72", blockHash: "0x284ca387ee41102c45bff69aa3199efbefe5ace6cc5b424e13fc4ea3b30e5097", transactionIndex: "89", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "28970", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf8bb201c000000000000000000000000ae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", contractAddress: "", cumulativeGasUsed: "7396953", gasUsed: "28970", confirmations: "843747"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newCroupier", value: addressList[4]}], name: "setCroupier", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCroupier(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544147736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setSecretSigner( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6839982", timeStamp: "1544147872", hash: "0xe502b2a998f16524caaf146ef0b11877719ed5e2683c83cac38795320e72f147", nonce: "73", blockHash: "0x59f2a3079280a14d52c4b6ad2e4103e95b6865ad21c37c80929216084cbc0345", transactionIndex: "145", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "28882", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd702087f000000000000000000000000ae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", contractAddress: "", cumulativeGasUsed: "6959668", gasUsed: "28882", confirmations: "843737"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newSecretSigner", value: addressList[4]}], name: "setSecretSigner", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSecretSigner(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544147872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxProfit( \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6839982", timeStamp: "1544147872", hash: "0xd0df70436dc6b9ceaef56138fef77d0fb9e92c3ca7d5bd3fc466e0cd9277e107", nonce: "74", blockHash: "0x59f2a3079280a14d52c4b6ad2e4103e95b6865ad21c37c80929216084cbc0345", transactionIndex: "146", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "42866", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfbd668a90000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "7002534", gasUsed: "42866", confirmations: "843737"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxProfit", value: "10000000000000000000"}], name: "setMaxProfit", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxProfit(uint256)" ]( "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544147872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6839993", timeStamp: "1544148105", hash: "0x1dcdb1740e04c795c7463992b243e277444487a2da577b82da94c0d556c77977", nonce: "75", blockHash: "0x7c990bdbfbac47d818e4147f07d32d1cdba46e2b82f8ffe602134e36aafde6d4", transactionIndex: "164", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "1000000000000000000", gas: "31560", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7789801", gasUsed: "21040", confirmations: "843726"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544148105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6842494\", \"30352034434566792... )", async function( ) {
		const txOriginal = {blockNumber: "6840000", timeStamp: "1544148198", hash: "0xd83144a9c8d4d8e26b696fab2881258aacb3c6750da17f58bd20f24e68cdb49c", nonce: "76", blockHash: "0x24edc155cf412fb45f7e4cefe99e9ae9aa86e06663145189ee2079fa7f082ebc", transactionIndex: "18", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000068687e431aa4881b102ca1d5190beff5c74af33445edb7a005cf936d36e38349d99f7b000000000000000000000000000000000000000000000000000000000000001b9ce54fc06d6fd175ee69b29caa16969d912051561ab55d23754ddc8109ee55c55fd1dfb9e9788c9691ec24aebdba123d7181f005289a987b6f7ec57b026d70a2", contractAddress: "", cumulativeGasUsed: "1042167", gasUsed: "140779", confirmations: "843719"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6842494"}, {type: "uint256", name: "commit", value: "30352034434566792012922835294121654322560435232518695654599763213911911407483"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9ce54fc06d6fd175ee69b29caa16969d912051561ab55d23754ddc8109ee55c5"}, {type: "bytes32", name: "s", value: "0x5fd1dfb9e9788c9691ec24aebdba123d7181f005289a987b6f7ec57b026d70a2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6842494", "30352034434566792012922835294121654322560435232518695654599763213911911407483", "27", "0x9ce54fc06d6fd175ee69b29caa16969d912051561ab55d23754ddc8109ee55c5", "0x5fd1dfb9e9788c9691ec24aebdba123d7181f005289a987b6f7ec57b026d70a2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544148198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "30352034434566792012922835294121654322560435232518695654599763213911911407483"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"7627123\", \"0x24edc155cf412fb45f7e4ce... )", async function( ) {
		const txOriginal = {blockNumber: "6840006", timeStamp: "1544148358", hash: "0xf01b903a0615f8820722c631b4f1e78dacc35f24baa89ef9d4bf04d3e0f5c546", nonce: "77", blockHash: "0xcde272354d93ea4b4edc1c7e5cccce5c854a6f5c40f8a4e437e30c07d5940070", transactionIndex: "65", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc000000000000000000000000000000000000000000000000000000000074617324edc155cf412fb45f7e4cefe99e9ae9aa86e06663145189ee2079fa7f082ebc", contractAddress: "", cumulativeGasUsed: "2571645", gasUsed: "39395", confirmations: "843713"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "7627123"}, {type: "bytes32", name: "blockHash", value: "0x24edc155cf412fb45f7e4cefe99e9ae9aa86e06663145189ee2079fa7f082ebc"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "7627123", "0x24edc155cf412fb45f7e4cefe99e9ae9aa86e06663145189ee2079fa7f082ebc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544148358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "0"}, {name: "dice", type: "uint256", value: "79"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6842550\", \"31613117950415463... )", async function( ) {
		const txOriginal = {blockNumber: "6840054", timeStamp: "1544149065", hash: "0x2a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62", nonce: "78", blockHash: "0xee53805250e71b55a1d5bdb2cfc5d0d438a9fb6781886d8e1cdc4ef8de782115", transactionIndex: "36", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000006868b645e4640370dd7d5b175ffa05def57bee61465901823e383bb3bcf223fb1386e4000000000000000000000000000000000000000000000000000000000000001cdf7cde36ed94dced028181c03b7966a4fa410b934bfc2f1bfe9101e92d09c9e0762b84aafbef6ac89905ed7c7df8b986cef6c8e13cfcdf46156253efa9bdb795", contractAddress: "", cumulativeGasUsed: "2768306", gasUsed: "125779", confirmations: "843665"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6842550"}, {type: "uint256", name: "commit", value: "31613117950415463715450364676845550560053100917727818899380209029290178873060"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xdf7cde36ed94dced028181c03b7966a4fa410b934bfc2f1bfe9101e92d09c9e0"}, {type: "bytes32", name: "s", value: "0x762b84aafbef6ac89905ed7c7df8b986cef6c8e13cfcdf46156253efa9bdb795"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6842550", "31613117950415463715450364676845550560053100917727818899380209029290178873060", "28", "0xdf7cde36ed94dced028181c03b7966a4fa410b934bfc2f1bfe9101e92d09c9e0", "0x762b84aafbef6ac89905ed7c7df8b986cef6c8e13cfcdf46156253efa9bdb795", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544149065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "31613117950415463715450364676845550560053100917727818899380209029290178873060"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8202961\", \"0x2a8ec8e7ad594d244877cc4... )", async function( ) {
		const txOriginal = {blockNumber: "6840088", timeStamp: "1544149519", hash: "0x1b55f62de7f5cd25889d5a6a9ac104efa3df0db1af2f8f10f4dfbc9d1e8e54f8", nonce: "79", blockHash: "0x616c4a3359ee95e284b946f0c2ba9b7e307bfab374c925d3f4c92d6bdf1ce409", transactionIndex: "101", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000007d2ad12a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62", contractAddress: "", cumulativeGasUsed: "4385707", gasUsed: "25621", confirmations: "843631"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8202961"}, {type: "bytes32", name: "blockHash", value: "0x2a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8202961", "0x2a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544149519 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8202961\", \"0x2a8ec8e7ad594d244877cc4... )", async function( ) {
		const txOriginal = {blockNumber: "6840097", timeStamp: "1544149618", hash: "0x578f76f3acc08fe4b8225ffed6e985ea649bba40a5679b81baa63cc86cbaa47b", nonce: "80", blockHash: "0xca5893db92229a12a1c91bec565b4134a978cddba4838667da65e1f4508183fe", transactionIndex: "103", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000007d2ad12a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62", contractAddress: "", cumulativeGasUsed: "4100702", gasUsed: "25621", confirmations: "843622"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8202961"}, {type: "bytes32", name: "blockHash", value: "0x2a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8202961", "0x2a8ec8e7ad594d244877cc48a5ef058baba2636e8a4c8a1def9d605a0fc36f62", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544149618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: refundBet( \"31613117950415463715450364676845550560... )", async function( ) {
		const txOriginal = {blockNumber: "6840157", timeStamp: "1544150535", hash: "0xf3011b977647f5984c0028c96f1dabeabaaaa5b1bf2f96a1a86f65a34c0bd1ec", nonce: "81", blockHash: "0xbd0ae22268e298f1676c541aef75285acda7731021bb575c7aed2e1df76f18f2", transactionIndex: "89", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xe1fdb4b445e4640370dd7d5b175ffa05def57bee61465901823e383bb3bcf223fb1386e4", contractAddress: "", cumulativeGasUsed: "3313198", gasUsed: "24972", confirmations: "843562"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "commit", value: "31613117950415463715450364676845550560053100917727818899380209029290178873060"}], name: "refundBet", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "refundBet(uint256)" ]( "31613117950415463715450364676845550560053100917727818899380209029290178873060", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544150535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6842660\", \"10870335404613495... )", async function( ) {
		const txOriginal = {blockNumber: "6840163", timeStamp: "1544150629", hash: "0x27af1f0708cd0cadb629d39bac7988a406bc592cd243210f35524876cfdae8ed", nonce: "82", blockHash: "0x7943d297184029f0a331048654533a2788c493c884262a1492af75fced9cef57", transactionIndex: "217", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686924f053eb064863140f7e73c9c587821eaa2f5a8f4193c952b5b34e288b19543d5b000000000000000000000000000000000000000000000000000000000000001cfe026a5a6c4b59bae465ef58e2fe132e84ab2973f4449ebeecbb35725207cd2f48e3b2f4a897a83e543301ed7d16a14bfd310d058593f476bdd33532f5b5b9fa", contractAddress: "", cumulativeGasUsed: "6437587", gasUsed: "110779", confirmations: "843556"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6842660"}, {type: "uint256", name: "commit", value: "108703354046134958368294927890038751339589519338407291460925354974072947359067"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xfe026a5a6c4b59bae465ef58e2fe132e84ab2973f4449ebeecbb35725207cd2f"}, {type: "bytes32", name: "s", value: "0x48e3b2f4a897a83e543301ed7d16a14bfd310d058593f476bdd33532f5b5b9fa"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6842660", "108703354046134958368294927890038751339589519338407291460925354974072947359067", "28", "0xfe026a5a6c4b59bae465ef58e2fe132e84ab2973f4449ebeecbb35725207cd2f", "0x48e3b2f4a897a83e543301ed7d16a14bfd310d058593f476bdd33532f5b5b9fa", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544150629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "108703354046134958368294927890038751339589519338407291460925354974072947359067"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"4403035\", \"0x7943d297184029f0a331048... )", async function( ) {
		const txOriginal = {blockNumber: "6840168", timeStamp: "1544150713", hash: "0xab8f7ef9918225ace80954e50ebbec5aa23b4b78c3aecead270078b5e71bffa7", nonce: "83", blockHash: "0x216eaf6f27680e7b1108b89465fb70b1bd375ee8048cd984465fb1f5c621e700", transactionIndex: "69", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc0000000000000000000000000000000000000000000000000000000000432f5b7943d297184029f0a331048654533a2788c493c884262a1492af75fced9cef57", contractAddress: "", cumulativeGasUsed: "2829162", gasUsed: "39395", confirmations: "843551"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "4403035"}, {type: "bytes32", name: "blockHash", value: "0x7943d297184029f0a331048654533a2788c493c884262a1492af75fced9cef57"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "4403035", "0x7943d297184029f0a331048654533a2788c493c884262a1492af75fced9cef57", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544150713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "0"}, {name: "dice", type: "uint256", value: "78"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"96\", \"6842685\", \"95981921523644945... )", async function( ) {
		const txOriginal = {blockNumber: "6840187", timeStamp: "1544150945", hash: "0x991763a0c9696f25928d74c7f7aa1cd9ebc05d67b669dde8ed5027d0f9410b95", nonce: "84", blockHash: "0x394ffea1ff473ced18c7ec5a083064e85f82dfcef46daafeea70f841c9c15718", transactionIndex: "71", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000068693dd433d7a8b3f89cf7caf0a5f92c92724a3aafb1e46f57299c7a7e8e0400490a46000000000000000000000000000000000000000000000000000000000000001c5f84322f3404753e4ca7e62270a04a7d31f233393a18954b73a4506dbba3370f55a5e9c5259a214e25707c1c50d355652894746e767dab530d7cb6384129b34a", contractAddress: "", cumulativeGasUsed: "3791375", gasUsed: "110715", confirmations: "843532"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "96"}, {type: "uint256", name: "commitLastBlock", value: "6842685"}, {type: "uint256", name: "commit", value: "95981921523644945717456013465149626107886971379669423805747766292720969648710"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x5f84322f3404753e4ca7e62270a04a7d31f233393a18954b73a4506dbba3370f"}, {type: "bytes32", name: "s", value: "0x55a5e9c5259a214e25707c1c50d355652894746e767dab530d7cb6384129b34a"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "96", "6842685", "95981921523644945717456013465149626107886971379669423805747766292720969648710", "28", "0x5f84322f3404753e4ca7e62270a04a7d31f233393a18954b73a4506dbba3370f", "0x55a5e9c5259a214e25707c1c50d355652894746e767dab530d7cb6384129b34a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544150945 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "95981921523644945717456013465149626107886971379669423805747766292720969648710"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"2372247\", \"0x394ffea1ff473ced18c7ec5... )", async function( ) {
		const txOriginal = {blockNumber: "6840197", timeStamp: "1544151060", hash: "0xf4d768823aea44169a70a25990065d9ac60cf18ac71e16db7f8d3d782d8983bc", nonce: "85", blockHash: "0xe1d1acf9c1f28cb343e3521684d4853a03ec0e2abd24cd8e90e2c85bee01a79c", transactionIndex: "129", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "54419", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc0000000000000000000000000000000000000000000000000000000000243297394ffea1ff473ced18c7ec5a083064e85f82dfcef46daafeea70f841c9c15718", contractAddress: "", cumulativeGasUsed: "7827148", gasUsed: "39419", confirmations: "843522"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "2372247"}, {type: "bytes32", name: "blockHash", value: "0x394ffea1ff473ced18c7ec5a083064e85f82dfcef46daafeea70f841c9c15718"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "2372247", "0x394ffea1ff473ced18c7ec5a083064e85f82dfcef46daafeea70f841c9c15718", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544151060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "dice", type: "uint256", value: "67"}, {name: "rollUnder", type: "uint256", value: "96"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setAvatarIndex( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6840296", timeStamp: "1544152454", hash: "0x6bee117e2b5ec7adb15a1380323be486363deb4b125bf969c01e18d83fe39885", nonce: "123", blockHash: "0x35b0a531ff543a2d49beb2fb53187bb509511b55dae2c2ebeb2d80459e7d43ce", transactionIndex: "125", from: "0xf187f13777f0b245976a257b98e6d4fe9124da74", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "62830", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x412648bf0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7459305", gasUsed: "41887", confirmations: "843423"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "6"}], name: "setAvatarIndex", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAvatarIndex(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544152454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "48262084654463462" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"96\", \"6842770\", \"53074986779551353... )", async function( ) {
		const txOriginal = {blockNumber: "6840307", timeStamp: "1544152701", hash: "0xd1deb9a30aebcd2045143e8f7b3eee8913f3112ae9f6e5eca4f07525da6fa20d", nonce: "2", blockHash: "0xa5ed64ac32a26c4362a287e478d862780eba969972d2662e9f3bbc7dd08bc575", transactionIndex: "103", from: "0x22e76212ff057427d67eba88c690612353d49457", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000686992755760c21a891acb073f32f1d7e8382b08831934b9062c990ddf89ce0e19db46000000000000000000000000000000000000000000000000000000000000001ca2ddcafb5beeb838684057d3d5d665d727695ca231d1f2c54709d5ad5e013eca723a8eb3737c6268eadeb11a6431d2075ff690cf305e49e53ed2acda09f7d336", contractAddress: "", cumulativeGasUsed: "4747509", gasUsed: "125779", confirmations: "843412"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "96"}, {type: "uint256", name: "commitLastBlock", value: "6842770"}, {type: "uint256", name: "commit", value: "53074986779551353366989621467557873440516779284044328349530880986585908239174"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xa2ddcafb5beeb838684057d3d5d665d727695ca231d1f2c54709d5ad5e013eca"}, {type: "bytes32", name: "s", value: "0x723a8eb3737c6268eadeb11a6431d2075ff690cf305e49e53ed2acda09f7d336"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "96", "6842770", "53074986779551353366989621467557873440516779284044328349530880986585908239174", "28", "0xa2ddcafb5beeb838684057d3d5d665d727695ca231d1f2c54709d5ad5e013eca", "0x723a8eb3737c6268eadeb11a6431d2075ff690cf305e49e53ed2acda09f7d336", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544152701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "53074986779551353366989621467557873440516779284044328349530880986585908239174"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "539188920644750404" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"4063722\", \"0xa5ed64ac32a26c4362a287e... )", async function( ) {
		const txOriginal = {blockNumber: "6840313", timeStamp: "1544152783", hash: "0xc17a5128b75764278718777448e8e495ff4be72f02d8092c5bcb85d71c0a7f76", nonce: "86", blockHash: "0xc9f007d51c332582cfb77c10a60b58d227829ca2bd2991eddb81205ae0eaa47d", transactionIndex: "25", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000003e01eaa5ed64ac32a26c4362a287e478d862780eba969972d2662e9f3bbc7dd08bc575", contractAddress: "", cumulativeGasUsed: "1605823", gasUsed: "39419", confirmations: "843406"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "4063722"}, {type: "bytes32", name: "blockHash", value: "0xa5ed64ac32a26c4362a287e478d862780eba969972d2662e9f3bbc7dd08bc575"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "4063722", "0xa5ed64ac32a26c4362a287e478d862780eba969972d2662e9f3bbc7dd08bc575", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544152783 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x22e76212ff057427d67eba88c690612353d49457"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "dice", type: "uint256", value: "46"}, {name: "rollUnder", type: "uint256", value: "96"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6843318\", \"11350545433664127... )", async function( ) {
		const txOriginal = {blockNumber: "6840821", timeStamp: "1544160074", hash: "0xd68fc66649be0e807db583afde683da56fb49f25f2c26a650032da977f4dc78c", nonce: "87", blockHash: "0x6f07de387c578591ede25e1ceecad28b07f9e1ade76294cb28d32aae19995701", transactionIndex: "20", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686bb6faf1cf7d9ed29122bc8e0b413c8b7b44f4765832e5801f65c0113e5c8cfa1f72000000000000000000000000000000000000000000000000000000000000001b75b3ecbad89b45c24f7e63c27aa4d17c981cc9dd72fb64cacfe53e6403017590091bada355649d7e7e80d32cd2e5e9f7fa849a65d91acbec8a6ad3445e5674f6", contractAddress: "", cumulativeGasUsed: "655123", gasUsed: "110779", confirmations: "842898"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6843318"}, {type: "uint256", name: "commit", value: "113505454336641271054247215141069134996018791997362186158856571618971881185138"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x75b3ecbad89b45c24f7e63c27aa4d17c981cc9dd72fb64cacfe53e6403017590"}, {type: "bytes32", name: "s", value: "0x091bada355649d7e7e80d32cd2e5e9f7fa849a65d91acbec8a6ad3445e5674f6"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6843318", "113505454336641271054247215141069134996018791997362186158856571618971881185138", "27", "0x75b3ecbad89b45c24f7e63c27aa4d17c981cc9dd72fb64cacfe53e6403017590", "0x091bada355649d7e7e80d32cd2e5e9f7fa849a65d91acbec8a6ad3445e5674f6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544160074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "113505454336641271054247215141069134996018791997362186158856571618971881185138"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8815699\", \"0x6f07de387c578591ede25e1... )", async function( ) {
		const txOriginal = {blockNumber: "6840825", timeStamp: "1544160113", hash: "0x42bc2adbb8081cb731daff12297bbf5a4908e10a3419a08134129decf4c4b215", nonce: "88", blockHash: "0xc55e674f7e45164f18dd2ebf6c28ae5377d70cad8245c975ba7ce221b4e867eb", transactionIndex: "40", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "15125000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000008684536f07de387c578591ede25e1ceecad28b07f9e1ade76294cb28d32aae19995701", contractAddress: "", cumulativeGasUsed: "1104708", gasUsed: "39419", confirmations: "842894"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8815699"}, {type: "bytes32", name: "blockHash", value: "0x6f07de387c578591ede25e1ceecad28b07f9e1ade76294cb28d32aae19995701"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8815699", "0x6f07de387c578591ede25e1ceecad28b07f9e1ade76294cb28d32aae19995701", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544160113 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "19200000000000000"}, {name: "dice", type: "uint256", value: "3"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6843355\", \"33005915430512820... )", async function( ) {
		const txOriginal = {blockNumber: "6840858", timeStamp: "1544160612", hash: "0x35a66bd281594b134460d68a0ddd0544aa4f30ce190bd442f5ef8dbb936ba201", nonce: "89", blockHash: "0xbe76bbeed7ba7869ab1f7ae6b5be66714ebfce2bdd2ccbfe2bbecc4efc11b9bc", transactionIndex: "135", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686bdb48f8afa53d40d03ccb464fa354fb1aa84a78fd909fdb047aea9af84777e9d7ad000000000000000000000000000000000000000000000000000000000000001c5263aeba4d2421fb383e81f180c88bc0484a1acfa9ef5ce388f43eb717e541221867774d322ca002bac9537814569236dea592b5f7ba0343288349af51f14735", contractAddress: "", cumulativeGasUsed: "5878608", gasUsed: "110779", confirmations: "842861"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6843355"}, {type: "uint256", name: "commit", value: "33005915430512820194557082175479474042038944617747077467534538343486809823149"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x5263aeba4d2421fb383e81f180c88bc0484a1acfa9ef5ce388f43eb717e54122"}, {type: "bytes32", name: "s", value: "0x1867774d322ca002bac9537814569236dea592b5f7ba0343288349af51f14735"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6843355", "33005915430512820194557082175479474042038944617747077467534538343486809823149", "28", "0x5263aeba4d2421fb383e81f180c88bc0484a1acfa9ef5ce388f43eb717e54122", "0x1867774d322ca002bac9537814569236dea592b5f7ba0343288349af51f14735", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544160612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "33005915430512820194557082175479474042038944617747077467534538343486809823149"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"6785671\", \"0xbe76bbeed7ba7869ab1f7ae... )", async function( ) {
		const txOriginal = {blockNumber: "6840867", timeStamp: "1544160759", hash: "0x82e58bb7757bba4aa5a0932e495a2ecfab480ef899804c895b96ba5e82e09324", nonce: "90", blockHash: "0x173f57d11a16145f435a81de8f3c95c4e78549e6e9f55bb787187a42522ccfa1", transactionIndex: "184", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "54419", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc0000000000000000000000000000000000000000000000000000000000678a87be76bbeed7ba7869ab1f7ae6b5be66714ebfce2bdd2ccbfe2bbecc4efc11b9bc", contractAddress: "", cumulativeGasUsed: "7324499", gasUsed: "39419", confirmations: "842852"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "6785671"}, {type: "bytes32", name: "blockHash", value: "0xbe76bbeed7ba7869ab1f7ae6b5be66714ebfce2bdd2ccbfe2bbecc4efc11b9bc"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "6785671", "0xbe76bbeed7ba7869ab1f7ae6b5be66714ebfce2bdd2ccbfe2bbecc4efc11b9bc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544160759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "19200000000000000"}, {name: "dice", type: "uint256", value: "22"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setAvatarIndex( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6840901", timeStamp: "1544161360", hash: "0xb5adcff5ddd67b24daa3b2fe216ae3a9a7e19f9ef9326e7a38ea18843f28be30", nonce: "91", blockHash: "0xa4ef4d59d2b92e74ad19cb369f86b1b10d84f17980cdeb193e9233d07ec6d9df", transactionIndex: "52", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "62830", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x412648bf0000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3321665", gasUsed: "41887", confirmations: "842818"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "5"}], name: "setAvatarIndex", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAvatarIndex(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544161360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6843607\", \"44289302638099369... )", async function( ) {
		const txOriginal = {blockNumber: "6841114", timeStamp: "1544164099", hash: "0x5fbd914ddc52943d9bbfb536b5b389238060e1f96e0b0dd4199bd102d9f7e8f2", nonce: "92", blockHash: "0x69eca3bd135d0024c1214acd91bf9adb56f889ac9c213225093ab5ae83d7fbfb", transactionIndex: "82", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686cd761eadb618c87dea1cc3f32c18ab653688176c39f7cd1129bd520be6b3cddc602000000000000000000000000000000000000000000000000000000000000001b5206bc0a84dd384b14a3d06fb671c637a35a5b60dad0c007cd9c7605055253de2a3899c145841040bcbce36725c8e3b00dbcb93c25458b85c8394c55dff5bfee", contractAddress: "", cumulativeGasUsed: "3762444", gasUsed: "110779", confirmations: "842605"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6843607"}, {type: "uint256", name: "commit", value: "44289302638099369820691363819245426245345796375813103648396712215616788743682"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x5206bc0a84dd384b14a3d06fb671c637a35a5b60dad0c007cd9c7605055253de"}, {type: "bytes32", name: "s", value: "0x2a3899c145841040bcbce36725c8e3b00dbcb93c25458b85c8394c55dff5bfee"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6843607", "44289302638099369820691363819245426245345796375813103648396712215616788743682", "27", "0x5206bc0a84dd384b14a3d06fb671c637a35a5b60dad0c007cd9c7605055253de", "0x2a3899c145841040bcbce36725c8e3b00dbcb93c25458b85c8394c55dff5bfee", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544164099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "44289302638099369820691363819245426245345796375813103648396712215616788743682"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8815699\", \"0x69eca3bd135d0024c1214ac... )", async function( ) {
		const txOriginal = {blockNumber: "6841143", timeStamp: "1544164572", hash: "0x415a08c62c1a5cbe85d1e3ebe9827c2e7abb517481b480016930c17c6f2b5ab6", nonce: "93", blockHash: "0xa1f8c790fb6e0fe4525dab13c6261af7fb68031ee0acb12165220b98685e129e", transactionIndex: "83", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xca722cdc000000000000000000000000000000000000000000000000000000000086845369eca3bd135d0024c1214acd91bf9adb56f889ac9c213225093ab5ae83d7fbfb", contractAddress: "", cumulativeGasUsed: "4338227", gasUsed: "25616", confirmations: "842576"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8815699"}, {type: "bytes32", name: "blockHash", value: "0x69eca3bd135d0024c1214acd91bf9adb56f889ac9c213225093ab5ae83d7fbfb"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8815699", "0x69eca3bd135d0024c1214acd91bf9adb56f889ac9c213225093ab5ae83d7fbfb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544164572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: refundBet( \"31613117950415463715450364676845550560... )", async function( ) {
		const txOriginal = {blockNumber: "6841289", timeStamp: "1544166757", hash: "0x973a2c06687dc29440c339b7888eae9695202da2cd3cc72dec60618a16692744", nonce: "94", blockHash: "0x0689c3048f803ba3a9013d825333371012ccb4fd80b8085441af6fa07e172356", transactionIndex: "181", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "51654", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xe1fdb4b445e4640370dd7d5b175ffa05def57bee61465901823e383bb3bcf223fb1386e4", contractAddress: "", cumulativeGasUsed: "5527516", gasUsed: "36654", confirmations: "842430"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "commit", value: "31613117950415463715450364676845550560053100917727818899380209029290178873060"}], name: "refundBet", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "refundBet(uint256)" ]( "31613117950415463715450364676845550560053100917727818899380209029290178873060", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544166757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "dice", type: "uint256", value: "0"}, {name: "rollUnder", type: "uint256", value: "0"}, {name: "betAmount", type: "uint256", value: "0"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"96\", \"6843804\", \"10502761289699099... )", async function( ) {
		const txOriginal = {blockNumber: "6841309", timeStamp: "1544167000", hash: "0x68a9f1701f79ff9bc8ec47a55d1a29df3d1d39a254bdab1ca48bd68f0516d9c1", nonce: "6", blockHash: "0x1ffb46229c6e5921279332c3aa41ffe082a5cd4d9e73f94836263846611909bc", transactionIndex: "124", from: "0x22e76212ff057427d67eba88c690612353d49457", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000686d9ce83385b57ed04610f9f5dc477b4d0ebb4e9a1b546f09a07dbf5772e2e2cb72b0000000000000000000000000000000000000000000000000000000000000001b15d96220ead6971c82a145ddb3586907bcaf620606c4d66579702aecb422f4ee7cbcbbf832d141fb1da6b199a07c69bb66c9b2c7eefeef47073d42076154a465", contractAddress: "", cumulativeGasUsed: "4341905", gasUsed: "110779", confirmations: "842410"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "96"}, {type: "uint256", name: "commitLastBlock", value: "6843804"}, {type: "uint256", name: "commit", value: "105027612896990997182114130116578594142916636457973600860351659545507893310128"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x15d96220ead6971c82a145ddb3586907bcaf620606c4d66579702aecb422f4ee"}, {type: "bytes32", name: "s", value: "0x7cbcbbf832d141fb1da6b199a07c69bb66c9b2c7eefeef47073d42076154a465"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "96", "6843804", "105027612896990997182114130116578594142916636457973600860351659545507893310128", "27", "0x15d96220ead6971c82a145ddb3586907bcaf620606c4d66579702aecb422f4ee", "0x7cbcbbf832d141fb1da6b199a07c69bb66c9b2c7eefeef47073d42076154a465", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544167000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "105027612896990997182114130116578594142916636457973600860351659545507893310128"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "539188920644750404" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8941882\", \"0x1ffb46229c6e5921279332c... )", async function( ) {
		const txOriginal = {blockNumber: "6841316", timeStamp: "1544167085", hash: "0xbf14b82447c63f4dfeee6605e824507d2ad28e70e40150d61a7230c05bfb356c", nonce: "95", blockHash: "0xa53867409ef50d1fc6cf5bffbcc34339f3cbbcf99cd6ba4ca44e81604ad1cdc2", transactionIndex: "51", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc000000000000000000000000000000000000000000000000000000000088713a1ffb46229c6e5921279332c3aa41ffe082a5cd4d9e73f94836263846611909bc", contractAddress: "", cumulativeGasUsed: "1916820", gasUsed: "39419", confirmations: "842403"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8941882"}, {type: "bytes32", name: "blockHash", value: "0x1ffb46229c6e5921279332c3aa41ffe082a5cd4d9e73f94836263846611909bc"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8941882", "0x1ffb46229c6e5921279332c3aa41ffe082a5cd4d9e73f94836263846611909bc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544167085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x22e76212ff057427d67eba88c690612353d49457"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "dice", type: "uint256", value: "11"}, {name: "rollUnder", type: "uint256", value: "96"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"86\", \"6843952\", \"11016457133609087... )", async function( ) {
		const txOriginal = {blockNumber: "6841455", timeStamp: "1544168948", hash: "0x5ea4748028e170056f5c67efd47c2b05ee95ea27c5a5260c617ac589409d39d0", nonce: "31", blockHash: "0x4bf3f39df54dc2290a28dcb555705bf00fe65be170dce5f3a673ed358446557f", transactionIndex: "129", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000560000000000000000000000000000000000000000000000000000000000686e30185b18019671a2f16559b5ba7064abff793cd31de19e4a803fed5b098eb7333f000000000000000000000000000000000000000000000000000000000000001b032bb9be0c06dbec9a6a50113722f150541f46c1ac07e1da1e7f0d57344e2fa4441e6b730531d56fbaadff69a15cd3b8577c1004ffe0a6de1b7376ff04679984", contractAddress: "", cumulativeGasUsed: "5178539", gasUsed: "125779", confirmations: "842264"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "86"}, {type: "uint256", name: "commitLastBlock", value: "6843952"}, {type: "uint256", name: "commit", value: "11016457133609087028891093699039257430190313023427518979019070761756341515071"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x032bb9be0c06dbec9a6a50113722f150541f46c1ac07e1da1e7f0d57344e2fa4"}, {type: "bytes32", name: "s", value: "0x441e6b730531d56fbaadff69a15cd3b8577c1004ffe0a6de1b7376ff04679984"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "86", "6843952", "11016457133609087028891093699039257430190313023427518979019070761756341515071", "27", "0x032bb9be0c06dbec9a6a50113722f150541f46c1ac07e1da1e7f0d57344e2fa4", "0x441e6b730531d56fbaadff69a15cd3b8577c1004ffe0a6de1b7376ff04679984", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544168948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "11016457133609087028891093699039257430190313023427518979019070761756341515071"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"1378780\", \"0x4bf3f39df54dc2290a28dcb... )", async function( ) {
		const txOriginal = {blockNumber: "6841457", timeStamp: "1544168987", hash: "0x2660d95cdb430a1954e36ec1618a894d30ff1d4f88b043545b1deb7c6dae02a8", nonce: "96", blockHash: "0x1283596e6e83b1a5ac66759bfae48e497517394cb849c11eda63f36341396685", transactionIndex: "133", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000001509dc4bf3f39df54dc2290a28dcb555705bf00fe65be170dce5f3a673ed358446557f", contractAddress: "", cumulativeGasUsed: "3153324", gasUsed: "39419", confirmations: "842262"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "1378780"}, {type: "bytes32", name: "blockHash", value: "0x4bf3f39df54dc2290a28dcb555705bf00fe65be170dce5f3a673ed358446557f"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "1378780", "0x4bf3f39df54dc2290a28dcb555705bf00fe65be170dce5f3a673ed358446557f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544168987 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "11162790697674418"}, {name: "dice", type: "uint256", value: "21"}, {name: "rollUnder", type: "uint256", value: "86"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"86\", \"6843961\", \"28743899391600226... )", async function( ) {
		const txOriginal = {blockNumber: "6841463", timeStamp: "1544169085", hash: "0xb9a230c1ec83b2ca9236847828f258ab7b80e01d8b53c8e73a60a90f33ba8832", nonce: "32", blockHash: "0x372c42f95c08e470d5a61aed2b653aa6a2243cf53a69254f9fe86a0107ce2ddd", transactionIndex: "126", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000560000000000000000000000000000000000000000000000000000000000686e393f8c78742e3e6aa05355ae47a1d47db1da37577e08fbd8c5fbad27f66f9bd8eb000000000000000000000000000000000000000000000000000000000000001c56541c38eede6957ecd5c47012712f21c8e4615c77390917a7f0223e837c41ae47e662741d7f0094ece4a3bf04dcf7f37db5bbae80d79fe1dc43052b768354aa", contractAddress: "", cumulativeGasUsed: "6157234", gasUsed: "110715", confirmations: "842256"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "86"}, {type: "uint256", name: "commitLastBlock", value: "6843961"}, {type: "uint256", name: "commit", value: "28743899391600226609994231157408968888633650357861017658454541043859879352555"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x56541c38eede6957ecd5c47012712f21c8e4615c77390917a7f0223e837c41ae"}, {type: "bytes32", name: "s", value: "0x47e662741d7f0094ece4a3bf04dcf7f37db5bbae80d79fe1dc43052b768354aa"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "86", "6843961", "28743899391600226609994231157408968888633650357861017658454541043859879352555", "28", "0x56541c38eede6957ecd5c47012712f21c8e4615c77390917a7f0223e837c41ae", "0x47e662741d7f0094ece4a3bf04dcf7f37db5bbae80d79fe1dc43052b768354aa", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544169085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "28743899391600226609994231157408968888633650357861017658454541043859879352555"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"2876129\", \"0x372c42f95c08e470d5a61ae... )", async function( ) {
		const txOriginal = {blockNumber: "6841465", timeStamp: "1544169100", hash: "0x23cc3649ad8bafe66cbfadae0a20b30e24b3e6c114ba0ddd3be860c637ecf7ad", nonce: "97", blockHash: "0xf91c5789252731d8287959a58d4bf502795f841d6e67bde3099d37919d65d037", transactionIndex: "41", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000002be2e1372c42f95c08e470d5a61aed2b653aa6a2243cf53a69254f9fe86a0107ce2ddd", contractAddress: "", cumulativeGasUsed: "1871845", gasUsed: "39419", confirmations: "842254"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "2876129"}, {type: "bytes32", name: "blockHash", value: "0x372c42f95c08e470d5a61aed2b653aa6a2243cf53a69254f9fe86a0107ce2ddd"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "2876129", "0x372c42f95c08e470d5a61aed2b653aa6a2243cf53a69254f9fe86a0107ce2ddd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544169100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "11162790697674418"}, {name: "dice", type: "uint256", value: "33"}, {name: "rollUnder", type: "uint256", value: "86"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"86\", \"6843965\", \"10010123347408597... )", async function( ) {
		const txOriginal = {blockNumber: "6841468", timeStamp: "1544169145", hash: "0x37128fe0c7ab7f29b6356278f1b3fa19d5947404e9e913e22825a2d949aa8093", nonce: "33", blockHash: "0x0c654dd125c63fb5a8e829ba6be558573227643a3ceb755b4905c85757a8d669", transactionIndex: "76", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000560000000000000000000000000000000000000000000000000000000000686e3ddd4f4a54ef4d4a23f71023650736a59e68f3b534f84473e5fd2efb636515d1b8000000000000000000000000000000000000000000000000000000000000001c46473eb3579998386df2fea25c21bef960ba119193f0247e96d422fc424c837f286b622df276ada1e8eb553da7cb1582e0576bac269aa6141080a7d8d599937d", contractAddress: "", cumulativeGasUsed: "2843246", gasUsed: "110779", confirmations: "842251"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "86"}, {type: "uint256", name: "commitLastBlock", value: "6843965"}, {type: "uint256", name: "commit", value: "100101233474085979545601137685231609051817156526002804110610608103090298409400"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x46473eb3579998386df2fea25c21bef960ba119193f0247e96d422fc424c837f"}, {type: "bytes32", name: "s", value: "0x286b622df276ada1e8eb553da7cb1582e0576bac269aa6141080a7d8d599937d"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "86", "6843965", "100101233474085979545601137685231609051817156526002804110610608103090298409400", "28", "0x46473eb3579998386df2fea25c21bef960ba119193f0247e96d422fc424c837f", "0x286b622df276ada1e8eb553da7cb1582e0576bac269aa6141080a7d8d599937d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544169145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "100101233474085979545601137685231609051817156526002804110610608103090298409400"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"5712823\", \"0x0c654dd125c63fb5a8e829b... )", async function( ) {
		const txOriginal = {blockNumber: "6841470", timeStamp: "1544169154", hash: "0x6b3465e9c0095542047137c3a9939389ce23bbbabb8c9f4862f31beba03a9f7d", nonce: "98", blockHash: "0x77b2d8932627dc915e23f1be1b84679d7ce00166ed2e8843a810833bb5faa2f8", transactionIndex: "76", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc0000000000000000000000000000000000000000000000000000000000572bb70c654dd125c63fb5a8e829ba6be558573227643a3ceb755b4905c85757a8d669", contractAddress: "", cumulativeGasUsed: "2611507", gasUsed: "39395", confirmations: "842249"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "5712823"}, {type: "bytes32", name: "blockHash", value: "0x0c654dd125c63fb5a8e829ba6be558573227643a3ceb755b4905c85757a8d669"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "5712823", "0x0c654dd125c63fb5a8e829ba6be558573227643a3ceb755b4905c85757a8d669", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544169154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "0"}, {name: "dice", type: "uint256", value: "92"}, {name: "rollUnder", type: "uint256", value: "86"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"72\", \"6843972\", \"10616119435507145... )", async function( ) {
		const txOriginal = {blockNumber: "6841476", timeStamp: "1544169273", hash: "0xb4aa374b0e7a6c66aef156b5eda8e82be9c6495b22fad7db492803d37c04d6d6", nonce: "34", blockHash: "0x6e09eafa540ed2ebadfe3e0d8177e4fcd004b013c41ed4b4c4ffab84652a3411", transactionIndex: "49", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000480000000000000000000000000000000000000000000000000000000000686e44eab51b4ea95a8e4906a22b6358f9d06b1203e1017bb41e39e9188c4d85896b22000000000000000000000000000000000000000000000000000000000000001bba3cdd343d167e5414e71d4500854023e3eeeb766835c0bbe19af4ca75cbbc851a1ee9c6d8a081adf81b9a7c1277df8e979d73767fa496893aed734d054bd7c2", contractAddress: "", cumulativeGasUsed: "2864728", gasUsed: "110715", confirmations: "842243"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "72"}, {type: "uint256", name: "commitLastBlock", value: "6843972"}, {type: "uint256", name: "commit", value: "106161194355071455614103850524998214013098919835940286030550375878432232401698"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xba3cdd343d167e5414e71d4500854023e3eeeb766835c0bbe19af4ca75cbbc85"}, {type: "bytes32", name: "s", value: "0x1a1ee9c6d8a081adf81b9a7c1277df8e979d73767fa496893aed734d054bd7c2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "72", "6843972", "106161194355071455614103850524998214013098919835940286030550375878432232401698", "27", "0xba3cdd343d167e5414e71d4500854023e3eeeb766835c0bbe19af4ca75cbbc85", "0x1a1ee9c6d8a081adf81b9a7c1277df8e979d73767fa496893aed734d054bd7c2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544169273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "106161194355071455614103850524998214013098919835940286030550375878432232401698"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"2593362\", \"0x6e09eafa540ed2ebadfe3e0... )", async function( ) {
		const txOriginal = {blockNumber: "6841478", timeStamp: "1544169325", hash: "0x54fb17d1e4f9063d03ced59f843597f89ac8d8aa74e3929624473d32d85d8c76", nonce: "99", blockHash: "0x55469030bc35ba44d7a19a74c3d7b59db5f8a1985263e870856bd0f7c69e4c26", transactionIndex: "110", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000002792526e09eafa540ed2ebadfe3e0d8177e4fcd004b013c41ed4b4c4ffab84652a3411", contractAddress: "", cumulativeGasUsed: "4196821", gasUsed: "39419", confirmations: "842241"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "2593362"}, {type: "bytes32", name: "blockHash", value: "0x6e09eafa540ed2ebadfe3e0d8177e4fcd004b013c41ed4b4c4ffab84652a3411"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "2593362", "0x6e09eafa540ed2ebadfe3e0d8177e4fcd004b013c41ed4b4c4ffab84652a3411", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544169325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "13333333333333333"}, {name: "dice", type: "uint256", value: "8"}, {name: "rollUnder", type: "uint256", value: "72"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"75\", \"6843992\", \"14967616136926457... )", async function( ) {
		const txOriginal = {blockNumber: "6841534", timeStamp: "1544170278", hash: "0xce3990b5e0ad5e21da9452d864811b74a52ecbdfcca33fc8535fe37bdb6951ef", nonce: "35", blockHash: "0x42e5cf8b8d5d214191e6e8d0e0468bcfe308b0d453bfdfea64a40b706e20e671", transactionIndex: "116", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c000000000000000000000000000000000000000000000000000000000000004b0000000000000000000000000000000000000000000000000000000000686e5821175eda5cb676704ff92939cd4f02c411129cd7166343681df6a30839cc8237000000000000000000000000000000000000000000000000000000000000001c37094632d4f6fad79bd00321473b9dc3c109ab3c76c01bd3982e7ff308c895c1067b44b8b233a07024c2bfcbf4af2440e08826212d7e3d0b372287bc76fc0a17", contractAddress: "", cumulativeGasUsed: "7797877", gasUsed: "110779", confirmations: "842185"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "75"}, {type: "uint256", name: "commitLastBlock", value: "6843992"}, {type: "uint256", name: "commit", value: "14967616136926457022286539458448967677259812766838179884198724414290357158455"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x37094632d4f6fad79bd00321473b9dc3c109ab3c76c01bd3982e7ff308c895c1"}, {type: "bytes32", name: "s", value: "0x067b44b8b233a07024c2bfcbf4af2440e08826212d7e3d0b372287bc76fc0a17"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "75", "6843992", "14967616136926457022286539458448967677259812766838179884198724414290357158455", "28", "0x37094632d4f6fad79bd00321473b9dc3c109ab3c76c01bd3982e7ff308c895c1", "0x067b44b8b233a07024c2bfcbf4af2440e08826212d7e3d0b372287bc76fc0a17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544170278 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "14967616136926457022286539458448967677259812766838179884198724414290357158455"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"6536420\", \"0x42e5cf8b8d5d214191e6e8d... )", async function( ) {
		const txOriginal = {blockNumber: "6841536", timeStamp: "1544170300", hash: "0x4cf8cc306db1eb3d0d094c07ef08c4cc8917386861086c56f7ddc70c0e1a87f9", nonce: "100", blockHash: "0x3b8c80d7ab3594da25904c1d869e86e98d7516b18c92f0c2322bfa9fda5fb500", transactionIndex: "119", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc000000000000000000000000000000000000000000000000000000000063bce442e5cf8b8d5d214191e6e8d0e0468bcfe308b0d453bfdfea64a40b706e20e671", contractAddress: "", cumulativeGasUsed: "3772418", gasUsed: "39419", confirmations: "842183"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "6536420"}, {type: "bytes32", name: "blockHash", value: "0x42e5cf8b8d5d214191e6e8d0e0468bcfe308b0d453bfdfea64a40b706e20e671"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "6536420", "0x42e5cf8b8d5d214191e6e8d0e0468bcfe308b0d453bfdfea64a40b706e20e671", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544170300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "12800000000000000"}, {name: "dice", type: "uint256", value: "20"}, {name: "rollUnder", type: "uint256", value: "75"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6844135\", \"57919549190998766... )", async function( ) {
		const txOriginal = {blockNumber: "6841650", timeStamp: "1544171972", hash: "0x3e2e967bbad9fae1524c55eabf5320990549d0eb4b60f9e03ca587ef548aa558", nonce: "36", blockHash: "0xc3b349bf232a2a10d40c02692801df741f3347c53a69aefb9d41de0bc1cb3300", transactionIndex: "137", from: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "20000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686ee70cce215c1ab318883f4ce4c9bbbb2eac99f48a00e9d7d6b6f6444f6640c3deb6000000000000000000000000000000000000000000000000000000000000001cbf4155b0d4b708fd566158314fb19c6e85ebde93766b018426e7548f872c2ae40cc72459baf9f615b846a31495041c7055e18e3952e5d01d4121f5cd5323413e", contractAddress: "", cumulativeGasUsed: "7186011", gasUsed: "110707", confirmations: "842069"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6844135"}, {type: "uint256", name: "commit", value: "5791954919099876632911525175404711876330872509834730875687491176574356807350"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xbf4155b0d4b708fd566158314fb19c6e85ebde93766b018426e7548f872c2ae4"}, {type: "bytes32", name: "s", value: "0x0cc72459baf9f615b846a31495041c7055e18e3952e5d01d4121f5cd5323413e"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6844135", "5791954919099876632911525175404711876330872509834730875687491176574356807350", "28", "0xbf4155b0d4b708fd566158314fb19c6e85ebde93766b018426e7548f872c2ae4", "0x0cc72459baf9f615b846a31495041c7055e18e3952e5d01d4121f5cd5323413e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544171972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "5791954919099876632911525175404711876330872509834730875687491176574356807350"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "227643181514549756" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6844137\", \"41287044200765886... )", async function( ) {
		const txOriginal = {blockNumber: "6841650", timeStamp: "1544171972", hash: "0xd3cb17707f4ea2ddf65e8bab623be13dcf5d93bd31da1d536a38feddcd9828d5", nonce: "101", blockHash: "0xc3b349bf232a2a10d40c02692801df741f3347c53a69aefb9d41de0bc1cb3300", transactionIndex: "141", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686ee95b47a38eee8d3c737e2158b1d4bca3a72d5f56aac3353637cf2794d5788e45c0000000000000000000000000000000000000000000000000000000000000001bd865986034d4fd11fa8703cb47eee162e74165f880ddf2ac79fb17f1ef2a48e02b59bf43286d382badd6104f8a2eef9020e0461d0c176953aae9945cace01a53", contractAddress: "", cumulativeGasUsed: "7441720", gasUsed: "110779", confirmations: "842069"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6844137"}, {type: "uint256", name: "commit", value: "41287044200765886820665358430804600354590754728340942432417157783790812022208"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd865986034d4fd11fa8703cb47eee162e74165f880ddf2ac79fb17f1ef2a48e0"}, {type: "bytes32", name: "s", value: "0x2b59bf43286d382badd6104f8a2eef9020e0461d0c176953aae9945cace01a53"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6844137", "41287044200765886820665358430804600354590754728340942432417157783790812022208", "27", "0xd865986034d4fd11fa8703cb47eee162e74165f880ddf2ac79fb17f1ef2a48e0", "0x2b59bf43286d382badd6104f8a2eef9020e0461d0c176953aae9945cace01a53", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544171972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "41287044200765886820665358430804600354590754728340942432417157783790812022208"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8697853\", \"0xc3b349bf232a2a10d40c026... )", async function( ) {
		const txOriginal = {blockNumber: "6841653", timeStamp: "1544171990", hash: "0x7beeb71c308cb153fb0db2d9169e16bdce069898f2fc1a886a2aa6425d8215e9", nonce: "102", blockHash: "0x524f5d1ff03335c170510c1a877af144378b4886346137ed5c014ed1733b8983", transactionIndex: "51", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc000000000000000000000000000000000000000000000000000000000084b7fdc3b349bf232a2a10d40c02692801df741f3347c53a69aefb9d41de0bc1cb3300", contractAddress: "", cumulativeGasUsed: "1904647", gasUsed: "39347", confirmations: "842066"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8697853"}, {type: "bytes32", name: "blockHash", value: "0xc3b349bf232a2a10d40c02692801df741f3347c53a69aefb9d41de0bc1cb3300"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8697853", "0xc3b349bf232a2a10d40c02692801df741f3347c53a69aefb9d41de0bc1cb3300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544171990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x5e2e95ba53d6fce42b991ebf397e055fa89bf800"}, {name: "amount", type: "uint256", value: "39200000000000000"}, {name: "dice", type: "uint256", value: "10"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "20000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"61\", \"6844155\", \"48148864331527717... )", async function( ) {
		const txOriginal = {blockNumber: "6841660", timeStamp: "1544172246", hash: "0xbff7df3d032a90496ca30b01c366f014ef7db2ef82ca7b6c5ef54854f6c3bc10", nonce: "7", blockHash: "0x3a875bc898145368f5f3b85195c9555130d47525bcb998656516ce4b8ac71991", transactionIndex: "190", from: "0x22e76212ff057427d67eba88c690612353d49457", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c000000000000000000000000000000000000000000000000000000000000003d0000000000000000000000000000000000000000000000000000000000686efb6a734a9d456b45811c9123d97a0461dbec432841edf519fda0dba6e6138f5983000000000000000000000000000000000000000000000000000000000000001b433594fffaad5c5dbff49cf78523abe2e5d207563be1525944ceb9a2ac4f75434d5e71d80b7bd9f646d9f510fd1819fbb6a84b47cc9cf0f7970ff2d528f2833d", contractAddress: "", cumulativeGasUsed: "6178957", gasUsed: "110779", confirmations: "842059"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "61"}, {type: "uint256", name: "commitLastBlock", value: "6844155"}, {type: "uint256", name: "commit", value: "48148864331527717671055583662439405616556552038479375542871261404043850766723"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x433594fffaad5c5dbff49cf78523abe2e5d207563be1525944ceb9a2ac4f7543"}, {type: "bytes32", name: "s", value: "0x4d5e71d80b7bd9f646d9f510fd1819fbb6a84b47cc9cf0f7970ff2d528f2833d"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "61", "6844155", "48148864331527717671055583662439405616556552038479375542871261404043850766723", "27", "0x433594fffaad5c5dbff49cf78523abe2e5d207563be1525944ceb9a2ac4f7543", "0x4d5e71d80b7bd9f646d9f510fd1819fbb6a84b47cc9cf0f7970ff2d528f2833d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544172246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "48148864331527717671055583662439405616556552038479375542871261404043850766723"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "539188920644750404" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"6003319\", \"0x3a875bc898145368f5f3b85... )", async function( ) {
		const txOriginal = {blockNumber: "6841662", timeStamp: "1544172291", hash: "0x1233a7104274b4bb5b59608011598bf6b22d93e36056ad138af3357a4e4ac38c", nonce: "103", blockHash: "0x53e9d881d9d6a375dd43f958fabfd515ca3e8d86fe061ea6a61b8f04b70be7fe", transactionIndex: "41", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000005b9a773a875bc898145368f5f3b85195c9555130d47525bcb998656516ce4b8ac71991", contractAddress: "", cumulativeGasUsed: "1108829", gasUsed: "39395", confirmations: "842057"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "6003319"}, {type: "bytes32", name: "blockHash", value: "0x3a875bc898145368f5f3b85195c9555130d47525bcb998656516ce4b8ac71991"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "6003319", "0x3a875bc898145368f5f3b85195c9555130d47525bcb998656516ce4b8ac71991", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544172291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x22e76212ff057427d67eba88c690612353d49457"}, {name: "amount", type: "uint256", value: "0"}, {name: "dice", type: "uint256", value: "71"}, {name: "rollUnder", type: "uint256", value: "61"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6841907\", \"48758386558330604... )", async function( ) {
		const txOriginal = {blockNumber: "6841900", timeStamp: "1544175508", hash: "0xa1b52c5beaba9c6c9b399301159212aad45ce6dd6ac3e32bf1bd05cc1ad7b122", nonce: "104", blockHash: "0x2300d214aff0fea38fe4389fcd1189df0c4acca455dff0f015c8132492e3076a", transactionIndex: "86", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000006866336bcc44d132927c3150aefcbd4d5b50bb7687d1df110acfaeb39b36f36eee0e60000000000000000000000000000000000000000000000000000000000000001bcc1d0c278e749a4f62880f83865dfe3c03553ec8284427ff19b827de0ede009067e441dc6495a1d8048564083ef80215441df245d9c1a9056a0863ceffc6bdbe", contractAddress: "", cumulativeGasUsed: "4047915", gasUsed: "110715", confirmations: "841819"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6841907"}, {type: "uint256", name: "commit", value: "48758386558330604221645851725856769694931595155135221600836996496175494205024"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xcc1d0c278e749a4f62880f83865dfe3c03553ec8284427ff19b827de0ede0090"}, {type: "bytes32", name: "s", value: "0x67e441dc6495a1d8048564083ef80215441df245d9c1a9056a0863ceffc6bdbe"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6841907", "48758386558330604221645851725856769694931595155135221600836996496175494205024", "27", "0xcc1d0c278e749a4f62880f83865dfe3c03553ec8284427ff19b827de0ede0090", "0x67e441dc6495a1d8048564083ef80215441df245d9c1a9056a0863ceffc6bdbe", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544175508 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "48758386558330604221645851725856769694931595155135221600836996496175494205024"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"50\", \"6841913\", \"75876741088905393... )", async function( ) {
		const txOriginal = {blockNumber: "6841906", timeStamp: "1544175574", hash: "0x1a7e7b682b72747ce8fba1877c802d7986f4e25233e9b94293621bea8cc3f137", nonce: "105", blockHash: "0xf71a5d51869bb6708e203be92a7e30a5e2f7de5858860eff716f8da11ed3eb07", transactionIndex: "85", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000686639a7c0b6ab692d62584dd1918f8f4dfd2a2893aca08b37615312db79c59616b3d8000000000000000000000000000000000000000000000000000000000000001bd1d9789da4e7fd2c79973bfef0cfc192f8154cf1402738709f8991748ace599b1169a605d143ef1b453cd37a6e9acd03d94fa812a0dcd789fc541995a0db2994", contractAddress: "", cumulativeGasUsed: "3875238", gasUsed: "110779", confirmations: "841813"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "50"}, {type: "uint256", name: "commitLastBlock", value: "6841913"}, {type: "uint256", name: "commit", value: "75876741088905393200683611341963926182115806438217897063570161828706125263832"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd1d9789da4e7fd2c79973bfef0cfc192f8154cf1402738709f8991748ace599b"}, {type: "bytes32", name: "s", value: "0x1169a605d143ef1b453cd37a6e9acd03d94fa812a0dcd789fc541995a0db2994"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "50", "6841913", "75876741088905393200683611341963926182115806438217897063570161828706125263832", "27", "0xd1d9789da4e7fd2c79973bfef0cfc192f8154cf1402738709f8991748ace599b", "0x1169a605d143ef1b453cd37a6e9acd03d94fa812a0dcd789fc541995a0db2994", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544175574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "75876741088905393200683611341963926182115806438217897063570161828706125263832"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8061750\", \"0x2300d214aff0fea38fe4389... )", async function( ) {
		const txOriginal = {blockNumber: "6841913", timeStamp: "1544175747", hash: "0xcfc3cd092f1ab9806f8f8e7e9207a5185c9e68afbc8965dea06bee539d968cb1", nonce: "106", blockHash: "0x58f0f9525508db5af3c3b24bf1fceefa188f011912bbc2d325e8940eeba9a201", transactionIndex: "145", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "54355", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000007b03362300d214aff0fea38fe4389fcd1189df0c4acca455dff0f015c8132492e3076a", contractAddress: "", cumulativeGasUsed: "7354216", gasUsed: "39355", confirmations: "841806"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8061750"}, {type: "bytes32", name: "blockHash", value: "0x2300d214aff0fea38fe4389fcd1189df0c4acca455dff0f015c8132492e3076a"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8061750", "0x2300d214aff0fea38fe4389fcd1189df0c4acca455dff0f015c8132492e3076a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544175747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "19200000000000000"}, {name: "dice", type: "uint256", value: "7"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"9081599\", \"0xf71a5d51869bb6708e203be... )", async function( ) {
		const txOriginal = {blockNumber: "6841918", timeStamp: "1544175898", hash: "0x015d8a13756142a816edf5efaad72d6246b6466a231a0c1ae976e4812f21bdce", nonce: "107", blockHash: "0x72f8367905b6351eb5c0e2c6188f8da3207fa6a472b08454f59fd9c721d211fc", transactionIndex: "173", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "54395", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000008a92fff71a5d51869bb6708e203be92a7e30a5e2f7de5858860eff716f8da11ed3eb07", contractAddress: "", cumulativeGasUsed: "7790688", gasUsed: "39395", confirmations: "841801"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "9081599"}, {type: "bytes32", name: "blockHash", value: "0xf71a5d51869bb6708e203be92a7e30a5e2f7de5858860eff716f8da11ed3eb07"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "9081599", "0xf71a5d51869bb6708e203be92a7e30a5e2f7de5858860eff716f8da11ed3eb07", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544175898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac"}, {name: "amount", type: "uint256", value: "0"}, {name: "dice", type: "uint256", value: "85"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"96\", \"6841933\", \"12914832052021232... )", async function( ) {
		const txOriginal = {blockNumber: "6841927", timeStamp: "1544176077", hash: "0x083d2b7f7b7ced4b814239ca8e48fd07f4cfa3428166483f7727130524b94b4e", nonce: "8", blockHash: "0xec8b652bf25bbbf0e16fa7385a35b6a9b6e51bad45f49f654a1678d28f11a353", transactionIndex: "65", from: "0x22e76212ff057427d67eba88c690612353d49457", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000068664d1c8d8930d313e0bf765e55e2838bd265097cdfdde1afcaec32d55676375fd5c6000000000000000000000000000000000000000000000000000000000000001c85f01503e3926b09f401d282652b02acd38c58d148dc9070e08036acbc5e94c06e638324b562c2c51ca194d18ba19fda8f5fbb5e2ab9da08808c317b4c09eeb4", contractAddress: "", cumulativeGasUsed: "2596448", gasUsed: "110779", confirmations: "841792"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "96"}, {type: "uint256", name: "commitLastBlock", value: "6841933"}, {type: "uint256", name: "commit", value: "12914832052021232240057484858921914340005079828594756721650403931883523003846"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x85f01503e3926b09f401d282652b02acd38c58d148dc9070e08036acbc5e94c0"}, {type: "bytes32", name: "s", value: "0x6e638324b562c2c51ca194d18ba19fda8f5fbb5e2ab9da08808c317b4c09eeb4"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "96", "6841933", "12914832052021232240057484858921914340005079828594756721650403931883523003846", "28", "0x85f01503e3926b09f401d282652b02acd38c58d148dc9070e08036acbc5e94c0", "0x6e638324b562c2c51ca194d18ba19fda8f5fbb5e2ab9da08808c317b4c09eeb4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544176077 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "12914832052021232240057484858921914340005079828594756721650403931883523003846"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "539188920644750404" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"8023608\", \"0xec8b652bf25bbbf0e16fa73... )", async function( ) {
		const txOriginal = {blockNumber: "6841929", timeStamp: "1544176095", hash: "0xc6681ecdd99e3d3572696e1947383a63f9704a2cae23a8c487ad2b5135aee850", nonce: "108", blockHash: "0x83f0e6f394b58feba1091a0d9cc2d7329aa569b1e1e551ff7378f0e2be1c641b", transactionIndex: "28", from: "0xae113b2fa9df869e45f9578ea8b02e0bc30ed7ac", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "0", gas: "3000000", gasPrice: "18875000000", isError: "0", txreceipt_status: "1", input: "0xca722cdc00000000000000000000000000000000000000000000000000000000007a6e38ec8b652bf25bbbf0e16fa7385a35b6a9b6e51bad45f49f654a1678d28f11a353", contractAddress: "", cumulativeGasUsed: "1024069", gasUsed: "39419", confirmations: "841790"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "reveal", value: "8023608"}, {type: "bytes32", name: "blockHash", value: "0xec8b652bf25bbbf0e16fa7385a35b6a9b6e51bad45f49f654a1678d28f11a353"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(uint256,bytes32)" ]( "8023608", "0xec8b652bf25bbbf0e16fa7385a35b6a9b6e51bad45f49f654a1678d28f11a353", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544176095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "dice", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "betAmount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x22e76212ff057427d67eba88c690612353d49457"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "dice", type: "uint256", value: "66"}, {name: "rollUnder", type: "uint256", value: "96"}, {name: "betAmount", type: "uint256", value: "10000000000000000"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5882613602115200" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"96\", \"6841942\", \"24039205259065987... )", async function( ) {
		const txOriginal = {blockNumber: "6841936", timeStamp: "1544176234", hash: "0x4f39d586ecbcc755018e5e1785251c199c03820a9b8933e36c9548ce97ff1020", nonce: "9", blockHash: "0xddd2077f66e95a9e89769fbc5c32aaf65dc1765320d0a5377c27297a95680e3c", transactionIndex: "92", from: "0x22e76212ff057427d67eba88c690612353d49457", to: "0xc06b5a46c0028f4b79f25d70e185155a0b471596", value: "10000000000000000", gas: "300000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xbb5a4f4c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000006866563525b5400bafb2b6730179ab12c41df1b955b4599f56985b1a4b76003d7d2dda000000000000000000000000000000000000000000000000000000000000001cf88e12875d6c704b85fd7e2d5f72316bf0ed129e702134c174b9e9a0943df6a507605fa1771bb7f9a80cc381a8153afe693e3136f862096a601a686472208bf0", contractAddress: "", cumulativeGasUsed: "4121356", gasUsed: "110715", confirmations: "841783"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "96"}, {type: "uint256", name: "commitLastBlock", value: "6841942"}, {type: "uint256", name: "commit", value: "24039205259065987806628493903436940763830180733103422499262673544433534578138"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf88e12875d6c704b85fd7e2d5f72316bf0ed129e702134c174b9e9a0943df6a5"}, {type: "bytes32", name: "s", value: "0x07605fa1771bb7f9a80cc381a8153afe693e3136f862096a601a686472208bf0"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint8,bytes32,bytes32)" ]( "96", "6841942", "24039205259065987806628493903436940763830180733103422499262673544433534578138", "28", "0xf88e12875d6c704b85fd7e2d5f72316bf0ed129e702134c174b9e9a0943df6a5", "0x07605fa1771bb7f9a80cc381a8153afe693e3136f862096a601a686472208bf0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544176234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "24039205259065987806628493903436940763830180733103422499262673544433534578138"}], address: "0xc06b5a46c0028f4b79f25d70e185155a0b471596"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "539188920644750404" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "19200000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
