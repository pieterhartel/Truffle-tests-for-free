const ArtistEditionControls = artifacts.require( "./ArtistEditionControls.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ArtistEditionControls" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x06C741e6Df49D7FdA1F27f75ffFD238D87619bA1", "0x3f8C962eb167aD2f80C72b5F933511CcDF0719D4", "0xFBeef911Dc5821886e1dda71586d90eD28174B7d", "0x576a655161B5502dCf40602BE1f3519A89b71658", "0xaB3627317c43D394eb171170f818153B976D28A3", "0xf8b32D30aC6Ab3030595432533D7836FD76B078d", "0x21316E6A4F0Af45E5F1503984E83B10C53b177D8", "0xa4aD045d62a493f0ED883b413866448AfB13087C", "0xe0F228070D8F7b5C25E9375Fa70FA418f8dfEDf8", "0x076E89FE9e24c191EbEE53CcEeC5356600C8d059", "0x4AF4aEBe930e938FA11aD28cD2c88645cCe739A1", "0x61987699055394c65355F2797D3e4e589f7FaBf4", "0x08f950816358F4306B70fB319E4F35c592d1B8a8", "0xceF2bf4aD6D84Aa37Fcc4Cab6530028EB31c8e69", "0xe13d4abEe4B304b67C52A56871141caD1B833aa7", "0x89C5dca00B9bf5AD746b91EC911c56Cb4AEE17F0", "0x3768225622d53FfCc1E00eaC53a2A870ECd825C8", "0x2e0B873d26f6d90f347757ed0d041bC65E02a89f", "0xE88cfe8535AF121121a4b475eEFD13dAE4fBC4Cc"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "kodaAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PriceChanged(uint256,address,uint256)", "Pause()", "Unpause()", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x7b9e70728348c5a660506950e5eeb19dee00e0a53e8ce602353738185a8cd372", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6659821 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6889579 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_kodaAddress", value: 4}], name: "ArtistEditionControls", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "kodaAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "kodaAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ArtistEditionControls", function( accounts ) {

	it( "TEST: ArtistEditionControls( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6659821", timeStamp: "1541589685", hash: "0x3a9e07323bb40a3f4d3ad1c8b6916a2d9cfefc0f7a262c252a41b01da4880037", nonce: "746", blockHash: "0xd44e107c31333291dc6bdcc8f71003073a0f71d750861ae52ffd25fff242f963", transactionIndex: "20", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: 0, value: "0", gas: "6075039", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd73ea8ed000000000000000000000000fbeef911dc5821886e1dda71586d90ed28174b7d", contractAddress: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", cumulativeGasUsed: "2173666", gasUsed: "827058", confirmations: "1062639"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_kodaAddress", value: addressList[4]}], name: "ArtistEditionControls", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ArtistEditionControls.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541589685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ArtistEditionControls.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1890063307862314066" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[6], \"19600\" )", async function( ) {
		const txOriginal = {blockNumber: "6662064", timeStamp: "1541620821", hash: "0xdd14b0e8506dafa4444cfe10644dd2a5831d85a63ee268b69edef186bd72074a", nonce: "21", blockHash: "0x1665e4705fdbc9d3d67575821aebd1f4a08c7918f0bdf17664f1dc7a04a709e9", transactionIndex: "22", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "471999", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c97000000000000000000000000ab3627317c43d394eb171170f818153b976d28a30000000000000000000000000000000000000000000000000000000000004c90", contractAddress: "", cumulativeGasUsed: "1293173", gasUsed: "310400", confirmations: "1060396"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[6]}, {type: "uint256", name: "_editionNumber", value: "19600"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[6], "19600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541620821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[8], \"12000\" )", async function( ) {
		const txOriginal = {blockNumber: "6662618", timeStamp: "1541628410", hash: "0x02626aab31e596a1124564eefcdc7e02a1b927a237369bcebb858d6927bebb20", nonce: "64", blockHash: "0x244fe9386e2c324cb6eca8b3dc7f6aedd4210d122976e39d2f251c39f6f9f786", transactionIndex: "163", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "471999", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c9700000000000000000000000021316e6a4f0af45e5f1503984e83b10c53b177d80000000000000000000000000000000000000000000000000000000000002ee0", contractAddress: "", cumulativeGasUsed: "7574113", gasUsed: "310400", confirmations: "1059842"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[8]}, {type: "uint256", name: "_editionNumber", value: "12000"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[8], "12000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541628410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16874917495321770994" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"12000\", \"250000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6662629", timeStamp: "1541628558", hash: "0xa770d19479d6579275f83abc0b1aff30bcc92fe3687234afef65d146fa7414df", nonce: "65", blockHash: "0xf8402784867eba83b382a43ea507fc2fde92c9dbc68f0583f77e392b1c49127e", transactionIndex: "112", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000002ee000000000000000000000000000000000000000000000000003782dace9d90000", contractAddress: "", cumulativeGasUsed: "5918092", gasUsed: "40818", confirmations: "1059831"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "12000"}, {type: "uint256", name: "_priceInWei", value: "250000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "12000", "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541628558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "12000"}, {name: "_artist", type: "address", value: "0xf8b32d30ac6ab3030595432533d7836fd76b078d"}, {name: "_priceInWei", type: "uint256", value: "250000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16874917495321770994" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"22900\", \"60000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6662710", timeStamp: "1541629686", hash: "0x82efa9ffbabd88de794288b0830695b96bc411f22e70bc235e9330b01077c1ff", nonce: "153", blockHash: "0x80ae750a76201084b8dbdf71ff503045991f854798bf76af2f68c04e74984226", transactionIndex: "31", from: "0xa4ad045d62a493f0ed883b413866448afb13087c", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000597400000000000000000000000000000000000000000000000000d529ae9e860000", contractAddress: "", cumulativeGasUsed: "1129274", gasUsed: "40754", confirmations: "1059750"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "22900"}, {type: "uint256", name: "_priceInWei", value: "60000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "22900", "60000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541629686 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "22900"}, {name: "_artist", type: "address", value: "0xa4ad045d62a493f0ed883b413866448afb13087c"}, {name: "_priceInWei", type: "uint256", value: "60000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3039346874605602457" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"21000\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6662712", timeStamp: "1541629743", hash: "0xb34c409c180eef34423593c8f4c81e8790285466486aa0c9b551cb6489934f44", nonce: "154", blockHash: "0x3c9b47ef0907d6b509a0106e8f3c22a7f9c99691ee903e29e4202c7b37f994f0", transactionIndex: "65", from: "0xa4ad045d62a493f0ed883b413866448afb13087c", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000520800000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "3205856", gasUsed: "40754", confirmations: "1059748"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21000"}, {type: "uint256", name: "_priceInWei", value: "50000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "21000", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541629743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "21000"}, {name: "_artist", type: "address", value: "0xa4ad045d62a493f0ed883b413866448afb13087c"}, {name: "_priceInWei", type: "uint256", value: "50000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3039346874605602457" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"21000\", \"60000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6662733", timeStamp: "1541630090", hash: "0x420e32e7f1d5e5155569999cd3229c5ef0e61b1431846a0bf610deb78ddbdd14", nonce: "155", blockHash: "0x56692fef62a4b08f17a6c723faba952dd6ec71c763ca3947c1310e82ce6234d3", transactionIndex: "53", from: "0xa4ad045d62a493f0ed883b413866448afb13087c", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000520800000000000000000000000000000000000000000000000000d529ae9e860000", contractAddress: "", cumulativeGasUsed: "4306436", gasUsed: "40754", confirmations: "1059727"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21000"}, {type: "uint256", name: "_priceInWei", value: "60000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "21000", "60000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541630090 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "21000"}, {name: "_artist", type: "address", value: "0xa4ad045d62a493f0ed883b413866448afb13087c"}, {name: "_priceInWei", type: "uint256", value: "60000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3039346874605602457" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"8900\", \"250000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6663974", timeStamp: "1541647591", hash: "0x2ab1e307d18573619cea87237a02294aebd77099943526a2375f6ea57b67fcb5", nonce: "9", blockHash: "0x98033cfeb0bcf59309ff72e17fe1c872f44e8501b28efb81db908f6a1e4da748", transactionIndex: "56", from: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "48981", gasPrice: "10350000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000022c400000000000000000000000000000000000000000000000003782dace9d90000", contractAddress: "", cumulativeGasUsed: "2797135", gasUsed: "40818", confirmations: "1058486"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "8900"}, {type: "uint256", name: "_priceInWei", value: "250000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "8900", "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541647591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "8900"}, {name: "_artist", type: "address", value: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8"}, {name: "_priceInWei", type: "uint256", value: "250000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "512726707654654282" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"9000\", \"250000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6663977", timeStamp: "1541647636", hash: "0x3902edd36b2c692986d99f26265c581b5c9a70187154c9bc5632f47ff59afe85", nonce: "10", blockHash: "0x1e35a72b59e93a85410652ef0e5f5d40b39c6e9950728777e4eaa530fc312490", transactionIndex: "94", from: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "48981", gasPrice: "10350000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000232800000000000000000000000000000000000000000000000003782dace9d90000", contractAddress: "", cumulativeGasUsed: "4858374", gasUsed: "40818", confirmations: "1058483"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9000"}, {type: "uint256", name: "_priceInWei", value: "250000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "9000", "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541647636 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "9000"}, {name: "_artist", type: "address", value: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8"}, {name: "_priceInWei", type: "uint256", value: "250000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "512726707654654282" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"21300\", \"150000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6663979", timeStamp: "1541647702", hash: "0x6453fb95743f3e4c39b795099a24f244e5fe72c9765a8bd12ed0f2d4fc27e906", nonce: "11", blockHash: "0x0ea9f870b3a6347fb1cccbac1bbb342c5048598a305f9a1bcf467c810726f4da", transactionIndex: "87", from: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "48981", gasPrice: "10350000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000053340000000000000000000000000000000000000000000000000214e8348c4f0000", contractAddress: "", cumulativeGasUsed: "4321171", gasUsed: "40818", confirmations: "1058481"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21300"}, {type: "uint256", name: "_priceInWei", value: "150000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "21300", "150000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541647702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "21300"}, {name: "_artist", type: "address", value: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8"}, {name: "_priceInWei", type: "uint256", value: "150000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "512726707654654282" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[11], \"21000\" )", async function( ) {
		const txOriginal = {blockNumber: "6667657", timeStamp: "1541699951", hash: "0x6b7e445a5c069c137c4a9fbc871de93910eed9622a986fa134bd2550d70a456c", nonce: "156", blockHash: "0xfde9bd559ef6ffa94077c3287ced9fe20a6e49c48a1315b0686af10725533f85", transactionIndex: "71", from: "0xa4ad045d62a493f0ed883b413866448afb13087c", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "494760", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c97000000000000000000000000076e89fe9e24c191ebee53cceec5356600c8d0590000000000000000000000000000000000000000000000000000000000005208", contractAddress: "", cumulativeGasUsed: "4334321", gasUsed: "325336", confirmations: "1054803"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[11]}, {type: "uint256", name: "_editionNumber", value: "21000"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[11], "21000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541699951 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3039346874605602457" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"23900\", \"75000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6675214", timeStamp: "1541807180", hash: "0xac726395c814e93579b9adb1b86427a336d0f0ec20e9c9d5cd93c40e17d5facc", nonce: "113", blockHash: "0xf72725a40cad16966848a2a90263b6cb4ca908335b09735684eb4e55ab4b3864", transactionIndex: "61", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61323", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000005d5c000000000000000000000000000000000000000000000000010a741a46278000", contractAddress: "", cumulativeGasUsed: "6153299", gasUsed: "40882", confirmations: "1047246"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "23900"}, {type: "uint256", name: "_priceInWei", value: "75000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "23900", "75000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541807180 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "23900"}, {name: "_artist", type: "address", value: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1"}, {name: "_priceInWei", type: "uint256", value: "75000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"24000\", \"75000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6675218", timeStamp: "1541807261", hash: "0xcb118b56cee8c3756f0cde863c543e57aa025aab3507d67419dc9d5f1473f6cf", nonce: "114", blockHash: "0x2162bcaa9da8749cdb5dd9802db260d005cd24789ada5417ffc29f7b9ed4068b", transactionIndex: "133", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61323", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000005dc0000000000000000000000000000000000000000000000000010a741a46278000", contractAddress: "", cumulativeGasUsed: "7950330", gasUsed: "40882", confirmations: "1047242"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "24000"}, {type: "uint256", name: "_priceInWei", value: "75000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "24000", "75000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541807261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "24000"}, {name: "_artist", type: "address", value: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1"}, {name: "_priceInWei", type: "uint256", value: "75000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"19600\", \"60000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6677505", timeStamp: "1541839644", hash: "0xd554a796a0bfa953bc0460db30af6e1334946496d8485f8d79f8a22b5b73f21b", nonce: "32", blockHash: "0x59aa056c50ecafa34b89bb387e4f84d749c85ae4113ea4c3524f22581025ee8a", transactionIndex: "114", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000004c9000000000000000000000000000000000000000000000000000d529ae9e860000", contractAddress: "", cumulativeGasUsed: "5219381", gasUsed: "40754", confirmations: "1044955"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19600"}, {type: "uint256", name: "_priceInWei", value: "60000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "19600", "60000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541839644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "19600"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "60000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25800\", \"20000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6677514", timeStamp: "1541839756", hash: "0x7f734f2e8f5a411a0c1ae9edaba52b34a47fc0a8b4120b543c71b5e1bc8c7c60", nonce: "33", blockHash: "0x067cd4de69ce036bce1a267a416c548b0edbe75cd549c25ec362ab571607ef96", transactionIndex: "23", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000064c800000000000000000000000000000000000000000000000000470de4df820000", contractAddress: "", cumulativeGasUsed: "1133965", gasUsed: "40754", confirmations: "1044946"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25800"}, {type: "uint256", name: "_priceInWei", value: "20000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25800", "20000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541839756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25800"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "20000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25800\", \"60000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6689736", timeStamp: "1542012372", hash: "0x011bdbe2bb7c6998af30753386f6aa2bfc5658c333dbd7d3456d845ae59ba95a", nonce: "43", blockHash: "0x8bf60007f43ed171049faa034cd234bf3df8c0bdd888398d49d59bc557acc7f8", transactionIndex: "82", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000064c800000000000000000000000000000000000000000000000000d529ae9e860000", contractAddress: "", cumulativeGasUsed: "7700910", gasUsed: "40754", confirmations: "1032724"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25800"}, {type: "uint256", name: "_priceInWei", value: "60000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25800", "60000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542012372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25800"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "60000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25700\", \"30000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6689750", timeStamp: "1542012595", hash: "0xc5fae4b672cbf6ee183c48bc292780119b78e0cb893e23e3d63294846fa01865", nonce: "44", blockHash: "0xd259d1c42fc753676bf2342eda73268508b569bf182f765d95258bcd7da75f6c", transactionIndex: "173", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006464000000000000000000000000000000000000000000000000006a94d74f430000", contractAddress: "", cumulativeGasUsed: "7951311", gasUsed: "40754", confirmations: "1032710"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25700"}, {type: "uint256", name: "_priceInWei", value: "30000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25700", "30000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542012595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25700"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "30000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25700\", \"70000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6693431", timeStamp: "1542063707", hash: "0xcc9754832764ec62cd8982f17032a79c05ba5294a66991bcbd063e3c5c3476ef", nonce: "57", blockHash: "0xa8c0e6e9ca15fa4aee77cfabcf6a7c40446ec5e84361dcc8b906a087b2602cc0", transactionIndex: "112", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000646400000000000000000000000000000000000000000000000000f8b0a10e470000", contractAddress: "", cumulativeGasUsed: "6226495", gasUsed: "40754", confirmations: "1029029"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25700"}, {type: "uint256", name: "_priceInWei", value: "70000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25700", "70000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542063707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25700"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "70000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[6], \"23900\" )", async function( ) {
		const txOriginal = {blockNumber: "6698637", timeStamp: "1542138069", hash: "0xb6487822a888560ccf5010d37c034065beee4eb67a97c66ede0133d4b9991bed", nonce: "119", blockHash: "0x9057cd2053d1b0c257aba03981b7af21b84b89ef058b2702a726cb2b8d7bf3ce", transactionIndex: "55", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "249142", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xcbce4c97000000000000000000000000ab3627317c43d394eb171170f818153b976d28a30000000000000000000000000000000000000000000000000000000000005d5c", contractAddress: "", cumulativeGasUsed: "3761677", gasUsed: "245798", confirmations: "1023823"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[6]}, {type: "uint256", name: "_editionNumber", value: "23900"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[6], "23900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542138069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[6], \"23900\" )", async function( ) {
		const txOriginal = {blockNumber: "6698646", timeStamp: "1542138169", hash: "0x0dc2f28f256989016e38f010f7074c8522bdf6dfe2614864fd9e5b2b29eb75a6", nonce: "120", blockHash: "0x7afc55756d77382d4ce48cca059e3aab07f2f1c9b4590a73d174c84091ef960d", transactionIndex: "102", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "449142", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c97000000000000000000000000ab3627317c43d394eb171170f818153b976d28a30000000000000000000000000000000000000000000000000000000000005d5c", contractAddress: "", cumulativeGasUsed: "6742454", gasUsed: "295400", confirmations: "1023814"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[6]}, {type: "uint256", name: "_editionNumber", value: "23900"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[6], "23900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542138169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[10], \"22900\" )", async function( ) {
		const txOriginal = {blockNumber: "6699119", timeStamp: "1542145021", hash: "0x1ae89bde7595393c88f451fb875c1635ff19967c5a98c46bbaa651e18b327f93", nonce: "161", blockHash: "0xe1f5a14cf9c5d069a2e35e88df60a004cf0b3100537054a9660a3646f084d0c3", transactionIndex: "24", from: "0xa4ad045d62a493f0ed883b413866448afb13087c", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "449142", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c97000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf80000000000000000000000000000000000000000000000000000000000005974", contractAddress: "", cumulativeGasUsed: "1328573", gasUsed: "295400", confirmations: "1023341"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[10]}, {type: "uint256", name: "_editionNumber", value: "22900"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[10], "22900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542145021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3039346874605602457" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[9], \"26500\" )", async function( ) {
		const txOriginal = {blockNumber: "6700728", timeStamp: "1542167234", hash: "0xac0e02b72d1a1cb5086b63302ce74faa7355374859b3ad3f14763a877a09e0e1", nonce: "12", blockHash: "0x3a98bb515fa891445172fbab0a3c895afa272478568f22b649f082dbadcb96dd", transactionIndex: "43", from: "0xe0f228070d8f7b5c25e9375fa70fa418f8dfedf8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "377599", gasPrice: "8165000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c97000000000000000000000000a4ad045d62a493f0ed883b413866448afb13087c0000000000000000000000000000000000000000000000000000000000006784", contractAddress: "", cumulativeGasUsed: "1923403", gasUsed: "310400", confirmations: "1021732"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[9]}, {type: "uint256", name: "_editionNumber", value: "26500"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[9], "26500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542167234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "512726707654654282" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25600\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6702678", timeStamp: "1542195491", hash: "0x242c93207c5d971a1e0f09325ba8fdd7e9863ae9bd2a8749a3b9cac158c41d37", nonce: "68", blockHash: "0x8e3d6f17c45df31fcd789bf53495368a13a88ec0b171773b374fe2642e1b49d7", transactionIndex: "133", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61035", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "6126085", gasUsed: "40690", confirmations: "1019782"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25600"}, {type: "uint256", name: "_priceInWei", value: "50000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25600", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542195491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25600"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "50000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25600\", \"40000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6702681", timeStamp: "1542195577", hash: "0xc458ab8dfac69c03e707accb1a054699059c3074f13b42b509e7c7d1222a730e", nonce: "69", blockHash: "0x16dde46eb4f3b5285d1c86328a77843827acb3abcbc04dfdd1d5e7782e3382a4", transactionIndex: "55", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61035", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "4015246", gasUsed: "40690", confirmations: "1019779"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25600"}, {type: "uint256", name: "_priceInWei", value: "40000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25600", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542195577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25600"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "40000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[13], \"27700\" )", async function( ) {
		const txOriginal = {blockNumber: "6704199", timeStamp: "1542216920", hash: "0xcf7aca4971a3ab4bfe108c963d65748cb177df5538aa311cc53e59cc040b5c63", nonce: "25", blockHash: "0xd3ca096e3a91d6c52d7e0b5b848292b753c70cbea7dd8624ba9b8358141689e8", transactionIndex: "129", from: "0xab3627317c43d394eb171170f818153b976d28a3", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "471999", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c9700000000000000000000000061987699055394c65355f2797d3e4e589f7fabf40000000000000000000000000000000000000000000000000000000000006c34", contractAddress: "", cumulativeGasUsed: "5428976", gasUsed: "310400", confirmations: "1018261"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[13]}, {type: "uint256", name: "_editionNumber", value: "27700"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[13], "27700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542216920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "137738583546770672" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25600\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6707760", timeStamp: "1542267536", hash: "0x2322eea0bd8910a32567ca50dc4f84ddf2f272a831355e166ace64b26f0d507e", nonce: "70", blockHash: "0xfe9bce38ea14d8f998b49c7ef97f67b9e5c892ca2e3f3fee79f122e9b903520d", transactionIndex: "127", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "7962211", gasUsed: "40754", confirmations: "1014700"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25600"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25600", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542267536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25600"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25900\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6714014", timeStamp: "1542355233", hash: "0xad92757ed97eac56c4a211fb7ecfa0d9011455081c94ca91ce15d8097b6ab068", nonce: "73", blockHash: "0xd08ae45ee6a9fb78b9eea028d85fad0a7970de3e28dfefe5d480b18b8ac3243c", transactionIndex: "207", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000652c000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "7596927", gasUsed: "40818", confirmations: "1008446"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25900"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25900", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542355233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25900"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25800\", \"40000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6720013", timeStamp: "1542440239", hash: "0x30ad2652dc1c673dea3e6a1ccb881012115218d4261fb24fd7a98d4b75e23ee8", nonce: "79", blockHash: "0x4d3e3b75cad95f835617a0894bfdb7d38a250457110f2bf26c091e1f8a628c7e", transactionIndex: "150", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000064c8000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "7406165", gasUsed: "40754", confirmations: "1002447"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25800"}, {type: "uint256", name: "_priceInWei", value: "40000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25800", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542440239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25800"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "40000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"28500\", \"250000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6721083", timeStamp: "1542455277", hash: "0xc2ffd877165945a99ccef3a123dece8874e57a054ab80cdb5f3e45b3a5feffc9", nonce: "0", blockHash: "0x57cd5f726a8fddc01932fd516d0535fd2d38fcdc6f2203a205679833fab2bfe0", transactionIndex: "90", from: "0x08f950816358f4306b70fb319e4f35c592d1b8a8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006f5400000000000000000000000000000000000000000000000003782dace9d90000", contractAddress: "", cumulativeGasUsed: "4916507", gasUsed: "40818", confirmations: "1001377"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "28500"}, {type: "uint256", name: "_priceInWei", value: "250000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "28500", "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542455277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "28500"}, {name: "_artist", type: "address", value: "0x08f950816358f4306b70fb319e4f35c592d1b8a8"}, {name: "_priceInWei", type: "uint256", value: "250000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1453859448536821806" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"28000\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6727995", timeStamp: "1542552457", hash: "0x8ec7c1fb468bca9cdb57632a055de3c7ee96d2e4de12edbf540ef29535a94541", nonce: "15", blockHash: "0xfc8af213ef14479334f959726404aa4e8532a142ee5e4efb2d74d3f3411a6ecb", transactionIndex: "34", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006d60000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "7344479", gasUsed: "40818", confirmations: "994465"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "28000"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "28000", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542552457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "28000"}, {name: "_artist", type: "address", value: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25800\", \"80000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6732621", timeStamp: "1542618056", hash: "0xbedb5ed5d6a335deaa0a7f5085ac967dbfbc6aca6cec7c01a589cc1953a87045", nonce: "92", blockHash: "0x928a118e281648b3929d2d97cfeb70e85991efeba5e5455a876aabf2340042cb", transactionIndex: "37", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000064c8000000000000000000000000000000000000000000000000011c37937e080000", contractAddress: "", cumulativeGasUsed: "4556007", gasUsed: "40818", confirmations: "989839"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25800"}, {type: "uint256", name: "_priceInWei", value: "80000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25800", "80000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542618056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25800"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "80000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25700\", \"40000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6732626", timeStamp: "1542618121", hash: "0xefc8049264cde236d4e406278d68bc0d74b7a34d648cef2b2ffc90190d742833", nonce: "93", blockHash: "0x15afdda62a537b42579ed0e167412a75a2b59abc33f08ac32037381cf97c64f0", transactionIndex: "97", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006464000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "3851609", gasUsed: "40754", confirmations: "989834"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25700"}, {type: "uint256", name: "_priceInWei", value: "40000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25700", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542618121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25700"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "40000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"25500\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6738679", timeStamp: "1542704742", hash: "0xe0a528b3736565a7b878b40f039fa68b62d09300d3d9a821a1621321080802a0", nonce: "95", blockHash: "0xb442baa835262e3333498e61dfe025c555eaebe46dda513ca87a60ac8c24073d", transactionIndex: "110", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000639c000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "6320795", gasUsed: "40818", confirmations: "983781"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "25500"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "25500", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542704742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "25500"}, {name: "_artist", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "58285462407846645" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"28000\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6752340", timeStamp: "1542899637", hash: "0x6f538128b634be3d0ec8069076d230ddbfd5bbfe18fb2626b00581a489783f3a", nonce: "16", blockHash: "0x2646992acecb588b691f7714ea371bf837329eeeb68ec0360d1aa980d2ec37e8", transactionIndex: "156", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006d6000000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "7500118", gasUsed: "40754", confirmations: "970120"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "28000"}, {type: "uint256", name: "_priceInWei", value: "50000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "28000", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542899637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "28000"}, {name: "_artist", type: "address", value: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69"}, {name: "_priceInWei", type: "uint256", value: "50000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"28000\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6752350", timeStamp: "1542899747", hash: "0x08f4bc93e37a2002c898d9aff110206238524b519a77486e338f8c27dfd66b4a", nonce: "17", blockHash: "0x4a9398ef985d225ff7b354d199737246228ec148f994573dcac511f8cdcc744e", transactionIndex: "87", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006d60000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "7694906", gasUsed: "40818", confirmations: "970110"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "28000"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "28000", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542899747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "28000"}, {name: "_artist", type: "address", value: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"28000\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6753601", timeStamp: "1542917200", hash: "0x5ef7fd873cc96beb2c5507c78d3b11ecbb6bf7c216b5e5c3c5883d28b7c5d118", nonce: "18", blockHash: "0xc55d469bfabe75c9fad4bf404abeb09c721c1b9bc5c05a0e273d38dcd6219b52", transactionIndex: "132", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006d6000000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "7267874", gasUsed: "40754", confirmations: "968859"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "28000"}, {type: "uint256", name: "_priceInWei", value: "50000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "28000", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542917200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "28000"}, {name: "_artist", type: "address", value: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69"}, {name: "_priceInWei", type: "uint256", value: "50000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"9200\", \"999000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6753822", timeStamp: "1542920328", hash: "0xcad9a82837827883dab6311ecead097579edb398b8725f42ad60b7a8689b3692", nonce: "134", blockHash: "0xc4117d2abc8f0e265484e3873653640104110e3921214bd5763832e78d0a71d4", transactionIndex: "32", from: "0x21316e6a4f0af45e5f1503984e83b10c53b177d8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61323", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000023f00000000000000000000000000000000000000000000000000ddd2935029d8000", contractAddress: "", cumulativeGasUsed: "1955173", gasUsed: "40882", confirmations: "968638"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9200"}, {type: "uint256", name: "_priceInWei", value: "999000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "9200", "999000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542920328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "9200"}, {name: "_artist", type: "address", value: "0x21316e6a4f0af45e5f1503984e83b10c53b177d8"}, {name: "_priceInWei", type: "uint256", value: "999000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "14702090022500000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"13000\", \"350000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6753826", timeStamp: "1542920344", hash: "0x9c3301d12f25a60c1f95b424ca3c7ebc617621949b20f231a7ba948d6da34f66", nonce: "135", blockHash: "0x295be30f1acecbd52fec6396244dd32a2c60b4a84170c0abd18db91ee7092af6", transactionIndex: "21", from: "0x21316e6a4f0af45e5f1503984e83b10c53b177d8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000032c800000000000000000000000000000000000000000000000004db732547630000", contractAddress: "", cumulativeGasUsed: "1657611", gasUsed: "40818", confirmations: "968634"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "13000"}, {type: "uint256", name: "_priceInWei", value: "350000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "13000", "350000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542920344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "13000"}, {name: "_artist", type: "address", value: "0x21316e6a4f0af45e5f1503984e83b10c53b177d8"}, {name: "_priceInWei", type: "uint256", value: "350000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "14702090022500000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"19300\", \"200000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790702", timeStamp: "1543443970", hash: "0x8bbfe8e988906eb058e43caa9aea2300e267d2ecd578d4883842d666ad4095f0", nonce: "225", blockHash: "0xa408d408cbc7e477f5b322d3fcef6e72120cfb5cdb474856c536fd828b1257ff", transactionIndex: "94", from: "0xe13d4abee4b304b67c52a56871141cad1b833aa7", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000004b6400000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "5010939", gasUsed: "40818", confirmations: "931758"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19300"}, {type: "uint256", name: "_priceInWei", value: "200000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "19300", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543443970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "19300"}, {name: "_artist", type: "address", value: "0xe13d4abee4b304b67c52a56871141cad1b833aa7"}, {name: "_priceInWei", type: "uint256", value: "200000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "177712223479584765" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"19400\", \"200000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790706", timeStamp: "1543444036", hash: "0x9d8988b22fba8a083afa5cac72af6ef2c67bb2532d775c0965b74e04b227030f", nonce: "226", blockHash: "0xf42f2ad76b08affb77b26949baa4f6aba20ed8f0311d1796931f25800c7ed6a2", transactionIndex: "111", from: "0xe13d4abee4b304b67c52a56871141cad1b833aa7", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000004bc800000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "6830500", gasUsed: "40818", confirmations: "931754"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19400"}, {type: "uint256", name: "_priceInWei", value: "200000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "19400", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543444036 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "19400"}, {name: "_artist", type: "address", value: "0xe13d4abee4b304b67c52a56871141cad1b833aa7"}, {name: "_priceInWei", type: "uint256", value: "200000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "177712223479584765" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"19500\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790707", timeStamp: "1543444042", hash: "0x4ef964ef032ec62c3e0bfb8e5b7f1cc1fd742dd8d72c5c869cb667953f42194a", nonce: "227", blockHash: "0x666944713340b7d84471e9c09f09992dfe2355dfe600a2f74c4b89d258a15947", transactionIndex: "78", from: "0xe13d4abee4b304b67c52a56871141cad1b833aa7", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000004c2c000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "6697081", gasUsed: "40818", confirmations: "931753"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19500"}, {type: "uint256", name: "_priceInWei", value: "100000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "19500", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543444042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "19500"}, {name: "_artist", type: "address", value: "0xe13d4abee4b304b67c52a56871141cad1b833aa7"}, {name: "_priceInWei", type: "uint256", value: "100000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "177712223479584765" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[17], \"24600\" )", async function( ) {
		const txOriginal = {blockNumber: "6805450", timeStamp: "1543653327", hash: "0xd6162daa49bdc0beb495d9583109c9df1ec18d6d9ed4d866a6e72b0d3ceda89f", nonce: "127", blockHash: "0xb1007443841c2fc878896a16d09c0d78b5476dd61f3504d6932b44b914683bf5", transactionIndex: "46", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "471999", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c9700000000000000000000000089c5dca00b9bf5ad746b91ec911c56cb4aee17f00000000000000000000000000000000000000000000000000000000000006018", contractAddress: "", cumulativeGasUsed: "2598621", gasUsed: "310400", confirmations: "917010"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[17]}, {type: "uint256", name: "_editionNumber", value: "24600"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[17], "24600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543653327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16874917495321770994" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"22000\", \"170000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6850604", timeStamp: "1544300081", hash: "0xc130b632bd7b4768dc38a79079d093c453a40d722efbb7bfaf6f87adecb25767", nonce: "12", blockHash: "0x7e43dddcaad1424d8fd99c9b530caf3c51399f6712a5128e0b0c11c25ce68576", transactionIndex: "1", from: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000055f0000000000000000000000000000000000000000000000000025bf6196bd10000", contractAddress: "", cumulativeGasUsed: "85235", gasUsed: "40818", confirmations: "871856"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "22000"}, {type: "uint256", name: "_priceInWei", value: "170000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "22000", "170000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544300081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "22000"}, {name: "_artist", type: "address", value: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8"}, {name: "_priceInWei", type: "uint256", value: "170000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "12996642851079542" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"27900\", \"300000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6850713", timeStamp: "1544301383", hash: "0x9e923be2873d6903c392f5ebccb3ffc8866d07454cd0ce2eb0d4d62e525de561", nonce: "13", blockHash: "0x001f8c26cb565ce55de81eb0706f477d3de0fedb02a0e5514dd934ffbce7c782", transactionIndex: "96", from: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006cfc0000000000000000000000000000000000000000000000000429d069189e0000", contractAddress: "", cumulativeGasUsed: "7502912", gasUsed: "40818", confirmations: "871747"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "27900"}, {type: "uint256", name: "_priceInWei", value: "300000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "27900", "300000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544301383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "27900"}, {name: "_artist", type: "address", value: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8"}, {name: "_priceInWei", type: "uint256", value: "300000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "12996642851079542" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"27900\", \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6850713", timeStamp: "1544301383", hash: "0xd071dca0d90cfea4778802fff77ef595b0506de3f2f04b17a9bdfd73c6bbaaa3", nonce: "14", blockHash: "0x001f8c26cb565ce55de81eb0706f477d3de0fedb02a0e5514dd934ffbce7c782", transactionIndex: "97", from: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd9980000000000000000000000000000000000000000000000000000000000006cfc00000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "7543730", gasUsed: "40818", confirmations: "871747"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "27900"}, {type: "uint256", name: "_priceInWei", value: "280000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "27900", "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544301383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "27900"}, {name: "_artist", type: "address", value: "0x3768225622d53ffcc1e00eac53a2a870ecd825c8"}, {name: "_priceInWei", type: "uint256", value: "280000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "12996642851079542" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: gift( addressList[19], \"18100\" )", async function( ) {
		const txOriginal = {blockNumber: "6853110", timeStamp: "1544336330", hash: "0x06c10bd33e92093e6add2a5bb6a5736571e64b8eeaa343785dde763b8eee3126", nonce: "23", blockHash: "0xc830d187ecf2a9b061b4d03d3cfaa444b25d64e8f370e77f000946a2500f74ec", transactionIndex: "118", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "471999", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcbce4c970000000000000000000000002e0b873d26f6d90f347757ed0d041bc65e02a89f00000000000000000000000000000000000000000000000000000000000046b4", contractAddress: "", cumulativeGasUsed: "7694442", gasUsed: "310400", confirmations: "869350"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receivingAddress", value: addressList[19]}, {type: "uint256", name: "_editionNumber", value: "18100"}], name: "gift", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gift(address,uint256)" ]( addressList[19], "18100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544336330 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"29500\", \"75000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6855896", timeStamp: "1544375850", hash: "0x089e01ef52bd4d467218941a0ad5ef6866c85229cd6a8f5d28800b062655cc10", nonce: "159", blockHash: "0x393587edd400d691d6fc72247f22e02f73366c3bd6bebce0a25e85031468fac9", transactionIndex: "11", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61323", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000733c000000000000000000000000000000000000000000000000010a741a46278000", contractAddress: "", cumulativeGasUsed: "7924856", gasUsed: "40882", confirmations: "866564"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "29500"}, {type: "uint256", name: "_priceInWei", value: "75000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "29500", "75000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544375850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "29500"}, {name: "_artist", type: "address", value: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1"}, {name: "_priceInWei", type: "uint256", value: "75000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"29600\", \"75000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6855899", timeStamp: "1544375902", hash: "0x1b3d870238f3b9544c5eed9b214ef54b4db0f581550f79af2e5c04de6b03aa74", nonce: "160", blockHash: "0x2a77392dcfa98a24e78299fb9cda92bfacc5900ccd4238c1b4fcfc851f2c55c2", transactionIndex: "81", from: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61323", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd99800000000000000000000000000000000000000000000000000000000000073a0000000000000000000000000000000000000000000000000010a741a46278000", contractAddress: "", cumulativeGasUsed: "7582983", gasUsed: "40882", confirmations: "866561"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "29600"}, {type: "uint256", name: "_priceInWei", value: "75000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "29600", "75000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544375902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "29600"}, {name: "_artist", type: "address", value: "0x4af4aebe930e938fa11ad28cd2c88645cce739a1"}, {name: "_priceInWei", type: "uint256", value: "75000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "20561347771697519" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"30000\", \"250000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6875662", timeStamp: "1544656684", hash: "0x9fc264c4d3f63c8137e55ae97e6988dfbec5357707225365fa9e0f2320b8f7fd", nonce: "24", blockHash: "0xca29eae35bf30ffb574f0906984a57f6df608f103efc2ceb26a2342e3b70f484", transactionIndex: "107", from: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "2200000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000753000000000000000000000000000000000000000000000000003782dace9d90000", contractAddress: "", cumulativeGasUsed: "6332477", gasUsed: "40818", confirmations: "846798"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "30000"}, {type: "uint256", name: "_priceInWei", value: "250000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "30000", "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544656684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "30000"}, {name: "_artist", type: "address", value: "0xcef2bf4ad6d84aa37fcc4cab6530028eb31c8e69"}, {name: "_priceInWei", type: "uint256", value: "250000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "73782220117836384" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: updateEditionPrice( \"31000\", \"120000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6889579", timeStamp: "1544854457", hash: "0xe358d2dde24b55565825c6714e926b67e576d1a63e55fb5071c971956cde397d", nonce: "24", blockHash: "0x7e8e1bd5544adb1c3ee8c27aa6c07461cdc1625c5296ff32abfaaf1f609e8cd6", transactionIndex: "33", from: "0xe88cfe8535af121121a4b475eefd13dae4fbc4cc", to: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1", value: "0", gas: "61227", gasPrice: "2900000000", isError: "0", txreceipt_status: "1", input: "0x9e0fd998000000000000000000000000000000000000000000000000000000000000791800000000000000000000000000000000000000000000000001aa535d3d0c0000", contractAddress: "", cumulativeGasUsed: "6227791", gasUsed: "40818", confirmations: "832881"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "31000"}, {type: "uint256", name: "_priceInWei", value: "120000000000000000"}], name: "updateEditionPrice", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateEditionPrice(uint256,uint256)" ]( "31000", "120000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544854457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_artist", type: "address"}, {indexed: false, name: "_priceInWei", type: "uint256"}], name: "PriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PriceChanged", events: [{name: "_editionNumber", type: "uint256", value: "31000"}, {name: "_artist", type: "address", value: "0xe88cfe8535af121121a4b475eefd13dae4fbc4cc"}, {name: "_priceInWei", type: "uint256", value: "120000000000000000"}], address: "0x06c741e6df49d7fda1f27f75fffd238d87619ba1"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "846696917041437203" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
