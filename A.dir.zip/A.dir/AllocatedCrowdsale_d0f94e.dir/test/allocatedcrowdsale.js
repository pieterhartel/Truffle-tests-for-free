const AllocatedCrowdsale = artifacts.require( "./AllocatedCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "AllocatedCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xbAcD554538c8037545098A36361f54C4E1d0f94E", "0x6699eD0AfC9761aFF5B7DbE08352fC0C8616Ca31", "0xac3211a5025414Af2866FF09c23FC18bc97e79b1", "0xAFe4eb0f65f94e1bAE3c31b0F1DCA72bc10b36aA", "0xf1492a63c6AbCB482499947aA15Ca167ef836c9b", "0xDf387b743A1Bf1679D9A8A69bAA34213D4f4a902", "0xfb7c9bD2045cD9129839A70C67AaBb0925b1fBE8", "0x9CFce10368A46daAbc90fC125DBeD71E426BB608", "0x00b0797DdcE269106529B8964409C2eC610797f8", "0xE377A13Fc8eE23284dEC5B2B7DA93798Ebb14633", "0xF7880dBf729299F6A0c0fA0fCcDC9e48213BbDc4", "0x64B8033738740946CF455d569555eD2C24f6144C", "0x7A0a875695F930e09585c066651038000b0dF475", "0xeC0946deCD92aBC97D6b67EB0e4A99238B3A04dA", "0xb6E999a27F9DC8bA391b2FEe5e144E870e0A53D7", "0x68b02Dd5DB5F58BA6e2D5916f4926D4023FA0aed", "0x4b49b5D5eB1f4106E9336f01077844B462650C68", "0x47e48c958628670469c7E67aeb276212015B26fe", "0x888f06F6fA192bF17A131523f1132Ddbc8260b20", "0x652146673583C156140674cdfC4f1c873951F808", "0x45C75C09e217Eb42c633fCf566494BC01F509a4D", "0xF69B630C48F109D108a6305d1c350e59cd853138", "0x1e54161768CF52953175CF72483Ff205491D2aA9", "0x587A93B20042A2B9551BB0C203F001475eFB52a1", "0x9a6b8aFfB87df5b0648f711D7Fd42d2fED30Ea2a", "0x002B007FF84A726c6D44f036Aaf75B13c0011501", "0xF55b32E2BB490bCbe69d12D41811A7B9153612e8", "0xd5531aA1B52ACC87c0bB03b5543E0dcd0338e245", "0x7dC3B9a6e618F012b4Be36A46E513D16fc5475A2", "0xa5a9470bc79dEbf5eC4Cef854cf77112404287B0", "0xD74d9f9915E53B8Bd0a6eD815eA075362e4eF8d2", "0xE0050656082C9831ebD40B81F4C0886734Cc7B5b", "0x1226e80A416725Eda3cdA49202a16ac843fCD907", "0x40880d91734e583ee362210D94FbEFAC1462D1Ab", "0xc9672EBa047f7DD7967BE9B1dDd62bc9EbE0b41E", "0x93B64c6bE9ce7Da95620399C1AC85c0D1A1ce410", "0x56768c4d3862a6b0b90d6b5191795acCE13f1d28", "0x24aE232A2f1Cd815691a82feC5821F6F6Ef8c876", "0x7F01a102fF96BDD41cCBE80577402f544706ADe5", "0xC1417DD374F047C4e4538052a3Db2b6352c8e13f", "0x38c6d693711b2A490eFF3e048bDA4A934797D07f"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "requireCustomerId", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "weiAmount", type: "uint256"}, {name: "tokenAmount", type: "uint256"}, {name: "weiRaisedTotal", type: "uint256"}, {name: "tokensSoldTotal", type: "uint256"}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "requiredSignedAddress", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}], name: "Refund", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newRequireCustomerId", type: "bool"}, {indexed: false, name: "newRequiredSignedAddress", type: "bool"}, {indexed: false, name: "newSignerAddress", type: "address"}], name: "InvestmentPolicyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newEndsAt", type: "uint256"}], name: "EndsAtChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Invested(address,uint256,uint256,uint128)", "Refund(address,uint256)", "InvestmentPolicyChanged(bool,bool,address)", "Whitelisted(address,bool)", "EndsAtChanged(uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x0396f60aaad038749091d273dc13aaabc63db6e2271c7bad442d5cf25cc43350", "0xbb28353e4598c3b9199101a66e0989549b659a59a54d2c27fbb183f1932c8e6d", "0x48d826081348f5f00e8a33c9ae8ce89ed4c6e88400b585a478bc203d9e8177d3", "0xa54714518c5d275fdcd3d2a461e4858e4e8cb04fb93cd0bca9d6d34115f26440", "0xd34bb772c4ae9baa99db852f622773b31c7827e8ee818449fef20d30980bd310", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4333057 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4333798 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_pricingStrategy", value: 5}, {type: "address", name: "_multisigWallet", value: 6}, {type: "uint256", name: "_start", value: "1507050000"}, {type: "uint256", name: "_end", value: "1508259600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: 3}], name: "AllocatedCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerTestValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "requireCustomerId", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "requireCustomerId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPricingSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumFundingGoal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investedAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalizeAgent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "beneficiary()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signerAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRefunded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pricingStrategy()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "loadedRefund()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isMinimumGoalReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multisigWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "weiAmount", value: random.range( maxRandom )}, {type: "uint256", name: "tokenAmount", value: random.range( maxRandom )}, {type: "uint256", name: "weiRaisedTotal", value: random.range( maxRandom )}, {type: "uint256", name: "tokensSoldTotal", value: random.range( maxRandom )}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isBreakingCap(uint256,uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalizerSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyParticipantWhitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "requiredSignedAddress", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "requiredSignedAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsaleFull()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokensLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleWeiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "AllocatedCrowdsale", function( accounts ) {

	it( "TEST: AllocatedCrowdsale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4333057", timeStamp: "1507027639", hash: "0x725a4b8c021f5a4799f7272de9c7a88b44c3cb6c60e94d4d5c0a3f22833a8ed9", nonce: "5", blockHash: "0xf7a7ffc3581ec747a5f70288cc645dc6a821c17392679b619c7fe9dac6170db3", transactionIndex: "21", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: 0, value: "0", gas: "2809180", gasPrice: "28322620330", isError: "0", txreceipt_status: "", input: "0x9832d193000000000000000000000000ac3211a5025414af2866ff09c23fc18bc97e79b1000000000000000000000000afe4eb0f65f94e1bae3c31b0f1dca72bc10b36aa000000000000000000000000f1492a63c6abcb482499947aa15ca167ef836c9b0000000000000000000000000000000000000000000000000000000059d3c2100000000000000000000000000000000000000000000000000000000059e6371000000000000000000000000000000000000000000000000000000000000000010000000000000000000000006699ed0afc9761aff5b7dbe08352fc0c8616ca31", contractAddress: "0xbacd554538c8037545098a36361f54c4e1d0f94e", cumulativeGasUsed: "3647604", gasUsed: "2709179", confirmations: "3382262"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_pricingStrategy", value: addressList[5]}, {type: "address", name: "_multisigWallet", value: addressList[6]}, {type: "uint256", name: "_start", value: "1507050000"}, {type: "uint256", name: "_end", value: "1508259600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: addressList[3]}], name: "AllocatedCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = AllocatedCrowdsale.new( addressList[4], addressList[5], addressList[6], "1507050000", "1508259600", "1", addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507027639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = AllocatedCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4333066", timeStamp: "1507027916", hash: "0x3ad7b0df8f4c739d4538bb13c4992b31dd01297bd639a8236168285f995a89d8", nonce: "12", blockHash: "0x2cf68f5fcaa73aa241c5e99385491ec26959069b1205335ca02446be9e1567c9", transactionIndex: "136", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "145560", gasPrice: "23659051724", isError: "0", txreceipt_status: "", input: "0x19b667da000000000000000000000000df387b743a1bf1679d9a8a69baa34213d4f4a902", contractAddress: "", cumulativeGasUsed: "6247739", gasUsed: "45559", confirmations: "3382253"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1507027916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[3], true )", async function( ) {
		const txOriginal = {blockNumber: "4333072", timeStamp: "1507028068", hash: "0xa9e4fc14075710f8e566d0895be6faa1d2a36b211b4401da3b9a97a0d16b0bc6", nonce: "15", blockHash: "0x9b9e7885b613df2cdc3d1a28dbb1799bd62c4348c414e0115c1d42d37a1c4d31", transactionIndex: "16", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "146282", gasPrice: "24371988670", isError: "0", txreceipt_status: "", input: "0xeac249320000000000000000000000006699ed0afc9761aff5b7dbe08352fc0c8616ca310000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "517065", gasUsed: "46281", confirmations: "3382247"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[3]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[3], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1507028068 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[8], true )", async function( ) {
		const txOriginal = {blockNumber: "4333073", timeStamp: "1507028099", hash: "0xad17a2c5c4702eea912ed04c149d526776cf7f0c24120cb8dd09a2d4b7fcdec4", nonce: "16", blockHash: "0xa5d2c4e160854a328b84e2ac08e7c87d168e4b2a79960e46f9ba79087aa58a44", transactionIndex: "16", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "146282", gasPrice: "24371988670", isError: "0", txreceipt_status: "", input: "0xeac24932000000000000000000000000fb7c9bd2045cd9129839a70c67aabb0925b1fbe80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1140233", gasUsed: "46281", confirmations: "3382246"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[8]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[8], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1507028099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0xfb7c9bd2045cd9129839a70c67aabb0925b1fbe8"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[9], true )", async function( ) {
		const txOriginal = {blockNumber: "4333074", timeStamp: "1507028121", hash: "0x1741f4b9ef50654667924d44e247c5f9f7dbe4f576ecb92b62e389e8da303553", nonce: "17", blockHash: "0x86d90f7f4f4ef89cf7df35b9032b93866c9ccfcd40ad56608eda27740b24f264", transactionIndex: "17", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "146282", gasPrice: "24371988670", isError: "0", txreceipt_status: "", input: "0xeac249320000000000000000000000009cfce10368a46daabc90fc125dbed71e426bb6080000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3429347", gasUsed: "46281", confirmations: "3382245"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[9]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[9], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1507028121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x9cfce10368a46daabc90fc125dbed71e426bb608"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4333131", timeStamp: "1507030200", hash: "0xb2e807145523151aab33120d152209d58673dfee46e72fbd0e498cb5df019737", nonce: "25", blockHash: "0x7ff3de9c789dc20832d053d651d89d869c61f616633cd8e6ae91f1f4d896f650", transactionIndex: "44", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "130560", gasPrice: "22126060921", isError: "0", txreceipt_status: "", input: "0x19b667da000000000000000000000000df387b743a1bf1679d9a8a69baa34213d4f4a902", contractAddress: "", cumulativeGasUsed: "2856417", gasUsed: "30559", confirmations: "3382188"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1507030200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4333151", timeStamp: "1507030865", hash: "0x8da843db6a5b05699f9e670be17376b48e07c171dc212cafc865446295a6fd60", nonce: "30", blockHash: "0x0b8d84f50bb0863144104da43a85cf554e031bcb406947f015b16646826e6835", transactionIndex: "168", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "130559", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x19b667da000000000000000000000000df387b743a1bf1679d9a8a69baa34213d4f4a902", contractAddress: "", cumulativeGasUsed: "6282962", gasUsed: "30559", confirmations: "3382168"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1507030865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4333223", timeStamp: "1507033354", hash: "0x2c276d245c63b2c8ed341a0f3f2728b59fc068495501a2150ac9718c8f8f4097", nonce: "36", blockHash: "0x6eb68865d55dd43ddadbb72851f056dc4c96516dcb10aede151fca28722b04fc", transactionIndex: "109", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "130559", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x19b667da000000000000000000000000df387b743a1bf1679d9a8a69baa34213d4f4a902", contractAddress: "", cumulativeGasUsed: "5633963", gasUsed: "30559", confirmations: "3382096"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1507033354 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[3], true )", async function( ) {
		const txOriginal = {blockNumber: "4333227", timeStamp: "1507033432", hash: "0x299843ee6dbbe99baf908367ac62d9951a44b585159ec2649bfe278579cf62c4", nonce: "38", blockHash: "0x8406471a35da47ba360a1744262dacd27432b99496359c7ca52bc984b4fa87d2", transactionIndex: "22", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "131281", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xeac249320000000000000000000000006699ed0afc9761aff5b7dbe08352fc0c8616ca310000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1083044", gasUsed: "31281", confirmations: "3382092"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[3]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[3], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1507033432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[8], true )", async function( ) {
		const txOriginal = {blockNumber: "4333229", timeStamp: "1507033455", hash: "0xdf8e74788de82175f7c2582cc4677b94a7d023801bf0aae36ff671b3fc0cdf89", nonce: "39", blockHash: "0xb48ef717d643cf4e10cbf56f6575c9d17da28e69b9d3af708faf6d9a92679f4b", transactionIndex: "105", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "131281", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xeac24932000000000000000000000000fb7c9bd2045cd9129839a70c67aabb0925b1fbe80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4359070", gasUsed: "31281", confirmations: "3382090"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[8]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[8], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1507033455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0xfb7c9bd2045cd9129839a70c67aabb0925b1fbe8"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[9], true )", async function( ) {
		const txOriginal = {blockNumber: "4333234", timeStamp: "1507033637", hash: "0x938e1aa565430a01e6c351510c5c8f7293205d57c0e18ae22ffc284de7876124", nonce: "40", blockHash: "0x264ec240f2678b7878ea3b790acde9dc56a532aa029bfc38d85935d0a548481e", transactionIndex: "95", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "0", gas: "131281", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xeac249320000000000000000000000009cfce10368a46daabc90fc125dbed71e426bb6080000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5729718", gasUsed: "31281", confirmations: "3382085"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[9]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[9], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1507033637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x9cfce10368a46daabc90fc125dbed71e426bb608"}, {name: "status", type: "bool", value: true}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4333244", timeStamp: "1507033956", hash: "0xbb77e736b85278b785d13a8d4ff368f6ab49c7adbc7f3cab2d2fa594cb64f65d", nonce: "44", blockHash: "0x2f004a83509e2ed9a823304b9f7c9463261d9461bbaf505a530c2718a5be7ff6", transactionIndex: "152", from: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "10000000000000000", gas: "315398", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "6046426", gasUsed: "215398", confirmations: "3382075"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507033956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x6699ed0afc9761aff5b7dbe08352fc0c8616ca31"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "34373925814818265445"}, {name: "customerId", type: "uint128", value: {s: 1, e: 0, c: [0]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "681973613058119936" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333765", timeStamp: "1507049606", hash: "0xdbd026afcc563bf7f216f0e8ca716a8752951ed7e63ac6a85041b58d564eb85e", nonce: "65", blockHash: "0xf7bd603f3ba69e8da23c372de1c19cceec5ced9367b389c4ff5043981897398c", transactionIndex: "0", from: "0x00b0797ddce269106529b8964409c2ec610797f8", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "7000000000000000000", gas: "260300", gasPrice: "151000000010", isError: "1", txreceipt_status: "", input: "0xbacd554538c8037545098a36361f54c4e1d0f94e", contractAddress: "", cumulativeGasUsed: "260300", gasUsed: "260300", confirmations: "3381554"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "7000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "211944665814848566" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"14965765513358101319461149342056197564... )", async function( ) {
		const txOriginal = {blockNumber: "4333778", timeStamp: "1507050014", hash: "0x30bf12971eeb1e43ec101aad380e352123cc77f30c4e03b5cca8698929c5a2ce", nonce: "113", blockHash: "0x8097079a68fa625571c5b2b28fb16a876ab9edfe05425c21f504a4439ef3ec37", transactionIndex: "31", from: "0xe377a13fc8ee23284dec5b2b7da93798ebb14633", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "10000000000000000000", gas: "250600", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c0000000000000000000000000000000070970414d4b54f2db419677e87fdc958", contractAddress: "", cumulativeGasUsed: "1333352", gasUsed: "184521", confirmations: "3381541"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "149657655133581013194611493420561975640"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "149657655133581013194611493420561975640", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1507050014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe377a13fc8ee23284dec5b2b7da93798ebb14633"}, {name: "weiAmount", type: "uint256", value: "10000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "34373925814818265445501"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [14965765513, 35810131946114, 93420561975640]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "12394602452158148017" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"28030159778973848082707017126662884358... )", async function( ) {
		const txOriginal = {blockNumber: "4333779", timeStamp: "1507050022", hash: "0x1a43f302d78cbdc1f0b0bb44c5b8a12947c3c1fe22d1b56a1a34a1299eab7e3a", nonce: "66", blockHash: "0x2c6e6b149d5bfcaa9b826379c289cc87a15be24818512d83f279fc32a93fb278", transactionIndex: "0", from: "0x00b0797ddce269106529b8964409c2ec610797f8", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "7000000000000000000", gas: "260300", gasPrice: "150000000010", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000d2e01fc2ad4c43c88c902e0ec2e5f83f", contractAddress: "", cumulativeGasUsed: "184521", gasUsed: "184521", confirmations: "3381540"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "7000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "280301597789738480827070171266628843583"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "280301597789738480827070171266628843583", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507050022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x00b0797ddce269106529b8964409c2ec610797f8"}, {name: "weiAmount", type: "uint256", value: "7000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "24061748070372785811850"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28030159778, 97384808270701, 71266628843583]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "211944665814848566" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"57095115753517050578107580028159680455... )", async function( ) {
		const txOriginal = {blockNumber: "4333779", timeStamp: "1507050022", hash: "0x5237b6e2f345a80417e2825502275936aee71e0ab79b46a90926c9e5bf374be6", nonce: "7", blockHash: "0x2c6e6b149d5bfcaa9b826379c289cc87a15be24818512d83f279fc32a93fb278", transactionIndex: "24", from: "0xf7880dbf729299f6a0c0fa0fccdc9e48213bbdc4", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "10272393700000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000002af41e8b26fc4110b749c849eb6a5fc7", contractAddress: "", cumulativeGasUsed: "1882427", gasUsed: "184521", confirmations: "3381540"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10272393700000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "57095115753517050578107580028159680455"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "57095115753517050578107580028159680455", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507050022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xf7880dbf729299f6a0c0fa0fccdc9e48213bbdc4"}, {name: "weiAmount", type: "uint256", value: "10272393700000000000"}, {name: "tokenAmount", type: "uint256", value: "35310249898440651660729"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [5709511575, 35170505781075, 80028159680455]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2590150000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"23704706620658402073506834430191323684... )", async function( ) {
		const txOriginal = {blockNumber: "4333781", timeStamp: "1507050037", hash: "0xa6dc9b97feec4fd00c37d08c586f413053dce12d6bfdc14b8fbce713729b2260", nonce: "17", blockHash: "0x4da862700276c2b1d29c54bee05477d8fbfa478211494061a754f4da98272156", transactionIndex: "7", from: "0x64b8033738740946cf455d569555ed2c24f6144c", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "3600000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000b2559ab3a4b446cca912ee2f4291e56f", contractAddress: "", cumulativeGasUsed: "558095", gasUsed: "184521", confirmations: "3381538"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "3600000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "237047066206584020735068344301913236847"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "237047066206584020735068344301913236847", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507050037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x64b8033738740946cf455d569555ed2c24f6144c"}, {name: "weiAmount", type: "uint256", value: "3600000000000000000"}, {name: "tokenAmount", type: "uint256", value: "12374613293334575560380"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [23704706620, 65840207350683, 44301913236847]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "61716091843610578" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333783", timeStamp: "1507050081", hash: "0x548782182da445277f728606e46b5f21aad290ad13c6c07a482c60c24232b2a1", nonce: "13", blockHash: "0x10d50b8b2ee5957249b3e33c91446a445c281b7f0dedefdf30b0207743984108", transactionIndex: "37", from: "0x7a0a875695f930e09585c066651038000b0df475", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1752107", gasUsed: "260300", confirmations: "3381536"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"28160692497466908344515184090330632404... )", async function( ) {
		const txOriginal = {blockNumber: "4333784", timeStamp: "1507050105", hash: "0x5ed49caf6e40d6be8bfb489f1b2e9647b0dffce8807482a5a83020e84fc46d78", nonce: "147", blockHash: "0xbbf4a3cd970498f9e38c8ef677e24cd6f65956bedfab9e98121ddf1c76e0c595", transactionIndex: "20", from: "0xec0946decd92abc97d6b67eb0e4a99238b3a04da", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "5000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000d3db855c084947a6be93a463d3a6a84c", contractAddress: "", cumulativeGasUsed: "1062347", gasUsed: "184521", confirmations: "3381535"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "281606924974669083445151840903306324044"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "281606924974669083445151840903306324044", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507050105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xec0946decd92abc97d6b67eb0e4a99238b3a04da"}, {name: "weiAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "17186962907409132722750"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28160692497, 46690834451518, 40903306324044]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "460360539212340377" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"26280590067242938090316906615305705070... )", async function( ) {
		const txOriginal = {blockNumber: "4333784", timeStamp: "1507050105", hash: "0xd1ee7002d81123a20899ba63e0a098a7f771c3b80acf8228ae131933ea0930d8", nonce: "15", blockHash: "0xbbf4a3cd970498f9e38c8ef677e24cd6f65956bedfab9e98121ddf1c76e0c595", transactionIndex: "52", from: "0xb6e999a27f9dc8ba391b2fee5e144e870e0a53d7", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "250600", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000c5b6934b3ae2487394b590a1f0bde04d", contractAddress: "", cumulativeGasUsed: "2330967", gasUsed: "184521", confirmations: "3381535"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "262805900672429380903169066153057050701"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "262805900672429380903169066153057050701", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1507050105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xb6e999a27f9dc8ba391b2fee5e144e870e0a53d7"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "6874785162963653089100"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26280590067, 24293809031690, 66153057050701]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "25057859925579008" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"77666259546914655939767250123101338297... )", async function( ) {
		const txOriginal = {blockNumber: "4333787", timeStamp: "1507050164", hash: "0xfb978adfd85c4ef671ef59681f85c5f8d2eec48f16f483e959d86e6d2b2ef603", nonce: "38", blockHash: "0xf94969a38b2fe20b144524f1fcb562947401bd3aa3f2418a0b9086798beb42d0", transactionIndex: "23", from: "0x68b02dd5db5f58ba6e2d5916f4926d4023fa0aed", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "500000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000003a6dfa3cfb1f4c7a91032249fa807ab9", contractAddress: "", cumulativeGasUsed: "1072161", gasUsed: "184521", confirmations: "3381532"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "77666259546914655939767250123101338297"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "77666259546914655939767250123101338297", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1507050164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x68b02dd5db5f58ba6e2d5916f4926d4023fa0aed"}, {name: "weiAmount", type: "uint256", value: "500000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1718696290740913272275"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [7766625954, 69146559397672, 50123101338297]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "224222171350153999" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"16334149783492616194111067185828475129... )", async function( ) {
		const txOriginal = {blockNumber: "4333787", timeStamp: "1507050164", hash: "0x366cfc5bd129bf5f085873fe0350a7794838962ed0ba70e018c375ce66114faa", nonce: "51", blockHash: "0xf94969a38b2fe20b144524f1fcb562947401bd3aa3f2418a0b9086798beb42d0", transactionIndex: "61", from: "0x4b49b5d5eb1f4106e9336f01077844b462650c68", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1000000000000000000", gas: "120000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000007ae26d9d79b744309f608487bae5e9bb", contractAddress: "", cumulativeGasUsed: "3098617", gasUsed: "120000", confirmations: "3381532"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "163341497834926161941110671858284751291"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6691870120993500538" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"16476020286528953171513809221216163403... )", async function( ) {
		const txOriginal = {blockNumber: "4333789", timeStamp: "1507050211", hash: "0x59213c893a2dcc913cb5e19a6493d3fec94d197f03315a4cbbc0ba40a9b27720", nonce: "183", blockHash: "0xf34c947434332b3dfe1f183b5f976fa5cde82f9ee52a6a1310665ea00e934c20", transactionIndex: "98", from: "0x47e48c958628670469c7e67aeb276212015b26fe", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "10000000000000000000", gas: "221425", gasPrice: "70000000010", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000007bf3a92c6d674ce0ac8ee02917505eef", contractAddress: "", cumulativeGasUsed: "5249428", gasUsed: "184521", confirmations: "3381530"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "164760202865289531715138092212161634031"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "164760202865289531715138092212161634031", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1507050211 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x47e48c958628670469c7e67aeb276212015b26fe"}, {name: "weiAmount", type: "uint256", value: "10000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "34373925814818265445501"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [16476020286, 52895317151380, 92212161634031]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "8540474000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"10318146097396327719443771877093839488... )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0xdcbfd2d00fcf4d5df196aa3f0cbc3e1efd40003bb667235a7584da5fea25e929", nonce: "106", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "38", from: "0x888f06f6fa192bf17a131523f1132ddbc8260b20", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "7000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000004da006cb4b8f435da238b9f55535b907", contractAddress: "", cumulativeGasUsed: "2310932", gasUsed: "184521", confirmations: "3381529"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "7000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "103181460973963277194437718770938394887"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "103181460973963277194437718770938394887", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1507050247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x888f06f6fa192bf17a131523f1132ddbc8260b20"}, {name: "weiAmount", type: "uint256", value: "7000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "24061748070372785811850"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10318146097, 39632771944377, 18770938394887]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1344415000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0xb606d24b1b2ca1002c699b932fa4a3da81ebef9ffb1334077eae0bfcc44bcb2f", nonce: "13", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "42", from: "0x652146673583c156140674cdfc4f1c873951f808", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "5000000000000000000", gas: "260500", gasPrice: "30000000000", isError: "1", txreceipt_status: "", input: "0xf86d0d8506fc23ac008303f99494bacd554538c8037545098a36361f54c4e1d0f94e884563918244f400008025a0ef721a5081127db140322d5818cc8c241d2f42ebe1b89c94b7d566c0066c7c8aa056cfbf76fa4e03780dc079950b36a415270380b1db82facf763b20c84ab1eb8e", contractAddress: "", cumulativeGasUsed: "2705025", gasUsed: "260500", confirmations: "3381529"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "3874128504000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"11328583988727493306955161412768872174... )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0x1a68c4f4504cc840fb55b89a57b2be4990e9153fb3f29d76c9b917dd4abb9f01", nonce: "32", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "43", from: "0x45c75c09e217eb42c633fcf566494bc01f509a4d", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000553a0f233c344b7688de3ef8cb0d254c", contractAddress: "", cumulativeGasUsed: "2889546", gasUsed: "184521", confirmations: "3381529"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "113285839887274933069551614127688721740"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "113285839887274933069551614127688721740", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1507050247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x45c75c09e217eb42c633fcf566494bc01f509a4d"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "6874785162963653089100"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [11328583988, 72749330695516, 14127688721740]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "112740000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"16095549546493773097220076165956421951... )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0x61a197fd21f83e56a66419ee2a40aee097d2671a636efae35bc729fea614905e", nonce: "46", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "44", from: "0xf69b630c48f109d108a6305d1c350e59cd853138", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "7500000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000007916e69da4ef42a08b97086d57c7dc7c", contractAddress: "", cumulativeGasUsed: "3074067", gasUsed: "184521", confirmations: "3381529"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "7500000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "160955495464937730972200761659564219516"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "160955495464937730972200761659564219516", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1507050247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xf69b630c48f109d108a6305d1c350e59cd853138"}, {name: "weiAmount", type: "uint256", value: "7500000000000000000"}, {name: "tokenAmount", type: "uint256", value: "25780444361113699084125"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [16095549546, 49377309722007, 61659564219516]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "1382653994000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0x8c676d71a925bd04879104cd278dd19818444b506d74c8652802a47216dfb088", nonce: "86", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "45", from: "0x1e54161768cf52953175cf72483ff205491d2aa9", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "3334367", gasUsed: "260300", confirmations: "3381529"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "10000000000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"18040175539622307272587070262293516870... )", async function( ) {
		const txOriginal = {blockNumber: "4333790", timeStamp: "1507050247", hash: "0x82f28ff3fc52017ec6fe86772800d639854ce70c393d2350d5aa3ec69d66ba31", nonce: "56", blockHash: "0x4acc0f2c654f6fbe8e38f75623dd2424e0f9231ae9726821587dcb7c92ac24a6", transactionIndex: "46", from: "0x587a93b20042a2b9551bb0c203f001475efb52a1", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c0000000000000000000000000000000087b81d410b914461acc3a2d6ab4136bf", contractAddress: "", cumulativeGasUsed: "3518888", gasUsed: "184521", confirmations: "3381529"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "180401755396223072725870702622935168703"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "180401755396223072725870702622935168703", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1507050247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x587a93b20042a2b9551bb0c203f001475efb52a1"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "6874785162963653089100"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [18040175539, 62230727258707, 2622935168703]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "46906667888825561" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"20119488010784029786994299677320934997... )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0xf553de620f7aa629647b3c7c1ad7d1772fcf5eb7e85d9a906ce0a407006ea0a3", nonce: "42", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "2", from: "0x9a6b8affb87df5b0648f711d7fd42d2fed30ea2a", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "500000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000975cb973f6984ce2956bb885698f9f59", contractAddress: "", cumulativeGasUsed: "257335", gasUsed: "184521", confirmations: "3381528"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "201194880107840297869942996773209349977"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "201194880107840297869942996773209349977", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1507050279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9a6b8affb87df5b0648f711d7fd42d2fed30ea2a"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "6874785162963653089100"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [20119488010, 78402978699429, 96773209349977]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "91657639963626383" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"14975099782200023846719379659248177805... )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0xec945ca24e43e4ec4dbb39b4b2c14b356a96001cf3b4172badeb37e718dd0f06", nonce: "6", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "14", from: "0x002b007ff84a726c6d44f036aaf75b13c0011501", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1250000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c0000000000000000000000000000000070a8fe3b319d453c8377f920e1bab989", contractAddress: "", cumulativeGasUsed: "917295", gasUsed: "184521", confirmations: "3381528"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "1250000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "149750997822000238467193796592481778057"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "149750997822000238467193796592481778057", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1507050279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x002b007ff84a726c6d44f036aaf75b13c0011501"}, {name: "weiAmount", type: "uint256", value: "1250000000000000000"}, {name: "tokenAmount", type: "uint256", value: "4296740726852283180687"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [14975099782, 20002384671937, 96592481778057]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0xf01410e8208e462c63bfe4197c4e5789a168ff9dc7052d6f534d84c3630b003e", nonce: "14", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "15", from: "0x7a0a875695f930e09585c066651038000b0df475", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1999380929000000000", gas: "260300", gasPrice: "30000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1177595", gasUsed: "260300", confirmations: "3381528"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1999380929000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"56085496926072130054075877786198429659... )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0x1c5e9dc735cc7cdccaa1b85a14934807d723d4b60548178ce7183589580c3e2c", nonce: "13", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "40", from: "0xf55b32e2bb490bcbe69d12d41811a7b9153612e8", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "14300000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000002a31ac7dff794b95b882d5a4a10b4fdb", contractAddress: "", cumulativeGasUsed: "2330011", gasUsed: "184521", confirmations: "3381528"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "14300000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "56085496926072130054075877786198429659"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "56085496926072130054075877786198429659", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1507050279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xf55b32e2bb490bcbe69d12d41811a7b9153612e8"}, {name: "weiAmount", type: "uint256", value: "14300000000000000000"}, {name: "tokenAmount", type: "uint256", value: "49154713915190119587066"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [5608549692, 60721300540758, 77786198429659]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "50017262273627238" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"64194125514703383988649468571422165223... )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0xc35e325c26b671dfe112ad2bb69df49301cfcbbaa7b5dac1223a3bb6d46bc433", nonce: "19", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "85", from: "0xd5531aa1b52acc87c0bb03b5543e0dcd0338e245", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "250000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000304b56bf6a1649c38b0ca067cab608e7", contractAddress: "", cumulativeGasUsed: "4470262", gasUsed: "184521", confirmations: "3381528"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "64194125514703383988649468571422165223"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "64194125514703383988649468571422165223", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1507050279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xd5531aa1b52acc87c0bb03b5543e0dcd0338e245"}, {name: "weiAmount", type: "uint256", value: "250000000000000000"}, {name: "tokenAmount", type: "uint256", value: "859348145370456636137"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6419412551, 47033839886494, 68571422165223]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "89496781000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333791", timeStamp: "1507050279", hash: "0xb9244952df48b1c27bb407751964b86171e9c9ccd4dca90fd81bd7f39c9dd267", nonce: "3", blockHash: "0xe08da371697f0385299bff91c586724a6d8875a03c21fe398422f910fd97da08", transactionIndex: "105", from: "0x7dc3b9a6e618f012b4be36a46e513d16fc5475a2", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "381991600000000000", gas: "260300", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "5497627", gasUsed: "260300", confirmations: "3381528"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "381991600000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "139415000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"3389304609732404259511619406927813494\... )", async function( ) {
		const txOriginal = {blockNumber: "4333792", timeStamp: "1507050325", hash: "0xac1a9bd508e36c8037addfa25d59d55e1dc0c03bc086a75451ca1187303e9c08", nonce: "14", blockHash: "0x09b3ca0fb12326797703ee414fd3033e6ada3bfd376e019829a4e17426194829", transactionIndex: "17", from: "0x652146673583c156140674cdfc4f1c873951f808", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "5000000000000000000", gas: "260500", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000028cc19e70a74024a8987913c4ccdb76", contractAddress: "", cumulativeGasUsed: "1281076", gasUsed: "184521", confirmations: "3381527"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "3389304609732404259511619406927813494"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "3389304609732404259511619406927813494", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1507050325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x652146673583c156140674cdfc4f1c873951f808"}, {name: "weiAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "17186962907409132722750"}, {name: "customerId", type: "uint128", value: {s: 1, e: 36, c: [338930460, 97324042595116, 19406927813494]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "3874128504000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"18893620216736818538055918639639503462... )", async function( ) {
		const txOriginal = {blockNumber: "4333792", timeStamp: "1507050325", hash: "0x8ab514c5a017aa4a29856ebf41b20b99fa674f21d92c08814eca94ce0de802d2", nonce: "14", blockHash: "0x09b3ca0fb12326797703ee414fd3033e6ada3bfd376e019829a4e17426194829", transactionIndex: "27", from: "0xa5a9470bc79debf5ec4cef854cf77112404287b0", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1000000000000000000", gas: "250600", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000008e23c9f788464a64811c0c343a6b5803", contractAddress: "", cumulativeGasUsed: "2225275", gasUsed: "184521", confirmations: "3381527"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "188936202167368185380559186396395034627"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "188936202167368185380559186396395034627", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1507050325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xa5a9470bc79debf5ec4cef854cf77112404287b0"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3437392581481826544550"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [18893620216, 73681853805591, 86396395034627]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "2001786937000010000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"33818693016990531617431059813259986316... )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0xb1f94b7fb736df8f7b6c57fb548bf1ff2d0e8fb5a40341545a82830798de2baa", nonce: "13", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "35", from: "0xd74d9f9915e53b8bd0a6ed815ea075362e4ef8d2", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "200000000000000000", gas: "260300", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000fe6c6efde24a466b91d1b75985fbb77f", contractAddress: "", cumulativeGasUsed: "2629656", gasUsed: "184521", confirmations: "3381525"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "338186930169905316174310598132599863167"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "338186930169905316174310598132599863167", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1507050454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xd74d9f9915e53b8bd0a6ed815ea075362e4ef8d2"}, {name: "weiAmount", type: "uint256", value: "200000000000000000"}, {name: "tokenAmount", type: "uint256", value: "687478516296365308910"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [33818693016, 99053161743105, 98132599863167]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "84707866278661306" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"36355091531337654078759017448376573374... )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0xf3086fb54ea5ed2277fe670b1d44268f944d4a00eb091599665cb70fd4e129a3", nonce: "17", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "44", from: "0xe0050656082c9831ebd40b81f4c0886734cc7b5b", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2200000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000001b59bc66a3094505bd441f1db3071dbe", contractAddress: "", cumulativeGasUsed: "3253460", gasUsed: "184521", confirmations: "3381525"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "2200000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "36355091531337654078759017448376573374"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "36355091531337654078759017448376573374", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1507050454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe0050656082c9831ebd40b81f4c0886734cc7b5b"}, {name: "weiAmount", type: "uint256", value: "2200000000000000000"}, {name: "tokenAmount", type: "uint256", value: "7562263679260018398010"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [3635509153, 13376540787590, 17448376573374]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1058065470382535100" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0x17c0546a7497ee84e1c359ac74f5cb4103b653e18eca0bb64391d36b14bbfce7", nonce: "87", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "47", from: "0x1e54161768cf52953175cf72483ff205491d2aa9", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "3602215", gasUsed: "260300", confirmations: "3381525"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "10000000000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"16291806130966000406187587859632544319... )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0xb17e87dfdfe11fae3d5196f5382afd3e55e9e0ea67ebec9ab1130433cc2508ef", nonce: "23", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "48", from: "0x1226e80a416725eda3cda49202a16ac843fcd907", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "990000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000007a90e095253c47c28ec0ebcc11ac8677", contractAddress: "", cumulativeGasUsed: "3786736", gasUsed: "184521", confirmations: "3381525"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "990000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "162918061309660004061875878596325443191"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "162918061309660004061875878596325443191", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1507050454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1226e80a416725eda3cda49202a16ac843fcd907"}, {name: "weiAmount", type: "uint256", value: "990000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3403018655667008279104"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [16291806130, 96600040618758, 78596325443191]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "52549405079407023" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0x2166da988d83d8134b69aabcbbea472dbdd7916db43a79be4eed1303dcaac5d8", nonce: "10", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "71", from: "0x40880d91734e583ee362210d94fbefac1462d1ab", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "10000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "5688253", gasUsed: "260300", confirmations: "3381525"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "651000000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"27674889087701019774714353116472341003... )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0x92287e74e61362e1424c1613c91c298ac1ca025ef98564e3e836de694bf2c43d", nonce: "2", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "77", from: "0xc9672eba047f7dd7967be9b1ddd62bc9ebe0b41e", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "400000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000d033e5c937e84ec88d41b51ccb757472", contractAddress: "", cumulativeGasUsed: "6344030", gasUsed: "184521", confirmations: "3381525"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "276748890877010197747143531164723410034"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "276748890877010197747143531164723410034", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1507050454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xc9672eba047f7dd7967be9b1ddd62bc9ebe0b41e"}, {name: "weiAmount", type: "uint256", value: "400000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1374957032592730617820"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [27674889087, 70101977471435, 31164723410034]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "106846875386149834" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"31989324893294462926820180416416151679... )", async function( ) {
		const txOriginal = {blockNumber: "4333794", timeStamp: "1507050454", hash: "0xa3493dab7ad5f129643fd4f85df4c894270946536353070a824729fadfd00fa7", nonce: "0", blockHash: "0x17c24fcfb558c863709f533d9a64d99ea453ddd11ef4e7915e52c53956bf7cc0", transactionIndex: "79", from: "0x93b64c6be9ce7da95620399c1ac85c0d1a1ce410", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "4450000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000f0a932ded65b4e18b736facefadab4fe", contractAddress: "", cumulativeGasUsed: "6603189", gasUsed: "184521", confirmations: "3381525"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "4450000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "319893248932944629268201804164161516798"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "319893248932944629268201804164161516798", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1507050454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x93b64c6be9ce7da95620399c1ac85c0d1a1ce410"}, {name: "weiAmount", type: "uint256", value: "4450000000000000000"}, {name: "tokenAmount", type: "uint256", value: "15296396987594128123248"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [31989324893, 29446292682018, 4164161516798]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "15337349000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"36511998809312217535590990311559192708... )", async function( ) {
		const txOriginal = {blockNumber: "4333797", timeStamp: "1507050589", hash: "0x20a04cc8a3c9fe7c7e46314d2a7ab25572cb8caaaba80baef471ec87b2a3d9d4", nonce: "78", blockHash: "0x1676cd0482b88e0126c0628311adf06730067abc15603087f6796da71d378bc9", transactionIndex: "37", from: "0x56768c4d3862a6b0b90d6b5191795acce13f1d28", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "2000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000001b77f486ea0e4c15bb23553c09cae084", contractAddress: "", cumulativeGasUsed: "2563262", gasUsed: "184521", confirmations: "3381522"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "36511998809312217535590990311559192708"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "36511998809312217535590990311559192708", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1507050589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x56768c4d3862a6b0b90d6b5191795acce13f1d28"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "6874785162963653089100"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [3651199880, 93122175355909, 90311559192708]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "3226101807310248" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"10174419489700990314469661868022573805... )", async function( ) {
		const txOriginal = {blockNumber: "4333797", timeStamp: "1507050589", hash: "0x9c0d7f2bd79196abf11cec5b735cd8bcd0e1a65b831b0950bc98fe28fb33c0fb", nonce: "24", blockHash: "0x1676cd0482b88e0126c0628311adf06730067abc15603087f6796da71d378bc9", transactionIndex: "39", from: "0x24ae232a2f1cd815691a82fec5821f6f6ef8c876", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "4000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c000000000000000000000000000000004c8b381affbf48c099aec8aa3261ad49", contractAddress: "", cumulativeGasUsed: "2768834", gasUsed: "184521", confirmations: "3381522"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "101744194897009903144696618680225738057"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "101744194897009903144696618680225738057", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1507050589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x24ae232a2f1cd815691a82fec5821f6f6ef8c876"}, {name: "weiAmount", type: "uint256", value: "4000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "13749570325927306178200"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10174419489, 70099031446966, 18680225738057]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "161341822905759367" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"21352502111300578747874055927533560762... )", async function( ) {
		const txOriginal = {blockNumber: "4333797", timeStamp: "1507050589", hash: "0xd630583f338869ac2629a4b98a56a70f2e1e31eb1b6fcba29e2186cd158551af", nonce: "8", blockHash: "0x1676cd0482b88e0126c0628311adf06730067abc15603087f6796da71d378bc9", transactionIndex: "47", from: "0x7f01a102ff96bdd41ccbe80577402f544706ade5", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1500000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000a0a36c5714a64b5dbefa850a7d17e54a", contractAddress: "", cumulativeGasUsed: "3131903", gasUsed: "184521", confirmations: "3381522"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "213525021113005787478740559275335607626"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "213525021113005787478740559275335607626", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1507050589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7f01a102ff96bdd41ccbe80577402f544706ade5"}, {name: "weiAmount", type: "uint256", value: "1500000000000000000"}, {name: "tokenAmount", type: "uint256", value: "5156088872222739816825"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21352502111, 30057874787405, 59275335607626]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "4122699281000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"67630845027020007735483976479281063894... )", async function( ) {
		const txOriginal = {blockNumber: "4333797", timeStamp: "1507050589", hash: "0x0a4a5bab7e44b678940a25efcc36b42e2ba0c1ca9fec6181082d4059639cfc08", nonce: "27", blockHash: "0x1676cd0482b88e0126c0628311adf06730067abc15603087f6796da71d378bc9", transactionIndex: "48", from: "0xc1417dd374f047c4e4538052a3db2b6352c8e13f", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c0000000000000000000000000000000032e13a1a0fe14ba687233f4029ad27d6", contractAddress: "", cumulativeGasUsed: "3316424", gasUsed: "184521", confirmations: "3381522"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "67630845027020007735483976479281063894"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "67630845027020007735483976479281063894", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1507050589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xc1417dd374f047c4e4538052a3db2b6352c8e13f"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3437392581481826544550"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6763084502, 70200077354839, 76479281063894]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "230951816855527454" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithCustomerId( \"23730421380540101144653712520284775745... )", async function( ) {
		const txOriginal = {blockNumber: "4333797", timeStamp: "1507050589", hash: "0x7870464d76cea6fc3bee715eb5523761c3f91b07ce5e8c34ecc03d849273b03d", nonce: "3", blockHash: "0x1676cd0482b88e0126c0628311adf06730067abc15603087f6796da71d378bc9", transactionIndex: "71", from: "0x38c6d693711b2a490eff3e048bda4a934797d07f", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "65043588000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99e9376c00000000000000000000000000000000b287210ea5064151a017965addbe7491", contractAddress: "", cumulativeGasUsed: "4877482", gasUsed: "184521", confirmations: "3381522"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "65043588000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "237304213805401011446537125202847757457"}], name: "buyWithCustomerId", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithCustomerId(uint128)" ]( "237304213805401011446537125202847757457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1507050589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x38c6d693711b2a490eff3e048bda4a934797d07f"}, {name: "weiAmount", type: "uint256", value: "65043588000000000"}, {name: "tokenAmount", type: "uint256", value: "223580346864160355251"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [23730421380, 54010114465371, 25202847757457]}}], address: "0xbacd554538c8037545098a36361f54c4e1d0f94e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "17979148574201484" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4333798", timeStamp: "1507050612", hash: "0xe8489d7a274ef5fb91120527c5264d92417063196f9e21582faab85aac390c7a", nonce: "15", blockHash: "0x427194a05c24d8e1b0a4dd0d7cbae15e2073c1ce2d9499b2c2797a987a68ba7b", transactionIndex: "15", from: "0x7a0a875695f930e09585c066651038000b0df475", to: "0xbacd554538c8037545098a36361f54c4e1d0f94e", value: "1500000000000000000", gas: "261000", gasPrice: "31000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "784576", gasUsed: "261000", confirmations: "3381521"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
