var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "Ambassador"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xFEa61DBc3B9882eFcd139A5E28b32234b9c76aeA","0x6863B16d476d1975E3f9C1aA494148678a1e13c1","0xbd3696b01a487b012BA99628B06A1A7859F5CA23","0x3f0F86BC3a503003b24614BD176a54CC17aeD4F3","0x8D783D84A18A46e2f6b1d60cCdf0DCF0d045E990","0x49c9FC300B9dce02d0811efE4bBA02EBdfb7DFB3","0x90EBFF73Ac80bB978F6782d0c82B84F0e38c7a14","0xD1eDe8def3Ee9cceCf9d43CB7e981A74fE94627E","0xB081b0a79186253B05d5d9D41eC270f8Ede86740","0xE35E8Ec4a164F8377F4De8F410bf26a062af9558","0x50C4A39CbC66d7258a0805Ac48B1Aa0d386BA571","0x194c7be397166A5293dB82ADDDE603bC4934f89F","0x45Ac14C71197D3C8872ea3a05D13BBB9Fc9959A6","0x7478B13C5f79db22a70853633b2A1E1C932BB06e","0xD25A5aa0120Ef5e0702a2f87A244c000247B23cc","0x8A68925DF00e4ae0eB1A2E51C42bb4000dEA199E","0xdFb7213bF0E1C264b421119A70744E6A846000d1","0x87cC596b39AA78c03CfAC96837706dCC3762F8e7","0x04D6f26cd44d76C436f2e6361D016c58D6F5fdB8","0x25Ad093F3A91801626e30c07eCf8F8eEd6c2E95c","0x4C826DD1Dc36D9e9cf79f1a62aE3750e97E6efe2","0x8B718Fd622167227D163246E13120fd6356E6Be2","0x2637e19650eF2b1230591dAa4725F3834127b8b6","0xD11128501Bf742444103b1882624E0d3d4eB6760","0xeF3784e98d11CB6C5d847e9d8841279c294a453b","0x8ad03320E59167e4cA293E802524B9dbe01ad77B","0xE5A7bA5dF1887739e92815FA6CF5B0DF565Eb149","0x9048EEc0f97C228b58dA76eF8eD13B4E3D33FC60","0xb6327724b9F067D131710478e240B27a70E5942a","0xF9650631616B83b904f941814871bD0a8fEB79bE","0xcAAB4Df4864f9437B83cEA6281A8A0C29C7f89A5","0xC5CAaCA6B24d3ab85328e527e4F4BdeDf99EAF1c","0x1dF9f6FFc9De4E221e30199C4d7DDA3de07D42C4","0xA82495ba4eb673D848def5133dC7442D4691690a","0x2C29234f313ae1aFaF4CCDF2F4F55ad343032fd6","0x129c8d265B5cb0e4758A35b8b5190122266a7450","0xa9934C4e681eD4e715d9e2DfB4Ab5725b1706e72","0xc9A99fFB711191dd6960313818E0C0539067Bb6B","0xf4c33665E7625BC515b95ce0ba8610cAF9FB6e27","0x07883D850C7330fD87d59dBD06Fc1d27bfB99dA1","0xF026B366a8bCEf9F266B881eE8e2A288a8E531AF","0x43CA03936d429E7863e78ce9725E906d6bc59049","0x6E4A20C951D7450D459292bAc3A14e6E18D8B5f1","0xbbD2e65afD28E73Cab552ad55b972A016f98dFa4","0x04a08e3e7C015556BCFd136eB2Fc46825c3FF56A","0x0f46707579f2BB4Dd7d9bc6d2D22C68202A71Cde","0xD3be20D8437a4C3f96332f176F250052b9DbcF78","0xCF19445716c632EeE41FEb68E11b574B0A5A6Af1"]
addressListOriginal.length = 50
methodPrototypeListOriginal = [{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"euroThreshold","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"startRC","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"bonusThreshold","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"soldTokensWithoutBonus","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"euroRaisedRc","outputs":[{"name":"euro","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceUser","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"endRC","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = []
eventSignatureListOriginal = []
topicListOriginal = []
nBlocksOriginal = 50
fromBlockOriginal = 4546661
toBlockOriginal = 5028912
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_icoContract","value":4},{"type":"address","name":"_ambassadorAddr","value":5},{"type":"uint256[]","name":"_euroThreshold","value":["0","50","100","150","200","250","300"]},{"type":"uint256[]","name":"_bonusThreshold","value":["20","25","30","35","40","45","50"]},{"type":"uint256","name":"_startRC","value":"0"},{"type":"uint256","name":"_endRC","value":"0"}],"name":"Ambassador","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4546661","timeStamp":"1510601312","hash":"0x76a9d130014f0e31de5830b6d694eb05fae9b5f05ddf371e462b08258410811e","nonce":"407","blockHash":"0xd866cea9fdddb9ed52d436b10d4e218fa6fa0e3b221d2942a7144e27ee188870","transactionIndex":"53","from":"0x6863b16d476d1975e3f9c1aa494148678a1e13c1","to":0,"value":"0","gas":"986245","gasPrice":"1000000000","isError":"0","txreceipt_status":"1","input":"0xfe1412dc000000000000000000000000bd3696b01a487b012ba99628b06a1a7859f5ca230000000000000000000000003f0f86bc3a503003b24614bd176a54cc17aed4f300000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000009600000000000000000000000000000000000000000000000000000000000000c800000000000000000000000000000000000000000000000000000000000000fa000000000000000000000000000000000000000000000000000000000000012c000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000032","contractAddress":"0xfea61dbc3b9882efcd139a5e28b32234b9c76aea","cumulativeGasUsed":"3868110","gasUsed":"986245","confirmations":"3194777"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"_icoContract","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"},{"type":"address","name":"_ambassadorAddr","value":"0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b"},{"type":"uint256[]","name":"_euroThreshold","value":["0","50","100","150","200","250","300"]},{"type":"uint256[]","name":"_bonusThreshold","value":["20","25","30","35","40","45","50"]},{"type":"uint256","name":"_startRC","value":"0"},{"type":"uint256","name":"_endRC","value":"0"}],"name":"Ambassador","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
