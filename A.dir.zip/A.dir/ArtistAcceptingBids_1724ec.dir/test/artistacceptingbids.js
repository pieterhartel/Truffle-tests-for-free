const ArtistAcceptingBids = artifacts.require( "./ArtistAcceptingBids.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ArtistAcceptingBids" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x921ade9018Eec4a01e41e80a7eeBa982B61724Ec", "0x3f8C962eb167aD2f80C72b5F933511CcDF0719D4", "0xFBeef911Dc5821886e1dda71586d90eD28174B7d", "0xa2cD656f8461d2C186D69fFB8A4a5c10EFF0914d", "0x0f48669B1681D41357EAc232F516B77D0c10F0F1", "0xf8b32D30aC6Ab3030595432533D7836FD76B078d", "0xCed2662Fe30D876bEf52F219eeAC67e2b328Effc", "0x576a655161B5502dCf40602BE1f3519A89b71658", "0xa4aD045d62a493f0ED883b413866448AfB13087C", "0xceF2bf4aD6D84Aa37Fcc4Cab6530028EB31c8e69", "0x96DEAD6149f580884410c873F6dA8d3DDE16F13C", "0x0b715cA8DC39e7f8A480D28d9822ae02f0A57008", "0xf397B52432fE7149Ce74849B15223f4502cdB1d3", "0xe0F228070D8F7b5C25E9375Fa70FA418f8dfEDf8"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_editionNumber", type: "uint256"}], name: "highestBidForEdition", outputs: [{name: "_bidder", type: "address"}, {name: "_value", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minBidAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_editionNumber", type: "uint256"}], name: "editionController", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "koCommissionAccount", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_editionNumber", type: "uint256"}], name: "auctionDetails", outputs: [{name: "_enabled", type: "bool"}, {name: "_bidder", type: "address"}, {name: "_value", type: "uint256"}, {name: "_controller", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "kodaAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_editionNumber", type: "uint256"}], name: "isEditionEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidIncreased", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}], name: "BidWithdrawn", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidderRefunded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}], name: "AuctionCancelled", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BidPlaced(address,uint256,uint256)", "BidIncreased(address,uint256,uint256)", "BidWithdrawn(address,uint256)", "BidAccepted(address,uint256,uint256,uint256)", "BidderRefunded(uint256,address,uint256)", "AuctionCancelled(uint256)", "Pause()", "Unpause()", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xdf8644c0a4c21ed214ce69f395675b3a5fcd1039083daea5058898de40ea3149", "0xabdd90c2558a13a111c790b3e52da9a52768834a1139e2993b68b6db09c071c5", "0x03f0427e8bcfdf5f69217150cf160ebe2dac5fa607336fd7643bfd61a9019080", "0x77273c2a169296530c120eb6f1142012378aad0ed4337eac090eaf4223a1a2f1", "0xa01ed4ff1bfc084518bd795b4114da41c800c9ae1fc5e594cb505cb4c0c3fae1", "0x2809c7e17bf978fbc7194c0a694b638c4215e9140cacc6c38ca36010b45697df", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6568535 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6605955 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_kodaAddress", value: 4}], name: "ArtistAcceptingBids", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_editionNumber", value: random.range( maxRandom )}], name: "highestBidForEdition", outputs: [{name: "_bidder", type: "address"}, {name: "_value", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "highestBidForEdition(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBidAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBidAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_editionNumber", value: random.range( maxRandom )}], name: "editionController", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "editionController(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "koCommissionAccount", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "koCommissionAccount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_editionNumber", value: random.range( maxRandom )}], name: "auctionDetails", outputs: [{name: "_enabled", type: "bool"}, {name: "_bidder", type: "address"}, {name: "_value", type: "uint256"}, {name: "_controller", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "auctionDetails(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "kodaAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "kodaAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_editionNumber", value: random.range( maxRandom )}], name: "isEditionEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isEditionEnabled(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ArtistAcceptingBids", function( accounts ) {

	it( "TEST: ArtistAcceptingBids( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6568535", timeStamp: "1540296373", hash: "0xa19d9d02835a8cf93d091bce95e83a8046598c2a37664f9364134e4cdd012969", nonce: "673", blockHash: "0xeec80a3da25f80cd3f872a0f1cd4880fbc5b56838b84ae7837e70eafc104f48a", transactionIndex: "23", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: 0, value: "0", gas: "6075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3eb7c8bb000000000000000000000000fbeef911dc5821886e1dda71586d90ed28174b7d", contractAddress: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", cumulativeGasUsed: "4034202", gasUsed: "2357148", confirmations: "1171966"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_kodaAddress", value: addressList[4]}], name: "ArtistAcceptingBids", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ArtistAcceptingBids.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540296373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ArtistAcceptingBids.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"18500\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6568717", timeStamp: "1540299039", hash: "0x82494fa0a4740b191892dd6540bee9798472715413a422f611f15e5288a1141a", nonce: "675", blockHash: "0x4676bd0ea99622d40e37f4fdac0a18f70f8115159386efb529d1790f0e594948", transactionIndex: "23", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "6075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004844000000000000000000000000a2cd656f8461d2c186d69ffb8a4a5c10eff0914d", contractAddress: "", cumulativeGasUsed: "1299275", gasUsed: "64720", confirmations: "1171784"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}, {type: "address", name: "_address", value: addressList[5]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "18500", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540299039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"18600\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6570380", timeStamp: "1540322862", hash: "0xb872eec45c3632480e71f1f9fca3fe75c88c3849cc37ac2cdfa86fd0ee875468", nonce: "676", blockHash: "0x7da4661b641f46a57027bb64ae8d7e36621707e8ed2651f4ed9c90a2ca87a4cd", transactionIndex: "6", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "6075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000048a8000000000000000000000000a2cd656f8461d2c186d69ffb8a4a5c10eff0914d", contractAddress: "", cumulativeGasUsed: "442628", gasUsed: "64720", confirmations: "1170121"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18600"}, {type: "address", name: "_address", value: addressList[5]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "18600", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540322862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"18700\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6570642", timeStamp: "1540326398", hash: "0xda6f580a0c5d849811648747c410408abdd52d101811b96794d84e5bbbf91a16", nonce: "677", blockHash: "0x6b61a029b0df69756730de748086874438f8b1b8fb6213100da94dabebd47104", transactionIndex: "5", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "6075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c3000000000000000000000000000000000000000000000000000000000000490c000000000000000000000000a2cd656f8461d2c186d69ffb8a4a5c10eff0914d", contractAddress: "", cumulativeGasUsed: "207840", gasUsed: "64720", confirmations: "1169859"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18700"}, {type: "address", name: "_address", value: addressList[5]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "18700", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540326398 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"18800\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6570679", timeStamp: "1540326828", hash: "0xcfce85deca87143ad618b0245a3de9f276ce01f4d96f317187a84429f5b9b82f", nonce: "678", blockHash: "0x4896871a0c5d62549765aa1c72b0b1a7b4eafa165998b15fd5582bae228da3a7", transactionIndex: "31", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "6075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004970000000000000000000000000a2cd656f8461d2c186d69ffb8a4a5c10eff0914d", contractAddress: "", cumulativeGasUsed: "1886190", gasUsed: "64720", confirmations: "1169822"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18800"}, {type: "address", name: "_address", value: addressList[5]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "18800", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540326828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6570847", timeStamp: "1540329505", hash: "0x7751ae1e6c32f880bbde82b73481c75c07f6eca32abedfe2caaad4a631e3faec", nonce: "48", blockHash: "0x137a203362daa58e2912df671c418a80e82103b79a4a1e78c06665fc2284dd09", transactionIndex: "66", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "98712", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "4090679", gasUsed: "75933", confirmations: "1169654"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540329505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6570852", timeStamp: "1540329549", hash: "0xb9061aba452400886e8c45b330885f1f76a9aa62e37369d00ecb0cf0e2ca883a", nonce: "49", blockHash: "0xa85ab2b4b1519a968b96e89e44e928ed150322945e5fd7634dbc725cb3510c55", transactionIndex: "26", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "56826", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0eaaf4c80000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "1067223", gasUsed: "28713", confirmations: "1169649"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "withdrawBid", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540329549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}], name: "BidWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidWithdrawn", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18500"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidderRefunded", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidderRefunded", events: [{name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6570866", timeStamp: "1540329697", hash: "0x90a6f727f343bba9235b6192f8cdbcdcc9df6d7ea1de284baea03a03add9c4e3", nonce: "50", blockHash: "0xb66704fb9b526d572b3d1e124fe1d57450135cabb86d4067026f10262de4ee72", transactionIndex: "67", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "79212", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "2802622", gasUsed: "60933", confirmations: "1169635"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540329697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18600\" )", async function( ) {
		const txOriginal = {blockNumber: "6573983", timeStamp: "1540373713", hash: "0x486b3b186b84ee9f4fbb63787fd0a14f26b3773bf1ff10566e3429572e4cdf42", nonce: "33", blockHash: "0x552849db89d1fb7b30b6b90fabeab40096fed13da870be84803b965d92acd9d3", transactionIndex: "217", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "20000000000000000", gas: "113899", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef4500000000000000000000000000000000000000000000000000000000000048a8", contractAddress: "", cumulativeGasUsed: "7511926", gasUsed: "75933", confirmations: "1166518"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18600"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540373713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0xf8b32d30ac6ab3030595432533d7836fd76b078d"}, {name: "_editionNumber", type: "uint256", value: "18600"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16884417495321770994" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"18600\" )", async function( ) {
		const txOriginal = {blockNumber: "6574818", timeStamp: "1540385566", hash: "0x956bccc09deea3dccf9dab084dabdc5a9627d7f0a635d7a3037bc1c0b29edc91", nonce: "0", blockHash: "0x62f52da096a7ad9c7d1eb3864bda52cea5ad0e17fb91fe09b00d12324b188bd4", transactionIndex: "175", from: "0xa2cd656f8461d2c186d69ffb8a4a5c10eff0914d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "502017", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a00000000000000000000000000000000000000000000000000000000000048a8", contractAddress: "", cumulativeGasUsed: "7409044", gasUsed: "319678", confirmations: "1165683"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18600"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "18600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540385566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0xf8b32d30ac6ab3030595432533d7836fd76b078d"}, {name: "_editionNumber", type: "uint256", value: "18600"}, {name: "_tokenId", type: "uint256", value: "18601"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34575249977723571" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6574826", timeStamp: "1540385680", hash: "0xcc02903a23b400b741ccc5e4b33e170b5dcc31c85e7493eab68a09cdb88204f3", nonce: "1", blockHash: "0x848816ed0bb396486f85df2354d7930e4dc5e5627631749598e92bd0a6837d8d", transactionIndex: "13", from: "0xa2cd656f8461d2c186d69ffb8a4a5c10eff0914d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "502017", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a0000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "3107941", gasUsed: "319678", confirmations: "1165675"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540385680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_tokenId", type: "uint256", value: "18501"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34575249977723571" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6576584", timeStamp: "1540409876", hash: "0x8020f9ff063aefc57ebec192ccd056b213043c3d010948ea0a91d6ad2cff0478", nonce: "50", blockHash: "0xdec86fa323634c271ac18ee8de44dcf6a4a15c4de425838cc4960db11a1ddf27", transactionIndex: "83", from: "0xced2662fe30d876bef52f219eeac67e2b328effc", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "7958507", gasUsed: "75933", confirmations: "1163917"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540409876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0xced2662fe30d876bef52f219eeac67e2b328effc"}, {name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "114171039020575798" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"18500\" )", async function( ) {
		const txOriginal = {blockNumber: "6581447", timeStamp: "1540478936", hash: "0xefbcff3c82fc8a1e10e9030ef10835498e7daf07d4f7c7f76e40b158aab085a8", nonce: "2", blockHash: "0x3a8aa4ada1e09c3d971d81d9236322cdeb76f8eb74bc57ac99061f53a59b1315", transactionIndex: "88", from: "0xa2cd656f8461d2c186d69ffb8a4a5c10eff0914d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "502017", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a0000000000000000000000000000000000000000000000000000000000004844", contractAddress: "", cumulativeGasUsed: "4412219", gasUsed: "319678", confirmations: "1159054"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18500"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "18500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540478936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0xced2662fe30d876bef52f219eeac67e2b328effc"}, {name: "_editionNumber", type: "uint256", value: "18500"}, {name: "_tokenId", type: "uint256", value: "18502"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34575249977723571" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18800\" )", async function( ) {
		const txOriginal = {blockNumber: "6582127", timeStamp: "1540487988", hash: "0xbb439b5e759430adf8e634434f43a4b88d721aef230e77b14fc939d5c5696e9d", nonce: "52", blockHash: "0x133d6f240ff4b28226a16cdb4fa3495e5f645f97505a7b22630ebef2232c84c2", transactionIndex: "88", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004970", contractAddress: "", cumulativeGasUsed: "7608480", gasUsed: "75933", confirmations: "1158374"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18800"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540487988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18800"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18700\" )", async function( ) {
		const txOriginal = {blockNumber: "6582129", timeStamp: "1540488050", hash: "0xff294f03f9f1896588b8b8e58f1767f938a0bd49597ef5c1bca83766cfdf1872", nonce: "53", blockHash: "0xa6a6fc0e157ba0cb68d3df791356ec38ec09fc08c549dc6cf40c93cbafa4c86a", transactionIndex: "49", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef45000000000000000000000000000000000000000000000000000000000000490c", contractAddress: "", cumulativeGasUsed: "2772296", gasUsed: "75933", confirmations: "1158372"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18700"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540488050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18700"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"18600\" )", async function( ) {
		const txOriginal = {blockNumber: "6582131", timeStamp: "1540488069", hash: "0x5d5f5c29e1161067c5ac2c822d6d2db61e646647f954b2263296061c492bab69", nonce: "54", blockHash: "0xfc64b690e45c68e1f5a3d2898e5851c5a38f301d2386aa5c1926fcd69f9b1473", transactionIndex: "10", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef4500000000000000000000000000000000000000000000000000000000000048a8", contractAddress: "", cumulativeGasUsed: "697541", gasUsed: "75933", confirmations: "1158370"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18600"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "18600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540488069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18600"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"18800\" )", async function( ) {
		const txOriginal = {blockNumber: "6586518", timeStamp: "1540550312", hash: "0x569a284864848e0702b47d6328a427339f5d83953e579f61c35c4b7126e25650", nonce: "3", blockHash: "0xab4ef536549492067913957114a714300ea4bf605773d0844a1ff2f08b95ee42", transactionIndex: "86", from: "0xa2cd656f8461d2c186d69ffb8a4a5c10eff0914d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "502017", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a0000000000000000000000000000000000000000000000000000000000004970", contractAddress: "", cumulativeGasUsed: "4128773", gasUsed: "319678", confirmations: "1153983"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18800"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "18800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540550312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18800"}, {name: "_tokenId", type: "uint256", value: "18801"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34575249977723571" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"18700\" )", async function( ) {
		const txOriginal = {blockNumber: "6586538", timeStamp: "1540550506", hash: "0xe341bc14592dd2fef0ea4606082a48b6aca0acaad40274f61ef2bb0956a96740", nonce: "4", blockHash: "0x184c97e27bfdab7cdfd93b7adfdffd3b6cf14ff8df11c17cb866ecee474578af", transactionIndex: "19", from: "0xa2cd656f8461d2c186d69ffb8a4a5c10eff0914d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "502017", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a000000000000000000000000000000000000000000000000000000000000490c", contractAddress: "", cumulativeGasUsed: "7712467", gasUsed: "319678", confirmations: "1153963"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18700"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "18700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540550506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "18700"}, {name: "_tokenId", type: "uint256", value: "18701"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34575249977723571" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"19600\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6586682", timeStamp: "1540552631", hash: "0x623eff4f284cae36f4f892a74838205bd3be11554e61bea681d7b09af76d26e0", nonce: "692", blockHash: "0xdf713ab23f537f46fd12e8d310bde84277241dc1b9026ffec12ea913cdb421fc", transactionIndex: "119", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004c90000000000000000000000000576a655161b5502dcf40602be1f3519a89b71658", contractAddress: "", cumulativeGasUsed: "7937185", gasUsed: "64720", confirmations: "1153819"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19600"}, {type: "address", name: "_address", value: addressList[9]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "19600", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540552631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"21000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6586710", timeStamp: "1540553153", hash: "0xd155314c565caba62688e87c29bc4955f1405d956c3b4546a1fb301b370c428d", nonce: "693", blockHash: "0x4bd5347435edc29e28bcd6e4d44c296ff6eae30b66fc2b6d1d777a371c2f44e9", transactionIndex: "4", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000005208000000000000000000000000a4ad045d62a493f0ed883b413866448afb13087c", contractAddress: "", cumulativeGasUsed: "213377", gasUsed: "64720", confirmations: "1153791"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21000"}, {type: "address", name: "_address", value: addressList[10]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "21000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540553153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"11000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6586710", timeStamp: "1540553153", hash: "0x151c413420c0c26eb2686284273e181c02ab201e45b3479f93dc6c79c6807d3a", nonce: "694", blockHash: "0x4bd5347435edc29e28bcd6e4d44c296ff6eae30b66fc2b6d1d777a371c2f44e9", transactionIndex: "5", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000002af8000000000000000000000000a4ad045d62a493f0ed883b413866448afb13087c", contractAddress: "", cumulativeGasUsed: "278097", gasUsed: "64720", confirmations: "1153791"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "11000"}, {type: "address", name: "_address", value: addressList[10]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "11000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540553153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"19700\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6586712", timeStamp: "1540553165", hash: "0x9e8a92c00e4816cceb77dd900275f18b3f368870e4ea2d0e3e7bd28584723057", nonce: "695", blockHash: "0xca029337f6e3bad766fde66cbc7e73ea3b442db8b664f206e9db0325cebb1103", transactionIndex: "56", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004cf4000000000000000000000000a4ad045d62a493f0ed883b413866448afb13087c", contractAddress: "", cumulativeGasUsed: "4586425", gasUsed: "64720", confirmations: "1153789"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19700"}, {type: "address", name: "_address", value: addressList[10]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "19700", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540553165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"19600\" )", async function( ) {
		const txOriginal = {blockNumber: "6586749", timeStamp: "1540553627", hash: "0xef73724dc571d611831ff598bac25629b2fa60349cea30390629ea00206b5499", nonce: "55", blockHash: "0x6129140ea0202a7e7cc8c2784d60b652df720a09b5af5dd7cf4aa19440adbd99", transactionIndex: "70", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004c90", contractAddress: "", cumulativeGasUsed: "4799373", gasUsed: "75933", confirmations: "1153752"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19600"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "19600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540553627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "19600"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"19700\" )", async function( ) {
		const txOriginal = {blockNumber: "6586801", timeStamp: "1540554470", hash: "0xc97927b1ac0679e7e2a77841dcea282ee2f9cb5e8026b9d0b070527eef0d5aa7", nonce: "56", blockHash: "0x8c8bd7fe9c9110648c34747f07d4b0dfd704d7964caf1008747da7293e050f5f", transactionIndex: "45", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000004cf4", contractAddress: "", cumulativeGasUsed: "7705385", gasUsed: "75933", confirmations: "1153700"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19700"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "19700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540554470 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "19700"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"12000\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6587078", timeStamp: "1540558476", hash: "0x78df1fb49b5626d8d71eece0ebdc0b1f1ba9c171385ce10f1320ad58d86b0365", nonce: "696", blockHash: "0xc845484f67f99f1e423907a808d6370f3233bba0157a3f1f1a0985eda786f82e", transactionIndex: "184", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000002ee0000000000000000000000000f8b32d30ac6ab3030595432533d7836fd76b078d", contractAddress: "", cumulativeGasUsed: "5744030", gasUsed: "64720", confirmations: "1153423"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "12000"}, {type: "address", name: "_address", value: addressList[7]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "12000", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540558476 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"12000\" )", async function( ) {
		const txOriginal = {blockNumber: "6587108", timeStamp: "1540559001", hash: "0xa7e44c1e5353170796f05c5e354c2206f64d30c1792c6f3617b6d930c80b203f", nonce: "57", blockHash: "0xfd5cb93eb5b8ff8271dd3b2f1bca18e751d528207a88c6729ab8084a9c5d127c", transactionIndex: "48", from: "0x0f48669b1681d41357eac232f516b77d0c10f0f1", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "10000000000000000", gas: "113899", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000002ee0", contractAddress: "", cumulativeGasUsed: "7309429", gasUsed: "75933", confirmations: "1153393"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "12000"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "12000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540559001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_editionNumber", type: "uint256", value: "12000"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1993121983165580561" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"22800\", addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6589262", timeStamp: "1540589343", hash: "0x7fb3d647b89af9a94b7d2e5d1d471756279fabfa5181c1068991857b4648c282", nonce: "708", blockHash: "0xaf40a7e8fbae36a2a1627f8fc39b31c77de65c4bf54cb2d956ea289bbac13f37", transactionIndex: "104", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "3150000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000005910000000000000000000000000cef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", contractAddress: "", cumulativeGasUsed: "6812101", gasUsed: "64720", confirmations: "1151239"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "22800"}, {type: "address", name: "_address", value: addressList[11]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "22800", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540589343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"18100\", addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6589266", timeStamp: "1540589437", hash: "0x0425e89de35a80d369e4ba54c664616887eeba31a8d6b052dc7a4a52b2c9453b", nonce: "709", blockHash: "0x18dd0d06b8fd74ee7aa63c8bdb023a4bee460c0a3fcaf385ed77a3e1b0214f7b", transactionIndex: "82", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "3150000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000046b4000000000000000000000000cef2bf4ad6d84aa37fcc4cab6530028eb31c8e69", contractAddress: "", cumulativeGasUsed: "7922178", gasUsed: "64720", confirmations: "1151235"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "18100"}, {type: "address", name: "_address", value: addressList[11]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "18100", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540589437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"22900\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6591680", timeStamp: "1540623264", hash: "0xa16885b4b2539da52e291f7b661c10ecbf9874c40878cfccd22854e323a498b6", nonce: "710", blockHash: "0x2e8d479f04cda5cd72179e78f8d6e572e061a58f28f850cd2bd8901320d66802", transactionIndex: "85", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "64720", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000005974000000000000000000000000a4ad045d62a493f0ed883b413866448afb13087c", contractAddress: "", cumulativeGasUsed: "6923031", gasUsed: "64720", confirmations: "1148821"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "22900"}, {type: "address", name: "_address", value: addressList[10]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "22900", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540623264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"22800\" )", async function( ) {
		const txOriginal = {blockNumber: "6593952", timeStamp: "1540655294", hash: "0xfeff65fc4ba9be21ede269dce7ffd55cbb16ee1d3f52e65ed491b664f820bd9f", nonce: "38", blockHash: "0xdf49326c0a61eabc706e5812c3347fb86f1090487cd84046330dd8198734088e", transactionIndex: "145", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "30000000000000000", gas: "113899", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000005910", contractAddress: "", cumulativeGasUsed: "7775598", gasUsed: "75933", confirmations: "1146549"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "22800"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "22800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540655294 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0xf8b32d30ac6ab3030595432533d7836fd76b078d"}, {name: "_editionNumber", type: "uint256", value: "22800"}, {name: "_amount", type: "uint256", value: "30000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16884417495321770994" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: placeBid( \"12000\" )", async function( ) {
		const txOriginal = {blockNumber: "6595900", timeStamp: "1540683036", hash: "0xe6c749385c891733d7deb060a692a7b40df6ef364d40a5adbd1b4b76c1b19afb", nonce: "17", blockHash: "0x6ecae938d3dc51f46b7f10e64102a065885dcfe34a54156cb08e489458375dbe", transactionIndex: "0", from: "0x576a655161b5502dcf40602be1f3519a89b71658", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "20000000000000000", gas: "136269", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x9979ef450000000000000000000000000000000000000000000000000000000000002ee0", contractAddress: "", cumulativeGasUsed: "75846", gasUsed: "75846", confirmations: "1144601"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "12000"}], name: "placeBid", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBid(uint256)" ]( "12000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540683036 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidPlaced", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BidPlaced", events: [{name: "_bidder", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_editionNumber", type: "uint256", value: "12000"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_amount", type: "uint256"}], name: "BidderRefunded", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidderRefunded", events: [{name: "_editionNumber", type: "uint256", value: "12000"}, {name: "_bidder", type: "address", value: "0x0f48669b1681d41357eac232f516b77d0c10f0f1"}, {name: "_amount", type: "uint256", value: "10000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "36531414987483172" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: acceptBid( \"12000\" )", async function( ) {
		const txOriginal = {blockNumber: "6597801", timeStamp: "1540709826", hash: "0x8084958dd72db30d94cded64dec86a8625cedb80ffa601fb095f3f27b178fdec", nonce: "39", blockHash: "0x4c7dcaa05ed447d05fd775b562c4415879c144f2ed2d900765242f8338aad5b7", transactionIndex: "27", from: "0xf8b32d30ac6ab3030595432533d7836fd76b078d", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "479517", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x2b1fd58a0000000000000000000000000000000000000000000000000000000000002ee0", contractAddress: "", cumulativeGasUsed: "7220141", gasUsed: "304678", confirmations: "1142700"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "12000"}], name: "acceptBid", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptBid(uint256)" ]( "12000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540709826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_bidder", type: "address"}, {indexed: true, name: "_editionNumber", type: "uint256"}, {indexed: true, name: "_tokenId", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "BidAccepted", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BidAccepted", events: [{name: "_bidder", type: "address", value: "0x576a655161b5502dcf40602be1f3519a89b71658"}, {name: "_editionNumber", type: "uint256", value: "12000"}, {name: "_tokenId", type: "uint256", value: "12002"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0x921ade9018eec4a01e41e80a7eeba982b61724ec"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "16884417495321770994" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"21200\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604841", timeStamp: "1540809841", hash: "0x177028928633ee0220a29f0a8d7db2a763323eec89fb1aecd73f21cb0013aec5", nonce: "711", blockHash: "0xf0eff556a9c92b7333f93275c7fbfa3e5ed0b7102aaa4280ce3131eb29c52959", transactionIndex: "67", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000052d000000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3880987", gasUsed: "64720", confirmations: "1135660"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21200"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "21200", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540809841 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"19200\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604841", timeStamp: "1540809841", hash: "0x8e325d0d4672efcf0f3141c83a6de254c1c2822b070dbfd9c258dae11e18cf99", nonce: "712", blockHash: "0xf0eff556a9c92b7333f93275c7fbfa3e5ed0b7102aaa4280ce3131eb29c52959", transactionIndex: "68", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004b0000000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3945643", gasUsed: "64656", confirmations: "1135660"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19200"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "19200", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540809841 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"19100\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604881", timeStamp: "1540810435", hash: "0x9833327dbeb8ff919859660fb9af5e055574ff5817eeec35840db74e97b56ad9", nonce: "713", blockHash: "0x0bc6f97e2daa34018dbb666a61cd8d3e17e45f5bd85e9d38acdea81090c5c631", transactionIndex: "49", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000004a9c00000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "2774961", gasUsed: "64720", confirmations: "1135620"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "19100"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "19100", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540810435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"6200\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604885", timeStamp: "1540810477", hash: "0xcc4a3b84995f08f6994dceeed2decf0d43f179dd49b894ee40a89b8fff0ad00a", nonce: "714", blockHash: "0x03ba400d02800f5b56c4b3853e7c8693c3bb0491b374cbaf5e0d415dd8d5f816", transactionIndex: "46", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c3000000000000000000000000000000000000000000000000000000000000183800000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "2848424", gasUsed: "64720", confirmations: "1135616"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "6200"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "6200", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540810477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"6500\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604902", timeStamp: "1540810729", hash: "0xc2b73606c5356a2d4e75c51febc36990b8c2ec295c60267b0f562a2fd43c31c7", nonce: "715", blockHash: "0xcfec2c84d99d2b204ed86019582b8d999f8264aba94b6c07a51880451ae0576f", transactionIndex: "74", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c3000000000000000000000000000000000000000000000000000000000000196400000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3697581", gasUsed: "64720", confirmations: "1135599"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "6500"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "6500", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540810729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"8100\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604902", timeStamp: "1540810729", hash: "0x36dd0dbf94e4ca1ae862f8d0741cabdd0567afa45399cc0c9d87025125e4fabd", nonce: "716", blockHash: "0xcfec2c84d99d2b204ed86019582b8d999f8264aba94b6c07a51880451ae0576f", transactionIndex: "75", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000001fa400000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3762301", gasUsed: "64720", confirmations: "1135599"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "8100"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "8100", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540810729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"8200\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604930", timeStamp: "1540811243", hash: "0x4e620d34560ac3cccbc20157e06b346678b8f051eee18ed879005534dcfa75f1", nonce: "717", blockHash: "0x26bba5e3ada5c7a88e49cec8f06cb1a8e7f6128a08eb6fbb696866519e5d7e96", transactionIndex: "48", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c3000000000000000000000000000000000000000000000000000000000000200800000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3677801", gasUsed: "64720", confirmations: "1135571"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "8200"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "8200", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540811243 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"6900\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6604930", timeStamp: "1540811243", hash: "0xa6618e11d33eb301b3d3c54144bc1e766101fed1091887b72f7d49e707e5d26c", nonce: "718", blockHash: "0x26bba5e3ada5c7a88e49cec8f06cb1a8e7f6128a08eb6fbb696866519e5d7e96", transactionIndex: "49", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000001af400000000000000000000000096dead6149f580884410c873f6da8d3dde16f13c", contractAddress: "", cumulativeGasUsed: "3742521", gasUsed: "64720", confirmations: "1135571"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "6900"}, {type: "address", name: "_address", value: addressList[12]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "6900", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540811243 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"20700\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6605036", timeStamp: "1540812710", hash: "0xfe16315e28a661a7683bf296fbff95095a0b0434c917ff67515cc3c98b4f8d9e", nonce: "719", blockHash: "0x4a0718c0f9081bd7353df8682420443ffb8eaa822ec97df34432ca51473ba26d", transactionIndex: "51", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000050dc0000000000000000000000000b715ca8dc39e7f8a480d28d9822ae02f0a57008", contractAddress: "", cumulativeGasUsed: "3924136", gasUsed: "64720", confirmations: "1135465"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "20700"}, {type: "address", name: "_address", value: addressList[13]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "20700", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540812710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"20800\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6605040", timeStamp: "1540812769", hash: "0xa77b6191f4a170b48db4beafc76e3fa27db970a74fbf3c92c6f5cb778af21963", nonce: "720", blockHash: "0x3a4ea5e6bf6192ce3e824645152d02c22e2b45baf273892a6bd3e9312573f4f7", transactionIndex: "86", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000051400000000000000000000000000b715ca8dc39e7f8a480d28d9822ae02f0a57008", contractAddress: "", cumulativeGasUsed: "3028439", gasUsed: "64720", confirmations: "1135461"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "20800"}, {type: "address", name: "_address", value: addressList[13]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "20800", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540812769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"20900\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6605061", timeStamp: "1540813095", hash: "0x8ea745452255076b32ea88ac319df5cb0bb2fb0ec48e817e8af7b5a0e92d564e", nonce: "721", blockHash: "0xe44fb8e9781f6785fe4d22bc46280e9c35f60ea11ed002a9821638daabbdb046", transactionIndex: "42", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000051a40000000000000000000000000b715ca8dc39e7f8a480d28d9822ae02f0a57008", contractAddress: "", cumulativeGasUsed: "3916656", gasUsed: "64720", confirmations: "1135440"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "20900"}, {type: "address", name: "_address", value: addressList[13]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "20900", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540813095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"8400\", addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6605063", timeStamp: "1540813120", hash: "0x10d26fdf029f0a4535f3953e66ec1805dcf1c010ec33b8d2c7d2e6a1d617072e", nonce: "722", blockHash: "0x5a9c1d13368b22c01a50d3bcbf58fa3954192049a2da10c306b3ff8b2fa0c74f", transactionIndex: "88", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000020d0000000000000000000000000f397b52432fe7149ce74849b15223f4502cdb1d3", contractAddress: "", cumulativeGasUsed: "3863009", gasUsed: "64720", confirmations: "1135438"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "8400"}, {type: "address", name: "_address", value: addressList[14]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "8400", addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540813120 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"8900\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605833", timeStamp: "1540823697", hash: "0x88754379ee8ef577eedf0ab484352d4d9b914d2bf25f6dcdefb77c29877d5dec", nonce: "724", blockHash: "0x6b936d75562af493aa06654571cd7c1b71d216ba5a215955afe09784d75fd839", transactionIndex: "57", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000022c4000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "2633939", gasUsed: "64720", confirmations: "1134668"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "8900"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "8900", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540823697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"9000\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605837", timeStamp: "1540823742", hash: "0xb27fddd903848394fffcbcd2a8e6d9709e3982dcb6d943a221b58ec56c9c012c", nonce: "725", blockHash: "0xef568b8b32b75914db01207ca83fdbe8d66b589de6aafa9f10fb2fb5339d80b7", transactionIndex: "71", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000002328000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "3047410", gasUsed: "64720", confirmations: "1134664"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9000"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "9000", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540823742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"9600\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605837", timeStamp: "1540823742", hash: "0xf3b6ca7be9bc42a8a53b839a473f52bf5618bb818a26ae488b24ac44d457f592", nonce: "726", blockHash: "0xef568b8b32b75914db01207ca83fdbe8d66b589de6aafa9f10fb2fb5339d80b7", transactionIndex: "72", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000002580000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "3112130", gasUsed: "64720", confirmations: "1134664"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9600"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "9600", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540823742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"21300\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605847", timeStamp: "1540823851", hash: "0xd5720a50297f5201f620a83f07ec1529806448a2e7e8c4903fcf5e27decc660e", nonce: "727", blockHash: "0x10f3567726a5e71b643cefddce3ba8e78ed1c982ce967f29d1090a6f3a2417c4", transactionIndex: "51", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000005334000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "3750368", gasUsed: "64720", confirmations: "1134654"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "21300"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "21300", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540823851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"9800\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605949", timeStamp: "1540825325", hash: "0xe81a5c9646b8e7ce42658e8a1c7c0a610fa169c2d7a0d901f61d33d6ada5eca2", nonce: "728", blockHash: "0x9f974f9ed147f07b6d51db9a3843a94c3116071255a93206262b52423d11eaf2", transactionIndex: "65", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c30000000000000000000000000000000000000000000000000000000000002648000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "3003079", gasUsed: "64720", confirmations: "1134552"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9800"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "9800", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540825325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setArtistsControlAddressAndEnabledEdition( \"9700\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6605955", timeStamp: "1540825358", hash: "0xbd42eecefbd03726be8090f4ebe4981eb22b46c6948743975360d4000be16c99", nonce: "729", blockHash: "0xf646d195c467fac2a23c4c57888f72acc16c655d4b1830fb6e7ab7175978b191", transactionIndex: "80", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x921ade9018eec4a01e41e80a7eeba982b61724ec", value: "0", gas: "4075039", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0xb5e7f3c300000000000000000000000000000000000000000000000000000000000025e4000000000000000000000000e0f228070d8f7b5c25e9375fa70fa418f8dfedf8", contractAddress: "", cumulativeGasUsed: "3372035", gasUsed: "64720", confirmations: "1134546"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_editionNumber", value: "9700"}, {type: "address", name: "_address", value: addressList[15]}], name: "setArtistsControlAddressAndEnabledEdition", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setArtistsControlAddressAndEnabledEdition(uint256,address)" ]( "9700", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540825358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1924433048862314066" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
