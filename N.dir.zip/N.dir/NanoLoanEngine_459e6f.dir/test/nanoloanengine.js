const NanoLoanEngine = artifacts.require( "./NanoLoanEngine.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "NanoLoanEngine" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE403fD53eb2Ab7735dF442191f9A03DffA459e6F", "0x80770e3D6B25eBF3314F3bA3a2A3ea83EeDc140A", "0xF970b8E36e23F7fC3FD752EeA86f8Be8D83375A6", "0xA1091481AEde4adDe00C1a26992AE49a7e0E1FB0", "0x0DDEF408012625E4269b35b6c494e25728341042", "0x0B92baeBE1C99Bbf1841CF81550E196dfb97cbD6", "0x61245b6A6678f3158A37AB2c5e52369B9F452318", "0x33f8f4A8A032457A8621b48d908EFF05EFCF8905", "0xaf73dcB04bFdAf3770d528C7EB223F5c7323B506", "0x4cD8daf4fe91FBe1bEd0040ffB61c48F139FC64c", "0x5A52567Ea2bA8C82F17a94b91B072298CBd99Fd2", "0x477cF523857050A9f929F910197d6ED66988E238", "0x263231ed9b51084816A44e18D16c0F6D0727491F", "0xeEEa10FB371324d9D4363d6B48273D92396720ed", "0x16A0772b17AE004E6645E0e95BF50aD69498a34e", "0xB16464300d1CD50eE0cFE73be14aA68fAc193F98"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "index", type: "uint256"}], name: "getLoanConfig", outputs: [{name: "oracle", type: "address"}, {name: "borrower", type: "address"}, {name: "lender", type: "address"}, {name: "creator", type: "address"}, {name: "amount", type: "uint256"}, {name: "cosignerFee", type: "uint256"}, {name: "interestRate", type: "uint256"}, {name: "interestRatePunitory", type: "uint256"}, {name: "duesIn", type: "uint256"}, {name: "cancelableAt", type: "uint256"}, {name: "decimals", type: "uint256"}, {name: "currencyHash", type: "bytes32"}, {name: "expirationRequest", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getApprovedTransfer", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "timeDelta", type: "uint256"}, {name: "interestRate", type: "uint256"}, {name: "amount", type: "uint256"}], name: "calculateInterest", outputs: [{name: "realDelta", type: "uint256"}, {name: "interest", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getInterestRate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "deprecated", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getOracle", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getInterestTimestamp", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getPaid", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCurrencyDecimals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getDuesIn", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getInterestRatePunitory", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getLenderBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getLoanState", outputs: [{name: "interest", type: "uint256"}, {name: "punitoryInterest", type: "uint256"}, {name: "interestTimestamp", type: "uint256"}, {name: "paid", type: "uint256"}, {name: "dueTime", type: "uint256"}, {name: "status", type: "uint8"}, {name: "lenderBalance", type: "uint256"}, {name: "approvedTransfer", type: "address"}, {name: "approved", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getDueTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getStatus", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}, {name: "cindex", type: "uint256"}], name: "getCurrencyByte", outputs: [{name: "", type: "bytes1"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getInterest", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "isApproved", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getTotalLoans", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getBorrower", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getPendingAmount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getPunitoryInterest", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCosigner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getAmount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}, {name: "_address", type: "address"}], name: "getApprobation", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCosignerFee", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCancelableAt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCurrency", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCreator", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCurrencyHash", outputs: [{name: "", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalLenderBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getExpirationRequest", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getLender", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "getCurrencyLength", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "VERSION", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lender", type: "address"}], name: "Lent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lend", type: "address"}], name: "CreatedDebt", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "DestroyedBy", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "PartialPayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}], name: "TotalPayment", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["CreatedLoan(uint256,address,address)", "ApprovedBy(uint256,address)", "Lent(uint256,address)", "CreatedDebt(uint256,address)", "DestroyedBy(uint256,address)", "PartialPayment(uint256,address,address,uint256)", "Transfer(uint256,address,address)", "TotalPayment(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xd1acb464ac8b592a0bd76da52fada20c0b6e5fc41cccd5ad10a27f7e410a9302", "0x25892f9206787c4121725a78d5ce4ccdd67396188489c0ec7181390a436776a9", "0xe69a2d9a97bd2617dba9d6377976d828bb5b0c24b515820e3a191eb1c5d57bc3", "0x5abfc588335c77def40b19b391e49cd55dbab4b544d3b45ce09039c3f05e3a21", "0x5e81ba96d90c4ed224a3379b681aa7910d3832eabf32b38d8fffdfb58b3ed962", "0x208972b4933bf2f7f9bb4c3c61cd484970eb0babe7539d22a18ab1d80fa7bec6", "0x0a429aba3d89849a2db0153e4534d95c46a1d83c8109d73893f55ebc44010ff4", "0x45bbf9b5373297284296c5c84c733f3e536eb719e3fe3ee1771900622621cfb7"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4558235 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4616553 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}], name: "NanoLoanEngine", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getLoanConfig", outputs: [{name: "oracle", type: "address"}, {name: "borrower", type: "address"}, {name: "lender", type: "address"}, {name: "creator", type: "address"}, {name: "amount", type: "uint256"}, {name: "cosignerFee", type: "uint256"}, {name: "interestRate", type: "uint256"}, {name: "interestRatePunitory", type: "uint256"}, {name: "duesIn", type: "uint256"}, {name: "cancelableAt", type: "uint256"}, {name: "decimals", type: "uint256"}, {name: "currencyHash", type: "bytes32"}, {name: "expirationRequest", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLoanConfig(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getApprovedTransfer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApprovedTransfer(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "timeDelta", value: random.range( maxRandom )}, {type: "uint256", name: "interestRate", value: random.range( maxRandom )}, {type: "uint256", name: "amount", value: random.range( maxRandom )}], name: "calculateInterest", outputs: [{name: "realDelta", type: "uint256"}, {name: "interest", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateInterest(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getInterestRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getInterestRate(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "deprecated", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "deprecated()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getOracle", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOracle(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getInterestTimestamp", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getInterestTimestamp(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getPaid", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPaid(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCurrencyDecimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrencyDecimals(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getDuesIn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDuesIn(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getInterestRatePunitory", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getInterestRatePunitory(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getLenderBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLenderBalance(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getLoanState", outputs: [{name: "interest", type: "uint256"}, {name: "punitoryInterest", type: "uint256"}, {name: "interestTimestamp", type: "uint256"}, {name: "paid", type: "uint256"}, {name: "dueTime", type: "uint256"}, {name: "status", type: "uint8"}, {name: "lenderBalance", type: "uint256"}, {name: "approvedTransfer", type: "address"}, {name: "approved", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLoanState(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getDueTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDueTime(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getStatus", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStatus(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}, {type: "uint256", name: "cindex", value: random.range( maxRandom )}], name: "getCurrencyByte", outputs: [{name: "", type: "bytes1"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrencyByte(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getInterest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getInterest(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "isApproved", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTotalLoans", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalLoans()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getBorrower", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBorrower(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getPendingAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPendingAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getPunitoryInterest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPunitoryInterest(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCosigner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCosigner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}, {type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getApprobation", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApprobation(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCosignerFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCosignerFee(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCancelableAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCancelableAt(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCurrency", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrency(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCreator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCreator(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCurrencyHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrencyHash(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalLenderBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalLenderBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getExpirationRequest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getExpirationRequest(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getLender", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLender(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getCurrencyLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrencyLength(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "VERSION", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "VERSION()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "NanoLoanEngine", function( accounts ) {

	it( "TEST: NanoLoanEngine( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4558235", timeStamp: "1510762852", hash: "0xa679313ff4f1952ec8597d47255b621ea2425c2fadd46800edf809cd760b1a7e", nonce: "17", blockHash: "0x0583b66a49b63040e38291f89245d60cc8c40b53bdf30bea6c3bb478be02f071", transactionIndex: "57", from: "0x80770e3d6b25ebf3314f3ba3a2a3ea83eedc140a", to: 0, value: "0", gas: "3412540", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0x9fc3b4c1000000000000000000000000f970b8e36e23f7fc3fd752eea86f8be8d83375a6", contractAddress: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", cumulativeGasUsed: "6204109", gasUsed: "3412540", confirmations: "3181385"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}], name: "NanoLoanEngine", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = NanoLoanEngine.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510762852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = NanoLoanEngine.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[6], addressList[7], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4558359", timeStamp: "1510764947", hash: "0x85ec9673c98317dcc1f24f27173de5d27c638e1d460006b583dd2ac499b735b1", nonce: "96", blockHash: "0x346c85db890544959b88c03f10731009589c13de43f181781f42305c10a9c9f3", transactionIndex: "12", from: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "312531", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xfe925e800000000000000000000000000ddef408012625e4269b35b6c494e257283410420000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000a1a6a7436db0000000000000000000000000000000000000000000000000000047d84a56db6000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000005a0dc2a100000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4713790", gasUsed: "312531", confirmations: "3181261"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[6]}, {type: "address", name: "_borrower", value: addressList[7]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "10000"}, {type: "uint256", name: "_interestRate", value: "11108571428571"}, {type: "uint256", name: "_interestRatePunitory", value: "4937142857142"}, {type: "uint256", name: "_duesIn", value: "172800"}, {type: "uint256", name: "_cancelableAt", value: "86400"}, {type: "uint256", name: "_expirationRequest", value: "1510851233"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[6], addressList[7], addressList[0], "0", `ARS`, "10000", "11108571428571", "4937142857142", "172800", "86400", "1510851233", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510764947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "0"}, {name: "_borrower", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_creator", type: "address", value: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "65725620937886899" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[7], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4558366", timeStamp: "1510765070", hash: "0x4323f22a98a14ceb66536da5613f31a0eba5f2eee231d85c3eedcaa6a4444585", nonce: "97", blockHash: "0x942aacb8ce4f7956305ff2d3879c3654051085e9a90ac932c98d57430bf3e795", transactionIndex: "68", from: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "297531", gasPrice: "1100000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000a1a6a7436db0000000000000000000000000000000000000000000000000000047d84a56db6000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000005a0dc2a200000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3155683", gasUsed: "297531", confirmations: "3181254"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[7]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "10000"}, {type: "uint256", name: "_interestRate", value: "11108571428571"}, {type: "uint256", name: "_interestRatePunitory", value: "4937142857142"}, {type: "uint256", name: "_duesIn", value: "172800"}, {type: "uint256", name: "_cancelableAt", value: "86400"}, {type: "uint256", name: "_expirationRequest", value: "1510851234"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[7], addressList[0], "0", `ARS`, "10000", "11108571428571", "4937142857142", "172800", "86400", "1510851234", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510765070 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "1"}, {name: "_borrower", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_creator", type: "address", value: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "65725620937886899" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: destroy( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4558386", timeStamp: "1510765321", hash: "0x6fea8360e72f0fc996b18366a5b3706a927b96faa73c45811e7b33e77aaadfed", nonce: "27", blockHash: "0xfd653625916e4cc7f667e1aa0fb4045e339770b60c685655f7f8d1dafa380aed", transactionIndex: "135", from: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "30632", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x9d1187700000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6554581", gasUsed: "30632", confirmations: "3181234"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "0"}], name: "destroy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "destroy(uint256)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510765321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "DestroyedBy", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DestroyedBy", events: [{name: "_index", type: "uint256", value: "0"}, {name: "_address", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4558487", timeStamp: "1510766566", hash: "0xfae262b19096da4c06d3dd304238774920fa516d9dae7fc3ca9e67ea2c1c5aa2", nonce: "28", blockHash: "0x54835ce635a91594891c4bd91bba9512f548da4e72b089d69f2dd0c96c185964", transactionIndex: "31", from: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1548648", gasUsed: "44908", confirmations: "3181133"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "1"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510766566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "1"}, {name: "_address", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: lend( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4558537", timeStamp: "1510767276", hash: "0xacac1dfc00a04b23dc58c21259da3b796305ea9b86b39765cd9498ae4d19f74a", nonce: "1", blockHash: "0xca1ea37a1df626e2ad476dac992d2299791e7668f65f07c9fb1825f283ce67ac", transactionIndex: "9", from: "0x33f8f4a8a032457a8621b48d908eff05efcf8905", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "318000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xa6aa57ce0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "475810", gasUsed: "250432", confirmations: "3181083"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "1"}], name: "lend", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lend(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510767276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lender", type: "address"}], name: "Lent", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Lent", events: [{name: "_index", type: "uint256", value: "1"}, {name: "_lender", type: "address", value: "0x33f8f4a8a032457a8621b48d908eff05efcf8905"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "510048000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: pay( \"1\", \"500\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4559061", timeStamp: "1510774617", hash: "0x2bca42204ab388b2b1b2e734d34b30e6fbf878aaae369c28c4e1c2498bf95d60", nonce: "31", blockHash: "0x88e3444cff519d3a9149ca882ca814897a586cbddf17882146f8c323c9091852", transactionIndex: "142", from: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "228943", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x0ad6ac85000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000001f40000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6", contractAddress: "", cumulativeGasUsed: "4856703", gasUsed: "198943", confirmations: "3180559"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "1"}, {type: "uint256", name: "_amount", value: "500"}, {type: "address", name: "_from", value: addressList[7]}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(uint256,uint256,address)" ]( "1", "500", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510774617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "PartialPayment", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PartialPayment", events: [{name: "_index", type: "uint256", value: "1"}, {name: "_sender", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_from", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_amount", type: "uint256", value: "500"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"1\", addressList[7], \"115939863503806... )", async function( ) {
		const txOriginal = {blockNumber: "4559072", timeStamp: "1510774799", hash: "0x59fa265ded8c6409014f3412a33461ab2bcef253efe204de6219f39b122a9211", nonce: "100", blockHash: "0xced08fadf89b91b59b7f80dc5812e230c88c9dee1741a1271ddd7feef5910cd0", transactionIndex: "3", from: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "25552", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6000000000000000000000000000000000000000000000000101702ea728437a3", contractAddress: "", cumulativeGasUsed: "88552", gasUsed: "25552", confirmations: "3180548"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "1"}, {type: "address", name: "to", value: addressList[7]}, {type: "uint256", name: "amount", value: "1159398635038062499"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "1", addressList[7], "1159398635038062499", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510774799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "65725620937886899" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[7], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4559423", timeStamp: "1510779549", hash: "0x3dce00137323773da34562921a17e196077ff6372b7b6d29aa54ab8dfb89a717", nonce: "101", blockHash: "0x93761a1ab3685e13d127a1e67414b99056dd2b31c63c32f0e3aeeedcf03c6d3b", transactionIndex: "29", from: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "313803", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6000000000000000000000000a1091481aede4adde00c1a26992ae49a7e0e1fb000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000138800000000000000000000000000000000000000000000000000000a1a6a7436db0000000000000000000000000000000000000000000000000000047d84a56db6000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000005a0dc2a200000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1682103", gasUsed: "313803", confirmations: "3180197"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[7]}, {type: "address", name: "_cosigner", value: addressList[5]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "5000"}, {type: "uint256", name: "_interestRate", value: "11108571428571"}, {type: "uint256", name: "_interestRatePunitory", value: "4937142857142"}, {type: "uint256", name: "_duesIn", value: "172800"}, {type: "uint256", name: "_cancelableAt", value: "86400"}, {type: "uint256", name: "_expirationRequest", value: "1510851234"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[7], addressList[5], "0", `ARS`, "5000", "11108571428571", "4937142857142", "172800", "86400", "1510851234", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510779549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "2"}, {name: "_borrower", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_creator", type: "address", value: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "65725620937886899" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4559428", timeStamp: "1510779618", hash: "0xe3f7c52dcd24f2af269c8e2628b4891f700daea260aa16bf3bad5eeb8c80add3", nonce: "32", blockHash: "0xd918b2f6f2aa2ff324dad9eaa6bd23627781fa170ce49d630a76aefefc067d5c", transactionIndex: "100", from: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5849071", gasUsed: "44908", confirmations: "3180192"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "2"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510779618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "2"}, {name: "_address", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4559449", timeStamp: "1510779868", hash: "0x1212fc047b2a7bd9818fc6bad57b5a6b4cdc305e6a1423b8198e5471c2911149", nonce: "102", blockHash: "0x28e97297a49201309dbcc365b28f238e7814cc89b57d9391843812267ea4aa49", transactionIndex: "32", from: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2647143", gasUsed: "44908", confirmations: "3180171"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "2"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510779868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "2"}, {name: "_address", type: "address", value: "0xa1091481aede4adde00c1a26992ae49a7e0e1fb0"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "65725620937886899" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: lend( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4561043", timeStamp: "1510801765", hash: "0x084ed58a350d798c48dc119770d4f5aadd80b0f12c1402379c5ecc87468fe06b", nonce: "1", blockHash: "0xdcdba07a226aca6811bc059bd16eee35d63d526fa2c46543611eb2de1dad88e3", transactionIndex: "25", from: "0xaf73dcb04bfdaf3770d528c7eb223f5c7323b506", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "318000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xa6aa57ce0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1032187", gasUsed: "242565", confirmations: "3178577"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "2"}], name: "lend", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lend(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510801765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lender", type: "address"}], name: "Lent", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Lent", events: [{name: "_index", type: "uint256", value: "2"}, {name: "_lender", type: "address", value: "0xaf73dcb04bfdaf3770d528c7eb223f5c7323b506"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1472786000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[11], address... )", async function( ) {
		const txOriginal = {blockNumber: "4564742", timeStamp: "1510853462", hash: "0x3b66e12f7809a1ff1e8433fd1f950e2aa2facc794d67d7286c49e10b4b690211", nonce: "0", blockHash: "0x952d50d4d37f4049b33a6aa7f8237d5010a6da29bab81f71400b2d8b7800f27b", transactionIndex: "75", from: "0x4cd8daf4fe91fbe1bed0040ffb61c48f139fc64c", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "282403", gasPrice: "1400000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000004cd8daf4fe91fbe1bed0040ffb61c48f139fc64c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000003d090000000000000000000000000000000000000000000000000000000e24fb6f800000000000000000000000000000000000000000000000000000000a1a6a7436db0000000000000000000000000000000000000000000000000000000001e133800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a203f9c00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5090101", gasUsed: "282403", confirmations: "3174878"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[11]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "4000000"}, {type: "uint256", name: "_interestRate", value: "15552000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "11108571428571"}, {type: "uint256", name: "_duesIn", value: "31536000"}, {type: "uint256", name: "_cancelableAt", value: "0"}, {type: "uint256", name: "_expirationRequest", value: "1512062876"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[11], addressList[0], "0", `ARS`, "4000000", "15552000000000", "11108571428571", "31536000", "0", "1512062876", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510853462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "3"}, {name: "_borrower", type: "address", value: "0x4cd8daf4fe91fbe1bed0040ffb61c48f139fc64c"}, {name: "_creator", type: "address", value: "0x4cd8daf4fe91fbe1bed0040ffb61c48f139fc64c"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "19541764600000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4564749", timeStamp: "1510853556", hash: "0xf0fbcd36b7a718992a65f6e8d5a1ee1fa554541c3329fcc172c973899ca82ab8", nonce: "1", blockHash: "0x804e736d78cc59bbab5b5f24fc918cf66cb5025ec4298d49d9322c8952277450", transactionIndex: "94", from: "0x4cd8daf4fe91fbe1bed0040ffb61c48f139fc64c", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "1400000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5079542", gasUsed: "44908", confirmations: "3174871"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "3"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510853556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "3"}, {name: "_address", type: "address", value: "0x4cd8daf4fe91fbe1bed0040ffb61c48f139fc64c"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "19541764600000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[12], address... )", async function( ) {
		const txOriginal = {blockNumber: "4565074", timeStamp: "1510858539", hash: "0xf730a1b2fe1a1f62f64701bf4709eee4a9d49eff39f591bf643a30b342a8b845", nonce: "2", blockHash: "0xb17b5285f4633c17100d9491d246d0d33a5f666d8aa00aa1e7aa63f46ca74ca1", transactionIndex: "28", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "282339", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000005a52567ea2ba8c82f17a94b91b072298cbd99fd200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000003567e00000000000000000000000000000000000000000000000000230311fe42f00000000000000000000000000000000000000000000000000000175761542ca0000000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a95f10000000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4540569", gasUsed: "282339", confirmations: "3174546"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[12]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "3500000"}, {type: "uint256", name: "_interestRate", value: "157680000000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "105120000000000000"}, {type: "uint256", name: "_duesIn", value: "7776000"}, {type: "uint256", name: "_cancelableAt", value: "0"}, {type: "uint256", name: "_expirationRequest", value: "1519776000"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[12], addressList[0], "0", `ARS`, "3500000", "157680000000000000", "105120000000000000", "7776000", "0", "1519776000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510858539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "4"}, {name: "_borrower", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}, {name: "_creator", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4565086", timeStamp: "1510858750", hash: "0x415d1e07556768f0b2b383a666df9c996d4eefb1aaab556bc34b5ee685e88780", nonce: "3", blockHash: "0x3a6a13cf9840a2fe44f140dd00f4631559b94f46cfa0b7e6223549570f9150bd", transactionIndex: "150", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "5353619", gasUsed: "44908", confirmations: "3174534"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "4"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510858750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "4"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: destroy( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4565091", timeStamp: "1510858805", hash: "0x8d1518eb43ca417d71aa401dd2a86a5f0285f51d1e59fff64f760929a5728c92", nonce: "4", blockHash: "0x2502dfc3587b7ef7d0edb5b3bd081c22e124fbc79c6f76cf3a12f39de596e7e9", transactionIndex: "18", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "30696", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x9d1187700000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "979499", gasUsed: "30696", confirmations: "3174529"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "4"}], name: "destroy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "destroy(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510858805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "DestroyedBy", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DestroyedBy", events: [{name: "_index", type: "uint256", value: "4"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[12], address... )", async function( ) {
		const txOriginal = {blockNumber: "4565123", timeStamp: "1510859081", hash: "0xbb5b5162f9765a679672aa99567bfb6b8d4a87f7babadb7e2af18a3005b17375", nonce: "5", blockHash: "0xa45e97250c7e1965b485047700148dc61a22c8104a03ed5026822513203fd269", transactionIndex: "8", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "282339", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000005a52567ea2ba8c82f17a94b91b072298cbd99fd200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000003567e00000000000000000000000000000000000000000000000000230311fe42f00000000000000000000000000000000000000000000000000000175761542ca0000000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a95f10000000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "529428", gasUsed: "282339", confirmations: "3174497"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[12]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "3500000"}, {type: "uint256", name: "_interestRate", value: "157680000000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "105120000000000000"}, {type: "uint256", name: "_duesIn", value: "7776000"}, {type: "uint256", name: "_cancelableAt", value: "0"}, {type: "uint256", name: "_expirationRequest", value: "1519776000"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[12], addressList[0], "0", `ARS`, "3500000", "157680000000000000", "105120000000000000", "7776000", "0", "1519776000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510859081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "5"}, {name: "_borrower", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}, {name: "_creator", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4565138", timeStamp: "1510859321", hash: "0xa28a214a113c0d7f6dcfebe3f1adc86eb7d777fd91c0c8d5bba71134b572135a", nonce: "6", blockHash: "0xdf198d39da6e205c48fe1e15bb0fa3c1d3054a22d472c4a95971b10466c1bde5", transactionIndex: "67", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2652745", gasUsed: "44908", confirmations: "3174482"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "5"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510859321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "5"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: destroy( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4565147", timeStamp: "1510859426", hash: "0x1737b491f1952d5383b9f33b9f230d44fa737db71192349cae15408f6c822264", nonce: "7", blockHash: "0x85e1423304f811fa777fea73bcde3293e262c7cbdb261533040ff1d78e7df4ed", transactionIndex: "137", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "30696", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x9d1187700000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "6661444", gasUsed: "30696", confirmations: "3174473"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "5"}], name: "destroy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "destroy(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510859426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "DestroyedBy", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DestroyedBy", events: [{name: "_index", type: "uint256", value: "5"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[12], address... )", async function( ) {
		const txOriginal = {blockNumber: "4565164", timeStamp: "1510859669", hash: "0x2fdd7c4c47bc16437ca37037d2c8fb367972b1fe92692ed5edf0262bebc9da2e", nonce: "8", blockHash: "0xdad44e24f9f4725399e7ec8f345b9f9d453310a8e6bdb028906eb96301058aa3", transactionIndex: "85", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "282211", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000005a52567ea2ba8c82f17a94b91b072298cbd99fd200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000003567e000000000000000000000000000000000000000000000000000000e574609f00000000000000000000000000000000000000000000000000000000b7904d4c000000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a95f10000000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4269421", gasUsed: "282211", confirmations: "3174456"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[12]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "3500000"}, {type: "uint256", name: "_interestRate", value: "15768000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "12614400000000"}, {type: "uint256", name: "_duesIn", value: "7776000"}, {type: "uint256", name: "_cancelableAt", value: "0"}, {type: "uint256", name: "_expirationRequest", value: "1519776000"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[12], addressList[0], "0", `ARS`, "3500000", "15768000000000", "12614400000000", "7776000", "0", "1519776000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510859669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "6"}, {name: "_borrower", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}, {name: "_creator", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4565178", timeStamp: "1510859925", hash: "0xfe30c3d7ffcb7d8d7299e82788eb6fcd3e6660e493e3742c4c1b550612388b23", nonce: "9", blockHash: "0xc6e34433191339a85807b68cdbd01f5a4c71ac91cff2b944abcfd497d233187a", transactionIndex: "83", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "1989648", gasUsed: "44908", confirmations: "3174442"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "6"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510859925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "6"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: lend( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4568424", timeStamp: "1510904733", hash: "0x4ea2bce65d488ed010b1358829943238ab2723d0af4fd2c9e880367a1191f03c", nonce: "2", blockHash: "0x6d6df47315b24afe0295c0f46b5ce5fd74a6f7a92756741a626b29c427ad0dde", transactionIndex: "20", from: "0x477cf523857050a9f929f910197d6ed66988e238", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "318000", gasPrice: "4000000000", isError: "0", txreceipt_status: "0", input: "0xa6aa57ce0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "2237025", gasUsed: "179922", confirmations: "3171196"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "6"}], name: "lend", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lend(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510904733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "45839267000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4608550", timeStamp: "1511463154", hash: "0xcb2c3f40ea2f9c85edfa1fc0592a2b0f2026e8cc8781d4289c1de8388ddcdfda", nonce: "1", blockHash: "0xb6f7971377376e2d39faeb2be1512b478bb19b2ea8c8a18d7f8d29cb491e5102", transactionIndex: "14", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000187680000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a20526700000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "889446", gasUsed: "297339", confirmations: "3131070"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "100200"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "15552000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1512067687"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "100200", "10368000000000", "15552000000000", "2592000", "864000", "1512067687", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511463154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "7"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4608619", timeStamp: "1511464117", hash: "0x4289afead28c9b13ca1494fa5081384a0862b9d41e6bad041d51395d82d5704f", nonce: "2", blockHash: "0xd31f3f5248d6b79b495700a1143c34a25be687b6cf7c4dd671c4afde6f9e2f8a", transactionIndex: "16", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000187cc0000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a20563300000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "843362", gasUsed: "297339", confirmations: "3131001"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "100300"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "15552000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1512068659"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "100300", "10368000000000", "15552000000000", "2592000", "864000", "1512068659", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511464117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "8"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4608659", timeStamp: "1511464825", hash: "0x0c1cdf04a4d87dc3f381fbd88bd81d0651efdcb3b26da4d7cf7d988b0be68ed7", nonce: "3", blockHash: "0x0e16b31b4440e3f031e9066af000295e30522f9baa52b8dadf668e99fc2fee2f", transactionIndex: "22", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000188300000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a2058fc00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1244499", gasUsed: "297339", confirmations: "3130961"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "100400"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "15552000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1512069372"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "100400", "10368000000000", "15552000000000", "2592000", "864000", "1512069372", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511464825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "9"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4608661", timeStamp: "1511464840", hash: "0xceba3c75c8a9570ff673fb26dc37df608a0d672fe44a98c4e2b9118e3b8b3701", nonce: "4", blockHash: "0xd18fd9f7b7e799c6ea661e7c05a4da29aceed2cfd302896e06583d16cf77176b", transactionIndex: "10", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb759f9540000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "334986", gasUsed: "44908", confirmations: "3130959"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511464840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "9"}, {name: "_address", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: lend( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4608877", timeStamp: "1511467944", hash: "0x7edbe962c320f36bacc1c9675e5637f786d86f8e9d8f16b62b7bade55365bfe6", nonce: "1", blockHash: "0xe1ef9f520526ded6e1680c561b6d39efffb0affa6027ca8cb32bb73cbf9b5491", transactionIndex: "62", from: "0xeeea10fb371324d9d4363d6b48273d92396720ed", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xa6aa57ce0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "2973777", gasUsed: "220432", confirmations: "3130743"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}], name: "lend", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lend(uint256)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511467944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lender", type: "address"}], name: "Lent", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Lent", events: [{name: "_index", type: "uint256", value: "9"}, {name: "_lender", type: "address", value: "0xeeea10fb371324d9d4363d6b48273d92396720ed"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "199581777000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: pay( \"9\", \"100\", addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "4609091", timeStamp: "1511470649", hash: "0xd5892d2a47d7f0859793c126ef24aa4d4c6ca674dbb3f7e2fbe1d69d6158c405", nonce: "6", blockHash: "0xe123294de4dd1e3a550518b616f87c1ae764fae6d8ab22cdae7ad4dd54c64e4a", transactionIndex: "11", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0ad6ac8500000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000064000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f", contractAddress: "", cumulativeGasUsed: "530277", gasUsed: "168879", confirmations: "3130529"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "uint256", name: "_amount", value: "100"}, {type: "address", name: "_from", value: addressList[14]}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(uint256,uint256,address)" ]( "9", "100", addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511470649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "PartialPayment", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PartialPayment", events: [{name: "_index", type: "uint256", value: "9"}, {name: "_sender", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_from", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_amount", type: "uint256", value: "100"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"9\", addressList[15], \"50293930189554... )", async function( ) {
		const txOriginal = {blockNumber: "4609436", timeStamp: "1511475347", hash: "0x823a194efa9724aa33b37fb835497523a0d1485dfbdd243b3e361f395afdccbb", nonce: "2", blockHash: "0x4b07a320662779132425406b3ab4a924860caa77a6193d0bcc4d2c93c834c839", transactionIndex: "48", from: "0xeeea10fb371324d9d4363d6b48273d92396720ed", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000eeea10fb371324d9d4363d6b48273d92396720ed00000000000000000000000000000000000000000000000006facca161111298", contractAddress: "", cumulativeGasUsed: "2230199", gasUsed: "37300", confirmations: "3130184"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "amount", value: "502939301895541400"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "9", addressList[15], "502939301895541400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511475347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "199581777000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"9\", addressList[15], \"50293930189554... )", async function( ) {
		const txOriginal = {blockNumber: "4609436", timeStamp: "1511475347", hash: "0x5e62a64b7e9f37df6142b9ee6f1849f740a5a0d1b32f731dd6041972524b9d28", nonce: "3", blockHash: "0x4b07a320662779132425406b3ab4a924860caa77a6193d0bcc4d2c93c834c839", transactionIndex: "61", from: "0xeeea10fb371324d9d4363d6b48273d92396720ed", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000eeea10fb371324d9d4363d6b48273d92396720ed00000000000000000000000000000000000000000000000006facca161111298", contractAddress: "", cumulativeGasUsed: "2956419", gasUsed: "25772", confirmations: "3130184"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "amount", value: "502939301895541400"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "9", addressList[15], "502939301895541400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511475347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "199581777000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: pay( \"9\", \"2000\", addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "4615441", timeStamp: "1511558767", hash: "0x976fbde143b9b6520f232294df8be0a1b92b51bed2fcb78c69ae511f0a938f52", nonce: "8", blockHash: "0x813d24a253b16e36cd48e13da9f24577e3114a89d09e9d82168145f1fbadb4c0", transactionIndex: "17", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0ad6ac85000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000007d0000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f", contractAddress: "", cumulativeGasUsed: "713052", gasUsed: "153943", confirmations: "3124179"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "uint256", name: "_amount", value: "2000"}, {type: "address", name: "_from", value: addressList[14]}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(uint256,uint256,address)" ]( "9", "2000", addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511558767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "PartialPayment", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PartialPayment", events: [{name: "_index", type: "uint256", value: "9"}, {name: "_sender", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_from", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_amount", type: "uint256", value: "2000"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"9\", addressList[15], \"10906829520067... )", async function( ) {
		const txOriginal = {blockNumber: "4615450", timeStamp: "1511558960", hash: "0x9361e7e35a8e89be87ebfafa4961ef2efba3d30f09adcafb02da11149bdea4ab", nonce: "4", blockHash: "0x386d76ee31501b13784631f571f2d56b1ff895a1aa7289bad55f1263b6f491ad", transactionIndex: "85", from: "0xeeea10fb371324d9d4363d6b48273d92396720ed", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000eeea10fb371324d9d4363d6b48273d92396720ed000000000000000000000000000000000000000000000000975cd7a9615df0d0", contractAddress: "", cumulativeGasUsed: "3604243", gasUsed: "37300", confirmations: "3124170"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "amount", value: "10906829520067490000"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "9", addressList[15], "10906829520067490000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511558960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "199581777000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"9\", addressList[15], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4615456", timeStamp: "1511559032", hash: "0x66dfd7c09eb9520c61fe10f27b253b5b13f417a301786296c6007d4f235b4850", nonce: "5", blockHash: "0xd6b3638b22c5e9263e33879b18bdfe28dffb9f5f3d9f93a78cac3f42a861fc84", transactionIndex: "48", from: "0xeeea10fb371324d9d4363d6b48273d92396720ed", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000eeea10fb371324d9d4363d6b48273d92396720ed0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2514944", gasUsed: "51788", confirmations: "3124164"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "9"}, {type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "amount", value: "0"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "9", addressList[15], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511559032 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "199581777000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4615624", timeStamp: "1511561431", hash: "0x61acbd10a92c399140cf474dd32da1926e5c4ee280cf11846c56d39a2d5107d4", nonce: "9", blockHash: "0x50a6d252cd7bfb439c1c4c852ec2ec5a8383f063c053c6aa9988b57dbecd1542", transactionIndex: "80", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000c3500000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000649534e00000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a21d25c00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2777523", gasUsed: "297211", confirmations: "3123996"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "50000"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "6912000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1512165980"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "50000", "10368000000000", "6912000000000", "2592000", "864000", "1512165980", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511561431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "10"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4615627", timeStamp: "1511561464", hash: "0xc31b8c6fd652859f387d7a2d5194b289771a1d6f537f978307eabafe75d0608f", nonce: "10", blockHash: "0x586d37852af4c362193c65aaf971a5194d5c5e5948ab57434890184a066a9255", transactionIndex: "51", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "90000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb759f954000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "1854647", gasUsed: "44908", confirmations: "3123993"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "10"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511561464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "10"}, {name: "_address", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4615765", timeStamp: "1511563210", hash: "0x638d602d9a3c6d2a5c08b4c37d5e2626e5d547bffc459af716b05cda8a301a59", nonce: "11", blockHash: "0x4abaf90911316508161b793945a35a543b5749b54fb49cd7a829ac8139d9769a", transactionIndex: "43", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000c3500000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000649534e00000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a1f363a00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1956299", gasUsed: "297211", confirmations: "3123855"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "50000"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "6912000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1511994938"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "50000", "10368000000000", "6912000000000", "2592000", "864000", "1511994938", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511563210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "11"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "4615767", timeStamp: "1511563246", hash: "0x368dfb7a0b630566c3825978a856e660872af07ea220ce0266e1e18b8854eff9", nonce: "12", blockHash: "0xa2433b6ab136b99616178882c8ef6ebbd62cfa84a5dbeac6229c4e3e5e1ee3e2", transactionIndex: "56", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb759f954000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "1776135", gasUsed: "44908", confirmations: "3123853"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "11"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511563246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "11"}, {name: "_address", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: destroy( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4615789", timeStamp: "1511563534", hash: "0x01a327780d4cb20cb73737fa80fa6cd25a13958e2888624606880c6b98b07b81", nonce: "10", blockHash: "0x01f0106e6afb88e357e794be91d1ca0a00e9996285d7b7836fdc21dfae0d24b9", transactionIndex: "68", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "30696", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9d1187700000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3586390", gasUsed: "30696", confirmations: "3123831"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "6"}], name: "destroy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "destroy(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511563534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "DestroyedBy", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DestroyedBy", events: [{name: "_index", type: "uint256", value: "6"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4615809", timeStamp: "1511563805", hash: "0x8de9155ae7b9d4f0f1522ef8db6bb3c2adc0fbb8ce553ebae96a5f84490c421b", nonce: "13", blockHash: "0x89d2f4fbed989faf67864fd09796e3c6436abd2767334548f105fa3223ae146c", transactionIndex: "88", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000649534e00000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a1f389c00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2844524", gasUsed: "297275", confirmations: "3123811"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "75000"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "6912000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1511995548"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "75000", "10368000000000", "6912000000000", "2592000", "864000", "1511995548", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511563805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "12"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4615811", timeStamp: "1511563823", hash: "0xba4a6629a03af11ad8ff524f8dc1520c2c668b51359350f616978e32b4d359a1", nonce: "14", blockHash: "0x834a20549e1857bd18fe790c43ead297d71644bc4c89f300f5405700d395acc1", transactionIndex: "21", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb759f954000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "606820", gasUsed: "44908", confirmations: "3123809"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "12"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511563823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "12"}, {name: "_address", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[12], address... )", async function( ) {
		const txOriginal = {blockNumber: "4615932", timeStamp: "1511565187", hash: "0xb5c91894c44b1937b560002c6b5a11f59ab8a21dccc551e11cb366e6ddb5880f", nonce: "11", blockHash: "0x6c0ec49e3133e2c303e5c9ce812bee9fc9ffa9ff8c1b4ab963005a941003b2f0", transactionIndex: "92", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "297531", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f4523180000000000000000000000005a52567ea2ba8c82f17a94b91b072298cbd99fd20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000632ea000000000000000000000000000000000000000000000000000000cdbcd4e174600000000000000000000000000000000000000000000000000000a49710b45d200000000000000000000000000000000000000000000000000000000009e34000000000000000000000000000000000000000000000000000000000000278d00000000000000000000000000000000000000000000000000000000005a33108000000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3206854", gasUsed: "297531", confirmations: "3123688"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[12]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "6500000"}, {type: "uint256", name: "_interestRate", value: "14138181818182"}, {type: "uint256", name: "_interestRatePunitory", value: "11310545454546"}, {type: "uint256", name: "_duesIn", value: "10368000"}, {type: "uint256", name: "_cancelableAt", value: "2592000"}, {type: "uint256", name: "_expirationRequest", value: "1513296000"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[12], addressList[0], "0", `ARS`, "6500000", "14138181818182", "11310545454546", "10368000", "2592000", "1513296000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511565187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "13"}, {name: "_borrower", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}, {name: "_creator", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "4615940", timeStamp: "1511565332", hash: "0x52807c130ef1bbf04b21010f7b46b21ed8747164b7891520e773a03b3d2f74b3", nonce: "12", blockHash: "0x6155be45c1368f404b920b017dfcd562654e8e4496548afcbd7807b9a750980d", transactionIndex: "23", from: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "44908", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb759f954000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "1456834", gasUsed: "44908", confirmations: "3123680"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "13"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511565332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "13"}, {name: "_address", type: "address", value: "0x5a52567ea2ba8c82f17a94b91b072298cbd99fd2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawal( \"1\", addressList[9], \"235979863503806... )", async function( ) {
		const txOriginal = {blockNumber: "4615975", timeStamp: "1511565886", hash: "0xce9330028097e0320646b22ecb7e7981e62a8c293d9c0394a66a7cc66ebceb5b", nonce: "2", blockHash: "0x48b99083f7d81ba16010d01a20869ef92d5f496e1d4cb9a35d197799942dabfb", transactionIndex: "81", from: "0x33f8f4a8a032457a8621b48d908eff05efcf8905", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf24ff92c000000000000000000000000000000000000000000000000000000000000000100000000000000000000000033f8f4a8a032457a8621b48d908eff05efcf890500000000000000000000000000000000000000000000000020bfb05b16e537a4", contractAddress: "", cumulativeGasUsed: "5465440", gasUsed: "26150", confirmations: "3123645"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "1"}, {type: "address", name: "to", value: addressList[9]}, {type: "uint256", name: "amount", value: "2359798635038062500"}], name: "withdrawal", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawal(uint256,address,uint256)" ]( "1", addressList[9], "2359798635038062500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511565886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "510048000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: pay( \"2\", \"10000\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4616048", timeStamp: "1511566929", hash: "0x48e2fb9a0d3b82aeb6aa8160b4aa644656a9e4b6cdb58689e206da39829f4610", nonce: "34", blockHash: "0x28af2b5f35085b72e6926be3468bfca10889a238c7fc426cb80f3446b0a66882", transactionIndex: "24", from: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "270931", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0x0ad6ac85000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000027100000000000000000000000000b92baebe1c99bbf1841cf81550e196dfb97cbd6", contractAddress: "", cumulativeGasUsed: "2003186", gasUsed: "240931", confirmations: "3123572"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "2"}, {type: "uint256", name: "_amount", value: "10000"}, {type: "address", name: "_from", value: addressList[7]}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(uint256,uint256,address)" ]( "2", "10000", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511566929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "PartialPayment", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PartialPayment", events: [{name: "_index", type: "uint256", value: "2"}, {name: "_sender", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_from", type: "address", value: "0x0b92baebe1c99bbf1841cf81550e196dfb97cbd6"}, {name: "_amount", type: "uint256", value: "5067"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}], name: "TotalPayment", type: "event"} ;
		console.error( "eventCallOriginal[44,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TotalPayment", events: [{name: "_index", type: "uint256", value: "2"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[44,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: changeOwner( addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "4616183", timeStamp: "1511568993", hash: "0x48febeac997f96fb7112fd30345cd5b1a821bca7f65e2d76f46ea27bbf1e109c", nonce: "18", blockHash: "0x35c7808af0d75b492c1af10aa589a28a4031659716dc8978343684658e5c852f", transactionIndex: "73", from: "0x80770e3d6b25ebf3314f3ba3a2a3ea83eedc140a", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "29364", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa6f9dae100000000000000000000000016a0772b17ae004e6645e0e95bf50ad69498a34e", contractAddress: "", cumulativeGasUsed: "6700079", gasUsed: "29364", confirmations: "3123437"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[16]}], name: "changeOwner", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeOwner(address)" ]( addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511568993 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: lend( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4616367", timeStamp: "1511571561", hash: "0x7c7ec5ff326d774ec835336bfc6670cf6c9f04e6f340dddadef96affe5807153", nonce: "1", blockHash: "0x188aedc264352ee19c7e32b3c3be102f793fa246b9e932159148bc7620eef25f", transactionIndex: "31", from: "0xb16464300d1cd50ee0cfe73be14aa68fac193f98", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "371000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xa6aa57ce000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3437641", gasUsed: "220432", confirmations: "3123253"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "10"}], name: "lend", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lend(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511571561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_lender", type: "address"}], name: "Lent", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Lent", events: [{name: "_index", type: "uint256", value: "10"}, {name: "_lender", type: "address", value: "0xb16464300d1cd50ee0cfe73be14aa68fac193f98"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "60618544200000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4616420", timeStamp: "1511572247", hash: "0x6fce5334b1c168ffbfd38ef6bed66e58c57810266f4ce2134c680ed427e67ee9", nonce: "15", blockHash: "0x7e355d5980e0336d7623e1a18740396df683f6b2714bb834728980e03a677c91", transactionIndex: "79", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000017e6c0000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000649534e00000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a404eed00000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4186159", gasUsed: "297275", confirmations: "3123200"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "97900"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "6912000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1514163949"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "97900", "10368000000000", "6912000000000", "2592000", "864000", "1514163949", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511572247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "14"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: approve( \"14\" )", async function( ) {
		const txOriginal = {blockNumber: "4616423", timeStamp: "1511572264", hash: "0x1992cd7f77b02f2f49947eb32f23e6fa4ee051a1f0313e48762a80a330483459", nonce: "16", blockHash: "0xcc8594ea59d42bdc1dd7f9ed24bf5ca5ce3dfb33162fcab12f1e76e73beddcec", transactionIndex: "20", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb759f954000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "706793", gasUsed: "44908", confirmations: "3123197"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "index", value: "14"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(uint256)" ]( "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511572264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "ApprovedBy", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ApprovedBy", events: [{name: "_index", type: "uint256", value: "14"}, {name: "_address", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: createLoan( addressList[8], addressList[14], address... )", async function( ) {
		const txOriginal = {blockNumber: "4616553", timeStamp: "1511574031", hash: "0x4fc9fa73c20c9644ccebddee01c5a7bd4f55669c69e91380ade7b8fac4eb7157", nonce: "17", blockHash: "0xee4cbce00d10955497133c95ee59f36bce232d6df76015eb5114f7d6ace1acd8", transactionIndex: "41", from: "0x263231ed9b51084816a44e18d16c0f6d0727491f", to: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfe925e8000000000000000000000000061245b6a6678f3158a37ab2c5e52369b9f452318000000000000000000000000263231ed9b51084816a44e18d16c0f6d0727491f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000c3500000000000000000000000000000000000000000000000000000096dfcf5000000000000000000000000000000000000000000000000000000000649534e00000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000005a40560500000000000000000000000000000000000000000000000000000000000000034152530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1836884", gasUsed: "297211", confirmations: "3123067"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_oracleContract", value: addressList[8]}, {type: "address", name: "_borrower", value: addressList[14]}, {type: "address", name: "_cosigner", value: addressList[0]}, {type: "uint256", name: "_cosignerFee", value: "0"}, {type: "string", name: "_currency", value: `ARS`}, {type: "uint256", name: "_amount", value: "50000"}, {type: "uint256", name: "_interestRate", value: "10368000000000"}, {type: "uint256", name: "_interestRatePunitory", value: "6912000000000"}, {type: "uint256", name: "_duesIn", value: "2592000"}, {type: "uint256", name: "_cancelableAt", value: "864000"}, {type: "uint256", name: "_expirationRequest", value: "1514165765"}], name: "createLoan", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createLoan(address,address,address,uint256,string,uint256,uint256,uint256,uint256,uint256,uint256)" ]( addressList[8], addressList[14], addressList[0], "0", `ARS`, "50000", "10368000000000", "6912000000000", "2592000", "864000", "1514165765", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511574031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_borrower", type: "address"}, {indexed: false, name: "_creator", type: "address"}], name: "CreatedLoan", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CreatedLoan", events: [{name: "_index", type: "uint256", value: "15"}, {name: "_borrower", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}, {name: "_creator", type: "address", value: "0x263231ed9b51084816a44e18d16c0f6d0727491f"}], address: "0xe403fd53eb2ab7735df442191f9a03dffa459e6f"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "841981559742781196" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
