const NeutrinoTokenStandard = artifacts.require( "./NeutrinoTokenStandard.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "NeutrinoTokenStandard" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x9C025C5EAb68f658C6C6C3A7f6a9E1b24616Ef0A", "0x10d915C0B3e01090C7B5f80eF2D9CdB616283853", "0x7B2e64CD7b6F924Ed3b7F17498450c6400596409", "0xa401E571e752Ded7C61f8132599874B885F4478D", "0xb055b9367FA68Fb12DFa9ce0fBdD335CEd0f0F71", "0x1234EE48A39292C695Bc3a2E027eDC15e6E1BC29", "0x369Db58997b157dAa9B7A65D51dBa2e982C5b66d", "0x00DFECf2df1b0bda707775C0c19287AfFa0cF21F", "0xB74D5f0a81Ce99aC1857133E489bC2b4954935fF", "0xc6C8649Cbffbb7463D6A5A6d85EF719b3192cDA4", "0xFc01A9ef0023Ca1f1B19fB689a5A649487bFF3eD", "0x337941C363e477D9beE57dC0E4DA51082709a033", "0x684969b54B3F010a6Dc7C9f8C3C5d3706584AEd4", "0x6c92FF3b02DC8B67576000b7Cad5949075781d59", "0x7d94793dC22278B6c81C56619d9ca5D5fA22DeFf", "0xC8E1b87765455A93d83A3156fA8fA4dC4242014D", "0x14049E874D1d720F6faEC9B548B8B54FCF5d6013", "0xaa521576fF0D4328Db76967a722D20cC1bA91955", "0x9e697c0aaeed5b45519FE9e4f8Bbd7E3ac2610F1", "0x68D0a0f67BF5dECda69e8C7ab31B07B60F1973B9", "0xD8592B0D6297C72f0C5bfE9B3b4bdF30d992aCE1", "0x869BbF02B923d7d0Ab01b82e0d2B35a71E589231", "0x42d6FB2ac47Cc44296759530433CEeEBC564760F", "0x49681aDF3579Ac627CC8980a767E9a4aF13D50d7", "0x8C02Ff198EDEf168e4E1C7A9Af45edBf2649E4fb", "0x9733D9d07F9e0Ec51c8B7FC7463C8c5153EAC815", "0xA79DD2D94772bBe4949e5bca5DF5CB875df4D995", "0xC786c8246F9aeDB79Bb3CE73cdD5E7AB0B2e9464", "0x1AdcbC4DF1d9Bc15070d1C1a6800bA6562974F3F", "0xb59B252570c51ab06f8382C06aca3E300c8cD1F6", "0xd956c1172077db01ec2c139676c1030B1e96C0F7", "0xE90a1F52E12825945Ea54a7d60ebcF4155424Fa6", "0x5090B841889600BED6ec38cAC1c5BA12cccA9c16", "0x1df3FD4D77455c76f2a65a8F6ddF47c7C2ab9b64", "0x2B546D8C42F6b74e9c50455d0B8577e26662387e", "0xb7c063b5BCDb56087B2ef9615C71b2439e0f2c70", "0x3E7603ce200457cb60accda91a3d99f1D825E15b"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ethereumToSpend", type: "uint256"}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokensToSell", type: "uint256"}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ethereum", type: "uint256"}], name: "ethereumToTokens_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_includeReferralBonus", type: "bool"}], name: "myDividends", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokens", type: "uint256"}], name: "tokensToEthereum_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "since", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onTokenPurchase(address,uint256,uint256,address,uint256,uint256)", "onTokenSell(address,uint256,uint256,uint256,uint256)", "onReinvestment(address,uint256,uint256)", "onWithdraw(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8032875b28d82ddbd303a9e4e5529d047a14ecb6290f80012a81b7e6227ff1ab", "0x8d3a0130073dbd54ab6ac632c05946df540553d3b514c9f8165b4ab7f2b1805e", "0xbe339fc14b041c2b0e0f3dd2cd325d0c3668b78378001e53160eab3615326458", "0xccad973dcd043c7d680389db4378bd6b9775db7124092e9e0422c9e46d7985dc"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6866986 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6879429 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "NeutrinoTokenStandard", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dividendsOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ethereumToSpend", value: random.range( maxRandom )}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateTokensReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokensToSell", value: random.range( maxRandom )}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateEthereumReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ethereum", value: random.range( maxRandom )}], name: "ethereumToTokens_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ethereumToTokens_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakingRequirement()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bool", name: "_includeReferralBonus", value: ( random.range( 2 ) === 0 )}], name: "myDividends", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myDividends(bool)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEthereumBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokens", value: random.range( maxRandom )}], name: "tokensToEthereum_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensToEthereum_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "since", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "since(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "NeutrinoTokenStandard", function( accounts ) {

	it( "TEST: NeutrinoTokenStandard(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6866986", timeStamp: "1544532780", hash: "0x70b0b68dc693528452078a673a79ec82c7f859a5bb371d726201e0453465bee8", nonce: "18", blockHash: "0x50135d4b718e28203376960a5225359bed40d0ee230d8ef63c38c8741fa0cf4f", transactionIndex: "21", from: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409", to: 0, value: "0", gas: "1201653", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x989375f1", contractAddress: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", cumulativeGasUsed: "2206875", gasUsed: "1201653", confirmations: "811627"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "NeutrinoTokenStandard", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = NeutrinoTokenStandard.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544532780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = NeutrinoTokenStandard.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "964469882460326" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6867082", timeStamp: "1544534272", hash: "0x4e22455ea9244a5922f50fe5482348d1b4eaa0f50304e4842b0819b5a1abb8a0", nonce: "0", blockHash: "0x46db6f81d7e813798d5e5532b0da9891354cd33960b5495f1191cd55e09f4ed4", transactionIndex: "19", from: "0xa401e571e752ded7c61f8132599874b885f4478d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1000000000000000000", gas: "200000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1123304", gasUsed: "136844", confirmations: "811531"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[4]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544534272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xa401e571e752ded7c61f8132599874b885f4478d"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "900000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544534272"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "32544766350583974" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6867155", timeStamp: "1544535556", hash: "0x3e4d8a4b3ea8df307f9385b1874a8c334f16e3eff854698f334eeedcff1d047d", nonce: "38", blockHash: "0x018bdc6fa948ab7b41b7b4fed0db285475e808e7a840972029168fdf0346d529", transactionIndex: "46", from: "0xb055b9367fa68fb12dfa9ce0fbdd335ced0f0f71", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "2000000000000000000", gas: "300000", gasPrice: "23200000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000001234ee48a39292c695bc3a2e027edc15e6e1bc29", contractAddress: "", cumulativeGasUsed: "1562037", gasUsed: "112740", confirmations: "811458"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[7]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544535556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb055b9367fa68fb12dfa9ce0fbdd335ced0f0f71"}, {name: "incomingEthereum", type: "uint256", value: "2000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1800000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544535556"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "646216210282068" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6867161", timeStamp: "1544535695", hash: "0xf5d44bd027cd98e1531ec1e94faa94a543cc534250424e135c61968b5fb3f773", nonce: "0", blockHash: "0xeb7f9306bede1dd45af2d114c05f5df4ff78ff70a6050919538d573cd8ac7088", transactionIndex: "170", from: "0x369db58997b157daa9b7a65d51dba2e982c5b66d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "100000000000000000000", gas: "195000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000a401e571e752ded7c61f8132599874b885f4478d", contractAddress: "", cumulativeGasUsed: "7036802", gasUsed: "127861", confirmations: "811452"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[5]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544535695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "90000000000000000000000"}, {name: "referredBy", type: "address", value: "0xa401e571e752ded7c61f8132599874b885f4478d"}, {name: "timestamp", type: "uint256", value: "1544535695"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "10086977335405920" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6867426", timeStamp: "1544539302", hash: "0x37b0aa47e43353156f680827ce040ed980fb016b5a55e4c9fa5e37e35b9ea427", nonce: "61", blockHash: "0xeb7a2f42a1ba0d510c1363fa16a9ff99a2b7ae7b54afdc517be310ad49055dc2", transactionIndex: "26", from: "0x00dfecf2df1b0bda707775c0c19287affa0cf21f", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "65000000000000000000", gas: "191791", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "2335201", gasUsed: "127861", confirmations: "811187"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "65000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544539302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x00dfecf2df1b0bda707775c0c19287affa0cf21f"}, {name: "incomingEthereum", type: "uint256", value: "65000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "58500000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544539302"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "88605717000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6867429", timeStamp: "1544539336", hash: "0xca452c2c8e7c6eb13271a3f6126f7031cea91de04eee73235d6de055281d3728", nonce: "6074", blockHash: "0xa976d5032e2d1a2529aac7c8740450b5fd78e7060c7547bed3c2d1a2706daa52", transactionIndex: "65", from: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "2100000000000000000", gas: "164547", gasPrice: "56000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2584934", gasUsed: "109698", confirmations: "811184"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "2100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544539336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff"}, {name: "incomingEthereum", type: "uint256", value: "2100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1890000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544539336"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3983970306814180" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6867520", timeStamp: "1544540579", hash: "0xeac6e26e035119f8be85068abe6eeedc438b87d2dc7368de2660685a2f5efed8", nonce: "0", blockHash: "0x91bc461c3a81e08bcd6402d3759e882277012ab866b527871f2649d23d731d1c", transactionIndex: "108", from: "0xc6c8649cbffbb7463d6a5a6d85ef719b3192cda4", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "490000000000000000", gas: "146719", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "6248959", gasUsed: "112861", confirmations: "811093"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "490000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544540579 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc6c8649cbffbb7463d6a5a6d85ef719b3192cda4"}, {name: "incomingEthereum", type: "uint256", value: "490000000000000000"}, {name: "tokensMinted", type: "uint256", value: "441000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544540579"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6867604", timeStamp: "1544541965", hash: "0x75acbbc18c370769fcc6ece8dedfc989f36f351649d766b9f46148391d8d4cc9", nonce: "1", blockHash: "0x37994e6c303c75258716770cd19f2fe4199ef2b97be48b8c8cddddd723c2977e", transactionIndex: "9", from: "0x369db58997b157daa9b7a65d51dba2e982c5b66d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "6670243", gasUsed: "60097", confirmations: "811009"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544541965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "incomingEthereum", type: "uint256", value: "9987250685000852822"}, {name: "tokensMinted", type: "uint256", value: "8988525616500767540000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544541965"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "ethereumReinvested", type: "uint256", value: "9987250685000852822"}, {name: "tokensMinted", type: "uint256", value: "8988525616500767540000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "10086977335405920" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6868425", timeStamp: "1544553372", hash: "0x513fcf7fcd9c23cc3d0d05ee97881090e9bcab0793d2aae83eb2bd10ca323f4e", nonce: "398", blockHash: "0x4ba9a110a028e43f3df8b181459f411caed1adea79459a3ca95c2ef0c1bb7fbe", transactionIndex: "19", from: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "100000000000000000", gas: "169014", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1936198", gasUsed: "112676", confirmations: "810188"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[4]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544553372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "90000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544553372"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "556541446627006646" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6868492", timeStamp: "1544554089", hash: "0x8442df4901054efa280cf0b08802dce09c58239da7c776d4f953744e254b8541", nonce: "21", blockHash: "0x7846cca0dc8a5dba263f18b6ca0c1663eaf26cb4ae03793f066e11ee1c8e5aa4", transactionIndex: "32", from: "0x337941c363e477d9bee57dc0e4da51082709a033", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1000000000000000000", gas: "191791", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "2205263", gasUsed: "127861", confirmations: "810121"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544554089 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "900000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544554089"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "32319879787702337" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6868533", timeStamp: "1544554554", hash: "0xa6c1caed1af50107ada1f3093f11aa75096b078b30dfc190567fb7859717cecf", nonce: "22", blockHash: "0xf6726113a31b1cd5e84722bd2a24454fde27c8a2415fdf6fee040878361839b1", transactionIndex: "3", from: "0x684969b54b3f010a6dc7c9f8c3c5d3706584aed4", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "300000000000000000", gas: "160000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "246688", gasUsed: "112861", confirmations: "810080"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544554554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x684969b54b3f010a6dc7c9f8c3c5d3706584aed4"}, {name: "incomingEthereum", type: "uint256", value: "300000000000000000"}, {name: "tokensMinted", type: "uint256", value: "270000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544554554"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "40869166346940866" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6868579", timeStamp: "1544555140", hash: "0x98fcd2c9cc510123d6e9e4293202d1d79360c59fcd30ab31cfc7a9bfbdc637c0", nonce: "399", blockHash: "0x8405bc0979295a055b11735772bac2514b1e2b63ef02a351128d1e7f003705ee", transactionIndex: "7", from: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1900000000000000000", gas: "93900", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "589175", gasUsed: "62600", confirmations: "810034"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[4]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544555140 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "incomingEthereum", type: "uint256", value: "1900000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1710000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544555140"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "556541446627006646" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6868959", timeStamp: "1544560501", hash: "0x074143ccc0d370d5e80a8102575f9e889b7ef46bbedadb069040b5e1bfd946bd", nonce: "93", blockHash: "0x6796c1d2a0fca00d0712b3768967b5286f36933efce5d99ac58f17ba57bad0ac", transactionIndex: "53", from: "0x6c92ff3b02dc8b67576000b7cad5949075781d59", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "960000000000000000", gas: "169291", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "3545053", gasUsed: "112861", confirmations: "809654"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "960000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544560501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x6c92ff3b02dc8b67576000b7cad5949075781d59"}, {name: "incomingEthereum", type: "uint256", value: "960000000000000000"}, {name: "tokensMinted", type: "uint256", value: "864000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544560501"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "592143184300570" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6868987", timeStamp: "1544560977", hash: "0xb0d575988de8d226cd2d243adcb7ef892d3e7b157cfeca7c9254ffb05ec00bbd", nonce: "8", blockHash: "0x35b568fd1295ef5b1bcfe6c13687389a9f1b76fcc3d77400ab5b66dcc1749264", transactionIndex: "94", from: "0x7d94793dc22278b6c81c56619d9ca5d5fa22deff", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "4900000000000000000", gas: "169291", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "7071468", gasUsed: "112861", confirmations: "809626"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "4900000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544560977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7d94793dc22278b6c81c56619d9ca5d5fa22deff"}, {name: "incomingEthereum", type: "uint256", value: "4900000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4410000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544560977"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "101687339286785318" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6869050", timeStamp: "1544561787", hash: "0xfecc9cbafcfed5b70ce5bacbc056952443562e2efeec15e50f849483f5184571", nonce: "2", blockHash: "0x6e3ded1b7cb61c8affbd575a5de144d1c525d602f18c64b23df3d8f2cb4cef63", transactionIndex: "50", from: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "330000000000000000", gas: "169291", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "4707592", gasUsed: "112861", confirmations: "809563"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "330000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544561787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d"}, {name: "incomingEthereum", type: "uint256", value: "330000000000000000"}, {name: "tokensMinted", type: "uint256", value: "297000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544561787"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "635390251926073554" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6869218", timeStamp: "1544564072", hash: "0x5a9b2fc4c5c9e0be0f03fdc514d89ecf278c8eb652bb05800b6d0b6459bf1f59", nonce: "113", blockHash: "0xd190368273a98cfb6911b73ac6f7de44ae5a1ec67fffbd54e2d3ec5678e7eef7", transactionIndex: "23", from: "0x14049e874d1d720f6faec9b548b8b54fcf5d6013", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "100000000000000000", gas: "191695", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000fc01a9ef0023ca1f1b19fb689a5a649487bff3ed", contractAddress: "", cumulativeGasUsed: "1118740", gasUsed: "127797", confirmations: "809395"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544564072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x14049e874d1d720f6faec9b548b8b54fcf5d6013"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "90000000000000000000"}, {name: "referredBy", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "timestamp", type: "uint256", value: "1544564072"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "7789623848016747" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6871485", timeStamp: "1544597573", hash: "0x225d51abbce80a2b0150662f4245e513235d78512bcb5550aed86d214bb9f31e", nonce: "206", blockHash: "0xe6567839cc9a83832f4cee95ec24fd587394b7847faeeeee2ac52e7cd0e10c2f", transactionIndex: "184", from: "0xaa521576ff0d4328db76967a722d20cc1ba91955", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "500000000000000000", gas: "200000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7126375", gasUsed: "109698", confirmations: "807128"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544597573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xaa521576ff0d4328db76967a722d20cc1ba91955"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "450000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544597573"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6871572", timeStamp: "1544598809", hash: "0xb09f69f951a078e2b4cb0c53308be01e33947c478ba17b8f8cb6e46e08c44bd6", nonce: "22", blockHash: "0x9320ee4bc7af7fe6e4ec68635f510ba99978a3447011a72031aa61cca1e74d80", transactionIndex: "137", from: "0x337941c363e477d9bee57dc0e4da51082709a033", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "33000000000000000000", gas: "93159", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000337941c363e477d9bee57dc0e4da51082709a033", contractAddress: "", cumulativeGasUsed: "5699271", gasUsed: "62106", confirmations: "807041"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "33000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544598809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "incomingEthereum", type: "uint256", value: "33000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "29700000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544598809"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "32319879787702337" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6871673", timeStamp: "1544600164", hash: "0xe3a86f08fb7ffc0849aff34a49c237ee45f5e106395a8a4039734ff50a0dd451", nonce: "21", blockHash: "0x44b3ce235c9fa47537071c75f2cdcf5f19730bc5a77e05b840ac5d203188aa36", transactionIndex: "151", from: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "5000000000000000000", gas: "169291", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "5362474", gasUsed: "112861", confirmations: "806940"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544600164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "incomingEthereum", type: "uint256", value: "5000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4500000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544600164"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6871690", timeStamp: "1544600406", hash: "0xf4d2614af246eec02c42c635208c1ac54068fd86bcbfbb43d75e3b254ddc32d1", nonce: "22", blockHash: "0x1da6ed6789ae1ec0b7c051d13606036fccbcef2f47286906959385c9270ea88b", transactionIndex: "182", from: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "5000000000000000000", gas: "94177", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "4906453", gasUsed: "62785", confirmations: "806923"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544600406 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "incomingEthereum", type: "uint256", value: "5000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4500000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544600406"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6871713", timeStamp: "1544600680", hash: "0x8d4f3aa27a893a5b3f45fba5a1a93663ae566d730ff1836d8f17e90318c63761", nonce: "40", blockHash: "0x8d4fea3e94d5d8aad20e4a5aebcb38996b7e5ba6d6e9d15ea0d9370c5d0cd841", transactionIndex: "133", from: "0x68d0a0f67bf5decda69e8c7ab31b07b60f1973b9", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "44500000000000000000", gas: "191791", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000337941c363e477d9bee57dc0e4da51082709a033", contractAddress: "", cumulativeGasUsed: "4453441", gasUsed: "127861", confirmations: "806900"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "44500000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544600680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x68d0a0f67bf5decda69e8c7ab31b07b60f1973b9"}, {name: "incomingEthereum", type: "uint256", value: "44500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "40050000000000000000000"}, {name: "referredBy", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "timestamp", type: "uint256", value: "1544600680"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "332827564420810374" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6871818", timeStamp: "1544602384", hash: "0x5085c624f070cfbda1c24fc1f12f37897df513d5aebb0a88aa38f035630fb2f5", nonce: "2", blockHash: "0xf94075449fe93ec60f85aeb26ee35808b0b1d7fc3c2e7465d411d54cc7bc18c0", transactionIndex: "60", from: "0x369db58997b157daa9b7a65d51dba2e982c5b66d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "2176934", gasUsed: "60097", confirmations: "806795"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544602384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "incomingEthereum", type: "uint256", value: "3461224480497190757"}, {name: "tokensMinted", type: "uint256", value: "3115102032447471682000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544602384"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "ethereumReinvested", type: "uint256", value: "3461224480497190757"}, {name: "tokensMinted", type: "uint256", value: "3115102032447471682000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "10086977335405920" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6872006", timeStamp: "1544604777", hash: "0xfdbd7bda7e87dce10132b78072699b6a6a3873fee9a51b744eb85a57745c7f02", nonce: "207", blockHash: "0x6c30a4f99623d2f3353ca1d43f5b4077171698c0a7ecde2881750acf2174028c", transactionIndex: "35", from: "0xaa521576ff0d4328db76967a722d20cc1ba91955", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "500000000000000000", gas: "200000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5610864", gasUsed: "59622", confirmations: "806607"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544604777 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xaa521576ff0d4328db76967a722d20cc1ba91955"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "450000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544604777"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6872365", timeStamp: "1544610114", hash: "0x041c1fb020e74972dbbdd6c88e6e4d03ce773dfcd692354bc914f017c391e20a", nonce: "141", blockHash: "0x917d868bdf44a4395feebd8649de1393c11319a48b215b88a265efaf112fc088", transactionIndex: "49", from: "0xd8592b0d6297c72f0c5bfe9b3b4bdf30d992ace1", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "450000000000000000", gas: "210000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "2333662", gasUsed: "112676", confirmations: "806248"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "450000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[4]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544610114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xd8592b0d6297c72f0c5bfe9b3b4bdf30d992ace1"}, {name: "incomingEthereum", type: "uint256", value: "450000000000000000"}, {name: "tokensMinted", type: "uint256", value: "405000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544610114"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "189454000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6872416", timeStamp: "1544610947", hash: "0x6869fc4e6fa92b12ebaf599fee0b430f7801d7f9b163754ba5557eb33eb5e7ed", nonce: "3", blockHash: "0xbcf25fb31b11b3d13b3b8b245bfd8d48d7614f8dc474a29ff44918be2faf26c5", transactionIndex: "148", from: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "350000000000000000", gas: "116677", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "7686750", gasUsed: "77785", confirmations: "806197"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544610947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d"}, {name: "incomingEthereum", type: "uint256", value: "350000000000000000"}, {name: "tokensMinted", type: "uint256", value: "315000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544610947"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "635390251926073554" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6872468", timeStamp: "1544611574", hash: "0x3c5bb00800ef87e13ce3cdf3f6e21f120259a809089e7ed9d25754663dafc80e", nonce: "4", blockHash: "0x1390fd46df69f6c3ceb696e970354be985c75565d6196216d95fb1b7f02522bb", transactionIndex: "49", from: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "650000000000000000", gas: "94177", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "7535280", gasUsed: "62785", confirmations: "806145"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "650000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544611574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc8e1b87765455a93d83a3156fa8fa4dc4242014d"}, {name: "incomingEthereum", type: "uint256", value: "650000000000000000"}, {name: "tokensMinted", type: "uint256", value: "585000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544611574"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "635390251926073554" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6872832", timeStamp: "1544616646", hash: "0x724506f9bd5dff9692bf1ae5e5b37ac39188a350447388221287c7526550a8cd", nonce: "23", blockHash: "0x2c905c060d8ed4389b35d72e3163230cf412af76f17460d62110aca032591c48", transactionIndex: "141", from: "0x337941c363e477d9bee57dc0e4da51082709a033", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "66339", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6112911", gasUsed: "28494", confirmations: "805781"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544616646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "ethereumWithdrawn", type: "uint256", value: "2188533479577852463"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "32319879787702337" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6873068", timeStamp: "1544619775", hash: "0xeabef6b211fd53407f5f0279ee662582171586c2523fea47dccc0428a8004bd8", nonce: "41", blockHash: "0x1d443d671515c82a2663711ac9ff303f9c071886e71403105dcf1856ff8c49e6", transactionIndex: "170", from: "0x68d0a0f67bf5decda69e8c7ab31b07b60f1973b9", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "500000000000000000", gas: "116677", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000337941c363e477d9bee57dc0e4da51082709a033", contractAddress: "", cumulativeGasUsed: "6489586", gasUsed: "77785", confirmations: "805545"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544619775 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x68d0a0f67bf5decda69e8c7ab31b07b60f1973b9"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "450000000000000000000"}, {name: "referredBy", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "timestamp", type: "uint256", value: "1544619775"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "332827564420810374" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6874326", timeStamp: "1544637803", hash: "0x41e516fc3e799cf384149a34f956a1d1e5b3daa08244403da1e9b245552de443", nonce: "16", blockHash: "0xdf8a99a45b7419ad4579f1e4d0bd17eaf4d408481cbce4d03d92861b3458f293", transactionIndex: "146", from: "0x869bbf02b923d7d0ab01b82e0d2b35a71e589231", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "5200000000000000000", gas: "169195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000fc01a9ef0023ca1f1b19fb689a5a649487bff3ed", contractAddress: "", cumulativeGasUsed: "7479016", gasUsed: "112797", confirmations: "804287"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "5200000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544637803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x869bbf02b923d7d0ab01b82e0d2b35a71e589231"}, {name: "incomingEthereum", type: "uint256", value: "5200000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4680000000000000000000"}, {name: "referredBy", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "timestamp", type: "uint256", value: "1544637803"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "71451964783050849" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6874822", timeStamp: "1544644838", hash: "0x120c0241f70b65f2a84e52708c8f86a41c7a2d570d312d1111f62483db48ecee", nonce: "1", blockHash: "0x523746d2eb9870bcf8680d7116506f919b7870148489650c0b74250f16d52b3f", transactionIndex: "26", from: "0x42d6fb2ac47cc44296759530433ceeebc564760f", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "65000000000000000", gas: "169291", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "6938109", gasUsed: "112861", confirmations: "803791"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "65000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544644838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x42d6fb2ac47cc44296759530433ceeebc564760f"}, {name: "incomingEthereum", type: "uint256", value: "65000000000000000"}, {name: "tokensMinted", type: "uint256", value: "58500000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544644838"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "3430473120443809432" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6874822", timeStamp: "1544644838", hash: "0x96b561292402159b45132a5d3cecb5f2effb81ca65428e73dd2cd522acf7af50", nonce: "66", blockHash: "0x523746d2eb9870bcf8680d7116506f919b7870148489650c0b74250f16d52b3f", transactionIndex: "33", from: "0x49681adf3579ac627cc8980a767e9a4af13d50d7", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1000000000000000000", gas: "169195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000fc01a9ef0023ca1f1b19fb689a5a649487bff3ed", contractAddress: "", cumulativeGasUsed: "7712476", gasUsed: "112797", confirmations: "803791"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544644838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x49681adf3579ac627cc8980a767e9a4af13d50d7"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "900000000000000000000"}, {name: "referredBy", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "timestamp", type: "uint256", value: "1544644838"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "3139716388723916" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6874839", timeStamp: "1544645050", hash: "0x5e1fa3b6fe9db59834275a38490169508b8fcd753481190460c1c916c4e0fa8b", nonce: "116", blockHash: "0xecddfb6c9764120c42639c1b2e0e9efb6ce6165512441ce1b90f1345e9779715", transactionIndex: "115", from: "0x14049e874d1d720f6faec9b548b8b54fcf5d6013", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "50000000000000000", gas: "94081", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000fc01a9ef0023ca1f1b19fb689a5a649487bff3ed", contractAddress: "", cumulativeGasUsed: "6898270", gasUsed: "62721", confirmations: "803774"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544645050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x14049e874d1d720f6faec9b548b8b54fcf5d6013"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "45000000000000000000"}, {name: "referredBy", type: "address", value: "0xfc01a9ef0023ca1f1b19fb689a5a649487bff3ed"}, {name: "timestamp", type: "uint256", value: "1544645050"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "7789623848016747" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6874911", timeStamp: "1544646068", hash: "0x7bf02a07894c17cd18f0b3d1df7ebb9df1699fb0abac73d6e21771a5fdf5c30d", nonce: "32", blockHash: "0x15e691b2e773dd52bd6f2cd180ef9d9a3ddd6eac58f66ada64a568e9ca4bf9b0", transactionIndex: "88", from: "0x8c02ff198edef168e4e1c7a9af45edbf2649e4fb", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "10000000000000000000", gas: "169291", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000337941c363e477d9bee57dc0e4da51082709a033", contractAddress: "", cumulativeGasUsed: "4755861", gasUsed: "112861", confirmations: "803702"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544646068 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x8c02ff198edef168e4e1c7a9af45edbf2649e4fb"}, {name: "incomingEthereum", type: "uint256", value: "10000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "9000000000000000000000"}, {name: "referredBy", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "timestamp", type: "uint256", value: "1544646068"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "50769954460361688" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6875009", timeStamp: "1544647469", hash: "0x02fd946794de0391bc7e1e214687acad67df831471564bcd8576ab609c688278", nonce: "26", blockHash: "0xd6fb4255720a04f77316af9c92c91da281a32dd1e81195e6b42dcb6ddf56ee53", transactionIndex: "25", from: "0x9733d9d07f9e0ec51c8b7fc7463c8c5153eac815", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "10000000000000000000", gas: "169291", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "1067924", gasUsed: "112861", confirmations: "803604"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544647469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9733d9d07f9e0ec51c8b7fc7463c8c5153eac815"}, {name: "incomingEthereum", type: "uint256", value: "10000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "9000000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544647469"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "2279762218484730" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6875395", timeStamp: "1544653088", hash: "0x408a3ee54a261c12324770abbfabc18e69a36abe2598ed5a58a850b162dfea21", nonce: "62", blockHash: "0xb954eb277fe62c1a1feb3cf443fd469cffe35ccca505ad71c88d39ac184761c7", transactionIndex: "81", from: "0xa79dd2d94772bbe4949e5bca5df5cb875df4d995", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "5000000000000000000", gas: "169291", gasPrice: "2200000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "6820118", gasUsed: "112861", confirmations: "803218"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544653088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xa79dd2d94772bbe4949e5bca5df5cb875df4d995"}, {name: "incomingEthereum", type: "uint256", value: "5000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4500000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544653088"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "85982722062305296" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6875723", timeStamp: "1544657581", hash: "0x8cc6d231c1c204cb6690660806c93fb1ae96dad7c5712a01dd5b11becb4a5f60", nonce: "43", blockHash: "0x8220e04373da2dd5f517f7b8383f16cae09533d5559cbf50c385b615370c332b", transactionIndex: "99", from: "0xc786c8246f9aedb79bb3ce73cdd5e7ab0b2e9464", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "178000000000000000", gas: "169291", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "5780880", gasUsed: "112861", confirmations: "802890"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "178000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544657581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc786c8246f9aedb79bb3ce73cdd5e7ab0b2e9464"}, {name: "incomingEthereum", type: "uint256", value: "178000000000000000"}, {name: "tokensMinted", type: "uint256", value: "160200000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544657581"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "16291058306942301" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6876704", timeStamp: "1544671239", hash: "0xc930b978337b359c3148af5b947353f6bd42a5e3b4c7d120e326aa91f1b9eaba", nonce: "17", blockHash: "0xebfc0b19dd2d188309066d770495b9b4a970d1f70f3cf9628b47ea4626284ca9", transactionIndex: "94", from: "0x1adcbc4df1d9bc15070d1c1a6800ba6562974f3f", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "100000000000000000", gas: "169291", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "4407668", gasUsed: "112861", confirmations: "801909"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544671239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x1adcbc4df1d9bc15070d1c1a6800ba6562974f3f"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "90000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544671239"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "62204509611556704" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6877249", timeStamp: "1544679244", hash: "0x49ee2863c4f0b6ece063698224cae9fe7924fd2ab3a1cae79e30fa6c76bf5076", nonce: "50", blockHash: "0x20c6a6f4aef6e17ac2f438cadff4ad804c3b1d9445702686f7d884ec97c120eb", transactionIndex: "108", from: "0xb59b252570c51ab06f8382c06aca3e300c8cd1f6", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "60000000000000000", gas: "169291", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "5592797", gasUsed: "112861", confirmations: "801364"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544679244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb59b252570c51ab06f8382c06aca3e300c8cd1f6"}, {name: "incomingEthereum", type: "uint256", value: "60000000000000000"}, {name: "tokensMinted", type: "uint256", value: "54000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544679244"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "6290751876037147" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6877408", timeStamp: "1544681419", hash: "0xfcc2bb87febe5c631852523bbfa44a703e53cbfa8f785e740b6b826f0eb219d3", nonce: "23", blockHash: "0x1504e53410a3b3820ca47fd579b79e504c141d1d7d6aa36b6e5b77c71f96efec", transactionIndex: "194", from: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "7740822", gasUsed: "75097", confirmations: "801205"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544681419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "incomingEthereum", type: "uint256", value: "180974035957304278"}, {name: "tokensMinted", type: "uint256", value: "162876632361573851000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544681419"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "ethereumReinvested", type: "uint256", value: "180974035957304278"}, {name: "tokensMinted", type: "uint256", value: "162876632361573851000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6877587", timeStamp: "1544683867", hash: "0xa19397f181830f1c9dc346194112c0759fbf6e681c0e131dac9b83d654d10c72", nonce: "21", blockHash: "0xd97d681914ad760cfbc7020b12983199aa05db4a710b9d51d1fab46cb6e3317f", transactionIndex: "55", from: "0xd956c1172077db01ec2c139676c1030b1e96c0f7", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "3400000000000000000", gas: "191791", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000068d0a0f67bf5decda69e8c7ab31b07b60f1973b9", contractAddress: "", cumulativeGasUsed: "3725197", gasUsed: "127861", confirmations: "801026"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "3400000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544683867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xd956c1172077db01ec2c139676c1030b1e96c0f7"}, {name: "incomingEthereum", type: "uint256", value: "3400000000000000000"}, {name: "tokensMinted", type: "uint256", value: "3060000000000000000000"}, {name: "referredBy", type: "address", value: "0x68d0a0f67bf5decda69e8c7ab31b07b60f1973b9"}, {name: "timestamp", type: "uint256", value: "1544683867"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "3155667214775865717" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[30] )", async function( ) {
		const txOriginal = {blockNumber: "6877675", timeStamp: "1544685327", hash: "0x7fca3186aeb45bcc2b2228439f813a4c55856efdeef8a933fd39e0e876f43d03", nonce: "0", blockHash: "0xbb17cd6965bf77be70a534aea7a532e55ae39654a5ca82ec1ac2ef53c3a3d0ce", transactionIndex: "132", from: "0xe90a1f52e12825945ea54a7d60ebcf4155424fa6", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "17020000000000000000", gas: "191695", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000001adcbc4df1d9bc15070d1c1a6800ba6562974f3f", contractAddress: "", cumulativeGasUsed: "7742117", gasUsed: "127797", confirmations: "800938"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "17020000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[30]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544685327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xe90a1f52e12825945ea54a7d60ebcf4155424fa6"}, {name: "incomingEthereum", type: "uint256", value: "17020000000000000000"}, {name: "tokensMinted", type: "uint256", value: "15318000000000000000000"}, {name: "referredBy", type: "address", value: "0x1adcbc4df1d9bc15070d1c1a6800ba6562974f3f"}, {name: "timestamp", type: "uint256", value: "1544685327"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1550965737859994" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6878215", timeStamp: "1544693236", hash: "0x21043ab97261494947ed4df3a450b532b14250dbdf7c676b48b67438170d58dd", nonce: "9", blockHash: "0xf9730568261e477dd2a2a5ae93c2d27920c947aa20935eeed75b667e1d872aec", transactionIndex: "64", from: "0x5090b841889600bed6ec38cac1c5ba12ccca9c16", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1000000000000000000", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "3311766", gasUsed: "112861", confirmations: "800398"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544693236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5090b841889600bed6ec38cac1c5ba12ccca9c16"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "900000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544693236"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[34] )", async function( ) {
		const txOriginal = {blockNumber: "6878308", timeStamp: "1544694675", hash: "0xc081b0b0e482361995095f64e58238be6053442bbd0825b3b79ba94b11fd4e99", nonce: "15", blockHash: "0x107a35841450434e5d2358366291467fe525929d35be6d5f3d146060e7f4a752", transactionIndex: "140", from: "0x1df3fd4d77455c76f2a65a8f6ddf47c7c2ab9b64", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "1400000000000000000", gas: "191695", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000005090b841889600bed6ec38cac1c5ba12ccca9c16", contractAddress: "", cumulativeGasUsed: "7295221", gasUsed: "127797", confirmations: "800305"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "1400000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[34]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[34], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544694675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x1df3fd4d77455c76f2a65a8f6ddf47c7c2ab9b64"}, {name: "incomingEthereum", type: "uint256", value: "1400000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1260000000000000000000"}, {name: "referredBy", type: "address", value: "0x5090b841889600bed6ec38cac1c5ba12ccca9c16"}, {name: "timestamp", type: "uint256", value: "1544694675"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "1407541557220811520" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6878437", timeStamp: "1544696562", hash: "0x425dd1d2c1ed1d132cd114027358a27954a0d736b20fd68fbc3ae33e39ee5781", nonce: "42", blockHash: "0xc48d8dcefdbdcab5218d8d177b75f7009addba6cc0509882b45d5b160336fdf6", transactionIndex: "109", from: "0x2b546d8c42f6b74e9c50455d0b8577e26662387e", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "800000000000000000", gas: "169014", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "4099388", gasUsed: "112676", confirmations: "800176"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "800000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[4]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544696562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x2b546d8c42f6b74e9c50455d0b8577e26662387e"}, {name: "incomingEthereum", type: "uint256", value: "800000000000000000"}, {name: "tokensMinted", type: "uint256", value: "720000000000000000000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544696562"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "24925146653426091" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6878525", timeStamp: "1544697866", hash: "0xe22a59d81fff7f7e5a959937cdd0896148288ab791bd0d6490876778971a13a2", nonce: "24", blockHash: "0x3e797c229f148fcedc9e5df53d74982c7ab4be5014b407e80674ebfec9bbdc92", transactionIndex: "122", from: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "7164481", gasUsed: "75097", confirmations: "800088"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544697866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "incomingEthereum", type: "uint256", value: "41364369573669774"}, {name: "tokensMinted", type: "uint256", value: "37227932616302797000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544697866"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x9e697c0aaeed5b45519fe9e4f8bbd7e3ac2610f1"}, {name: "ethereumReinvested", type: "uint256", value: "41364369573669774"}, {name: "tokensMinted", type: "uint256", value: "37227932616302797000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6878625", timeStamp: "1544699309", hash: "0xe33500d199bfc9de25fb1a8fd41bdaeb8f0667b8a66d85229ee5cbc1c30c1563", nonce: "95", blockHash: "0x0e544d6b237478efbb5685efafa2464958730caf7f9d40c4b9a26c724e005cf1", transactionIndex: "87", from: "0x6c92ff3b02dc8b67576000b7cad5949075781d59", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "5052174", gasUsed: "75097", confirmations: "799988"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544699309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x6c92ff3b02dc8b67576000b7cad5949075781d59"}, {name: "incomingEthereum", type: "uint256", value: "31916870080683151"}, {name: "tokensMinted", type: "uint256", value: "28725183072614836000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544699309"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x6c92ff3b02dc8b67576000b7cad5949075781d59"}, {name: "ethereumReinvested", type: "uint256", value: "31916870080683151"}, {name: "tokensMinted", type: "uint256", value: "28725183072614836000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "592143184300570" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6878709", timeStamp: "1544700456", hash: "0xa2322f06b9183f488199131014278ccaba53dd857f769ffc46569d3ddc9cd8f4", nonce: "6", blockHash: "0xaa44ab3c2ece8d78b48594dfed690215b1a4bae1cf5394be5e94b1bab5304a0b", transactionIndex: "88", from: "0xb7c063b5bcdb56087b2ef9615c71b2439e0f2c70", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "2000000000000000000", gas: "169291", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "5838715", gasUsed: "112861", confirmations: "799904"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544700456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb7c063b5bcdb56087b2ef9615c71b2439e0f2c70"}, {name: "incomingEthereum", type: "uint256", value: "2000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1800000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544700456"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "14637985184164034" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6878718", timeStamp: "1544700549", hash: "0x69ce4646cbed20777487c08ea668211ea06bd1e5bcfdb338e312af0e40ff9152", nonce: "10", blockHash: "0x7b8bcfbe4a7af2d4d215e6ca507dcf495bc67ce0e87df2a0710d6992de609252", transactionIndex: "43", from: "0x5090b841889600bed6ec38cac1c5ba12ccca9c16", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "4100000000000000000", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000369db58997b157daa9b7a65d51dba2e982c5b66d", contractAddress: "", cumulativeGasUsed: "1832780", gasUsed: "62785", confirmations: "799895"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "4100000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[8]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544700549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5090b841889600bed6ec38cac1c5ba12ccca9c16"}, {name: "incomingEthereum", type: "uint256", value: "4100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "3690000000000000000000"}, {name: "referredBy", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "timestamp", type: "uint256", value: "1544700549"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6878756", timeStamp: "1544701195", hash: "0xf073a363ac3d93be138c035a70a5b1aae7f4f0c7bc21ffe654f82cb665aee5c9", nonce: "0", blockHash: "0x862f09912069cf9fdf5c5dfd6620f34fee1fa93635557cb04748db82502c3f4a", transactionIndex: "178", from: "0x3e7603ce200457cb60accda91a3d99f1d825e15b", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "29900000000000000000", gas: "169291", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000337941c363e477d9bee57dc0e4da51082709a033", contractAddress: "", cumulativeGasUsed: "4962129", gasUsed: "112861", confirmations: "799857"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "29900000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544701195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x3e7603ce200457cb60accda91a3d99f1d825e15b"}, {name: "incomingEthereum", type: "uint256", value: "29900000000000000000"}, {name: "tokensMinted", type: "uint256", value: "26910000000000000000000"}, {name: "referredBy", type: "address", value: "0x337941c363e477d9bee57dc0e4da51082709a033"}, {name: "timestamp", type: "uint256", value: "1544701195"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6879429", timeStamp: "1544710277", hash: "0x24ad3ebcac4fafc3a98dc7fb9fdfbdbab34f3ed497ddb8500447dff47dc026d8", nonce: "3", blockHash: "0xa03591e3c8a14cf25a149098afa72e3c34fdba6ca510d8d6ba39d96d8e0ce8da", transactionIndex: "42", from: "0x369db58997b157daa9b7a65d51dba2e982c5b66d", to: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a", value: "0", gas: "112645", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "1575254", gasUsed: "60097", confirmations: "799184"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544710277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "incomingEthereum", type: "uint256", value: "2676806648177214077"}, {name: "tokensMinted", type: "uint256", value: "2409125983359492670000"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1544710277"}, {name: "price", type: "uint256", value: "1100000000000000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x369db58997b157daa9b7a65d51dba2e982c5b66d"}, {name: "ethereumReinvested", type: "uint256", value: "2676806648177214077"}, {name: "tokensMinted", type: "uint256", value: "2409125983359492670000"}], address: "0x9c025c5eab68f658c6c6c3a7f6a9e1b24616ef0a"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "10086977335405920" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1078180102236474053" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
