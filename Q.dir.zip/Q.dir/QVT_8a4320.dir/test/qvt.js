const QVT = artifacts.require( "./QVT.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "QVT" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x70c4EEa814BEE9B74CAfecA0200991Bb0d8a4320", "0x00fEE5170c113e84ac05742D4afF6408d1CF46Bb", "0x8A7a7D59FaCd65b80b0d2Bb4f5cA815Ed29B0E88", "0xACe822BdeC3499C0259668C1cE17358dac86Fa8B", "0x6257832d2443922c4BDc2ABDF94f4d4AB20FE98e", "0x89a94b48B21d3b5F959305643d3C71DC88CC7fbc", "0x4EFF5305325F5d6a1e8A0270A696CA9C5fA931Ae", "0x7F5F1958eA0549CE127D9a740ED557c268848C36", "0xBeC556CA07A44ffcDD19389151657Cf66D62c2Ea", "0x2373919B5FdEeE27Bfa3D54610d3f28e3C47194f", "0xcE368Ece096953f77A56D084FBb38564D932091d", "0xEF05De91263De87788119DAABE25ed6Ca32110Eb", "0xEc862eFed6bD4cdc1F333645D95B24Ba04065686", "0xbb49d91C65D3f58F9E114780644db62e3c42AFe5", "0x8F27Bd58160eF4fcfdd1cAD57D6328E96dBC96fa", "0x8D0e16E77d357728d650481A01680FaE49F9CCF3", "0x8A836F727ae7396d681C04Bd2EDD5E046A86cFC2", "0x225b4bC64E051827c069312f82fA590Ec9632209", "0x55f32c50CC315f14A8D225BAF7E5EEC108778185", "0x035b91c95258C6FD55404Ac1cD55dc8614CFED33", "0x0f3FBe0b6AD590b3d761F53581c57766200f8EeD", "0x8b89F0de3d3f07f9aFC9D27f773A24dB91Ab3191", "0xDEd0a02807B8241703E2509A1Eaa2CC160bA53f1", "0xADcf8f36f433de99231CBd4008692a96D52Ed2ef", "0x787D6b93e32dEa45B195ecE5b613Af966E1B15C9", "0x82D99d98115565d2A58e99fC53704CEe56e3C0De", "0x59f114b8F7Ac2Db0C6fb6C05A8d84b10e8d881D3", "0x614a7b62d883555d6DAce13AbbEBc0C2F8355172", "0xd24400ae8BfEBb18cA49Be86258a3C749cf46853", "0x240500A1A6262dB06fa375155038a812C83AA982", "0x46dA1F8a4bAEa8CA89Cd69Bd9721182C494Cd008", "0xb8389dbC13D232E42071439aec7d7d04ae55e4be", "0xAF8343E44000cCf0d7C4A7CCe560114a3F71AeD2", "0xA995c454d51dBE2D3167A070Df96dE459D94Dc64", "0x19Cd0e4347f84C7Fe1076D2e75e71abd9Dd20fca", "0x58C61a555E147214231D6910AD5F04ccE84b2095", "0xE9f8b46a71B6b324633566a9CB15dBf4a8AFC385", "0x1151314c646Ce4E0eFD76d1aF4760aE66a9Fe30F", "0x3d2dAAd115dD00669fb880Fdd2c3E97BBF1F2B66", "0x3D6f29C67F571caD827bb512C7949b0A1C0B9899", "0xE07412D5af80291a022e768e85C64b3743fD3746", "0x28D07Ce0a312aa4aB889d44800Dd6Dfa37B64322", "0x525eC281a57BC34Ec6c63C9D007fA3940b183249", "0x28cE29BFb9FbEbb4Ff83F42866e59814BF3D53bf", "0x354decB3Aed53F92c24c0c458Efe14C7aF6a88cC", "0xea0f9E1AD062daaFb0653F760432EFcEb914CA2E", "0x0070b6B071f209fA963bB543Cd689dd30ba8F496"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "preIcoTokenSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "presaleEtherRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "preIco", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "founder", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalTokens", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "team", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "bounty", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "presaleTokenSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "preIcoCap", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "icoCap", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isToken", outputs: [{name: "weAre", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "eth", type: "uint256"}, {indexed: false, name: "fbt", type: "uint256"}], name: "Buy", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionReceived", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Burn", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Minted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Buy(address,uint256,uint256)", "TokensSent(address,uint256)", "ContributionReceived(address,uint256)", "Burn(address,uint256)", "Minted(address,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1cbc5ab135991bd2b6a4b034a04aa2aa086dac1371cb9b16b8b5e2ed6b036bed", "0xf18d5a93c62c1d0c761ed52107f11d20bc2071851206b79c4dd3283bd9f006f1", "0x1bb460ccaaf70fbacfec17a376f8acbd278c1405590ffcc8ebe4b88daf4f64ad", "0xcc16f5dbb4873280815c1ee09dbd06736cffcc184412cf7a71a0fdb75d397ca5", "0x30385c845b448a36257a6a1716e6ad2e1bc2cbe333cde1e69fe849ad6511adfe", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4173939 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4177001 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_founder", value: 4}], name: "QVT", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "preIcoTokenSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "preIcoTokenSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleEtherRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleEtherRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "preIco", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "preIco()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "founder", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "founder()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "team", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "team()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "bounty", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bounty()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleTokenSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleTokenSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "preIcoCap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "preIcoCap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "icoCap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "icoCap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isToken", outputs: [{name: "weAre", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "QVT", function( accounts ) {

	it( "TEST: QVT( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4173939", timeStamp: "1503072548", hash: "0x74f8b30fa0af2ca04a8e18a7311d13538b618051b676b7c362586b634d6034a9", nonce: "7", blockHash: "0xe0fd1dc32fda8f2fe49192e4e61e7ad4df06c4e1c52577d42676669210c7f36f", transactionIndex: "6", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: 0, value: "0", gas: "2184431", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x0930f27b0000000000000000000000008a7a7d59facd65b80b0d2bb4f5ca815ed29b0e88", contractAddress: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", cumulativeGasUsed: "2091920", gasUsed: "1820359", confirmations: "3527206"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_founder", value: addressList[4]}], name: "QVT", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = QVT.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1503072548 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = QVT.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4173960", timeStamp: "1503072978", hash: "0x3e7a000c4f0051fffbca7fd1ca0883b068ebf120756786998a550fd3e801a82b", nonce: "3", blockHash: "0xc9d0612daa9acfbb5a499a5039ad3c7bedbc9a56c53b577c45116502543e60e4", transactionIndex: "42", from: "0xace822bdec3499c0259668c1ce17358dac86fa8b", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "500000000000000000", gas: "125573", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "3616486", gasUsed: "125572", confirmations: "3527185"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1503072978 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "eth", type: "uint256"}, {indexed: false, name: "fbt", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "sender", type: "address", value: "0xace822bdec3499c0259668c1ce17358dac86fa8b"}, {name: "eth", type: "uint256", value: "500000000000000000"}, {name: "fbt", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xace822bdec3499c0259668c1ce17358dac86fa8b"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionReceived", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionReceived", events: [{name: "to", type: "address", value: "0xace822bdec3499c0259668c1ce17358dac86fa8b"}, {name: "value", type: "uint256", value: "500000000000000000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xace822bdec3499c0259668c1ce17358dac86fa8b"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "501778374000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[6], \"75\" )", async function( ) {
		const txOriginal = {blockNumber: "4174978", timeStamp: "1503094045", hash: "0x3284a5c0bf4149753e76dda7d68b48ee6a082a94573ccf147d95096fafe2dbb8", nonce: "8", blockHash: "0x17bd88a698a39bf430c1801030edd663cb6d343bd0ddf9ad2ecc78602c623fe3", transactionIndex: "16", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000006257832d2443922c4bdc2abdf94f4d4ab20fe98e000000000000000000000000000000000000000000000000000000000000004b", contractAddress: "", cumulativeGasUsed: "518788", gasUsed: "53837", confirmations: "3526167"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "75"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[6], "75", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1503094045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x6257832d2443922c4bdc2abdf94f4d4ab20fe98e"}, {name: "value", type: "uint256", value: "75"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x6257832d2443922c4bdc2abdf94f4d4ab20fe98e"}, {name: "value", type: "uint256", value: "75"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[2,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[3], \"150\" )", async function( ) {
		const txOriginal = {blockNumber: "4176375", timeStamp: "1503122456", hash: "0x0a5be13be6761977c2e6a181dd2efe080c464f089d07bae37395ba98caf53842", nonce: "9", blockHash: "0x36bb2983eb9e3089cb39fc286177e07ddd13d7506e558288108f92b304ce3554", transactionIndex: "8", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "46528", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000000fee5170c113e84ac05742d4aff6408d1cf46bb0000000000000000000000000000000000000000000000000000000000000096", contractAddress: "", cumulativeGasUsed: "456828", gasUsed: "38773", confirmations: "3524770"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[3]}, {type: "uint256", name: "_value", value: "150"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[3], "150", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1503122456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "value", type: "uint256", value: "150"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "value", type: "uint256", value: "150"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[6], \"75\" )", async function( ) {
		const txOriginal = {blockNumber: "4176384", timeStamp: "1503122655", hash: "0x5bbc31d5a995a77c94320268fca8663d7d87c95890391c67860f3b84d0db22f3", nonce: "10", blockHash: "0xf2034acc2571b617317f2dd8005abbd15eeeac2d2a8d607290deff0b86236ac0", transactionIndex: "102", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "46604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000006257832d2443922c4bdc2abdf94f4d4ab20fe98e000000000000000000000000000000000000000000000000000000000000004b", contractAddress: "", cumulativeGasUsed: "3445576", gasUsed: "38837", confirmations: "3524761"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "75"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[6], "75", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1503122655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x6257832d2443922c4bdc2abdf94f4d4ab20fe98e"}, {name: "value", type: "uint256", value: "75"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x6257832d2443922c4bdc2abdf94f4d4ab20fe98e"}, {name: "value", type: "uint256", value: "75"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[7], \"15000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176396", timeStamp: "1503122945", hash: "0xa0d47430a0dcc8df0b66ea78f0eaf7dd7041c2e57e80ef4077050fd673cb9fab", nonce: "11", blockHash: "0xeeb9715f5947173b3101b59b76b159ae81acfbdcd6039929a7b1c37d7af13107", transactionIndex: "46", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000089a94b48b21d3b5f959305643d3c71dc88cc7fbc0000000000000000000000000000000000000000000000000000000000003a98", contractAddress: "", cumulativeGasUsed: "2864774", gasUsed: "53901", confirmations: "3524749"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "15000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[7], "15000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1503122945 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x89a94b48b21d3b5f959305643d3c71dc88cc7fbc"}, {name: "value", type: "uint256", value: "15000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x89a94b48b21d3b5f959305643d3c71dc88cc7fbc"}, {name: "value", type: "uint256", value: "15000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[8], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176426", timeStamp: "1503123625", hash: "0x905c2faa2b99ecc6ceb87f215b5772f41282d2a37da865e7b96b1a51c4d8ae33", nonce: "12", blockHash: "0x98ce1eb0ee4ddecb6a91aca3a26ce0c7b75600df34b8543cef7df1d6473c0414", transactionIndex: "34", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000004eff5305325f5d6a1e8a0270a696ca9c5fa931ae00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1219772", gasUsed: "53901", confirmations: "3524719"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[8], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1503123625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x4eff5305325f5d6a1e8a0270a696ca9c5fa931ae"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x4eff5305325f5d6a1e8a0270a696ca9c5fa931ae"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[9], \"195\" )", async function( ) {
		const txOriginal = {blockNumber: "4176436", timeStamp: "1503123808", hash: "0x9ca14e5f32c5d7a9ea157996218fb426fd461e8d6bc9b653e65e3ef7ad4b9537", nonce: "13", blockHash: "0xe96704475ac81215195c432e552009c86cc153ff2a5e4c18e6586475ca581f58", transactionIndex: "47", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000007f5f1958ea0549ce127d9a740ed557c268848c3600000000000000000000000000000000000000000000000000000000000000c3", contractAddress: "", cumulativeGasUsed: "1676789", gasUsed: "53837", confirmations: "3524709"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "195"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[9], "195", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1503123808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x7f5f1958ea0549ce127d9a740ed557c268848c36"}, {name: "value", type: "uint256", value: "195"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x7f5f1958ea0549ce127d9a740ed557c268848c36"}, {name: "value", type: "uint256", value: "195"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[10], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176451", timeStamp: "1503124160", hash: "0x642e217f01779866c9954a6da25b30153235903359e7d9c5b3b1491af338bb15", nonce: "14", blockHash: "0xa22c66aaa60e6ff3aabb3f1ae596c7300b7376cc931edd9e99a22ca9e99fb05b", transactionIndex: "26", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000bec556ca07a44ffcdd19389151657cf66d62c2ea00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1032166", gasUsed: "53901", confirmations: "3524694"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[10], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1503124160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xbec556ca07a44ffcdd19389151657cf66d62c2ea"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xbec556ca07a44ffcdd19389151657cf66d62c2ea"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[11], \"150\" )", async function( ) {
		const txOriginal = {blockNumber: "4176470", timeStamp: "1503124650", hash: "0x6a117e9c70b4d89cd121199ca022310d50db6f8fb2a3411034a75b01b61c00aa", nonce: "15", blockHash: "0xabba686eb058e4e2e169a83b752378557504f0519d97d627f0a552635dee88ac", transactionIndex: "155", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000002373919b5fdeee27bfa3d54610d3f28e3c47194f0000000000000000000000000000000000000000000000000000000000000096", contractAddress: "", cumulativeGasUsed: "5323903", gasUsed: "53837", confirmations: "3524675"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "150"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[11], "150", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1503124650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x2373919b5fdeee27bfa3d54610d3f28e3c47194f"}, {name: "value", type: "uint256", value: "150"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x2373919b5fdeee27bfa3d54610d3f28e3c47194f"}, {name: "value", type: "uint256", value: "150"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[12], \"1184\" )", async function( ) {
		const txOriginal = {blockNumber: "4176494", timeStamp: "1503125260", hash: "0xfa5deaeae9c7950e5cbfb8a7517413c258c0faf6fd3dcfc83b953e6b2b93266f", nonce: "16", blockHash: "0x3c852688469c311db62bfe51ae803ccfebd38a6b814aa8063f5a432b1d6ab7ec", transactionIndex: "121", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000ce368ece096953f77a56d084fbb38564d932091d00000000000000000000000000000000000000000000000000000000000004a0", contractAddress: "", cumulativeGasUsed: "4521953", gasUsed: "53901", confirmations: "3524651"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "1184"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[12], "1184", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1503125260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xce368ece096953f77a56d084fbb38564d932091d"}, {name: "value", type: "uint256", value: "1184"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xce368ece096953f77a56d084fbb38564d932091d"}, {name: "value", type: "uint256", value: "1184"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[13], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176530", timeStamp: "1503126035", hash: "0xbf121e493bc8f0b67eb5c3356baad0c2172483a3c1c3074108ffd0e813472dd2", nonce: "17", blockHash: "0x53ad90ad3373ff449f6959067716cc118b8cc429fbcb47712ad7b02b5deae639", transactionIndex: "58", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000ef05de91263de87788119daabe25ed6ca32110eb00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1534325", gasUsed: "53901", confirmations: "3524615"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[13], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1503126035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xef05de91263de87788119daabe25ed6ca32110eb"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xef05de91263de87788119daabe25ed6ca32110eb"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[14], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176541", timeStamp: "1503126272", hash: "0xe07d78d1f2766d0aac293c46ae013bddbf4e509d188134902d988d531a84691a", nonce: "18", blockHash: "0x170cbba7e086ad583d800ee6feea7604b571c68f12550816af7d24a62d5d15ce", transactionIndex: "50", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000ec862efed6bd4cdc1f333645d95b24ba0406568600000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1447379", gasUsed: "53901", confirmations: "3524604"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[14], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1503126272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xec862efed6bd4cdc1f333645d95b24ba04065686"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xec862efed6bd4cdc1f333645d95b24ba04065686"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[15], \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "4176557", timeStamp: "1503126491", hash: "0xf1a82fa517e060e2e51087dd7c0728b23d430576692ef6c81e59d6f3bbf4298a", nonce: "19", blockHash: "0xb9b36ca04df46e7b603acf833a2b80284d44de112a60b1977398341f797ba720", transactionIndex: "51", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000bb49d91c65d3f58f9e114780644db62e3c42afe5000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "1698619", gasUsed: "53901", confirmations: "3524588"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "300"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[15], "300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1503126491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xbb49d91c65d3f58f9e114780644db62e3c42afe5"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xbb49d91c65d3f58f9e114780644db62e3c42afe5"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[15], \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "4176571", timeStamp: "1503126763", hash: "0x2cd1c6413175f3e88d68ec5ce45b2c684a57277517705e19e1209ae4b7134f75", nonce: "20", blockHash: "0x33568a7f96ae5b2774a0f09ded494a1228313bcc3a92ca7c1915c5056515d33b", transactionIndex: "17", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "46681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000bb49d91c65d3f58f9e114780644db62e3c42afe5000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "903324", gasUsed: "38901", confirmations: "3524574"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "300"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[15], "300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1503126763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xbb49d91c65d3f58f9e114780644db62e3c42afe5"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xbb49d91c65d3f58f9e114780644db62e3c42afe5"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[16], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176580", timeStamp: "1503126931", hash: "0xab237addbf343a0428da9174ab3dd455ce37a145dfcdf72af118a214fff9982f", nonce: "21", blockHash: "0xfc1fc1bb9bc8cfa18a1affa7e87e0659b2e7ababcaeb9fd77d07d4ce170e4b87", transactionIndex: "66", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000008f27bd58160ef4fcfdd1cad57d6328e96dbc96fa00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "4408987", gasUsed: "53901", confirmations: "3524565"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[16], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1503126931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x8f27bd58160ef4fcfdd1cad57d6328e96dbc96fa"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x8f27bd58160ef4fcfdd1cad57d6328e96dbc96fa"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[17], \"2100\" )", async function( ) {
		const txOriginal = {blockNumber: "4176583", timeStamp: "1503127026", hash: "0x1c22fb42f187a0ec191610bf95d2abc2753fcbedd48ee2421e884dd23512a030", nonce: "22", blockHash: "0x9de2f70e4cc96cb9928e6ea66c7cce030dbfc50ecf2ee6f72460e053c3660cc2", transactionIndex: "98", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000008d0e16e77d357728d650481a01680fae49f9ccf30000000000000000000000000000000000000000000000000000000000000834", contractAddress: "", cumulativeGasUsed: "4227078", gasUsed: "53901", confirmations: "3524562"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "2100"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[17], "2100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1503127026 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x8d0e16e77d357728d650481a01680fae49f9ccf3"}, {name: "value", type: "uint256", value: "2100"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x8d0e16e77d357728d650481a01680fae49f9ccf3"}, {name: "value", type: "uint256", value: "2100"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[18], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176587", timeStamp: "1503127147", hash: "0xe39e4a63458b5421c71a56f352ae5ec750c14cbf5d2272d7768f2289735df24d", nonce: "23", blockHash: "0x44f4b285841e94ebc0914bbc0613198afa3cadcf96178c281b5d5b9fe324dfee", transactionIndex: "64", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000008a836f727ae7396d681c04bd2edd5e046a86cfc200000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "2796419", gasUsed: "53901", confirmations: "3524558"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[18], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1503127147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x8a836f727ae7396d681c04bd2edd5e046a86cfc2"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x8a836f727ae7396d681c04bd2edd5e046a86cfc2"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[19], \"12000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176590", timeStamp: "1503127215", hash: "0x9fa05c637bfaecb348e2e6ee01b9c4b11937611d051372c08954ab8bcdf68720", nonce: "24", blockHash: "0x2bfa6d33fdff1968568854db51dbf17bdd8c9ac82a0ba804941422cde1919657", transactionIndex: "18", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000225b4bc64e051827c069312f82fa590ec96322090000000000000000000000000000000000000000000000000000000000002ee0", contractAddress: "", cumulativeGasUsed: "529372", gasUsed: "53901", confirmations: "3524555"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "12000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[19], "12000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1503127215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x225b4bc64e051827c069312f82fa590ec9632209"}, {name: "value", type: "uint256", value: "12000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x225b4bc64e051827c069312f82fa590ec9632209"}, {name: "value", type: "uint256", value: "12000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[20], \"216\" )", async function( ) {
		const txOriginal = {blockNumber: "4176594", timeStamp: "1503127263", hash: "0x8abc3194fe441e18c35aa6d529d35f5c6f1db5fc8457472ab24f56e157673417", nonce: "25", blockHash: "0x3df57c55024c76f19bb1f51d83564065388130b4e2af72616cac37b12005a309", transactionIndex: "50", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000055f32c50cc315f14a8d225baf7e5eec10877818500000000000000000000000000000000000000000000000000000000000000d8", contractAddress: "", cumulativeGasUsed: "1752180", gasUsed: "53837", confirmations: "3524551"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "216"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[20], "216", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1503127263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x55f32c50cc315f14a8d225baf7e5eec108778185"}, {name: "value", type: "uint256", value: "216"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x55f32c50cc315f14a8d225baf7e5eec108778185"}, {name: "value", type: "uint256", value: "216"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[21], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176595", timeStamp: "1503127291", hash: "0xe242304ed863327ec34666fd51ec2e056c7f783fe4af1660353af79588546d2b", nonce: "26", blockHash: "0x1327eef1219e9d0deba97f48e038792bc632966640976abdd2716d81673567ce", transactionIndex: "33", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000035b91c95258c6fd55404ac1cd55dc8614cfed3300000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1136992", gasUsed: "53901", confirmations: "3524550"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[21], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1503127291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x035b91c95258c6fd55404ac1cd55dc8614cfed33"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x035b91c95258c6fd55404ac1cd55dc8614cfed33"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[22], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176600", timeStamp: "1503127329", hash: "0x7725ae5102b418aa2b77c68a7637c420e877722d940e7b849292717231ab5ad2", nonce: "27", blockHash: "0x5a42ae8beb183f7229bdd9a897dd78972a65b8c57ba76174368ede8f56689fb3", transactionIndex: "11", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000000f3fbe0b6ad590b3d761f53581c57766200f8eed00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "783220", gasUsed: "53901", confirmations: "3524545"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[22], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1503127329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x0f3fbe0b6ad590b3d761f53581c57766200f8eed"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x0f3fbe0b6ad590b3d761f53581c57766200f8eed"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[11], \"4350\" )", async function( ) {
		const txOriginal = {blockNumber: "4176608", timeStamp: "1503127400", hash: "0x32760cfec6646b08ac2bb8aad7a6d7b402112c9734af2951be3885dcbd80e9d0", nonce: "28", blockHash: "0x5d7cba94490146173a3cb481658aaa49dded3314a6bf088cbdbabb676623373a", transactionIndex: "22", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "46681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000002373919b5fdeee27bfa3d54610d3f28e3c47194f00000000000000000000000000000000000000000000000000000000000010fe", contractAddress: "", cumulativeGasUsed: "628317", gasUsed: "38901", confirmations: "3524537"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "4350"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[11], "4350", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1503127400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x2373919b5fdeee27bfa3d54610d3f28e3c47194f"}, {name: "value", type: "uint256", value: "4350"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x2373919b5fdeee27bfa3d54610d3f28e3c47194f"}, {name: "value", type: "uint256", value: "4350"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[23], \"750\" )", async function( ) {
		const txOriginal = {blockNumber: "4176612", timeStamp: "1503127436", hash: "0xf83358a74c29ce93439da1dcbbe92b8773dd8debe1d513c039ea29de79bb72aa", nonce: "29", blockHash: "0x6d13f7471eee92854671ec21babc34478ef66a4beec2a0fb8a26786d14ba10c4", transactionIndex: "40", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000008b89f0de3d3f07f9afc9d27f773a24db91ab319100000000000000000000000000000000000000000000000000000000000002ee", contractAddress: "", cumulativeGasUsed: "1694416", gasUsed: "53901", confirmations: "3524533"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "750"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[23], "750", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1503127436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x8b89f0de3d3f07f9afc9d27f773a24db91ab3191"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x8b89f0de3d3f07f9afc9d27f773a24db91ab3191"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[24], \"750\" )", async function( ) {
		const txOriginal = {blockNumber: "4176613", timeStamp: "1503127480", hash: "0x8dbd8ecd2404800ab85eab0edc6ca4642eaa82e94a87754390428c6b268e87cc", nonce: "30", blockHash: "0x298c93bb837485eacbdfe25eb9a557d366b1e18dcfdcfd9befa87a94664b3b50", transactionIndex: "144", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000ded0a02807b8241703e2509a1eaa2cc160ba53f100000000000000000000000000000000000000000000000000000000000002ee", contractAddress: "", cumulativeGasUsed: "5165718", gasUsed: "53901", confirmations: "3524532"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "750"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[24], "750", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1503127480 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xded0a02807b8241703e2509a1eaa2cc160ba53f1"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xded0a02807b8241703e2509a1eaa2cc160ba53f1"}, {name: "value", type: "uint256", value: "750"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[25], \"19500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176615", timeStamp: "1503127559", hash: "0x105b04cdeac991e1865e4ef1768f5adee792932ae33bc7368f9831da0625b7f9", nonce: "31", blockHash: "0x9ea2d074a60d4cb8e066767d30e435761ea09d0a05d82540f0a8982c5565f783", transactionIndex: "126", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000adcf8f36f433de99231cbd4008692a96d52ed2ef0000000000000000000000000000000000000000000000000000000000004c2c", contractAddress: "", cumulativeGasUsed: "5106556", gasUsed: "53901", confirmations: "3524530"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "19500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[25], "19500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1503127559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xadcf8f36f433de99231cbd4008692a96d52ed2ef"}, {name: "value", type: "uint256", value: "19500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xadcf8f36f433de99231cbd4008692a96d52ed2ef"}, {name: "value", type: "uint256", value: "19500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[26], \"2250\" )", async function( ) {
		const txOriginal = {blockNumber: "4176619", timeStamp: "1503127620", hash: "0x4f6d5de8484af1e75d9de45953ba3c44d3171a721a32ad2d61d32f39909a50d2", nonce: "32", blockHash: "0xdee0c6b726d8f741bf126f0363c79acebdcbf37c3141522e4b37025978d154a1", transactionIndex: "66", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000787d6b93e32dea45b195ece5b613af966e1b15c900000000000000000000000000000000000000000000000000000000000008ca", contractAddress: "", cumulativeGasUsed: "2779098", gasUsed: "53901", confirmations: "3524526"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "2250"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[26], "2250", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1503127620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x787d6b93e32dea45b195ece5b613af966e1b15c9"}, {name: "value", type: "uint256", value: "2250"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x787d6b93e32dea45b195ece5b613af966e1b15c9"}, {name: "value", type: "uint256", value: "2250"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[27], \"15000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176624", timeStamp: "1503127709", hash: "0xca5d25e1c3d20309a8e5ff513eb8748c883d415e4076876fb7221e80e0931f6a", nonce: "33", blockHash: "0xf104c6c8c5bd853783780dd2bf280ed5a38498b0fe06005f97249a6699bd05db", transactionIndex: "32", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000082d99d98115565d2a58e99fc53704cee56e3c0de0000000000000000000000000000000000000000000000000000000000003a98", contractAddress: "", cumulativeGasUsed: "1174186", gasUsed: "53901", confirmations: "3524521"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "15000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[27], "15000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1503127709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x82d99d98115565d2a58e99fc53704cee56e3c0de"}, {name: "value", type: "uint256", value: "15000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x82d99d98115565d2a58e99fc53704cee56e3c0de"}, {name: "value", type: "uint256", value: "15000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[28], \"6000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176629", timeStamp: "1503127774", hash: "0xe4d5f73839d1cab3006c9e3b8d62156388d5114e0dec9e56ed7f1201006d6e87", nonce: "34", blockHash: "0x76d232e7383bd4a85c0a8d29fb4ac3377cddd80f8dedca9aa03c76146e9a7c8c", transactionIndex: "28", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000059f114b8f7ac2db0c6fb6c05a8d84b10e8d881d30000000000000000000000000000000000000000000000000000000000001770", contractAddress: "", cumulativeGasUsed: "1596805", gasUsed: "53901", confirmations: "3524516"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "6000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[28], "6000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1503127774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x59f114b8f7ac2db0c6fb6c05a8d84b10e8d881d3"}, {name: "value", type: "uint256", value: "6000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x59f114b8f7ac2db0c6fb6c05a8d84b10e8d881d3"}, {name: "value", type: "uint256", value: "6000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[28], \"6000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176643", timeStamp: "1503128041", hash: "0x8b6486668a72ddf041b7a6457e382f326fe7384c13d44c0ebb93a260a84c5ae8", nonce: "35", blockHash: "0xb0cf42479c62b84e7b1fdaf8d6765d096fc83b7d69a7b520fb4edf79b7658495", transactionIndex: "36", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "46681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000059f114b8f7ac2db0c6fb6c05a8d84b10e8d881d30000000000000000000000000000000000000000000000000000000000001770", contractAddress: "", cumulativeGasUsed: "1044312", gasUsed: "38901", confirmations: "3524502"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "6000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[28], "6000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1503128041 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x59f114b8f7ac2db0c6fb6c05a8d84b10e8d881d3"}, {name: "value", type: "uint256", value: "6000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x59f114b8f7ac2db0c6fb6c05a8d84b10e8d881d3"}, {name: "value", type: "uint256", value: "6000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[29], \"2100\" )", async function( ) {
		const txOriginal = {blockNumber: "4176644", timeStamp: "1503128096", hash: "0x9bcb67ef40a340d517ee06b8fedeb515a02824e8cb55f865d714a91768a08915", nonce: "36", blockHash: "0x3acfc6f7304ced9c57c2b3ae367482a30fc06f7c2ec5c7341f8b4936c5640183", transactionIndex: "57", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000614a7b62d883555d6dace13abbebc0c2f83551720000000000000000000000000000000000000000000000000000000000000834", contractAddress: "", cumulativeGasUsed: "2256718", gasUsed: "53901", confirmations: "3524501"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "2100"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[29], "2100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1503128096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x614a7b62d883555d6dace13abbebc0c2f8355172"}, {name: "value", type: "uint256", value: "2100"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x614a7b62d883555d6dace13abbebc0c2f8355172"}, {name: "value", type: "uint256", value: "2100"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[30], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176645", timeStamp: "1503128130", hash: "0xa2606edd1487db6a7f3e7f907a10d3ccae8b668420915e8f419a32e1a0adfb73", nonce: "37", blockHash: "0xd68d4d1015b5d774a7a774de9d407a56c4ab7f884d133800e9a5e7b142cc5295", transactionIndex: "62", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000d24400ae8bfebb18ca49be86258a3c749cf4685300000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1649551", gasUsed: "53837", confirmations: "3524500"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[30], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1503128130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xd24400ae8bfebb18ca49be86258a3c749cf46853"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xd24400ae8bfebb18ca49be86258a3c749cf46853"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[31], \"1125\" )", async function( ) {
		const txOriginal = {blockNumber: "4176648", timeStamp: "1503128187", hash: "0xdbcbaa1c95737157f4f0fc8096878255f408013e9ce1ea37e34d0f30c37ce2c7", nonce: "38", blockHash: "0x7c6bb78a03b2af88c34e975625b6d8fe3256e2e125d1cf1b78c7f2700c0cc880", transactionIndex: "25", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000240500a1a6262db06fa375155038a812c83aa9820000000000000000000000000000000000000000000000000000000000000465", contractAddress: "", cumulativeGasUsed: "1226014", gasUsed: "53837", confirmations: "3524497"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "1125"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[31], "1125", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1503128187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x240500a1a6262db06fa375155038a812c83aa982"}, {name: "value", type: "uint256", value: "1125"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x240500a1a6262db06fa375155038a812c83aa982"}, {name: "value", type: "uint256", value: "1125"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[32], \"714\" )", async function( ) {
		const txOriginal = {blockNumber: "4176650", timeStamp: "1503128240", hash: "0x3c426d414f8c641645087464ab7245b29049829ae1e6325f86a77019b6deaa1d", nonce: "39", blockHash: "0x95eceff6b0bf1a0491851844a1eb7c4da4bb2b596d3cc59e25c803448e1f9e7d", transactionIndex: "69", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000046da1f8a4baea8ca89cd69bd9721182c494cd00800000000000000000000000000000000000000000000000000000000000002ca", contractAddress: "", cumulativeGasUsed: "2070848", gasUsed: "53901", confirmations: "3524495"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "714"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[32], "714", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1503128240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x46da1f8a4baea8ca89cd69bd9721182c494cd008"}, {name: "value", type: "uint256", value: "714"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x46da1f8a4baea8ca89cd69bd9721182c494cd008"}, {name: "value", type: "uint256", value: "714"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[33], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176651", timeStamp: "1503128287", hash: "0x242f29fa0445800fd92cc8698f69203ee62c5c54a82df9271f41ed3a42a618c6", nonce: "40", blockHash: "0xb8e49208b3137d684b3d893f51967f7104de1a4e67e9a347a6e9e35ad208eb5b", transactionIndex: "52", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000b8389dbc13d232e42071439aec7d7d04ae55e4be00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1348394", gasUsed: "53901", confirmations: "3524494"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[33], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1503128287 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xb8389dbc13d232e42071439aec7d7d04ae55e4be"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xb8389dbc13d232e42071439aec7d7d04ae55e4be"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[34], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176656", timeStamp: "1503128352", hash: "0xcbd406835f14ecb79383af0b0a03102ef4c4ed62e4ebb4462c30eebead2fd4ab", nonce: "41", blockHash: "0x33d4b54e45fcf00defd6adb3b7508936f577981a9638e49ae68348a5df0bed6e", transactionIndex: "47", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000af8343e44000ccf0d7c4a7cce560114a3f71aed200000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1638215", gasUsed: "53837", confirmations: "3524489"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[34], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1503128352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xaf8343e44000ccf0d7c4a7cce560114a3f71aed2"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xaf8343e44000ccf0d7c4a7cce560114a3f71aed2"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[35], \"7506\" )", async function( ) {
		const txOriginal = {blockNumber: "4176662", timeStamp: "1503128444", hash: "0x0d59aa3e57a63bc99135a389d1c080f13fa5225fecf60d4a5aa3fbe8b01f0272", nonce: "42", blockHash: "0x0f62ba42d40acdfb7a409eed78169aec803fb73ae0cee09c12dacad8cf07cc5c", transactionIndex: "30", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000a995c454d51dbe2d3167a070df96de459d94dc640000000000000000000000000000000000000000000000000000000000001d52", contractAddress: "", cumulativeGasUsed: "793655", gasUsed: "53901", confirmations: "3524483"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "7506"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[35], "7506", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1503128444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xa995c454d51dbe2d3167a070df96de459d94dc64"}, {name: "value", type: "uint256", value: "7506"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xa995c454d51dbe2d3167a070df96de459d94dc64"}, {name: "value", type: "uint256", value: "7506"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[36], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176665", timeStamp: "1503128477", hash: "0x1f451300f14ca55dd9da3542216909fe32cddd4352fcd228309f8c7c43fda442", nonce: "43", blockHash: "0xd240b3b893893ccfdd0db16ef463dae05a84f11bea56de573f817e390058a4e5", transactionIndex: "28", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000019cd0e4347f84c7fe1076d2e75e71abd9dd20fca00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "1125460", gasUsed: "53901", confirmations: "3524480"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[36], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1503128477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x19cd0e4347f84c7fe1076d2e75e71abd9dd20fca"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x19cd0e4347f84c7fe1076d2e75e71abd9dd20fca"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[37], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176666", timeStamp: "1503128553", hash: "0x659289d7eddad77909cf52ee7c71f17e2118bdcf2582051484c841ce93857f4f", nonce: "44", blockHash: "0x2121e5a292ef8bacc44bd6d72e3d4e7858396b5da4d525dda649be49385bb4dd", transactionIndex: "116", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000058c61a555e147214231d6910ad5f04cce84b209500000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "2885060", gasUsed: "53901", confirmations: "3524479"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[37], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1503128553 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x58c61a555e147214231d6910ad5f04cce84b2095"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x58c61a555e147214231d6910ad5f04cce84b2095"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[38], \"4500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176670", timeStamp: "1503128624", hash: "0xc1c6c6beb86db0c46cee7a11fd96751a615a1b784bfc75213fb6034685c5a1bf", nonce: "45", blockHash: "0x113f892715bcf111657c035c8ff47578920a387c6c724302f558cf157daa99db", transactionIndex: "29", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000e9f8b46a71b6b324633566a9cb15dbf4a8afc3850000000000000000000000000000000000000000000000000000000000001194", contractAddress: "", cumulativeGasUsed: "1237093", gasUsed: "53901", confirmations: "3524475"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "4500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[38], "4500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1503128624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xe9f8b46a71b6b324633566a9cb15dbf4a8afc385"}, {name: "value", type: "uint256", value: "4500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xe9f8b46a71b6b324633566a9cb15dbf4a8afc385"}, {name: "value", type: "uint256", value: "4500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[39], \"480\" )", async function( ) {
		const txOriginal = {blockNumber: "4176965", timeStamp: "1503134849", hash: "0x463c62292cbcc7425c05839a607e8234e4c330ba0da93500608e71ba8721b587", nonce: "46", blockHash: "0x956b09ce8ff4ce0eb95a8c6cb76bdd7d2aaadf060479f29b517fdcdac40ff088", transactionIndex: "6", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000001151314c646ce4e0efd76d1af4760ae66a9fe30f00000000000000000000000000000000000000000000000000000000000001e0", contractAddress: "", cumulativeGasUsed: "211919", gasUsed: "53901", confirmations: "3524180"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "480"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[39], "480", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1503134849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x1151314c646ce4e0efd76d1af4760ae66a9fe30f"}, {name: "value", type: "uint256", value: "480"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x1151314c646ce4e0efd76d1af4760ae66a9fe30f"}, {name: "value", type: "uint256", value: "480"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[40], \"1485\" )", async function( ) {
		const txOriginal = {blockNumber: "4176970", timeStamp: "1503134915", hash: "0x58ea849cdc690cd7bedeafe2c25f595dfd87efea85323216f8d53a9e93ba7cdd", nonce: "47", blockHash: "0x63f0f84cc86b94a55768e842bf371a7378162d371881727f76b7e97941375fd1", transactionIndex: "33", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000003d2daad115dd00669fb880fdd2c3e97bbf1f2b6600000000000000000000000000000000000000000000000000000000000005cd", contractAddress: "", cumulativeGasUsed: "1470879", gasUsed: "53837", confirmations: "3524175"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "1485"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[40], "1485", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1503134915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x3d2daad115dd00669fb880fdd2c3e97bbf1f2b66"}, {name: "value", type: "uint256", value: "1485"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x3d2daad115dd00669fb880fdd2c3e97bbf1f2b66"}, {name: "value", type: "uint256", value: "1485"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[41], \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "4176971", timeStamp: "1503134986", hash: "0x7bf8cedd0ea23e19634600a5c5c4d58f799f4e61b138ff368ae0ff84a760c79b", nonce: "48", blockHash: "0x9df8a015d3ff5d1b5d069a25e0f44b5b5382e920aa0ff7d3e8305c1450dcc221", transactionIndex: "60", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000003d6f29c67f571cad827bb512c7949b0a1c0b9899000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "2938666", gasUsed: "53901", confirmations: "3524174"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "300"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[41], "300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1503134986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x3d6f29c67f571cad827bb512c7949b0a1c0b9899"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x3d6f29c67f571cad827bb512c7949b0a1c0b9899"}, {name: "value", type: "uint256", value: "300"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[42], \"3000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176971", timeStamp: "1503134986", hash: "0x9e77278be8ebd48eb7894c8e0753cf5fc56870114c5df4dd759f9aa3020929ac", nonce: "49", blockHash: "0x9df8a015d3ff5d1b5d069a25e0f44b5b5382e920aa0ff7d3e8305c1450dcc221", transactionIndex: "61", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000e07412d5af80291a022e768e85c64b3743fd37460000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "2992567", gasUsed: "53901", confirmations: "3524174"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "3000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[42], "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1503134986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xe07412d5af80291a022e768e85c64b3743fd3746"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xe07412d5af80291a022e768e85c64b3743fd3746"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[43], \"3000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176979", timeStamp: "1503135117", hash: "0x0ee9f21deb18a9818500390bfba3fb4e01ffb4ae0395d05c5c0193a8d8cfb5ad", nonce: "50", blockHash: "0x897924d3a3c61f801b7e47d7b3daa17c242cd6b63d0a7cb3b00f3cf732e4121f", transactionIndex: "20", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000028d07ce0a312aa4ab889d44800dd6dfa37b643220000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "645381", gasUsed: "53837", confirmations: "3524166"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "3000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[43], "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1503135117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x28d07ce0a312aa4ab889d44800dd6dfa37b64322"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x28d07ce0a312aa4ab889d44800dd6dfa37b64322"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[44], \"585\" )", async function( ) {
		const txOriginal = {blockNumber: "4176982", timeStamp: "1503135215", hash: "0x109f63154147a8d29e3a69d09fd95f2e86bb6ef16ee4eb5785f9ea5f842522e6", nonce: "51", blockHash: "0x2690e413d149184d28f174765e25a3f00ba52c7314de02629cc589445521b7b2", transactionIndex: "18", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000525ec281a57bc34ec6c63c9d007fa3940b1832490000000000000000000000000000000000000000000000000000000000000249", contractAddress: "", cumulativeGasUsed: "538473", gasUsed: "53837", confirmations: "3524163"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "585"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[44], "585", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1503135215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x525ec281a57bc34ec6c63c9d007fa3940b183249"}, {name: "value", type: "uint256", value: "585"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x525ec281a57bc34ec6c63c9d007fa3940b183249"}, {name: "value", type: "uint256", value: "585"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[45], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4176992", timeStamp: "1503135486", hash: "0x5b531707460b446cd1ead7841bb8a65a35020d80abf26daa97222aadaaac8276", nonce: "52", blockHash: "0xee643c8feee04c7b62c9da9717ffeb5b39b41f5cf30e5f4380de003ad85641a3", transactionIndex: "28", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea82100000000000000000000000028ce29bfb9fbebb4ff83f42866e59814bf3d53bf00000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "766165", gasUsed: "53901", confirmations: "3524153"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "1500"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[45], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1503135486 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x28ce29bfb9fbebb4ff83f42866e59814bf3d53bf"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x28ce29bfb9fbebb4ff83f42866e59814bf3d53bf"}, {name: "value", type: "uint256", value: "1500"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[46], \"3000\" )", async function( ) {
		const txOriginal = {blockNumber: "4176999", timeStamp: "1503135614", hash: "0xf775000ac66cdae5d34d057f6ed12a35e6344373b92dc41bcab50b7f50280001", nonce: "53", blockHash: "0x76d8d07786f12924c5ba72907df7a07c654d1312a51bbf32051359200c7831ba", transactionIndex: "65", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64681", gasPrice: "22127224645", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000354decb3aed53f92c24c0c458efe14c7af6a88cc0000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "3173639", gasUsed: "53901", confirmations: "3524146"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "3000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[46], "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1503135614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x354decb3aed53f92c24c0c458efe14c7af6a88cc"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x354decb3aed53f92c24c0c458efe14c7af6a88cc"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[47], \"163\" )", async function( ) {
		const txOriginal = {blockNumber: "4177000", timeStamp: "1503135658", hash: "0xec5537f566b2d6d7289a88d88965433feb51ed7e87da41b094efeea685bf8a42", nonce: "54", blockHash: "0x5090fd27cf7a35fa401653ab99975178dda810e1969395debf8cdc33e4b2bee4", transactionIndex: "78", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "22000001337", isError: "0", txreceipt_status: "", input: "0x66bea821000000000000000000000000ea0f9e1ad062daafb0653f760432efceb914ca2e00000000000000000000000000000000000000000000000000000000000000a3", contractAddress: "", cumulativeGasUsed: "2828201", gasUsed: "53837", confirmations: "3524145"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[47]}, {type: "uint256", name: "_value", value: "163"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[47], "163", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1503135658 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0xea0f9e1ad062daafb0653f760432efceb914ca2e"}, {name: "value", type: "uint256", value: "163"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0xea0f9e1ad062daafb0653f760432efceb914ca2e"}, {name: "value", type: "uint256", value: "163"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendSupplyTokens( addressList[48], \"3000\" )", async function( ) {
		const txOriginal = {blockNumber: "4177001", timeStamp: "1503135695", hash: "0x2a0315f0dc54c25461772aec847e5f72984910af2ddb867ff6d58e8ecd37524e", nonce: "55", blockHash: "0x3cf402907b42f9d0e70891bd43b8e59b3ca3988aa2112612d002ee7815156e09", transactionIndex: "20", from: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb", to: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320", value: "0", gas: "64604", gasPrice: "22000001337", isError: "0", txreceipt_status: "", input: "0x66bea8210000000000000000000000000070b6b071f209fa963bb543cd689dd30ba8f4960000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "940546", gasUsed: "53837", confirmations: "3524144"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "3000"}], name: "sendSupplyTokens", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sendSupplyTokens(address,uint256)" ]( addressList[48], "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1503135695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TokensSent", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensSent", events: [{name: "to", type: "address", value: "0x0070b6b071f209fa963bb543cd689dd30ba8f496"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x00fee5170c113e84ac05742d4aff6408d1cf46bb"}, {name: "to", type: "address", value: "0x0070b6b071f209fa963bb543cd689dd30ba8f496"}, {name: "value", type: "uint256", value: "3000"}], address: "0x70c4eea814bee9b74cafeca0200991bb0d8a4320"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "93437581924931377" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
