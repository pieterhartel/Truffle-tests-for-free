const YoLoChips = artifacts.require( "./YoLoChips.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "YoLoChips" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x1B6089EFB8932f5FD47D98c8a5eabd77ED7e8107", "0xeA4CBB776f5970E1f5A0ED04b5790c269Bb8cD18", "0xd5d2f23ecEe29Bcf80D1935Fe3270Eea63A2e124", "0xEff5D0b009E6a89bE3D263C228aD0aE3929B63EE", "0x526a05f8A3EA5Be7187d50DcE7147b0516D53f60", "0xC858C09B7BAE5De3A5CCFE501Da9DD1809331994", "0xd88b4571c084D548f6dEF1a4B88b633730b018EA", "0x7eE2EBE5c6510e3606c689a84DB62553D5c5345c", "0x78C410896E67d5C9BAe4dD6BA2F8860927a31059", "0x87044dbb77c2a08518aD7C74CA2f217aB36f1bF5", "0x3Ac568119D0aCc22470e6E446f5b25544274551C", "0xEB3326B097C403c7C668D9daE2BBBd89E915dE53", "0xadc76C22bdC95a4b27b44cc391198770Bcbc9ED6", "0x56f33C2fe432334B9078faE1Ba7790c54F413ae4", "0x49F1fC2d4E93F5223e870d122a23175407D63737", "0xCE816d9905eDeD7811C0847cD22ab7dEf2894e20", "0xC8b345B98641253E58B8b4d0222Ba397e2b37ABb", "0xEE6229C4e58e31cAB52625c398f9cD9Fe3a0ec74", "0x348e49F126e47DBBc09C627878E5DBF0400e311d", "0xd33794605098eed8E18320C8fd508c5A401817ef", "0x83677e51d1d5787a06BD6689f73ca0006fc39995", "0x8DfD13c1Fb9bC276B0084C43CC099C5141456cA1", "0xB238fCBc02F15045DBAcd85fAFFAda6654058C45", "0x78d8faAA50B38dcaA679D3A773EAcDB4D7D74EcA", "0x6b618Fd0E4B05FE2333220F00a022d11248FDDCa", "0x91ef4e3Ec6d7B0bFf50cc77Dd257937705DC5fc2", "0x16d135eEfa836f53e02EF12552081bc5C345DA4c", "0xFBA33c991D2F9799eCcF94a29CaB2bda7a7940ab", "0x71b2641Ca8B2A4AE9d8A6A51F4897F8234a7E721", "0x44D9eD29378fd7d5b72c494bd05FaD30dcB1B07b", "0x81eb5c24E3ec823d6B80F5D0E2f8dA75bF38A25b", "0x5E51cc1408FEDEbED38783fCc72bE488282E3C89", "0xa76e7F8fE481448F1a803212b0C8b6FD7EC90078", "0x3c34169efFe7d8e238BA68BbDB3244290F914676", "0xE3D6923B458Bd5c55FAd7Db6fCcC4728bcded99F", "0x98153b7F4E6Ee68683db3D147E95D954C7C7CA4D", "0xe5Ae74F48401f3F9043812C2a6fe2169E5F0C9b3", "0xAe84197BCc5DaE81298149f82afA22750A0eB23D", "0xe6a8589ddB49c2D263aA8437F96C4B37080BF433", "0xBa3e4217A4c289895ACBe26dc894cDe7ccC61D30", "0x435085eA1AD8CD1ebC67C99d5faD17F95Caf7482", "0x395f935f13ea0795c11136675469E420fb68904e", "0x7fC069C7aAAd4384b20AeEC9CFD4e314a5E4619B", "0xd3Ed6A0FD9800C2e636FF5b3d7F0914162bfaDAc", "0x9e17cc6ad7F32E88a8c863788Adf1BEB00301E58", "0xf1e5412126C18178d0C5B909CD40502d7F0652f1", "0xcB44e6ac67FCa11e46A0e4d0758455a06846Fb5b", "0xDD142453213080E90a2849353E72401e8A5313Cb", "0xE679A668C3b84464ADdDb9b73938baa6A2a3c5dE", "0x42faB16B923b45e115285F9b36fC291266129589", "0x0F86F8c48C346B9a5eb80558d990ED1A2F561D6c", "0xBBfc74F1F4Acf3b67675ccb6e48BcDCDd355D43B", "0xb35B5Ff75b0922Af427F17AaDDa5B870FeE66B57", "0x476c5D4B1B86F1a83E92FB671746701748F8D18A", "0x406c6cA639c42F038dDa19dF4897945006AB9aAB", "0xB4615ecBd3c00E78348d794525388a85EBAB89Ec", "0x7431E7F8C5997Ffba567D71C0C846D5D25E0fC2b", "0x600757b7D32cE5624B027Add897D2Da36De487ed", "0x84a60F09d0F7ED7073233a35bAc0F571D04878e8", "0x23ae111D790874bC2b55cBb1C4c27357Ee8b8715", "0xF94Ee00f5d2CafDf77d30C8220FA4397e62cb554", "0x932D4b56fab68CB9B6024a7A86a5313F0511E3D9", "0x9e046B941379F673878D7696577411ef030e5F4E", "0x3bCb98Aa6f0bCB4f2abCA22987e81E7A547b1f90", "0x79EB7cA0f1744071D4a94c70760E2058F1D30400", "0x546493137cFd7ce09b5b461A669B6DE3e66861C3", "0x63f60A4b7FCd4E8A979C449b71ceF2dB046E6521", "0x4aBa6Cb413035F22947c82F561fEF050eD9FeEE2", "0x44d23Ea744662DF447497bc8B1163f8244cd4763", "0x6D3b742E29551483fB3BdA7A8F07d77b924B3590", "0xE90ca49f51Af7cB8B82374453527A69cEEcF6aE7", "0xA2a9532d713aE6AD67AbE840f30555984C3F486B", "0xc1097E40DA134c8645272Ef778c569642e93969A", "0xaD12D207FADDA2b249819Eb87396227BA8A8CE7C", "0x7a58D5faBc1b5397E4956011218f0DE9d39385f6", "0x3953Bbd13a2863B377355b10e4A5889E84fB7C74", "0x4B8818dCCbC9a72c6F3B74549738fbc1F6d41eDb", "0xb8209EA712C83999C5AA949350205cCb17ea9988", "0x25ae4db38B78aBFc92387E4ec03afA386921CaAb", "0xeEbcfce40EC0624355D72a101a6EDA802C56946e", "0x0C509f4bb93B48a99358fc32beb9B2037156348a", "0xe03c23519e18D64F144d2800E30E81B0065C48B5", "0xDA4389B3387Bd0dAB738dAE68Fe106aC7Df5F167", "0x23d07e110BAEC060AFaf492a4e52924442B0ca59", "0x14B560E5eFfdF219d2F363593053F77A2C34fB0D", "0xE85FD3Eff890E0195998120465bdc5330Dc19c57", "0x8C0547B848E1f8031e2347065faA149f4A3fDF8B", "0x2724138648B134a8792b28bAa4444230De68CbbD", "0x0e8E5Ad47fE7d24024CA66677E67eb1446f222c0", "0x265a1a6605cfeaF8593460c5D77639b3e46354cb", "0x0537A2B93dCA3bD723965781df8e569dcBC58211", "0x246d2d8670cEC3d65eB3D7887E0585261D2bCa0f", "0xE4aDc923aE77Bb9fec022c3Ad52D52F81CC5ac21", "0xf0E63D4C5079629f59aEc6ba3466f52D88306d03", "0x389B675CDD46602197F71d0aC0b422E850f9cECD", "0xF06b144E392eDaEA080F2ebab3A1d3ECeaF4176f", "0x04D0dC750022Ac254645797e3A07394A32111393", "0xA7487fEFE0A907B660c195e2183c4736B548cB13", "0x8D531B74bD532B4FC31d338F395a898C38B8dB7b", "0x7C6C3FBe3248AB70c99C3Cb4D40F50eD081DE07d", "0xBbee1a9C10d64Fd67c35833daC4eAF307d44569D", "0x0bDd3f6eC2fD45f5647bcB92F546d8F1377eBf30", "0x09AC022B6FbCC56DCB946c703E39Db006fd0c419", "0xcAA593c06F29e2CD56373761B75Fe77E56c9E069", "0x69F5c172acA542a9483efF7EB854957Ba7137097", "0x21757F6D3AF44047Cb5775B21dB3cF90D19757D9", "0xEF763E4f0dEb2B5a114E0a31FD7eC63407d31766", "0x48A6578aD5162752fA29D38f3C8b0d857d20d568", "0x55bBb6878Ac4e7aA202716C45374D374d6011693", "0xd0DCfe5BD6eCccf14AdeC89111746F41CF806Ec1", "0x7f3233C101E8662C24989b4048022F5B2e7c7ea8", "0x36560F050cA156AB9c5c2BEE4cEB221fd6c5C44F", "0xe6B76ec36B5584a9DD9b86b7f80b268E8255d526", "0xa17b4B0658124BFbBd815A906776a508C658e6Cf"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MIN_CONTRIBUTION", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "distributionFinished", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenAddress", type: "address"}, {name: "who", type: "address"}], name: "getTokenBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensPerEth", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalDistributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Distr", type: "event"}, {anonymous: false, inputs: [], name: "DistrFinished", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tokensPerEth", type: "uint256"}], name: "TokensPerEthUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "burner", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Burn", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Approval(address,address,uint256)", "Distr(address,uint256)", "DistrFinished()", "Airdrop(address,uint256,uint256)", "TokensPerEthUpdated(uint256)", "Burn(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x8940c4b8e215f8822c5c8f0056c12652c746cbc57eedbd2a440b175971d47a77", "0x7f95d919e78bdebe8a285e6e33357c2fcb65ccf66e72d7573f9f8f6caad0c4cc", "0xada993ad066837289fe186cd37227aa338d27519a8a1547472ecb9831486d272", "0xf7729fa834bbef70b6d3257c2317a562aa88b56c81b544814f93dc5963a2c003", "0xcc16f5dbb4873280815c1ee09dbd06736cffcc184412cf7a71a0fdb75d397ca5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6591270 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6591975 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "YoLoChips", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MIN_CONTRIBUTION", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_CONTRIBUTION()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "distributionFinished", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "distributionFinished()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "tokenAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "who", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getTokenBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenBalance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensPerEth", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensPerEth()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalDistributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalDistributed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "YoLoChips", function( accounts ) {

	it( "TEST: YoLoChips(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6591270", timeStamp: "1540617123", hash: "0x8e08021600d08f2586bbc057f5aa07d228d8d4a5df74214209c05c0f5ba9b162", nonce: "111", blockHash: "0x20c68f79919dd159482a7f2e804b075174b14dc2277f65eaf645f6e2f124e45e", transactionIndex: "28", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: 0, value: "0", gas: "1232713", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e0d67ae", contractAddress: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", cumulativeGasUsed: "3380411", gasUsed: "1232713", confirmations: "1143773"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "YoLoChips", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = YoLoChips.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540617123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = YoLoChips.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18"}, {name: "_value", type: "uint256", value: "0"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Distr", type: "event"} ;
		console.error( "eventCallOriginal[0,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Distr", events: [{name: "to", type: "address", value: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18"}, {name: "amount", type: "uint256", value: "0"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[0,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[4], \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591704", timeStamp: "1540623507", hash: "0x541e1c22e5ca02f6f10560ea1836716026b66c8e806e79cabb4e5cece026cfa8", nonce: "112", blockHash: "0xaa3cbb1f35354b3d3922dcf6e67f0eee2385527e280552b65cbbb5c6760f0f97", transactionIndex: "72", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "69507", gasPrice: "3343750000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000d5d2f23ecee29bcf80d1935fe3270eea63a2e124000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "6807468", gasUsed: "69507", confirmations: "1143339"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[4]}, {type: "uint256", name: "_amount", value: "100000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[4], "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540623507 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd5d2f23ecee29bcf80d1935fe3270eea63a2e124"}, {name: "_value", type: "uint256", value: "100000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xd5d2f23ecee29bcf80d1935fe3270eea63a2e124"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_balance", type: "uint256", value: "100000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[5], \"75000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591709", timeStamp: "1540623559", hash: "0x632f9bfb02642726218fb11e97a81bc57b26d69ff070670dbd009cbf0538149b", nonce: "113", blockHash: "0x24052416aeeaed98055d236a6cbb193ae7e34910e2779171d037df9c8d581175", transactionIndex: "66", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54571", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000eff5d0b009e6a89be3d263c228ad0ae3929b63ee000000000000000000000000000000000000000000000000010a741a46278000", contractAddress: "", cumulativeGasUsed: "3054849", gasUsed: "54571", confirmations: "1143334"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[5]}, {type: "uint256", name: "_amount", value: "75000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[5], "75000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540623559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xeff5d0b009e6a89be3d263c228ad0ae3929b63ee"}, {name: "_value", type: "uint256", value: "75000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xeff5d0b009e6a89be3d263c228ad0ae3929b63ee"}, {name: "_amount", type: "uint256", value: "75000000000000000"}, {name: "_balance", type: "uint256", value: "75000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[6], \"60000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591711", timeStamp: "1540623582", hash: "0xde3dde6046f357bec8e0956dfe6dea902717e47efb001b77283af4f2a6fce657", nonce: "114", blockHash: "0xdf50f45bf84d1724021404a4aa19c17cda1b7c553ed8ecc45856c24fa5020b59", transactionIndex: "22", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000526a05f8a3ea5be7187d50dce7147b0516d53f6000000000000000000000000000000000000000000000000000d529ae9e860000", contractAddress: "", cumulativeGasUsed: "3498777", gasUsed: "54443", confirmations: "1143332"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[6]}, {type: "uint256", name: "_amount", value: "60000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[6], "60000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540623582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x526a05f8a3ea5be7187d50dce7147b0516d53f60"}, {name: "_value", type: "uint256", value: "60000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x526a05f8a3ea5be7187d50dce7147b0516d53f60"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_balance", type: "uint256", value: "60000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[7], \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591727", timeStamp: "1540623878", hash: "0x8ec90cbe5129a90d2f0829f2fdd2efdadae208f8138d142c99f6e2b93e9659d2", nonce: "115", blockHash: "0x21b4f16df87bc5e123d40b6090719de08df301b604886b13a98f00a525a597f3", transactionIndex: "128", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000c858c09b7bae5de3a5ccfe501da9dd180933199400000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "6958283", gasUsed: "54443", confirmations: "1143316"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[7]}, {type: "uint256", name: "_amount", value: "50000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[7], "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540623878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc858c09b7bae5de3a5ccfe501da9dd1809331994"}, {name: "_value", type: "uint256", value: "50000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xc858c09b7bae5de3a5ccfe501da9dd1809331994"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_balance", type: "uint256", value: "50000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[8], \"49200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591730", timeStamp: "1540623891", hash: "0x753d75579a918aad11e83def9a208802f1aaed9f5b78c94a625804c967cd7a39", nonce: "116", blockHash: "0xa76a6235016790742fe244dc86334ec17b76c3a3fd6add25765e6255c3024155", transactionIndex: "25", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000d88b4571c084d548f6def1a4b88b633730b018ea00000000000000000000000000000000000000000000000000aecb23aaf30000", contractAddress: "", cumulativeGasUsed: "5020241", gasUsed: "54443", confirmations: "1143313"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[8]}, {type: "uint256", name: "_amount", value: "49200000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[8], "49200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540623891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd88b4571c084d548f6def1a4b88b633730b018ea"}, {name: "_value", type: "uint256", value: "49200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xd88b4571c084d548f6def1a4b88b633730b018ea"}, {name: "_amount", type: "uint256", value: "49200000000000000"}, {name: "_balance", type: "uint256", value: "49200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[9], \"24210000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591735", timeStamp: "1540623968", hash: "0xbd55283d3c5ca5bc69f0f649878ff40f6577f90c4476d71d713bc28bf8c4a676", nonce: "117", blockHash: "0x67a365b271b2a2755f32d1e628fcbc17de688727b985b31dd1a41d04510ce32e", transactionIndex: "67", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000007ee2ebe5c6510e3606c689a84db62553d5c5345c000000000000000000000000000000000000000000000000005602dde2032000", contractAddress: "", cumulativeGasUsed: "2346673", gasUsed: "54507", confirmations: "1143308"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[9]}, {type: "uint256", name: "_amount", value: "24210000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[9], "24210000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540623968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7ee2ebe5c6510e3606c689a84db62553d5c5345c"}, {name: "_value", type: "uint256", value: "24210000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7ee2ebe5c6510e3606c689a84db62553d5c5345c"}, {name: "_amount", type: "uint256", value: "24210000000000000"}, {name: "_balance", type: "uint256", value: "24210000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[10], \"24000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591737", timeStamp: "1540623980", hash: "0x706996bb725c298ca97a0663c5de40918a303b460cbefefbcb2e80704c0e84e9", nonce: "118", blockHash: "0x9af34cff7609053125c8bf718aa3ab189a4e7e24789361fec7d2056486a420d5", transactionIndex: "24", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000078c410896e67d5c9bae4dd6ba2f8860927a31059000000000000000000000000000000000000000000000000005543df729c0000", contractAddress: "", cumulativeGasUsed: "1160810", gasUsed: "54443", confirmations: "1143306"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[10]}, {type: "uint256", name: "_amount", value: "24000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[10], "24000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540623980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x78c410896e67d5c9bae4dd6ba2f8860927a31059"}, {name: "_value", type: "uint256", value: "24000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x78c410896e67d5c9bae4dd6ba2f8860927a31059"}, {name: "_amount", type: "uint256", value: "24000000000000000"}, {name: "_balance", type: "uint256", value: "24000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[11], \"23089054700000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591750", timeStamp: "1540624229", hash: "0x34ffa68f3d3435f8ef43926cde1692ef69e12c765af1ebe5941ac64f6053b54c", nonce: "119", blockHash: "0x5515d07885f9cbb87fe7bef5ffe63be688de3caa716188571240ed5e725fcb90", transactionIndex: "58", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000087044dbb77c2a08518ad7c74ca2f217ab36f1bf50000000000000000000000000000000000000000000000000052075f7797d300", contractAddress: "", cumulativeGasUsed: "4964049", gasUsed: "54507", confirmations: "1143293"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[11]}, {type: "uint256", name: "_amount", value: "23089054700000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[11], "23089054700000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540624229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x87044dbb77c2a08518ad7c74ca2f217ab36f1bf5"}, {name: "_value", type: "uint256", value: "23089054700000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x87044dbb77c2a08518ad7c74ca2f217ab36f1bf5"}, {name: "_amount", type: "uint256", value: "23089054700000000"}, {name: "_balance", type: "uint256", value: "23089054700000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[12], \"21400000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591755", timeStamp: "1540624349", hash: "0x5f46b22ef8ddbbf5300cd720000c26f8b1e0c1313e8f26c8b8887f397762f71c", nonce: "120", blockHash: "0xecc0a284319b77e9e6d8c05fea6c44c6a846bacc1c2bcee65b7c98dd21bccb29", transactionIndex: "79", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000003ac568119d0acc22470e6e446f5b25544274551c000000000000000000000000000000000000000000000000004c072fc6318000", contractAddress: "", cumulativeGasUsed: "3691012", gasUsed: "54507", confirmations: "1143288"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[12]}, {type: "uint256", name: "_amount", value: "21400000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[12], "21400000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540624349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3ac568119d0acc22470e6e446f5b25544274551c"}, {name: "_value", type: "uint256", value: "21400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x3ac568119d0acc22470e6e446f5b25544274551c"}, {name: "_amount", type: "uint256", value: "21400000000000000"}, {name: "_balance", type: "uint256", value: "21400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[13], \"20000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591758", timeStamp: "1540624383", hash: "0xe7e655ecb769cb3da609f6ec1e5df605255dcc2208d77d3fab008232feeb105e", nonce: "121", blockHash: "0xb6fe3663179acd51768aede9a85f96d7ac95a3f859183825f51885546e4cb6db", transactionIndex: "88", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000eb3326b097c403c7c668d9dae2bbbd89e915de5300000000000000000000000000000000000000000000000000470de4df820000", contractAddress: "", cumulativeGasUsed: "3913016", gasUsed: "54443", confirmations: "1143285"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[13]}, {type: "uint256", name: "_amount", value: "20000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[13], "20000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540624383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xeb3326b097c403c7c668d9dae2bbbd89e915de53"}, {name: "_value", type: "uint256", value: "20000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xeb3326b097c403c7c668d9dae2bbbd89e915de53"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_balance", type: "uint256", value: "20000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[14], \"13300000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591761", timeStamp: "1540624413", hash: "0xdb49837c63cbee203a6e1bddeec2782ebdb292fd150b24d02f92b160f13b0adc", nonce: "122", blockHash: "0x7aaaa7d53e46b2171e23bffd9fe2d0a530674d0eea2daea119419c316929c0d8", transactionIndex: "138", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000adc76c22bdc95a4b27b44cc391198770bcbc9ed6000000000000000000000000000000000000000000000000002f40478f834000", contractAddress: "", cumulativeGasUsed: "5315332", gasUsed: "54507", confirmations: "1143282"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[14]}, {type: "uint256", name: "_amount", value: "13300000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[14], "13300000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540624413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xadc76c22bdc95a4b27b44cc391198770bcbc9ed6"}, {name: "_value", type: "uint256", value: "13300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xadc76c22bdc95a4b27b44cc391198770bcbc9ed6"}, {name: "_amount", type: "uint256", value: "13300000000000000"}, {name: "_balance", type: "uint256", value: "13300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[15],addressList[16],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591777", timeStamp: "1540624604", hash: "0x9019492453c2098f531b5943f533b94784ce22d107494fd80e4aa1aa0b148893", nonce: "123", blockHash: "0x0254a1de7444af4d06106966be75cf38fea44a30c183262d2ce624afaa72036a", transactionIndex: "89", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "215377", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd70000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000056f33c2fe432334b9078fae1ba7790c54f413ae400000000000000000000000049f1fc2d4e93f5223e870d122a23175407d63737000000000000000000000000ce816d9905eded7811c0847cd22ab7def2894e20000000000000000000000000c8b345b98641253e58b8b4d0222ba397e2b37abb000000000000000000000000ee6229c4e58e31cab52625c398f9cd9fe3a0ec74000000000000000000000000348e49f126e47dbbc09c627878e5dbf0400e311d", contractAddress: "", cumulativeGasUsed: "6103415", gasUsed: "215377", confirmations: "1143266"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]], "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540624604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x56f33c2fe432334b9078fae1ba7790c54f413ae4"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x49f1fc2d4e93f5223e870d122a23175407d63737"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xce816d9905eded7811c0847cd22ab7def2894e20"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc8b345b98641253e58b8b4d0222ba397e2b37abb"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xee6229c4e58e31cab52625c398f9cd9fe3a0ec74"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x348e49f126e47dbbc09c627878e5dbf0400e311d"}, {name: "_value", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x56f33c2fe432334b9078fae1ba7790c54f413ae4"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x49f1fc2d4e93f5223e870d122a23175407d63737"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xce816d9905eded7811c0847cd22ab7def2894e20"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xc8b345b98641253e58b8b4d0222ba397e2b37abb"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xee6229c4e58e31cab52625c398f9cd9fe3a0ec74"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x348e49f126e47dbbc09c627878e5dbf0400e311d"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_balance", type: "uint256", value: "10000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[21], \"7400000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591787", timeStamp: "1540624731", hash: "0xea1a072c65d72fa5289d54e35494ec659235337cca2fc19cd4d635f6550fba61", nonce: "124", blockHash: "0xe24e3023762e462dc6ffedc6e6e7ff9e9b411acf211d87e978d94c8dd1844de7", transactionIndex: "58", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000d33794605098eed8e18320c8fd508c5a401817ef000000000000000000000000000000000000000000000000001a4a42c3568000", contractAddress: "", cumulativeGasUsed: "6194810", gasUsed: "54507", confirmations: "1143256"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[21]}, {type: "uint256", name: "_amount", value: "7400000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[21], "7400000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540624731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd33794605098eed8e18320c8fd508c5a401817ef"}, {name: "_value", type: "uint256", value: "7400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xd33794605098eed8e18320c8fd508c5a401817ef"}, {name: "_amount", type: "uint256", value: "7400000000000000"}, {name: "_balance", type: "uint256", value: "7400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[22], \"6000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591791", timeStamp: "1540624759", hash: "0xde2a1d127c6151ffc22ea8ac14fadf886125f371c2e82280a508b399f6395f22", nonce: "125", blockHash: "0x0101c31c474a2d3560cb623a40e97a995ea34c61d27b1e62c5e2de19f0c8b904", transactionIndex: "99", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54379", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000083677e51d1d5787a06bd6689f73ca0006fc39995000000000000000000000000000000000000000000000000001550f7dca70000", contractAddress: "", cumulativeGasUsed: "6194979", gasUsed: "54379", confirmations: "1143252"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[22]}, {type: "uint256", name: "_amount", value: "6000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[22], "6000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540624759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x83677e51d1d5787a06bd6689f73ca0006fc39995"}, {name: "_value", type: "uint256", value: "6000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x83677e51d1d5787a06bd6689f73ca0006fc39995"}, {name: "_amount", type: "uint256", value: "6000000000000000"}, {name: "_balance", type: "uint256", value: "6000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[23], \"5000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591794", timeStamp: "1540624784", hash: "0xbda51f886819df14c6a5cfbeda8c721e77d0404e8328773ff34f32a7dfecbb7d", nonce: "126", blockHash: "0xbd08cec93afd2abc1343758722241bf31a76236547bb79d19d3d2f7111e6fb20", transactionIndex: "63", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000008dfd13c1fb9bc276b0084c43cc099c5141456ca10000000000000000000000000000000000000000000000000011c37937e08000", contractAddress: "", cumulativeGasUsed: "3375861", gasUsed: "54507", confirmations: "1143249"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[23]}, {type: "uint256", name: "_amount", value: "5000000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[23], "5000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540624784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8dfd13c1fb9bc276b0084c43cc099c5141456ca1"}, {name: "_value", type: "uint256", value: "5000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x8dfd13c1fb9bc276b0084c43cc099c5141456ca1"}, {name: "_amount", type: "uint256", value: "5000000000000000"}, {name: "_balance", type: "uint256", value: "5000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[24], \"4500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591802", timeStamp: "1540624884", hash: "0x450e55ea3302f049b7cfe819a9f9265dd2abe9774b37f3db6058c43c6a665d4d", nonce: "127", blockHash: "0x487073dd4a8604ebb74f581f04ede99185062715fa1f6845f57ce9a7942f4c51", transactionIndex: "117", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000b238fcbc02f15045dbacd85faffada6654058c45000000000000000000000000000000000000000000000000000ffcb9e57d4000", contractAddress: "", cumulativeGasUsed: "6808150", gasUsed: "54507", confirmations: "1143241"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[24]}, {type: "uint256", name: "_amount", value: "4500000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[24], "4500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540624884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xb238fcbc02f15045dbacd85faffada6654058c45"}, {name: "_value", type: "uint256", value: "4500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xb238fcbc02f15045dbacd85faffada6654058c45"}, {name: "_amount", type: "uint256", value: "4500000000000000"}, {name: "_balance", type: "uint256", value: "4500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[25], \"3300000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591806", timeStamp: "1540624916", hash: "0xedd981284ed7891d9c5ca7253500ac43743bee1ccb75b2835bfa38511d6047b7", nonce: "128", blockHash: "0x0598effe2be1d6387eb07ae3abe3e88b6dbb1e7988248990c53f57d3783edc8d", transactionIndex: "57", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000078d8faaa50b38dcaa679d3a773eacdb4d7d74eca000000000000000000000000000000000000000000000000000bb9551fc24000", contractAddress: "", cumulativeGasUsed: "5201417", gasUsed: "54507", confirmations: "1143237"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[25]}, {type: "uint256", name: "_amount", value: "3300000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[25], "3300000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540624916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x78d8faaa50b38dcaa679d3a773eacdb4d7d74eca"}, {name: "_value", type: "uint256", value: "3300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x78d8faaa50b38dcaa679d3a773eacdb4d7d74eca"}, {name: "_amount", type: "uint256", value: "3300000000000000"}, {name: "_balance", type: "uint256", value: "3300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[26], \"2900000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591807", timeStamp: "1540624946", hash: "0x3fcdfd3358f1bff6dad2dc9c32491fd30b596080b882343a01c9e99e659d36b6", nonce: "129", blockHash: "0xe79024d864bf640d27b4acebfccb4682cb85092bc9609afaabd0e79a33feb4d2", transactionIndex: "118", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3400000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000006b618fd0e4b05fe2333220f00a022d11248fddca000000000000000000000000000000000000000000000000000a4d88ddd94000", contractAddress: "", cumulativeGasUsed: "7303033", gasUsed: "54507", confirmations: "1143236"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[26]}, {type: "uint256", name: "_amount", value: "2900000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[26], "2900000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540624946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x6b618fd0e4b05fe2333220f00a022d11248fddca"}, {name: "_value", type: "uint256", value: "2900000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x6b618fd0e4b05fe2333220f00a022d11248fddca"}, {name: "_amount", type: "uint256", value: "2900000000000000"}, {name: "_balance", type: "uint256", value: "2900000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[27], \"2520000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591811", timeStamp: "1540624985", hash: "0x8f2cd4171527fe47b654c43863b450663ad128c25d37c20de297a8207e9f1a7a", nonce: "130", blockHash: "0x4ba9a092d9639b1684216df82c71ebd1735a3dbc7c7808650c57cdb9642df9b0", transactionIndex: "46", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3700000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000091ef4e3ec6d7b0bff50cc77dd257937705dc5fc20000000000000000000000000000000000000000000000000008f3ed38d58000", contractAddress: "", cumulativeGasUsed: "2697590", gasUsed: "54507", confirmations: "1143232"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[27]}, {type: "uint256", name: "_amount", value: "2520000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[27], "2520000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540624985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x91ef4e3ec6d7b0bff50cc77dd257937705dc5fc2"}, {name: "_value", type: "uint256", value: "2520000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x91ef4e3ec6d7b0bff50cc77dd257937705dc5fc2"}, {name: "_amount", type: "uint256", value: "2520000000000000"}, {name: "_balance", type: "uint256", value: "2520000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[28], \"2500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591813", timeStamp: "1540625017", hash: "0x5fdfcb5c01e388a6c7e8354e41a363de4d1dc68d4f74251365284d47c6d4e6cb", nonce: "131", blockHash: "0x1ffcd47be2270a47457c4567dc9467c531e936e4a5c4779f7be4f97c91b9b2ee", transactionIndex: "66", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3020000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000016d135eefa836f53e02ef12552081bc5c345da4c0000000000000000000000000000000000000000000000000008e1bc9bf04000", contractAddress: "", cumulativeGasUsed: "3228772", gasUsed: "54507", confirmations: "1143230"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[28]}, {type: "uint256", name: "_amount", value: "2500000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[28], "2500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540625017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x16d135eefa836f53e02ef12552081bc5c345da4c"}, {name: "_value", type: "uint256", value: "2500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x16d135eefa836f53e02ef12552081bc5c345da4c"}, {name: "_amount", type: "uint256", value: "2500000000000000"}, {name: "_balance", type: "uint256", value: "2500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[29],addressList[30],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591824", timeStamp: "1540625130", hash: "0xa6bc0fa5170efb7ef0d04bac1c34982bff89f8afa8f5d44c71cdb637d74cb671", nonce: "132", blockHash: "0xa7b03ab1996251cb3b81552fbf12eefb927934707b03d362718f59a3220e4397", transactionIndex: "114", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "151257", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd7000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000071afd498d00000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000fba33c991d2f9799eccf94a29cab2bda7a7940ab00000000000000000000000071b2641ca8b2a4ae9d8a6a51f4897f8234a7e72100000000000000000000000044d9ed29378fd7d5b72c494bd05fad30dcb1b07b00000000000000000000000081eb5c24e3ec823d6b80f5d0e2f8da75bf38a25b", contractAddress: "", cumulativeGasUsed: "6904279", gasUsed: "151257", confirmations: "1143219"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[29],addressList[30],addressList[31],addressList[32]]}, {type: "uint256", name: "_amount", value: "2000000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[29],addressList[30],addressList[31],addressList[32]], "2000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540625130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xfba33c991d2f9799eccf94a29cab2bda7a7940ab"}, {name: "_value", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x71b2641ca8b2a4ae9d8a6a51f4897f8234a7e721"}, {name: "_value", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x44d9ed29378fd7d5b72c494bd05fad30dcb1b07b"}, {name: "_value", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x81eb5c24e3ec823d6b80f5d0e2f8da75bf38a25b"}, {name: "_value", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xfba33c991d2f9799eccf94a29cab2bda7a7940ab"}, {name: "_amount", type: "uint256", value: "2000000000000000"}, {name: "_balance", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x71b2641ca8b2a4ae9d8a6a51f4897f8234a7e721"}, {name: "_amount", type: "uint256", value: "2000000000000000"}, {name: "_balance", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x44d9ed29378fd7d5b72c494bd05fad30dcb1b07b"}, {name: "_amount", type: "uint256", value: "2000000000000000"}, {name: "_balance", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x81eb5c24e3ec823d6b80f5d0e2f8da75bf38a25b"}, {name: "_amount", type: "uint256", value: "2000000000000000"}, {name: "_balance", type: "uint256", value: "2000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[33], \"1611299000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591838", timeStamp: "1540625343", hash: "0x5977c5492b26b43ff24917b147d36d9d69f06cf80928e7e161c603067db6b200", nonce: "133", blockHash: "0xcb7784e65ad15a532c5260629a14176cdbcab52f18829b50564ae2a8cf3d1cb4", transactionIndex: "291", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000005e51cc1408fedebed38783fcc72be488282e3c890000000000000000000000000000000000000000000000000005b977c8859e00", contractAddress: "", cumulativeGasUsed: "6849950", gasUsed: "54507", confirmations: "1143205"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[33]}, {type: "uint256", name: "_amount", value: "1611299000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[33], "1611299000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540625343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x5e51cc1408fedebed38783fcc72be488282e3c89"}, {name: "_value", type: "uint256", value: "1611299000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x5e51cc1408fedebed38783fcc72be488282e3c89"}, {name: "_amount", type: "uint256", value: "1611299000000000"}, {name: "_balance", type: "uint256", value: "1611299000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[34], \"1500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591840", timeStamp: "1540625360", hash: "0xeb0320fac47fea86d30a263fb399d4c0efa57b375ba0108b453ac34bf4d322c5", nonce: "134", blockHash: "0xe948240c724b4f03b2e06c84aa799075c07de1c8bdb1a71d54cd3a1f54537114", transactionIndex: "124", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3020000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000a76e7f8fe481448f1a803212b0c8b6fd7ec900780000000000000000000000000000000000000000000000000005543df729c000", contractAddress: "", cumulativeGasUsed: "5577419", gasUsed: "54443", confirmations: "1143203"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[34]}, {type: "uint256", name: "_amount", value: "1500000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[34], "1500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540625360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa76e7f8fe481448f1a803212b0c8b6fd7ec90078"}, {name: "_value", type: "uint256", value: "1500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xa76e7f8fe481448f1a803212b0c8b6fd7ec90078"}, {name: "_amount", type: "uint256", value: "1500000000000000"}, {name: "_balance", type: "uint256", value: "1500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[35], \"1380000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591840", timeStamp: "1540625360", hash: "0x0df9ddf48156264ddadc42f3358954704b7f9d401456e5c8dce956bf0b112d60", nonce: "135", blockHash: "0xe948240c724b4f03b2e06c84aa799075c07de1c8bdb1a71d54cd3a1f54537114", transactionIndex: "125", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3030000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000003c34169effe7d8e238ba68bbdb3244290f9146760000000000000000000000000000000000000000000000000004e71a49ca4000", contractAddress: "", cumulativeGasUsed: "5631926", gasUsed: "54507", confirmations: "1143203"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[35]}, {type: "uint256", name: "_amount", value: "1380000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[35], "1380000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540625360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3c34169effe7d8e238ba68bbdb3244290f914676"}, {name: "_value", type: "uint256", value: "1380000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x3c34169effe7d8e238ba68bbdb3244290f914676"}, {name: "_amount", type: "uint256", value: "1380000000000000"}, {name: "_balance", type: "uint256", value: "1380000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[36], \"1200000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591842", timeStamp: "1540625379", hash: "0xf7d649f0272558361954bf5f6d26165bf1c59a6f9ee417a441170577a2d2e22a", nonce: "136", blockHash: "0x72f4ca8ff2ebbac8743268b762ee661aa8e5875fc675f206ed49032d3b958654", transactionIndex: "66", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000e3d6923b458bd5c55fad7db6fccc4728bcded99f00000000000000000000000000000000000000000000000000044364c5bb0000", contractAddress: "", cumulativeGasUsed: "2798559", gasUsed: "54443", confirmations: "1143201"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[36]}, {type: "uint256", name: "_amount", value: "1200000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[36], "1200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540625379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe3d6923b458bd5c55fad7db6fccc4728bcded99f"}, {name: "_value", type: "uint256", value: "1200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe3d6923b458bd5c55fad7db6fccc4728bcded99f"}, {name: "_amount", type: "uint256", value: "1200000000000000"}, {name: "_balance", type: "uint256", value: "1200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[37], \"1174536200000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591844", timeStamp: "1540625400", hash: "0xee73578912fb4a119f7794f3637ab7e12bc0e8e0307ef63adb16d446b6fc791e", nonce: "137", blockHash: "0x67e2009be8f91dea865d86557dfe97d0dc1493ec8381e9faaaacb1bd6c7df84e", transactionIndex: "45", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3050000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000098153b7f4e6ee68683db3d147e95d954c7c7ca4d00000000000000000000000000000000000000000000000000042c3c04fa1200", contractAddress: "", cumulativeGasUsed: "2484991", gasUsed: "54507", confirmations: "1143199"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[37]}, {type: "uint256", name: "_amount", value: "1174536200000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[37], "1174536200000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540625400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x98153b7f4e6ee68683db3d147e95d954c7c7ca4d"}, {name: "_value", type: "uint256", value: "1174536200000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x98153b7f4e6ee68683db3d147e95d954c7c7ca4d"}, {name: "_amount", type: "uint256", value: "1174536200000000"}, {name: "_balance", type: "uint256", value: "1174536200000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[38], \"1050000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591847", timeStamp: "1540625419", hash: "0xc6c8ab23b81c7b613ce0ff4278d59fb400ad73700c249815e55fe6abffaadae9", nonce: "138", blockHash: "0xe4de008d457416d7cef74beae59cc01b04789cff0455935a4226f15820e7ff1c", transactionIndex: "40", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3090000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000e5ae74f48401f3f9043812c2a6fe2169e5f0c9b30000000000000000000000000000000000000000000000000003baf82d03a000", contractAddress: "", cumulativeGasUsed: "2371297", gasUsed: "54507", confirmations: "1143196"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[38]}, {type: "uint256", name: "_amount", value: "1050000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[38], "1050000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540625419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe5ae74f48401f3f9043812c2a6fe2169e5f0c9b3"}, {name: "_value", type: "uint256", value: "1050000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe5ae74f48401f3f9043812c2a6fe2169e5f0c9b3"}, {name: "_amount", type: "uint256", value: "1050000000000000"}, {name: "_balance", type: "uint256", value: "1050000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[39], \"1040000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591850", timeStamp: "1540625467", hash: "0x59662183a8c26eea84b12a4d6194b99ced8be13378e166b54a9bd36c6e8d7d23", nonce: "139", blockHash: "0xc268bce29edc8e763896fe393ecd704f3c231f1428943822d06446d3afdc4fd3", transactionIndex: "93", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3090000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000ae84197bcc5dae81298149f82afa22750a0eb23d0000000000000000000000000000000000000000000000000003b1dfde910000", contractAddress: "", cumulativeGasUsed: "5485399", gasUsed: "54443", confirmations: "1143193"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[39]}, {type: "uint256", name: "_amount", value: "1040000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[39], "1040000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540625467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xae84197bcc5dae81298149f82afa22750a0eb23d"}, {name: "_value", type: "uint256", value: "1040000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xae84197bcc5dae81298149f82afa22750a0eb23d"}, {name: "_amount", type: "uint256", value: "1040000000000000"}, {name: "_balance", type: "uint256", value: "1040000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[40],addressList[41],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591859", timeStamp: "1540625630", hash: "0x5ac2e48610f0a1cc074278b6e313f9de299595850eddfc9fc157825bc389b414", nonce: "140", blockHash: "0x8aac1c307c057e4fd6add9505f427ca3ba56d7c863a73c3fc9d210e4a83a313a", transactionIndex: "58", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "375677", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd7000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000e6a8589ddb49c2d263aa8437f96c4b37080bf433000000000000000000000000ba3e4217a4c289895acbe26dc894cde7ccc61d30000000000000000000000000435085ea1ad8cd1ebc67c99d5fad17f95caf7482000000000000000000000000395f935f13ea0795c11136675469e420fb68904e0000000000000000000000007fc069c7aaad4384b20aeec9cfd4e314a5e4619b000000000000000000000000d3ed6a0fd9800c2e636ff5b3d7f0914162bfadac0000000000000000000000009e17cc6ad7f32e88a8c863788adf1beb00301e58000000000000000000000000f1e5412126c18178d0c5b909cd40502d7f0652f1000000000000000000000000cb44e6ac67fca11e46a0e4d0758455a06846fb5b000000000000000000000000dd142453213080e90a2849353e72401e8a5313cb000000000000000000000000e679a668c3b84464adddb9b73938baa6a2a3c5de", contractAddress: "", cumulativeGasUsed: "2828208", gasUsed: "375677", confirmations: "1143184"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50]]}, {type: "uint256", name: "_amount", value: "1000000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50]], "1000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540625630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe6a8589ddb49c2d263aa8437f96c4b37080bf433"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xba3e4217a4c289895acbe26dc894cde7ccc61d30"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x435085ea1ad8cd1ebc67c99d5fad17f95caf7482"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x395f935f13ea0795c11136675469e420fb68904e"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7fc069c7aaad4384b20aeec9cfd4e314a5e4619b"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd3ed6a0fd9800c2e636ff5b3d7f0914162bfadac"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x9e17cc6ad7f32e88a8c863788adf1beb00301e58"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf1e5412126c18178d0c5b909cd40502d7f0652f1"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcb44e6ac67fca11e46a0e4d0758455a06846fb5b"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xdd142453213080e90a2849353e72401e8a5313cb"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe679a668c3b84464adddb9b73938baa6a2a3c5de"}, {name: "_value", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe6a8589ddb49c2d263aa8437f96c4b37080bf433"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xba3e4217a4c289895acbe26dc894cde7ccc61d30"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x435085ea1ad8cd1ebc67c99d5fad17f95caf7482"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x395f935f13ea0795c11136675469e420fb68904e"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7fc069c7aaad4384b20aeec9cfd4e314a5e4619b"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xd3ed6a0fd9800c2e636ff5b3d7f0914162bfadac"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x9e17cc6ad7f32e88a8c863788adf1beb00301e58"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xf1e5412126c18178d0c5b909cd40502d7f0652f1"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xcb44e6ac67fca11e46a0e4d0758455a06846fb5b"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xdd142453213080e90a2849353e72401e8a5313cb"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe679a668c3b84464adddb9b73938baa6a2a3c5de"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_balance", type: "uint256", value: "1000000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[51], \"991949900000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591866", timeStamp: "1540625693", hash: "0x98f803f0f04b7a9767a6bf9cab2ef389c80cdaec2a7ca90db3b47f3b2af14164", nonce: "141", blockHash: "0x86e11f6203c6dc5f8879bf84cd32804849841d3f12980b6b8e3873cac18fe4c6", transactionIndex: "80", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3050000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000042fab16b923b45e115285f9b36fc2912661295890000000000000000000000000000000000000000000000000003862c556cab00", contractAddress: "", cumulativeGasUsed: "2875623", gasUsed: "54507", confirmations: "1143177"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[51]}, {type: "uint256", name: "_amount", value: "991949900000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[51], "991949900000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540625693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x42fab16b923b45e115285f9b36fc291266129589"}, {name: "_value", type: "uint256", value: "991949900000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x42fab16b923b45e115285f9b36fc291266129589"}, {name: "_amount", type: "uint256", value: "991949900000000"}, {name: "_balance", type: "uint256", value: "991949900000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[52],addressList[53]], \"850... )", async function( ) {
		const txOriginal = {blockNumber: "6591869", timeStamp: "1540625743", hash: "0xfaf9611fc19dd51bd6e37f066c756af37ee97dee97a99ad27538bd50c0366176", nonce: "142", blockHash: "0xd4e61d4ef95a8a11a6ead776863274e5599bda86ac5d0a0fdfcc43ac5161b8e5", transactionIndex: "199", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "87201", gasPrice: "3090000000", isError: "0", txreceipt_status: "1", input: "0x67220fd70000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000305120c0f200000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000f86f8c48c346b9a5eb80558d990ed1a2f561d6c000000000000000000000000bbfc74f1f4acf3b67675ccb6e48bcdcdd355d43b", contractAddress: "", cumulativeGasUsed: "6476007", gasUsed: "87201", confirmations: "1143174"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[52],addressList[53]]}, {type: "uint256", name: "_amount", value: "850000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[52],addressList[53]], "850000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540625743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0f86f8c48c346b9a5eb80558d990ed1a2f561d6c"}, {name: "_value", type: "uint256", value: "850000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbbfc74f1f4acf3b67675ccb6e48bcdcdd355d43b"}, {name: "_value", type: "uint256", value: "850000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x0f86f8c48c346b9a5eb80558d990ed1a2f561d6c"}, {name: "_amount", type: "uint256", value: "850000000000000"}, {name: "_balance", type: "uint256", value: "850000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xbbfc74f1f4acf3b67675ccb6e48bcdcdd355d43b"}, {name: "_amount", type: "uint256", value: "850000000000000"}, {name: "_balance", type: "uint256", value: "850000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[54],addressList[55]], \"800... )", async function( ) {
		const txOriginal = {blockNumber: "6591876", timeStamp: "1540625798", hash: "0x226630453c4d5b0ca4fb30d08a2dfd48b8807b4204627808711c391a7e2f894d", nonce: "143", blockHash: "0x1da00e0bc48b2db3f164a8eea6c27fdb5da079cd74999e5ff1f4db6e5ad5e431", transactionIndex: "75", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "87137", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0x67220fd700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000002d79883d200000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000b35b5ff75b0922af427f17aadda5b870fee66b57000000000000000000000000476c5d4b1b86f1a83e92fb671746701748f8d18a", contractAddress: "", cumulativeGasUsed: "3672453", gasUsed: "87137", confirmations: "1143167"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[54],addressList[55]]}, {type: "uint256", name: "_amount", value: "800000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[54],addressList[55]], "800000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540625798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xb35b5ff75b0922af427f17aadda5b870fee66b57"}, {name: "_value", type: "uint256", value: "800000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x476c5d4b1b86f1a83e92fb671746701748f8d18a"}, {name: "_value", type: "uint256", value: "800000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xb35b5ff75b0922af427f17aadda5b870fee66b57"}, {name: "_amount", type: "uint256", value: "800000000000000"}, {name: "_balance", type: "uint256", value: "800000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x476c5d4b1b86f1a83e92fb671746701748f8d18a"}, {name: "_amount", type: "uint256", value: "800000000000000"}, {name: "_balance", type: "uint256", value: "800000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[56],addressList[57]], \"780... )", async function( ) {
		const txOriginal = {blockNumber: "6591879", timeStamp: "1540625859", hash: "0xe636ebc402f218d9ddba73bd42b5b649f93ce75a01add8b9028cc3fcab4ef273", nonce: "144", blockHash: "0x9dfc06b918a3e8e802777c6d749ec602387f434b50a03579d03a6d6fa424367b", transactionIndex: "110", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "87201", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000002c567e6ecc0000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000406c6ca639c42f038dda19df4897945006ab9aab000000000000000000000000b4615ecbd3c00e78348d794525388a85ebab89ec", contractAddress: "", cumulativeGasUsed: "7305034", gasUsed: "87201", confirmations: "1143164"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[56],addressList[57]]}, {type: "uint256", name: "_amount", value: "780000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[56],addressList[57]], "780000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540625859 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x406c6ca639c42f038dda19df4897945006ab9aab"}, {name: "_value", type: "uint256", value: "780000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xb4615ecbd3c00e78348d794525388a85ebab89ec"}, {name: "_value", type: "uint256", value: "780000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x406c6ca639c42f038dda19df4897945006ab9aab"}, {name: "_amount", type: "uint256", value: "780000000000000"}, {name: "_balance", type: "uint256", value: "780000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xb4615ecbd3c00e78348d794525388a85ebab89ec"}, {name: "_amount", type: "uint256", value: "780000000000000"}, {name: "_balance", type: "uint256", value: "780000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[58],addressList[59]], \"600... )", async function( ) {
		const txOriginal = {blockNumber: "6591891", timeStamp: "1540626034", hash: "0x49491cad325061a999875875dd539380a00b7d525956954357316d79162ed015", nonce: "145", blockHash: "0xd104c923713f6644287eb4d8a9eb397340d21e1851b7e49c081298982387702a", transactionIndex: "93", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "87201", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd70000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000221b262dd800000000000000000000000000000000000000000000000000000000000000000020000000000000000000000007431e7f8c5997ffba567d71c0c846d5d25e0fc2b000000000000000000000000600757b7d32ce5624b027add897d2da36de487ed", contractAddress: "", cumulativeGasUsed: "7850066", gasUsed: "87201", confirmations: "1143152"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[58],addressList[59]]}, {type: "uint256", name: "_amount", value: "600000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[58],addressList[59]], "600000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540626034 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7431e7f8c5997ffba567d71c0c846d5d25e0fc2b"}, {name: "_value", type: "uint256", value: "600000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x600757b7d32ce5624b027add897d2da36de487ed"}, {name: "_value", type: "uint256", value: "600000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7431e7f8c5997ffba567d71c0c846d5d25e0fc2b"}, {name: "_amount", type: "uint256", value: "600000000000000"}, {name: "_balance", type: "uint256", value: "600000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x600757b7d32ce5624b027add897d2da36de487ed"}, {name: "_amount", type: "uint256", value: "600000000000000"}, {name: "_balance", type: "uint256", value: "600000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[60], \"550000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591895", timeStamp: "1540626111", hash: "0xa52cf3d28c3d6c41df254f5268168a1b8b334fe9a285ac40ee38f4f81131af69", nonce: "146", blockHash: "0x7129f18f1ea833434d12fdca4771b27aafb685315e8c01524d2f09ac992e7463", transactionIndex: "99", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000084a60f09d0f7ed7073233a35bac0f571d04878e80000000000000000000000000000000000000000000000000001f438daa06000", contractAddress: "", cumulativeGasUsed: "5609373", gasUsed: "54507", confirmations: "1143148"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[60]}, {type: "uint256", name: "_amount", value: "550000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[60], "550000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540626111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x84a60f09d0f7ed7073233a35bac0f571d04878e8"}, {name: "_value", type: "uint256", value: "550000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x84a60f09d0f7ed7073233a35bac0f571d04878e8"}, {name: "_amount", type: "uint256", value: "550000000000000"}, {name: "_balance", type: "uint256", value: "550000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[61], \"510000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591895", timeStamp: "1540626111", hash: "0x555fc740eb295dcf4f5961944e227f065374130a3df06d4c4e19763ee3de86db", nonce: "147", blockHash: "0x7129f18f1ea833434d12fdca4771b27aafb685315e8c01524d2f09ac992e7463", transactionIndex: "100", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000023ae111d790874bc2b55cbb1c4c27357ee8b87150000000000000000000000000000000000000000000000000001cfd7a0d5e000", contractAddress: "", cumulativeGasUsed: "5663880", gasUsed: "54507", confirmations: "1143148"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[61]}, {type: "uint256", name: "_amount", value: "510000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[61], "510000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540626111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x23ae111d790874bc2b55cbb1c4c27357ee8b8715"}, {name: "_value", type: "uint256", value: "510000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x23ae111d790874bc2b55cbb1c4c27357ee8b8715"}, {name: "_amount", type: "uint256", value: "510000000000000"}, {name: "_balance", type: "uint256", value: "510000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[62],addressList[63],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591898", timeStamp: "1540626148", hash: "0x8b7dd3af92a965df3593bcbe6b997041cb08bd0169cad66de1e1a433c939161d", nonce: "148", blockHash: "0x39d38cc74c557a513b36ee3f116ddbcfdd403a9c731594e1afd4eec3f1ce358b", transactionIndex: "30", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "279497", gasPrice: "3311000000", isError: "0", txreceipt_status: "1", input: "0x67220fd700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000001c6bf526340000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000f94ee00f5d2cafdf77d30c8220fa4397e62cb554000000000000000000000000932d4b56fab68cb9b6024a7a86a5313f0511e3d90000000000000000000000009e046b941379f673878d7696577411ef030e5f4e0000000000000000000000003bcb98aa6f0bcb4f2abca22987e81e7a547b1f9000000000000000000000000079eb7ca0f1744071d4a94c70760e2058f1d30400000000000000000000000000546493137cfd7ce09b5b461a669b6de3e66861c300000000000000000000000063f60a4b7fcd4e8a979c449b71cef2db046e65210000000000000000000000004aba6cb413035f22947c82f561fef050ed9feee2", contractAddress: "", cumulativeGasUsed: "2247758", gasUsed: "279497", confirmations: "1143145"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69]]}, {type: "uint256", name: "_amount", value: "500000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69]], "500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540626148 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf94ee00f5d2cafdf77d30c8220fa4397e62cb554"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x932d4b56fab68cb9b6024a7a86a5313f0511e3d9"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x9e046b941379f673878d7696577411ef030e5f4e"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3bcb98aa6f0bcb4f2abca22987e81e7a547b1f90"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x79eb7ca0f1744071d4a94c70760e2058f1d30400"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x546493137cfd7ce09b5b461a669b6de3e66861c3"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x63f60a4b7fcd4e8a979c449b71cef2db046e6521"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x4aba6cb413035f22947c82f561fef050ed9feee2"}, {name: "_value", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xf94ee00f5d2cafdf77d30c8220fa4397e62cb554"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x932d4b56fab68cb9b6024a7a86a5313f0511e3d9"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x9e046b941379f673878d7696577411ef030e5f4e"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x3bcb98aa6f0bcb4f2abca22987e81e7a547b1f90"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x79eb7ca0f1744071d4a94c70760e2058f1d30400"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x546493137cfd7ce09b5b461a669b6de3e66861c3"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x63f60a4b7fcd4e8a979c449b71cef2db046e6521"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x4aba6cb413035f22947c82f561fef050ed9feee2"}, {name: "_amount", type: "uint256", value: "500000000000000"}, {name: "_balance", type: "uint256", value: "500000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[70], \"470000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591900", timeStamp: "1540626173", hash: "0x76ed56050b05846ced446c2acbbdb213f48b0c360b457cf941c5e3f7a6f7f7af", nonce: "149", blockHash: "0xc472b5d74687ad720e58275f78151e6bdb9b23bc412806c3a4d7b54452b5e158", transactionIndex: "82", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000044d23ea744662df447497bc8b1163f8244cd47630000000000000000000000000000000000000000000000000001ab76670b6000", contractAddress: "", cumulativeGasUsed: "4276672", gasUsed: "54507", confirmations: "1143143"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[70]}, {type: "uint256", name: "_amount", value: "470000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[70], "470000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540626173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x44d23ea744662df447497bc8b1163f8244cd4763"}, {name: "_value", type: "uint256", value: "470000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x44d23ea744662df447497bc8b1163f8244cd4763"}, {name: "_amount", type: "uint256", value: "470000000000000"}, {name: "_balance", type: "uint256", value: "470000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[71],addressList[72]], \"400... )", async function( ) {
		const txOriginal = {blockNumber: "6591904", timeStamp: "1540626240", hash: "0x905fe9067420382f22fc75c03bab99cba074eacaee6551462a642745ac5f2dac", nonce: "150", blockHash: "0x2c24053a4a04a0ba813fb2481bb8307367998b1c61844517080a1a7d9243c631", transactionIndex: "112", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "87137", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x67220fd7000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000016bcc41e9000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000006d3b742e29551483fb3bda7a8f07d77b924b3590000000000000000000000000e90ca49f51af7cb8b82374453527a69ceecf6ae7", contractAddress: "", cumulativeGasUsed: "5417587", gasUsed: "87137", confirmations: "1143139"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[71],addressList[72]]}, {type: "uint256", name: "_amount", value: "400000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[71],addressList[72]], "400000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540626240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x6d3b742e29551483fb3bda7a8f07d77b924b3590"}, {name: "_value", type: "uint256", value: "400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe90ca49f51af7cb8b82374453527a69ceecf6ae7"}, {name: "_value", type: "uint256", value: "400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x6d3b742e29551483fb3bda7a8f07d77b924b3590"}, {name: "_amount", type: "uint256", value: "400000000000000"}, {name: "_balance", type: "uint256", value: "400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe90ca49f51af7cb8b82374453527a69ceecf6ae7"}, {name: "_amount", type: "uint256", value: "400000000000000"}, {name: "_balance", type: "uint256", value: "400000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[73],addressList[74],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591909", timeStamp: "1540626336", hash: "0x58b1f926a7cdd157cf014e86756217284a08b526a59ab1e17fd0d3f8fe326abf", nonce: "151", blockHash: "0x22beef47481471ae2d5a0245fefce02907f0d8a637827e8646f89cb40dd46d65", transactionIndex: "90", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "279561", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x67220fd70000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000110d9316ec0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000a2a9532d713ae6ad67abe840f30555984c3f486b000000000000000000000000c1097e40da134c8645272ef778c569642e93969a000000000000000000000000ad12d207fadda2b249819eb87396227ba8a8ce7c0000000000000000000000007a58d5fabc1b5397e4956011218f0de9d39385f60000000000000000000000003953bbd13a2863b377355b10e4a5889e84fb7c740000000000000000000000004b8818dccbc9a72c6f3b74549738fbc1f6d41edb000000000000000000000000b8209ea712c83999c5aa949350205ccb17ea998800000000000000000000000025ae4db38b78abfc92387e4ec03afa386921caab", contractAddress: "", cumulativeGasUsed: "7546800", gasUsed: "279561", confirmations: "1143134"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80]]}, {type: "uint256", name: "_amount", value: "300000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80]], "300000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540626336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa2a9532d713ae6ad67abe840f30555984c3f486b"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc1097e40da134c8645272ef778c569642e93969a"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xad12d207fadda2b249819eb87396227ba8a8ce7c"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7a58d5fabc1b5397e4956011218f0de9d39385f6"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3953bbd13a2863b377355b10e4a5889e84fb7c74"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x4b8818dccbc9a72c6f3b74549738fbc1f6d41edb"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xb8209ea712c83999c5aa949350205ccb17ea9988"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x25ae4db38b78abfc92387e4ec03afa386921caab"}, {name: "_value", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xa2a9532d713ae6ad67abe840f30555984c3f486b"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xc1097e40da134c8645272ef778c569642e93969a"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xad12d207fadda2b249819eb87396227ba8a8ce7c"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7a58d5fabc1b5397e4956011218f0de9d39385f6"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x3953bbd13a2863b377355b10e4a5889e84fb7c74"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x4b8818dccbc9a72c6f3b74549738fbc1f6d41edb"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xb8209ea712c83999c5aa949350205ccb17ea9988"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x25ae4db38b78abfc92387e4ec03afa386921caab"}, {name: "_amount", type: "uint256", value: "300000000000000"}, {name: "_balance", type: "uint256", value: "300000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[81], \"297000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591916", timeStamp: "1540626471", hash: "0x142cd8c57f81caf587e08bd561500f78417a9882c6373f2b2cd26f196d19fdaa", nonce: "152", blockHash: "0x87646eeb3261fba502d598735b5391385a40b2541f758912e0c807189b87bfbc", transactionIndex: "43", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54507", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000eebcfce40ec0624355d72a101a6eda802c56946e00000000000000000000000000000000000000000000000000010e1eb37f9000", contractAddress: "", cumulativeGasUsed: "2351817", gasUsed: "54507", confirmations: "1143127"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[81]}, {type: "uint256", name: "_amount", value: "297000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[81], "297000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540626471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xeebcfce40ec0624355d72a101a6eda802c56946e"}, {name: "_value", type: "uint256", value: "297000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xeebcfce40ec0624355d72a101a6eda802c56946e"}, {name: "_amount", type: "uint256", value: "297000000000000"}, {name: "_balance", type: "uint256", value: "297000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[82], \"250000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591919", timeStamp: "1540626521", hash: "0x26d85535b64b756db61ea265f56d000de2648567beb01aa05939de8ebe4c165b", nonce: "153", blockHash: "0x55ef4e11f66a6c6f0e9ee565e555d900f5c218c12b0e1c003bd8e410cfbfbecf", transactionIndex: "135", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d0000000000000000000000000c509f4bb93b48a99358fc32beb9b2037156348a0000000000000000000000000000000000000000000000000000e35fa931a000", contractAddress: "", cumulativeGasUsed: "6185428", gasUsed: "54443", confirmations: "1143124"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[82]}, {type: "uint256", name: "_amount", value: "250000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[82], "250000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540626521 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0c509f4bb93b48a99358fc32beb9b2037156348a"}, {name: "_value", type: "uint256", value: "250000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x0c509f4bb93b48a99358fc32beb9b2037156348a"}, {name: "_amount", type: "uint256", value: "250000000000000"}, {name: "_balance", type: "uint256", value: "250000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[83], \"236832000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591924", timeStamp: "1540626617", hash: "0xdc53fefa5ab29ed7467f15c044404d496acc3762e7ffa6dcc4b456cac1383561", nonce: "154", blockHash: "0xfa3734c2d038a3d8c8d3d47326134ce102188158c2304fc21d443a787f94b661", transactionIndex: "153", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54379", gasPrice: "3050000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000e03c23519e18d64f144d2800e30e81b0065c48b50000000000000000000000000000000000000000000000000000d765bf3b4000", contractAddress: "", cumulativeGasUsed: "6940096", gasUsed: "54379", confirmations: "1143119"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[83]}, {type: "uint256", name: "_amount", value: "236832000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[83], "236832000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540626617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe03c23519e18d64f144d2800e30e81b0065c48b5"}, {name: "_value", type: "uint256", value: "236832000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe03c23519e18d64f144d2800e30e81b0065c48b5"}, {name: "_amount", type: "uint256", value: "236832000000000"}, {name: "_balance", type: "uint256", value: "236832000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[84], \"225058700000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591933", timeStamp: "1540626708", hash: "0x75706daf9b43ba9a6d5997da9d5056247e534d5d774e19eb68742aea8def797e", nonce: "155", blockHash: "0x4ec8c620eab0157fe29700b5ea58a464218fd1e7254987f18ebbc050782f48a1", transactionIndex: "83", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000da4389b3387bd0dab738dae68fe106ac7df5f1670000000000000000000000000000000000000000000000000000ccb08fddfb00", contractAddress: "", cumulativeGasUsed: "5820922", gasUsed: "54443", confirmations: "1143110"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[84]}, {type: "uint256", name: "_amount", value: "225058700000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[84], "225058700000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540626708 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xda4389b3387bd0dab738dae68fe106ac7df5f167"}, {name: "_value", type: "uint256", value: "225058700000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xda4389b3387bd0dab738dae68fe106ac7df5f167"}, {name: "_amount", type: "uint256", value: "225058700000000"}, {name: "_balance", type: "uint256", value: "225058700000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[85],addressList[86],address... )", async function( ) {
		const txOriginal = {blockNumber: "6591952", timeStamp: "1540626944", hash: "0xd35edca77c9a3b16581cbb69a37a3cee104f04d059c4e417cdbec46a45bbcad4", nonce: "156", blockHash: "0xdd2ab097178171cca323c2b3cd4e40e7f6bfec838519313aada37217bdb7cd35", transactionIndex: "106", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "792330", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x67220fd700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000b5e620f48000000000000000000000000000000000000000000000000000000000000000001800000000000000000000000023d07e110baec060afaf492a4e52924442b0ca5900000000000000000000000014b560e5effdf219d2f363593053f77a2c34fb0d000000000000000000000000e85fd3eff890e0195998120465bdc5330dc19c570000000000000000000000008c0547b848e1f8031e2347065faa149f4a3fdf8b0000000000000000000000002724138648b134a8792b28baa4444230de68cbbd0000000000000000000000000e8e5ad47fe7d24024ca66677e67eb1446f222c0000000000000000000000000265a1a6605cfeaf8593460c5d77639b3e46354cb0000000000000000000000000537a2b93dca3bd723965781df8e569dcbc58211000000000000000000000000246d2d8670cec3d65eb3d7887e0585261d2bca0f000000000000000000000000e4adc923ae77bb9fec022c3ad52d52f81cc5ac21000000000000000000000000f0e63d4c5079629f59aec6ba3466f52d88306d03000000000000000000000000389b675cdd46602197f71d0ac0b422e850f9cecd000000000000000000000000f06b144e392edaea080f2ebab3a1d3eceaf4176f00000000000000000000000004d0dc750022ac254645797e3a07394a32111393000000000000000000000000a7487fefe0a907b660c195e2183c4736b548cb130000000000000000000000008d531b74bd532b4fc31d338f395a898c38b8db7b0000000000000000000000007c6c3fbe3248ab70c99c3cb4d40f50ed081de07d000000000000000000000000bbee1a9c10d64fd67c35833dac4eaf307d44569d0000000000000000000000000bdd3f6ec2fd45f5647bcb92f546d8f1377ebf3000000000000000000000000009ac022b6fbcc56dcb946c703e39db006fd0c419000000000000000000000000caa593c06f29e2cd56373761b75fe77e56c9e06900000000000000000000000069f5c172aca542a9483eff7eb854957ba713709700000000000000000000000021757f6d3af44047cb5775b21db3cf90d19757d9000000000000000000000000ef763e4f0deb2b5a114e0a31fd7ec63407d31766", contractAddress: "", cumulativeGasUsed: "6326693", gasUsed: "792330", confirmations: "1143091"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108]]}, {type: "uint256", name: "_amount", value: "200000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108]], "200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540626944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x23d07e110baec060afaf492a4e52924442b0ca59"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x14b560e5effdf219d2f363593053f77a2c34fb0d"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe85fd3eff890e0195998120465bdc5330dc19c57"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8c0547b848e1f8031e2347065faa149f4a3fdf8b"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x2724138648b134a8792b28baa4444230de68cbbd"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0e8e5ad47fe7d24024ca66677e67eb1446f222c0"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x265a1a6605cfeaf8593460c5d77639b3e46354cb"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0537a2b93dca3bd723965781df8e569dcbc58211"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x246d2d8670cec3d65eb3d7887e0585261d2bca0f"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe4adc923ae77bb9fec022c3ad52d52f81cc5ac21"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf0e63d4c5079629f59aec6ba3466f52d88306d03"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x389b675cdd46602197f71d0ac0b422e850f9cecd"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf06b144e392edaea080f2ebab3a1d3eceaf4176f"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x04d0dc750022ac254645797e3a07394a32111393"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa7487fefe0a907b660c195e2183c4736b548cb13"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8d531b74bd532b4fc31d338f395a898c38b8db7b"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7c6c3fbe3248ab70c99c3cb4d40f50ed081de07d"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbbee1a9c10d64fd67c35833dac4eaf307d44569d"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0bdd3f6ec2fd45f5647bcb92f546d8f1377ebf30"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x09ac022b6fbcc56dcb946c703e39db006fd0c419"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcaa593c06f29e2cd56373761b75fe77e56c9e069"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x69f5c172aca542a9483eff7eb854957ba7137097"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x21757f6d3af44047cb5775b21db3cf90d19757d9"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xef763e4f0deb2b5a114e0a31fd7ec63407d31766"}, {name: "_value", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x23d07e110baec060afaf492a4e52924442b0ca59"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x14b560e5effdf219d2f363593053f77a2c34fb0d"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe85fd3eff890e0195998120465bdc5330dc19c57"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x8c0547b848e1f8031e2347065faa149f4a3fdf8b"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x2724138648b134a8792b28baa4444230de68cbbd"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x0e8e5ad47fe7d24024ca66677e67eb1446f222c0"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x265a1a6605cfeaf8593460c5d77639b3e46354cb"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x0537a2b93dca3bd723965781df8e569dcbc58211"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x246d2d8670cec3d65eb3d7887e0585261d2bca0f"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe4adc923ae77bb9fec022c3ad52d52f81cc5ac21"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xf0e63d4c5079629f59aec6ba3466f52d88306d03"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x389b675cdd46602197f71d0ac0b422e850f9cecd"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xf06b144e392edaea080f2ebab3a1d3eceaf4176f"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x04d0dc750022ac254645797e3a07394a32111393"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xa7487fefe0a907b660c195e2183c4736b548cb13"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x8d531b74bd532b4fc31d338f395a898c38b8db7b"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7c6c3fbe3248ab70c99c3cb4d40f50ed081de07d"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xbbee1a9c10d64fd67c35833dac4eaf307d44569d"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x0bdd3f6ec2fd45f5647bcb92f546d8f1377ebf30"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x09ac022b6fbcc56dcb946c703e39db006fd0c419"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xcaa593c06f29e2cd56373761b75fe77e56c9e069"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x69f5c172aca542a9483eff7eb854957ba7137097"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x21757f6d3af44047cb5775b21db3cf90d19757d9"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xef763e4f0deb2b5a114e0a31fd7ec63407d31766"}, {name: "_amount", type: "uint256", value: "200000000000000"}, {name: "_balance", type: "uint256", value: "200000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[109], \"198400000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591967", timeStamp: "1540627179", hash: "0xf563b09cb3b94e5fd21079a5669d693656c728142d15f8cd7bbfa2bd75554125", nonce: "157", blockHash: "0x53d560515d314e6c83a649a4f5a97ec1823c7004588c6dda0a311c0f5f14f268", transactionIndex: "119", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54379", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d00000000000000000000000048a6578ad5162752fa29d38f3c8b0d857d20d5680000000000000000000000000000000000000000000000000000b47199860000", contractAddress: "", cumulativeGasUsed: "7493186", gasUsed: "54379", confirmations: "1143076"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[109]}, {type: "uint256", name: "_amount", value: "198400000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[109], "198400000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540627179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x48a6578ad5162752fa29d38f3c8b0d857d20d568"}, {name: "_value", type: "uint256", value: "198400000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x48a6578ad5162752fa29d38f3c8b0d857d20d568"}, {name: "_amount", type: "uint256", value: "198400000000000"}, {name: "_balance", type: "uint256", value: "198400000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdropMultiple( [addressList[110],addressList[111],addre... )", async function( ) {
		const txOriginal = {blockNumber: "6591969", timeStamp: "1540627214", hash: "0x90a22df9ac282d0bff03940c2fa02dd94d7aabf48ab884e90564a51c2a142eb4", nonce: "158", blockHash: "0x67e92a632ad94afc7e610eeb7d0c6311854c959e9c6e55911dd54e4413087391", transactionIndex: "98", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "151257", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x67220fd700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000886c98b76000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000055bbb6878ac4e7aa202716c45374d374d6011693000000000000000000000000d0dcfe5bd6ecccf14adec89111746f41cf806ec10000000000000000000000007f3233c101e8662c24989b4048022f5b2e7c7ea800000000000000000000000036560f050ca156ab9c5c2bee4ceb221fd6c5c44f", contractAddress: "", cumulativeGasUsed: "6795623", gasUsed: "151257", confirmations: "1143074"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[110],addressList[111],addressList[112],addressList[113]]}, {type: "uint256", name: "_amount", value: "150000000000000"}], name: "adminClaimAirdropMultiple", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdropMultiple(address[],uint256)" ]( [addressList[110],addressList[111],addressList[112],addressList[113]], "150000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540627214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x55bbb6878ac4e7aa202716c45374d374d6011693"}, {name: "_value", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd0dcfe5bd6ecccf14adec89111746f41cf806ec1"}, {name: "_value", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7f3233c101e8662c24989b4048022f5b2e7c7ea8"}, {name: "_value", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x36560f050ca156ab9c5c2bee4ceb221fd6c5c44f"}, {name: "_value", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x55bbb6878ac4e7aa202716c45374d374d6011693"}, {name: "_amount", type: "uint256", value: "150000000000000"}, {name: "_balance", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xd0dcfe5bd6ecccf14adec89111746f41cf806ec1"}, {name: "_amount", type: "uint256", value: "150000000000000"}, {name: "_balance", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x7f3233c101e8662c24989b4048022f5b2e7c7ea8"}, {name: "_amount", type: "uint256", value: "150000000000000"}, {name: "_balance", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}, {name: "Airdrop", events: [{name: "_owner", type: "address", value: "0x36560f050ca156ab9c5c2bee4ceb221fd6c5c44f"}, {name: "_amount", type: "uint256", value: "150000000000000"}, {name: "_balance", type: "uint256", value: "150000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[114], \"130000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591969", timeStamp: "1540627214", hash: "0x23a23aefce2ab1247a3d8dcdfe7f817e7d997263c0915ff0cbfe07ffab14f88e", nonce: "159", blockHash: "0x67e92a632ad94afc7e610eeb7d0c6311854c959e9c6e55911dd54e4413087391", transactionIndex: "99", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3010000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000e6b76ec36b5584a9dd9b86b7f80b268e8255d5260000000000000000000000000000000000000000000000000000763bfbd22000", contractAddress: "", cumulativeGasUsed: "6850066", gasUsed: "54443", confirmations: "1143074"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[114]}, {type: "uint256", name: "_amount", value: "130000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[114], "130000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540627214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe6b76ec36b5584a9dd9b86b7f80b268e8255d526"}, {name: "_value", type: "uint256", value: "130000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xe6b76ec36b5584a9dd9b86b7f80b268e8255d526"}, {name: "_amount", type: "uint256", value: "130000000000000"}, {name: "_balance", type: "uint256", value: "130000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: adminClaimAirdrop( addressList[115], \"120000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6591975", timeStamp: "1540627265", hash: "0x146d319c17dc285615e15f7c2e4b5febed1973b83082ff66d01ac8c9827adca9", nonce: "160", blockHash: "0x4cce49f46e453ec6707349d165fd83223c57b3b20d1b4f7da627be6846cbf018", transactionIndex: "102", from: "0xea4cbb776f5970e1f5a0ed04b5790c269bb8cd18", to: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107", value: "0", gas: "54443", gasPrice: "3050000000", isError: "0", txreceipt_status: "1", input: "0x4a63464d000000000000000000000000a17b4b0658124bfbbd815a906776a508c658e6cf00000000000000000000000000000000000000000000000000006d23ad5f8000", contractAddress: "", cumulativeGasUsed: "5031371", gasUsed: "54443", confirmations: "1143068"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_participant", value: addressList[115]}, {type: "uint256", name: "_amount", value: "120000000000000"}], name: "adminClaimAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminClaimAirdrop(address,uint256)" ]( addressList[115], "120000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540627265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa17b4b0658124bfbbd815a906776a508c658e6cf"}, {name: "_value", type: "uint256", value: "120000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_balance", type: "uint256"}], name: "Airdrop", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Airdrop", events: [{name: "_owner", type: "address", value: "0xa17b4b0658124bfbbd815a906776a508c658e6cf"}, {name: "_amount", type: "uint256", value: "120000000000000"}, {name: "_balance", type: "uint256", value: "120000000000000"}], address: "0x1b6089efb8932f5fd47d98c8a5eabd77ed7e8107"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1631788568713620" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
