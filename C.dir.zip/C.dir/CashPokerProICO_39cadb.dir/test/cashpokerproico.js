const CashPokerProICO = artifacts.require( "./CashPokerProICO.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CashPokerProICO" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xA746A9A309e7D498f830cffEB683b6d5bb39CADb", "0x774D91ac35f4e2f94f0E821a03C6eAff8AD4c138", "0xA8F93FAee440644F89059a2c88bdC9BF3Be5e2ea", "0x07C40eAe1f960fB33Ec663dfaBc3993D8436418b", "0xE9AF8AA1C1e32024aC8F4804c636f27F637ab8aF", "0xA0B8b814F2aB93f63A42E37ddcab994b5b21A29B", "0x25adb30498548C7810481FfE0355F22c765D334d", "0x522033F8D7b49227bfC7A56D44b0b2Cbca70DC9b"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "holdTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "holdTokenInvestors", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minInvest", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "holdTokenInvestorsCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isHoldTokens", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "weiAmount", type: "uint256"}], name: "getCountBonus", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "time", type: "uint256"}], name: "getTimeBonus", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "purchaseTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "promoMap", outputs: [{name: "enable", type: "bool"}, {name: "investorPercentToken", type: "uint256"}, {name: "dealer", type: "address"}, {name: "dealerPercentToken", type: "uint256"}, {name: "dealerPercentETH", type: "uint256"}, {name: "buyCount", type: "uint256"}, {name: "investorTokenAmount", type: "uint256"}, {name: "dealerTokenAmount", type: "uint256"}, {name: "investorEthAmount", type: "uint256"}, {name: "dealerEthAmount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sendInvestorIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TokenPurchase(address,address,uint256,uint256)", "Pause()", "Unpause()"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x623b3804fa71d67900d064613da8f94b9617215ee90799290593e1745087ad18", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4395305 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4419911 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "CashPokerProICO", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "holdTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "holdTokens(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "holdTokenInvestors", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "holdTokenInvestors(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minInvest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minInvest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "holdTokenInvestorsCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "holdTokenInvestorsCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isHoldTokens", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isHoldTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "weiAmount", value: random.range( maxRandom )}], name: "getCountBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCountBonus(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "time", value: random.range( maxRandom )}], name: "getTimeBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTimeBonus(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "purchaseTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "purchaseTokens(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "promoMap", outputs: [{name: "enable", type: "bool"}, {name: "investorPercentToken", type: "uint256"}, {name: "dealer", type: "address"}, {name: "dealerPercentToken", type: "uint256"}, {name: "dealerPercentETH", type: "uint256"}, {name: "buyCount", type: "uint256"}, {name: "investorTokenAmount", type: "uint256"}, {name: "dealerTokenAmount", type: "uint256"}, {name: "investorEthAmount", type: "uint256"}, {name: "dealerEthAmount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "promoMap(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sendInvestorIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sendInvestorIndex()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CashPokerProICO", function( accounts ) {

	it( "TEST: CashPokerProICO(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4395305", timeStamp: "1508498058", hash: "0x7892410943683b2e4be9a3294e8b186cd94da0822a4f72e60689445a7341c0af", nonce: "0", blockHash: "0xb662a4098fc162efe087f3bfa45e7f3fcafc38ebd5c061676b002068498ea6e7", transactionIndex: "29", from: "0x07c40eae1f960fb33ec663dfabc3993d8436418b", to: 0, value: "0", gas: "3391375", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x221d08c7", contractAddress: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", cumulativeGasUsed: "4491208", gasUsed: "3391375", confirmations: "3325142"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "CashPokerProICO", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CashPokerProICO.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508498058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CashPokerProICO.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "4407516", timeStamp: "1508665634", hash: "0x4a37555a128a3811cb868ee34c97413d90ba5dadc22f688c16a9fcccc34b760b", nonce: "1", blockHash: "0xeaa77d06a06923562360129d751e8e829c33d2e30032e9167ba340e0efe465e3", transactionIndex: "25", from: "0x07c40eae1f960fb33ec663dfabc3993d8436418b", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "29031", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b000000000000000000000000e9af8aa1c1e32024ac8f4804c636f27f637ab8af", contractAddress: "", cumulativeGasUsed: "576414", gasUsed: "29031", confirmations: "3312931"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[6]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508665634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4408234", timeStamp: "1508675617", hash: "0xda2f076bdda008a8438a0690c72fcd2c801ee08c54b0ba958c9935b3de4e7b6a", nonce: "39", blockHash: "0x07b36ba510d85d30f729cc9d61431b936a28633b0f402230a44f0a4f48688983", transactionIndex: "3", from: "0xa0b8b814f2ab93f63a42e37ddcab994b5b21a29b", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "1000000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "139405", gasUsed: "21655", confirmations: "3312213"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508675617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "20445167237520453130" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4413225", timeStamp: "1508745342", hash: "0x5daa759a5716f68ca57f1764e01b6090509c8305cd8639124d94fb5719235ac5", nonce: "22", blockHash: "0x6dfc208359bbbbb9a41475e9221b61a0c6fb78292196a2ff2ba3cbf93fd75489", transactionIndex: "0", from: "0x25adb30498548c7810481ffe0355f22c765d334d", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "800000000000000000", gas: "300000", gasPrice: "25000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "21655", gasUsed: "21655", confirmations: "3307222"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "800000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508745342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "3095708293317098" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x000947a90e7992a27b0a097e1360b62914c4... )", async function( ) {
		const txOriginal = {blockNumber: "4419697", timeStamp: "1508835084", hash: "0x0979f981dbf02cef2b5e091bc1a1d7bfe579a8af7d72c7bc6a7054157715aca1", nonce: "0", blockHash: "0x604daafa34c121586b9d160c50ee0251b24e01452c23f9a94f307c22e1037400", transactionIndex: "36", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17000947a90e7992a27b0a097e1360b62914c4a9e16d84a08ea0e6d673ed3f19960000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1834497", gasUsed: "137376", confirmations: "3300750"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x000947a90e7992a27b0a097e1360b62914c4a9e16d84a08ea0e6d673ed3f1996"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x000947a90e7992a27b0a097e1360b62914c4a9e16d84a08ea0e6d673ed3f1996", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508835084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00187778ee8e595ab9b11828bed5587c77b2... )", async function( ) {
		const txOriginal = {blockNumber: "4419738", timeStamp: "1508835494", hash: "0xf80a8b8a795900ef093a9df20803ad30ceb788281ebda15b443e913bf65677c7", nonce: "1", blockHash: "0xb6997248ad3dd2b9ba5a8f86b8ab766cc248a6f10bb07f24e4ab56b954daba34", transactionIndex: "12", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700187778ee8e595ab9b11828bed5587c77b20ba4f4351c18dc595a61d19adbd10000000000000000000000000000000000000000000000000000000000000001000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "453152", gasUsed: "137376", confirmations: "3300709"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00187778ee8e595ab9b11828bed5587c77b20ba4f4351c18dc595a61d19adbd1"}, {type: "uint256", name: "userPercentToken", value: "1"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00187778ee8e595ab9b11828bed5587c77b20ba4f4351c18dc595a61d19adbd1", "1", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508835494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x001fe748946e9b8f806e3ce8d299a7fcf903... )", async function( ) {
		const txOriginal = {blockNumber: "4419751", timeStamp: "1508835654", hash: "0x0a7084d5490f658c7fa3a93c2e1f3ab88381f338481a883d0eaeda30d024d0c2", nonce: "2", blockHash: "0xabb3c9855470578ba4689289bd88c125da260e8f3acf2bb00857ede8a8a5c2fd", transactionIndex: "5", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17001fe748946e9b8f806e3ce8d299a7fcf90389590f14b4811bd49c922633f9100000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "318835", gasUsed: "137376", confirmations: "3300696"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x001fe748946e9b8f806e3ce8d299a7fcf90389590f14b4811bd49c922633f910"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x001fe748946e9b8f806e3ce8d299a7fcf90389590f14b4811bd49c922633f910", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508835654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x001ff000f5273f31f6c0ff104ba39d1451ad... )", async function( ) {
		const txOriginal = {blockNumber: "4419753", timeStamp: "1508835727", hash: "0xbd447c2b8eecb621a972f35e8322b652e60ee5395f8f5ff28bc61d72111bfc8f", nonce: "3", blockHash: "0x7789fd78faf6d27343ebee9ff4f75b7ad9ec3cc2007e81dd8cfb4211478e47c4", transactionIndex: "88", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137312", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17001ff000f5273f31f6c0ff104ba39d1451ade01e9093364946bc9d5d4ec3b64f0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "2866027", gasUsed: "137312", confirmations: "3300694"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x001ff000f5273f31f6c0ff104ba39d1451ade01e9093364946bc9d5d4ec3b64f"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x001ff000f5273f31f6c0ff104ba39d1451ade01e9093364946bc9d5d4ec3b64f", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508835727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0027c8f6daabc106338e0cfc13044fad95c0... )", async function( ) {
		const txOriginal = {blockNumber: "4419755", timeStamp: "1508835782", hash: "0xc3080ed87c8a1bd1c2007cd30bd1410ebc1abeb4a4afedce108943af02fa45de", nonce: "4", blockHash: "0x8521f7abd96fdbf52d24d394643574eb43cabeaedacf17bc0e12f450e8d4e973", transactionIndex: "31", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170027c8f6daabc106338e0cfc13044fad95c043a04acddbc6753044ed5dcaabdd0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "2098792", gasUsed: "137376", confirmations: "3300692"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0027c8f6daabc106338e0cfc13044fad95c043a04acddbc6753044ed5dcaabdd"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0027c8f6daabc106338e0cfc13044fad95c043a04acddbc6753044ed5dcaabdd", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508835782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00285be519d9ccd5c3600f73a7941ac27b6f... )", async function( ) {
		const txOriginal = {blockNumber: "4419762", timeStamp: "1508835845", hash: "0x7628c05b15af4262bdf2ccfbc8935aafa5dfbdcaead7f46828e9f57a214dca3d", nonce: "5", blockHash: "0xc5d24405b8445325e06ec24dae397afc768538e13cbcc6c20642a3ab644ffcb6", transactionIndex: "12", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700285be519d9ccd5c3600f73a7941ac27b6fc7ddac2138d75e172cda2d713edb0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "577771", gasUsed: "137376", confirmations: "3300685"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00285be519d9ccd5c3600f73a7941ac27b6fc7ddac2138d75e172cda2d713edb"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00285be519d9ccd5c3600f73a7941ac27b6fc7ddac2138d75e172cda2d713edb", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508835845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x002e95b450345fc5fc6349e546cd3f290618... )", async function( ) {
		const txOriginal = {blockNumber: "4419765", timeStamp: "1508835867", hash: "0xc211b9984eff6508bd797fb6f990642bfe7100a175381a2b7f1f9ae6c5a6d569", nonce: "6", blockHash: "0x094a8fd6e4d93ffcd00ed54e6ec10f2c9434965629156b95826caa24a769eba3", transactionIndex: "18", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17002e95b450345fc5fc6349e546cd3f29061839f541090c6969d16cf123e9cefb0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "719173", gasUsed: "137376", confirmations: "3300682"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x002e95b450345fc5fc6349e546cd3f29061839f541090c6969d16cf123e9cefb"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x002e95b450345fc5fc6349e546cd3f29061839f541090c6969d16cf123e9cefb", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508835867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x002f92ee1953b213c76b556db3ee5a667a8c... )", async function( ) {
		const txOriginal = {blockNumber: "4419776", timeStamp: "1508836010", hash: "0x744637fc45980f3b8b86ef5995e8dbefb7be841f0668eedfc1d60f5d022d2773", nonce: "7", blockHash: "0x5638f793eb7de1a57391cc36d818a3975bf7c34471416f208a5946190becbd71", transactionIndex: "38", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17002f92ee1953b213c76b556db3ee5a667a8c27081b56b58a0e83888c1e908bf60000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1813205", gasUsed: "137376", confirmations: "3300671"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x002f92ee1953b213c76b556db3ee5a667a8c27081b56b58a0e83888c1e908bf6"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x002f92ee1953b213c76b556db3ee5a667a8c27081b56b58a0e83888c1e908bf6", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508836010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0035f612c4dda2def92c05ee53ac1eca44b8... )", async function( ) {
		const txOriginal = {blockNumber: "4419780", timeStamp: "1508836059", hash: "0x19937bdc1de72f292bf76372f6c8eaa8588b39144d1b157193abde7e6ab9b93a", nonce: "8", blockHash: "0x19aa6edc0bdff68b845a8939abac56102f5f237dc6ea3a4c94bd9899b006e48a", transactionIndex: "4", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170035f612c4dda2def92c05ee53ac1eca44b8a9115647f6df4906858097fe6be10000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "223404", gasUsed: "137376", confirmations: "3300667"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0035f612c4dda2def92c05ee53ac1eca44b8a9115647f6df4906858097fe6be1"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0035f612c4dda2def92c05ee53ac1eca44b8a9115647f6df4906858097fe6be1", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508836059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0046128b3d327550db69fbb8da1122744deb... )", async function( ) {
		const txOriginal = {blockNumber: "4419785", timeStamp: "1508836147", hash: "0x49692f2e7d953d069fd461c8ff95c7477f70a12b2924ba55355775ba3682130c", nonce: "9", blockHash: "0xa6e57624b151125efd1e4d685dfcbf1f3333917653dd8317d812304d4aa1f2f9", transactionIndex: "20", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137312", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170046128b3d327550db69fbb8da1122744deb2afff813007c0af39783288d31450000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1192647", gasUsed: "137312", confirmations: "3300662"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0046128b3d327550db69fbb8da1122744deb2afff813007c0af39783288d3145"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0046128b3d327550db69fbb8da1122744deb2afff813007c0af39783288d3145", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508836147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00419d93d00ccc7e7be8b9416a4a9d70bf49... )", async function( ) {
		const txOriginal = {blockNumber: "4419787", timeStamp: "1508836182", hash: "0x0e918b7a5f89a876f7b13186e5dd0d8e9812a93e54010e07ad90700c3083a573", nonce: "10", blockHash: "0x08e70475b6cf43ae46d2904b6f520436cf4bc0d9dc22eebad3e58cc72212d185", transactionIndex: "59", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700419d93d00ccc7e7be8b9416a4a9d70bf49db44e6a03e06754e155890635cd20000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1808682", gasUsed: "137376", confirmations: "3300660"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00419d93d00ccc7e7be8b9416a4a9d70bf49db44e6a03e06754e155890635cd2"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00419d93d00ccc7e7be8b9416a4a9d70bf49db44e6a03e06754e155890635cd2", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508836182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x005c7c00cf42598964636cc71a9130b10bfb... )", async function( ) {
		const txOriginal = {blockNumber: "4419789", timeStamp: "1508836206", hash: "0xfcce0e69f7aa5ae30995e9bc6b26e381127034fe542bae0f22583b02feba8856", nonce: "11", blockHash: "0x700dadbf87e92c1589fa7d07ffe5d399d8e2c5332166e4a5429216feb9685f41", transactionIndex: "9", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137312", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17005c7c00cf42598964636cc71a9130b10bfbece191b8c8c404e97934f21f9d6b0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "474125", gasUsed: "137312", confirmations: "3300658"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x005c7c00cf42598964636cc71a9130b10bfbece191b8c8c404e97934f21f9d6b"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x005c7c00cf42598964636cc71a9130b10bfbece191b8c8c404e97934f21f9d6b", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508836206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x005dd8daf116a28b2d8f46a0b96ef0f3e268... )", async function( ) {
		const txOriginal = {blockNumber: "4419804", timeStamp: "1508836345", hash: "0xb8108f0f525e25a3d7ac48b2e9c4e3759abf4dd5a9f78ea6f9ce0db8bae651ab", nonce: "12", blockHash: "0xc16a21e998e7ad646b6fc952a789ee538fa85305b9fbfe446c1614cc6c867939", transactionIndex: "7", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17005dd8daf116a28b2d8f46a0b96ef0f3e26893688d116ab4c8cd3c0372a95b1b0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "427050", gasUsed: "137376", confirmations: "3300643"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x005dd8daf116a28b2d8f46a0b96ef0f3e26893688d116ab4c8cd3c0372a95b1b"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x005dd8daf116a28b2d8f46a0b96ef0f3e26893688d116ab4c8cd3c0372a95b1b", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508836345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x005eff5e4b4243857f6003b1ac0cad1ded68... )", async function( ) {
		const txOriginal = {blockNumber: "4419806", timeStamp: "1508836382", hash: "0xe0e2c07c42da7050ff95c95290568b71ffa140d72fb0aea6bdaf4d4dce676f55", nonce: "13", blockHash: "0x473c53679c2c56323c6fe1ec356bc7ef135b8f818dfe72e245931edfe0a8de5e", transactionIndex: "18", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17005eff5e4b4243857f6003b1ac0cad1ded68bc6ef7191512130cfd7d271a30b00000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1129744", gasUsed: "137376", confirmations: "3300641"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x005eff5e4b4243857f6003b1ac0cad1ded68bc6ef7191512130cfd7d271a30b0"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x005eff5e4b4243857f6003b1ac0cad1ded68bc6ef7191512130cfd7d271a30b0", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508836382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0078faa988f80f9c00e28ff8cb87e0a61970... )", async function( ) {
		const txOriginal = {blockNumber: "4419808", timeStamp: "1508836424", hash: "0x2d49d6620c1e026984c36d9796d2cb5328b15d73fbec2e65db903d842bafe23d", nonce: "14", blockHash: "0x9b86e8e13fc0dc6a2fd00799590a33ed46ea098c156035f7f2282fc40b255a10", transactionIndex: "9", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137312", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170078faa988f80f9c00e28ff8cb87e0a6197017cb48ffad8548a035e4047fd4760000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "418447", gasUsed: "137312", confirmations: "3300639"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0078faa988f80f9c00e28ff8cb87e0a6197017cb48ffad8548a035e4047fd476"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0078faa988f80f9c00e28ff8cb87e0a6197017cb48ffad8548a035e4047fd476", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508836424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00835cc1d6c28b90d8f2a5620dfcbbc7721c... )", async function( ) {
		const txOriginal = {blockNumber: "4419809", timeStamp: "1508836437", hash: "0xb5ab02d7f81da1bf94c7486bf3bb747715bf25bc3777ceaeb772947c12872d9f", nonce: "15", blockHash: "0xe202665508f51dd52d0e55d0e7020d8d764d34b38f437ff2adba2f6fde2804fc", transactionIndex: "50", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700835cc1d6c28b90d8f2a5620dfcbbc7721cd8ab9aef0e6f0ac703a4950a62150000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "2350305", gasUsed: "137376", confirmations: "3300638"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00835cc1d6c28b90d8f2a5620dfcbbc7721cd8ab9aef0e6f0ac703a4950a6215"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00835cc1d6c28b90d8f2a5620dfcbbc7721cd8ab9aef0e6f0ac703a4950a6215", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508836437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x008a8f699bb1432a403602236392b4859d6e... )", async function( ) {
		const txOriginal = {blockNumber: "4419811", timeStamp: "1508836472", hash: "0x65c366bb798f62855c4373aad2d7687c7ae8a434e925268858556b9ef4d293a4", nonce: "16", blockHash: "0xb5219d358ca196aa1b6ac1c166005d0bb79729875f18e0fd08a8e153810f4d92", transactionIndex: "16", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17008a8f699bb1432a403602236392b4859d6e85959397d1e0f801440a45391f2f0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1185526", gasUsed: "137376", confirmations: "3300636"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x008a8f699bb1432a403602236392b4859d6e85959397d1e0f801440a45391f2f"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x008a8f699bb1432a403602236392b4859d6e85959397d1e0f801440a45391f2f", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508836472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x008fe20594d3f40e2fa4446ff6aa47ff22f0... )", async function( ) {
		const txOriginal = {blockNumber: "4419814", timeStamp: "1508836523", hash: "0xeb89543971799985b565326410ed3ca09762193cb3f15ec25f785cad4c55b750", nonce: "17", blockHash: "0x08f7fc3043ecd495480f75ed6cc6486e1abd2efac885fb674b2ddd2c9d28c9c8", transactionIndex: "62", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17008fe20594d3f40e2fa4446ff6aa47ff22f065fce66381853330fad5e7bcefcc0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1715878", gasUsed: "137376", confirmations: "3300633"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x008fe20594d3f40e2fa4446ff6aa47ff22f065fce66381853330fad5e7bcefcc"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x008fe20594d3f40e2fa4446ff6aa47ff22f065fce66381853330fad5e7bcefcc", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508836523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00972519f6c1feaab593e2ae7722aabd10d0... )", async function( ) {
		const txOriginal = {blockNumber: "4419815", timeStamp: "1508836530", hash: "0x913d801d81c51cbea723e20778c64eb986edb96c4ef72421487d1b438ed95325", nonce: "18", blockHash: "0xe912d654cb3fe4b2f43d5a0c260e1a632efc3de25d5449c6f8e8f3077dcb6fda", transactionIndex: "25", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700972519f6c1feaab593e2ae7722aabd10d088706ee0d301400a71678aee1be10000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1718486", gasUsed: "137376", confirmations: "3300632"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00972519f6c1feaab593e2ae7722aabd10d088706ee0d301400a71678aee1be1"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00972519f6c1feaab593e2ae7722aabd10d088706ee0d301400a71678aee1be1", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508836530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x009ccf59a3e8b2894fcd494b7dda50bfdc9b... )", async function( ) {
		const txOriginal = {blockNumber: "4419817", timeStamp: "1508836568", hash: "0x32c69a3775d4604e950ba345e478c6e715571b0caf2dd9be7cf615330563f22d", nonce: "19", blockHash: "0x948c163cc20917bd84854a45a61efa2ae91cf924f905afede7e653c581058040", transactionIndex: "49", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17009ccf59a3e8b2894fcd494b7dda50bfdc9b4333a07e80b2cc1a436dd4101b640000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1934813", gasUsed: "137376", confirmations: "3300630"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x009ccf59a3e8b2894fcd494b7dda50bfdc9b4333a07e80b2cc1a436dd4101b64"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x009ccf59a3e8b2894fcd494b7dda50bfdc9b4333a07e80b2cc1a436dd4101b64", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508836568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00a3b03177738e86e3c0f9b9027d742f9806... )", async function( ) {
		const txOriginal = {blockNumber: "4419818", timeStamp: "1508836591", hash: "0x4763e24d8dbe13a78c0246aacbcc79d736d12a1ce6a9065c7103bfd4dddc3c8a", nonce: "20", blockHash: "0x1c72cc7c42cc211d91fc9b3bbb384ef895ebb28261d5d52f651dc16567ca3655", transactionIndex: "10", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700a3b03177738e86e3c0f9b9027d742f9806a741805fa4d40502d647d3761c1f0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "479774", gasUsed: "137376", confirmations: "3300629"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00a3b03177738e86e3c0f9b9027d742f9806a741805fa4d40502d647d3761c1f"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00a3b03177738e86e3c0f9b9027d742f9806a741805fa4d40502d647d3761c1f", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508836591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00a65bc9da3611b8561362d65422ede2e114... )", async function( ) {
		const txOriginal = {blockNumber: "4419821", timeStamp: "1508836629", hash: "0xc27548ecdd1392055a36ef03816fc563ff631c5afdd3bda1741a27e3a8cd4aa9", nonce: "21", blockHash: "0xeddcd33bb33357f1a46c553b5da84e146c2b2dbac41329e2a01b80d2babb9183", transactionIndex: "31", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700a65bc9da3611b8561362d65422ede2e114ebda4d2fdb21ed95d9605d026d530000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1442839", gasUsed: "137376", confirmations: "3300626"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00a65bc9da3611b8561362d65422ede2e114ebda4d2fdb21ed95d9605d026d53"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00a65bc9da3611b8561362d65422ede2e114ebda4d2fdb21ed95d9605d026d53", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508836629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00ab84b25562962116481f94653c14c5028b... )", async function( ) {
		const txOriginal = {blockNumber: "4419824", timeStamp: "1508836652", hash: "0xce8d36cc122ed8e77f70e2898a86a4b8b4ce19b58ca7f641384b5f27e3aa3ea4", nonce: "22", blockHash: "0x0a18c9f8a5f9985c5a4c539759813a900a18796f057e173b98863e4858cd77d5", transactionIndex: "28", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700ab84b25562962116481f94653c14c5028b128ff444c7948ae8847802ede3420000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "983293", gasUsed: "137376", confirmations: "3300623"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00ab84b25562962116481f94653c14c5028b128ff444c7948ae8847802ede342"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00ab84b25562962116481f94653c14c5028b128ff444c7948ae8847802ede342", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508836652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00abeedefb347db51fb03f20338adca89b13... )", async function( ) {
		const txOriginal = {blockNumber: "4419826", timeStamp: "1508836685", hash: "0xe8d159e6149669e8e1865b4a2b6964a4c2df615f90220f4ec6bbf9d6a0b013c9", nonce: "23", blockHash: "0x6efbf8fb15386943433e73554f257235ae2ba87ff1807de7714afc8b9c063c28", transactionIndex: "29", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700abeedefb347db51fb03f20338adca89b132e177bb6e462998b8e5d1f8920410000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1230106", gasUsed: "137376", confirmations: "3300621"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00abeedefb347db51fb03f20338adca89b132e177bb6e462998b8e5d1f892041"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00abeedefb347db51fb03f20338adca89b132e177bb6e462998b8e5d1f892041", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508836685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00b75555abce6922afef6b27029599bf32e4... )", async function( ) {
		const txOriginal = {blockNumber: "4419828", timeStamp: "1508836706", hash: "0x9e6f8cd2de80476b139a433544d0173c583e2d256e81c4a0494af109ce9fea5b", nonce: "24", blockHash: "0xb049a9fbe2e243f0a9d5a77933079cfe301464cb9165185c0b9a1b48e91ac957", transactionIndex: "11", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700b75555abce6922afef6b27029599bf32e4c491a8532d6bb24501b528f468e60000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "949647", gasUsed: "137376", confirmations: "3300619"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00b75555abce6922afef6b27029599bf32e4c491a8532d6bb24501b528f468e6"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00b75555abce6922afef6b27029599bf32e4c491a8532d6bb24501b528f468e6", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508836706 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00b95c5bd6b11f381c2ead038eacbe561333... )", async function( ) {
		const txOriginal = {blockNumber: "4419832", timeStamp: "1508836744", hash: "0x3707850d041b6689cefe77260b4214d337c0b60b74149225f09da992c72d9255", nonce: "25", blockHash: "0x05448a0d77563e002c27aee6ae38410b4f9aac1f3b31046cee6fe7f263c23dd1", transactionIndex: "7", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700b95c5bd6b11f381c2ead038eacbe561333d931e8658c241024e7984b7c38480000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "469384", gasUsed: "137376", confirmations: "3300615"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00b95c5bd6b11f381c2ead038eacbe561333d931e8658c241024e7984b7c3848"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00b95c5bd6b11f381c2ead038eacbe561333d931e8658c241024e7984b7c3848", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508836744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00ba8c25620c4191a8833f9d667c1357b10f... )", async function( ) {
		const txOriginal = {blockNumber: "4419835", timeStamp: "1508836789", hash: "0xfcd82adaccd4fbe47982a0b4315ed235fabad85b049db09ae1a1b051ab1ad203", nonce: "26", blockHash: "0x171a3c5e0271fd97f74820dd2d97c5cd180fed82438ae7223d9c073ff0ecea75", transactionIndex: "18", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700ba8c25620c4191a8833f9d667c1357b10fb6913dcf7d503dc8fca77ba0c2f40000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1400008", gasUsed: "137376", confirmations: "3300612"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00ba8c25620c4191a8833f9d667c1357b10fb6913dcf7d503dc8fca77ba0c2f4"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00ba8c25620c4191a8833f9d667c1357b10fb6913dcf7d503dc8fca77ba0c2f4", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508836789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00bea93482e0d380b831e52dbb9c3bc18dde... )", async function( ) {
		const txOriginal = {blockNumber: "4419838", timeStamp: "1508836828", hash: "0xeb55b4d259ed3363c8f3d3d019f894a95da980e9287663f5b56c29b859b566e9", nonce: "27", blockHash: "0xb5f7d7cf66f5b7bd48bc45d3a982bb531cab0702a1ca1e629c0c16338c44f163", transactionIndex: "69", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700bea93482e0d380b831e52dbb9c3bc18dde8a0a5bafb515cbac1ae011d8a9720000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "3191115", gasUsed: "137376", confirmations: "3300609"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00bea93482e0d380b831e52dbb9c3bc18dde8a0a5bafb515cbac1ae011d8a972"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00bea93482e0d380b831e52dbb9c3bc18dde8a0a5bafb515cbac1ae011d8a972", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508836828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00bef235c626401408ae69aff2d483858610... )", async function( ) {
		const txOriginal = {blockNumber: "4419839", timeStamp: "1508836846", hash: "0x459520057fcab75dd5998ea3905c9ea810d4f746e8f94e22aebbcb9013ddbf33", nonce: "28", blockHash: "0x205740abd3241e46aac58815b8baaa270605eafad47c792ff623036d170bb787", transactionIndex: "9", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700bef235c626401408ae69aff2d483858610bfa8790691dffe4f59d9c5b76f3d0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "522490", gasUsed: "137376", confirmations: "3300608"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00bef235c626401408ae69aff2d483858610bfa8790691dffe4f59d9c5b76f3d"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00bef235c626401408ae69aff2d483858610bfa8790691dffe4f59d9c5b76f3d", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508836846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00cf9c32f6e550662ea3fc726b859f91dd62... )", async function( ) {
		const txOriginal = {blockNumber: "4419842", timeStamp: "1508836886", hash: "0x00b77286027c82385a58f6b8a9704737453c0ec65c7a14c49e55712547160215", nonce: "29", blockHash: "0x7597d87fb19124a949dde1b9affd916a5658e896331132df719f82e104b13290", transactionIndex: "13", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700cf9c32f6e550662ea3fc726b859f91dd621510c2ddce502e5729f17d4f4c6f0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "841625", gasUsed: "137376", confirmations: "3300605"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00cf9c32f6e550662ea3fc726b859f91dd621510c2ddce502e5729f17d4f4c6f"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00cf9c32f6e550662ea3fc726b859f91dd621510c2ddce502e5729f17d4f4c6f", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1508836886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00dd948444d179e3d6fda1211b1190753e3e... )", async function( ) {
		const txOriginal = {blockNumber: "4419842", timeStamp: "1508836886", hash: "0x095e18872571676e814dbd88bfb02fb40bde223ccba44bffc632b517c1a7a6fc", nonce: "30", blockHash: "0x7597d87fb19124a949dde1b9affd916a5658e896331132df719f82e104b13290", transactionIndex: "98", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700dd948444d179e3d6fda1211b1190753e3e8ad3b49c35329e0863a0b98af3430000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "4296565", gasUsed: "137376", confirmations: "3300605"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00dd948444d179e3d6fda1211b1190753e3e8ad3b49c35329e0863a0b98af343"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00dd948444d179e3d6fda1211b1190753e3e8ad3b49c35329e0863a0b98af343", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508836886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00e4c7d5efad41b2d40506027df68384e71c... )", async function( ) {
		const txOriginal = {blockNumber: "4419847", timeStamp: "1508836929", hash: "0x79e74855c0f23cade72bb3363328ea0b3e4b9aad150c5b5ebfd68328f1c2afd6", nonce: "31", blockHash: "0x557c385c5d8edcd1e6846c9b311981a034b14bf9ec6557ddef6702f7921dbb5d", transactionIndex: "19", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700e4c7d5efad41b2d40506027df68384e71c4182c94cf52dd8e20f20a0ef4d290000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1060939", gasUsed: "137376", confirmations: "3300600"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00e4c7d5efad41b2d40506027df68384e71c4182c94cf52dd8e20f20a0ef4d29"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00e4c7d5efad41b2d40506027df68384e71c4182c94cf52dd8e20f20a0ef4d29", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508836929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00e55bae2eff3dd5622b8510872057764007... )", async function( ) {
		const txOriginal = {blockNumber: "4419848", timeStamp: "1508836959", hash: "0xde0485ed7cc0b859691713fb6eb0ea527000e2944e3f0d806ea4398c559a272e", nonce: "32", blockHash: "0xa2c65f2e60058c435a014fa20bcf37901206cf5389127a48ed93cfecd9aac4c5", transactionIndex: "47", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700e55bae2eff3dd5622b85108720577640074d19d550f901c3e711daf35435c70000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1536482", gasUsed: "137376", confirmations: "3300599"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00e55bae2eff3dd5622b85108720577640074d19d550f901c3e711daf35435c7"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00e55bae2eff3dd5622b85108720577640074d19d550f901c3e711daf35435c7", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508836959 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x00e6ca89d7b6b20518d4f01bbe1af04ea661... )", async function( ) {
		const txOriginal = {blockNumber: "4419848", timeStamp: "1508836959", hash: "0xf8ea46d1cb0cca93fb1dbc75eb973dba18e45807be80734e7c238bf89d7b01b9", nonce: "33", blockHash: "0xa2c65f2e60058c435a014fa20bcf37901206cf5389127a48ed93cfecd9aac4c5", transactionIndex: "78", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1700e6ca89d7b6b20518d4f01bbe1af04ea661d949bba8a0963bde53185488d17b0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "4187771", gasUsed: "137376", confirmations: "3300599"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x00e6ca89d7b6b20518d4f01bbe1af04ea661d949bba8a0963bde53185488d17b"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x00e6ca89d7b6b20518d4f01bbe1af04ea661d949bba8a0963bde53185488d17b", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508836959 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x01016c413a31dbe6528b17d3b15c0fe4a3e6... )", async function( ) {
		const txOriginal = {blockNumber: "4419854", timeStamp: "1508837005", hash: "0x365467c813fd452f2ffb49fd33e3403ec35a69bde2e23b604b4854e745234dae", nonce: "34", blockHash: "0xf8d11c28d2b5d5112ce8475bc7c33108e77da3aa8667383ff0eb1e53808cf070", transactionIndex: "20", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1701016c413a31dbe6528b17d3b15c0fe4a3e6df81b708682e569343b55f485bc90000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "881815", gasUsed: "137440", confirmations: "3300593"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x01016c413a31dbe6528b17d3b15c0fe4a3e6df81b708682e569343b55f485bc9"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x01016c413a31dbe6528b17d3b15c0fe4a3e6df81b708682e569343b55f485bc9", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508837005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x01094068226016012c03c9fb914321cc3355... )", async function( ) {
		const txOriginal = {blockNumber: "4419855", timeStamp: "1508837021", hash: "0x65b3125a896f519c6b631a33eb9b2f7d6b48a32ae8fb46a31753b23b0e8a7507", nonce: "35", blockHash: "0x15e4313c0c54fdcec878c5a66ba6981ecb36381d90d29c108eb2d4a251737b84", transactionIndex: "26", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1701094068226016012c03c9fb914321cc3355ccb1199e557c3ef4d0f185b600920000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1813770", gasUsed: "137376", confirmations: "3300592"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x01094068226016012c03c9fb914321cc3355ccb1199e557c3ef4d0f185b60092"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x01094068226016012c03c9fb914321cc3355ccb1199e557c3ef4d0f185b60092", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508837021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x011194487b5592a30c29c1ba1ca10702e7b3... )", async function( ) {
		const txOriginal = {blockNumber: "4419863", timeStamp: "1508837060", hash: "0x69713f49b9ce75db2ef52535ade52dd2a791b0573f85b4c4f5c59cd85cae9094", nonce: "36", blockHash: "0x5d575729805365e77d60b11d314195b787b301440d1c729d0d6ec3c9e408d118", transactionIndex: "3", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17011194487b5592a30c29c1ba1ca10702e7b35d412e6824b11fb26fbbe749f37b0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "316351", gasUsed: "137440", confirmations: "3300584"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x011194487b5592a30c29c1ba1ca10702e7b35d412e6824b11fb26fbbe749f37b"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x011194487b5592a30c29c1ba1ca10702e7b35d412e6824b11fb26fbbe749f37b", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1508837060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0111a8921c60d6f8b448e4fe31746ae503b9... )", async function( ) {
		const txOriginal = {blockNumber: "4419866", timeStamp: "1508837091", hash: "0x386024de9e94caa67ba81534d81575cd0f2332cd12872326512e3262d951af39", nonce: "37", blockHash: "0x8a265b869db98427fd63a6520a8c615334b0eab263feb60c6ef36fc1477508aa", transactionIndex: "11", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170111a8921c60d6f8b448e4fe31746ae503b9d9663025c1c3295a6bd3fade342f0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "518920", gasUsed: "137440", confirmations: "3300581"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0111a8921c60d6f8b448e4fe31746ae503b9d9663025c1c3295a6bd3fade342f"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0111a8921c60d6f8b448e4fe31746ae503b9d9663025c1c3295a6bd3fade342f", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508837091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x0119c56e98003bdb9b7318ea9a95609b6380... )", async function( ) {
		const txOriginal = {blockNumber: "4419869", timeStamp: "1508837128", hash: "0x649f82c0317d8c01781282e45d9c3c57457c9b32c54e2f832007b4691b42953d", nonce: "38", blockHash: "0x947926fbe676b500501edc4a982dd05c8495979489cad4f5cefe9877eb54d141", transactionIndex: "7", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137376", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a170119c56e98003bdb9b7318ea9a95609b6380c6a1f93cc292da3adc76ee813a060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "520221", gasUsed: "137376", confirmations: "3300578"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x0119c56e98003bdb9b7318ea9a95609b6380c6a1f93cc292da3adc76ee813a06"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x0119c56e98003bdb9b7318ea9a95609b6380c6a1f93cc292da3adc76ee813a06", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508837128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x011d66e7a8c6dc3cf8650ea8cae6f0239cff... )", async function( ) {
		const txOriginal = {blockNumber: "4419872", timeStamp: "1508837172", hash: "0x8b29f729cf13047fd7efcfb9aee6b3b41555b9505bb10c0324e9a5c2f2c24b1e", nonce: "39", blockHash: "0x530eb3da652caa5e63da8c01d53ce69a4335055bc5b47e82b2a74cd4d41b5380", transactionIndex: "16", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17011d66e7a8c6dc3cf8650ea8cae6f0239cffbcdd929501ec8001e3c5c4d6b2d40000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "750097", gasUsed: "137440", confirmations: "3300575"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x011d66e7a8c6dc3cf8650ea8cae6f0239cffbcdd929501ec8001e3c5c4d6b2d4"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x011d66e7a8c6dc3cf8650ea8cae6f0239cffbcdd929501ec8001e3c5c4d6b2d4", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508837172 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x011f9881f8e1edaba76b7bd8c3d1a8cd9120... )", async function( ) {
		const txOriginal = {blockNumber: "4419894", timeStamp: "1508837505", hash: "0xd70ffff47991050ce9d243959115a56e8ad7aafdc16f40641c28600ac0f9da1a", nonce: "40", blockHash: "0xfb67e2f7a0ab7888495396ed40d8ad4c7bb11a9be97aabfad17a3991dcda9725", transactionIndex: "139", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17011f9881f8e1edaba76b7bd8c3d1a8cd912090545ca804cdb21de3071e5e7dfe0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "3638104", gasUsed: "137440", confirmations: "3300553"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x011f9881f8e1edaba76b7bd8c3d1a8cd912090545ca804cdb21de3071e5e7dfe"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x011f9881f8e1edaba76b7bd8c3d1a8cd912090545ca804cdb21de3071e5e7dfe", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508837505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x01206da9c27d8307785f3fac9cbcaa8c954b... )", async function( ) {
		const txOriginal = {blockNumber: "4419903", timeStamp: "1508837621", hash: "0x1982a41e6361708b818552e6ca340a0d9d432dc03069fda6b34f44f5dc6da0f2", nonce: "41", blockHash: "0x1d7df128e443b23e98b07b631eb2ac6415fe017de1c7876410f4e5114d16dc7d", transactionIndex: "23", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1701206da9c27d8307785f3fac9cbcaa8c954b83a3f6b6fa6e010b37c3f02ae8a80000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1311191", gasUsed: "137440", confirmations: "3300544"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x01206da9c27d8307785f3fac9cbcaa8c954b83a3f6b6fa6e010b37c3f02ae8a8"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x01206da9c27d8307785f3fac9cbcaa8c954b83a3f6b6fa6e010b37c3f02ae8a8", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508837621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x012455d536fdb81eb8edb7a761fafdb87265... )", async function( ) {
		const txOriginal = {blockNumber: "4419904", timeStamp: "1508837645", hash: "0xccbe7cef83e28d2cc3318fa02216d2348985d122a9619b6e136acf540a340ccd", nonce: "42", blockHash: "0x70fedfe48c09863fc8fa147fcfedc777a5f84e4ca982b750ef1b7bc93861b930", transactionIndex: "23", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17012455d536fdb81eb8edb7a761fafdb872652fd96f8ddea689ca5ed04d1de12c0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1218610", gasUsed: "137440", confirmations: "3300543"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x012455d536fdb81eb8edb7a761fafdb872652fd96f8ddea689ca5ed04d1de12c"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x012455d536fdb81eb8edb7a761fafdb872652fd96f8ddea689ca5ed04d1de12c", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508837645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x01257620ad167661eea9f7b2942d544ec788... )", async function( ) {
		const txOriginal = {blockNumber: "4419908", timeStamp: "1508837676", hash: "0x27167a65b4aa11c1952a2638911475e566e1796e5ae95defe2bc0e95a8c4b7f2", nonce: "43", blockHash: "0xfe42a184647e070ff8418a419f56910e98b6ec74c2b9e56994d84a619ca3096e", transactionIndex: "15", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a1701257620ad167661eea9f7b2942d544ec788a311125d2d4ac42fc237ab1eb3f90000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "595553", gasUsed: "137440", confirmations: "3300539"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x01257620ad167661eea9f7b2942d544ec788a311125d2d4ac42fc237ab1eb3f9"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x01257620ad167661eea9f7b2942d544ec788a311125d2d4ac42fc237ab1eb3f9", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508837676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x012a94bd7ece1a537d4bbfee2e4584f77ad7... )", async function( ) {
		const txOriginal = {blockNumber: "4419910", timeStamp: "1508837744", hash: "0x6f33253b77d52a213620a119c76f747aca59759a1d9a917b943a43aa421a15a6", nonce: "44", blockHash: "0xe4380917b781acabbc982b9f5c6e0a5c4aa617812f2e292d44c72929452b7b7a", transactionIndex: "23", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17012a94bd7ece1a537d4bbfee2e4584f77ad7fd3506942a8d04bb8095d3602b500000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1058206", gasUsed: "137440", confirmations: "3300537"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x012a94bd7ece1a537d4bbfee2e4584f77ad7fd3506942a8d04bb8095d3602b50"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x012a94bd7ece1a537d4bbfee2e4584f77ad7fd3506942a8d04bb8095d3602b50", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508837744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addPromo( \"0x012e515a8a8e8edf12203c9e6fb1de72180e... )", async function( ) {
		const txOriginal = {blockNumber: "4419911", timeStamp: "1508837753", hash: "0x2ce54c60c0444575960891fca4c96fb75565951601a4b0166a5f39eabd8867b2", nonce: "45", blockHash: "0x4bb9ec8de9084f5586ce322238e7b0059ba52b10e0aa9e3421353cca38b7fabe", transactionIndex: "19", from: "0xe9af8aa1c1e32024ac8f4804c636f27f637ab8af", to: "0xa746a9a309e7d498f830cffeb683b6d5bb39cadb", value: "0", gas: "137440", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xa6980a17012e515a8a8e8edf12203c9e6fb1de72180ea2b10c589a7bc165bcbc36f658da0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000522033f8d7b49227bfc7a56d44b0b2cbca70dc9b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000384", contractAddress: "", cumulativeGasUsed: "1147116", gasUsed: "137440", confirmations: "3300536"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "promoPublicKey", value: "0x012e515a8a8e8edf12203c9e6fb1de72180ea2b10c589a7bc165bcbc36f658da"}, {type: "uint256", name: "userPercentToken", value: "100"}, {type: "address", name: "dealer", value: addressList[9]}, {type: "uint256", name: "dealerPercentToken", value: "0"}, {type: "uint256", name: "dealerPercentETH", value: "900"}], name: "addPromo", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addPromo(bytes32,uint256,address,uint256,uint256)" ]( "0x012e515a8a8e8edf12203c9e6fb1de72180ea2b10c589a7bc165bcbc36f658da", "100", addressList[9], "0", "900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508837753 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8441031999701088" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
