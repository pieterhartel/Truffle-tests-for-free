const ClashHash = artifacts.require( "./ClashHash.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ClashHash" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xaE33185575973ee122793b5703273e502caEE424", "0xcde89BbE47B9995B4AAa35f73BeE5777D92b75d3", "0xCD0BA5c1A81782Ed5c01e9959e6bFDB7e9344067", "0x6FE155F3DAa9120D9e4f7F5d6e67A03d5e9C3c81", "0xEA674fdDe714fd979de3EdF0F56AA9716B898ec8", "0x2a5994b501E6A560e727b6C2DE5D856396aaDd38", "0xC1630FC6c9faF31853C9b67526A3F6432F144fc8", "0x5A0b54D5dc17e0AadC383d2db43B0a0D3E029c4c", "0x52bc44d5378309EE2abF1539BF71dE1b7d7bE3b5", "0x9E21b76A3AaD0c284F3F77ac2DA96c69B43eC47F", "0x8EcC411B42f9105eCf567c8dDb22346969459A29", "0x829BD824B016326A401d083B33D092293333A830", "0x67BfF8171AB078a5ac961973873862B31d67Bf1b", "0x00000668Cd2B9d2Ae367E4232E28656fE2e7613d", "0xb2930B35844a230f00E51431aCAe96Fe543a0347", "0x7F30f0a148Fa77B0688c8029faAb97b509bA55e6", "0x5Cf8530f33b197c74933120bFf512A3FedbcE407", "0x37E6Cf2F6f27c2f0f695AEc27acC03a6B2E23339", "0x2a65Aca4D5fC5B5C859090a6c34d164135398226", "0x1111111e3A7486F3880b8F0c0D25f5aA2eD3084a"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "MIN_BLOCKS_BEFORE_ROUND", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "referrers", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "referrerFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MIN_BLOCKS_AFTER_ROUND", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "rounds", outputs: [{name: "records", type: "address"}, {name: "betsCount", type: "uint256"}, {name: "totalReward", type: "uint256"}, {name: "winner", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_BLOCKS_AFTER_ROUND", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "adminFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_blockStorage", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ReferralReward", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldFee", type: "uint256"}, {indexed: false, name: "newFee", type: "uint256"}], name: "AdminFeeUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldFee", type: "uint256"}, {indexed: false, name: "newFee", type: "uint256"}], name: "ReferrerFeeUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldMinBet", type: "uint256"}, {indexed: false, name: "newMinBet", type: "uint256"}], name: "MinBetUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RoundCreated(uint256,address)", "RoundBetAdded(uint256,address,address,uint256)", "RoundFinalized(uint256,address)", "RewardClaimed(uint256,address,address,uint256)", "NewReferral(address,address)", "ReferralReward(address,address,uint256)", "AdminFeeUpdate(uint256,uint256)", "ReferrerFeeUpdate(uint256,uint256)", "MinBetUpdate(uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x238eeac651d649604615173573d5b8a916ef1f91e8e7a556b442d5f6284dd21d", "0x614f1f83c920769190e84c46afa11c89f75926d8acc5efcccb5d9f4c26e60718", "0x9ca7bb3ddcb08cddff325383cad687ad15d36fdc27ac79d8a580cd8aa7c4dacc", "0xd7566a1f449b7ee89a6af29f319e117c231ea862057eb65395ca2bf70283b1c8", "0x965e581fd2224ce85185c5f48cfbcc00e17fa216f970b274fc724888f6b8994a", "0x53958b9c644a1d5529da7c36929d59417eb9a996f08e02a52632bfe20c92ef48", "0xef692ea50bf7088692060ccd423bffe68aae228c457cfc564910d36e556875e1", "0x6df0d8e0d09e2d9fcf7e36a5c54c6d21d8867f77a40fae28354ab435cf242a36", "0x1a28909f8219e79c83c8bfa182dc104f7bc7864a120924952afe956c07374d2b", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6925932 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6943701 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "blockStorage", value: 4}], name: "ClashHash", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "MIN_BLOCKS_BEFORE_ROUND", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_BLOCKS_BEFORE_ROUND()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "referrers", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "referrers(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "referrerFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "referrerFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MIN_BLOCKS_AFTER_ROUND", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_BLOCKS_AFTER_ROUND()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "rounds", outputs: [{name: "records", type: "address"}, {name: "betsCount", type: "uint256"}, {name: "totalReward", type: "uint256"}, {name: "winner", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rounds(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_BLOCKS_AFTER_ROUND", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_BLOCKS_AFTER_ROUND()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "adminFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "adminFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_blockStorage", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_blockStorage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ClashHash", function( accounts ) {

	it( "TEST: ClashHash( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6925932", timeStamp: "1545385039", hash: "0xace3f851d1d267d281f02ecba30dd5ac0e4ebb24b53e927b57e415d3d3e80f19", nonce: "1", blockHash: "0xd2507efcdf67df88486253083c4d13a6e15b1c1621675796c83167e818141971", transactionIndex: "2", from: "0xcde89bbe47b9995b4aaa35f73bee5777d92b75d3", to: 0, value: "0", gas: "2474639", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x33c6765c000000000000000000000000cd0ba5c1a81782ed5c01e9959e6bfdb7e9344067", contractAddress: "0xae33185575973ee122793b5703273e502caee424", cumulativeGasUsed: "3259035", gasUsed: "2474639", confirmations: "749977"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "blockStorage", value: addressList[4]}], name: "ClashHash", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ClashHash.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545385039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ClashHash.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xcde89bbe47b9995b4aaa35f73bee5777d92b75d3"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[0,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1783726911186508105" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6926200\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6926105", timeStamp: "1545387586", hash: "0x29be95c93fc5fbf39ed66d0305304fa8fd5916dcf525f4c76976127b003118ad", nonce: "0", blockHash: "0x5bdf6e0d95e0be0dfabe1e3b6c76ef27db1aba5af27d900c0ff8e92d93dbc0ef", transactionIndex: "93", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798838", gasPrice: "5200000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069af78000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "5760916", gasUsed: "798838", confirmations: "749804"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926200"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6926200", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545387586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6926200"}, {name: "contractAddress", type: "address", value: "0x156aa5d9665ed4a57eda68dcc0e403e377e164b3"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926200"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6926300\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6926251", timeStamp: "1545389640", hash: "0xa40f34d0f2100db75ad09288f13b1ca2287ff6980f1b67e56be31ee11739c902", nonce: "1", blockHash: "0x3f6c304e1a8fdf788ba756da8822621a6f1b9c66a224c5e84e2b74dc1d27fba6", transactionIndex: "160", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798838", gasPrice: "5040000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069afdc0000000000000000000000002a5994b501e6a560e727b6c2de5d856396aadd38", contractAddress: "", cumulativeGasUsed: "7620034", gasUsed: "798838", confirmations: "749658"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926300"}, {type: "address", name: "option", value: addressList[7]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6926300", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545389640 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6926300"}, {name: "contractAddress", type: "address", value: "0x2672b22742684f6542a09b1212e5aa51f5d72411"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926300"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "option", type: "address", value: "0x2a5994b501e6a560e727b6c2de5d856396aadd38"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addBlockData( \"6926200\", \"0xf9020ba081b704ccec4ed58... )", async function( ) {
		const txOriginal = {blockNumber: "6926403", timeStamp: "1545392035", hash: "0x0453fb2e5b3f21a57893e851156640511442a4a1a81d5a16b0752ea7053ad988", nonce: "0", blockHash: "0x85841d3c29f2509f36e167b00e35a2808358224a6940e290b38343be0ab1485c", transactionIndex: "93", from: "0xc1630fc6c9faf31853c9b67526a3f6432f144fc8", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "190000", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0x1483fc8c000000000000000000000000000000000000000000000000000000000069af780000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000020ef9020ba081b704ccec4ed58c46683cfbd2707d15a00da0575e596f22594d2a1ef22fe3e4a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347942a5994b501e6a560e727b6c2de5d856396aadd38a011d28870f29d146c9995840a51ad9932b934130c6a34fe61df54c4cb0aad9d45a03c3616bd24e90a15b0fafec60acf6fed6edf35a668f6bf587abac99e3c58c139a0b6e8d73c544419725c796d677e7f324d5cd073f595cb56b24f698b9cee7612a6b9010000000000000000000000000000000002000000000000002000100000000000000000000000000000000000000000800000000000000000000000000000000008000000000000000000000008000000008000002000000000000000000000000000000000000000000000004000000000400000000800000000000110000000000000020000000000800000000000000000000000008000000000000000000900000100000000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000004020000000000000100020000000000000000000000000000000000000000000000000000000800040870832140bc786548369af78837a20ec83037104845c1cc36e8a70616e64615f706f6f6ca0fa158e62dabd2e67c319abae80eeb3718cec2c2814633fd61cfbb1031d8f14fe8818ab85d80d68984c000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5811923", gasUsed: "88332", confirmations: "749506"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926200"}, {type: "bytes", name: "blockData", value: "0xf9020ba081b704ccec4ed58c46683cfbd2707d15a00da0575e596f22594d2a1ef22fe3e4a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347942a5994b501e6a560e727b6c2de5d856396aadd38a011d28870f29d146c9995840a51ad9932b934130c6a34fe61df54c4cb0aad9d45a03c3616bd24e90a15b0fafec60acf6fed6edf35a668f6bf587abac99e3c58c139a0b6e8d73c544419725c796d677e7f324d5cd073f595cb56b24f698b9cee7612a6b9010000000000000000000000000000000002000000000000002000100000000000000000000000000000000000000000800000000000000000000000000000000008000000000000000000000008000000008000002000000000000000000000000000000000000000000000004000000000400000000800000000000110000000000000020000000000800000000000000000000000008000000000000000000900000100000000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000004020000000000000100020000000000000000000000000000000000000000000000000000000800040870832140bc786548369af78837a20ec83037104845c1cc36e8a70616e64615f706f6f6ca0fa158e62dabd2e67c319abae80eeb3718cec2c2814633fd61cfbb1031d8f14fe8818ab85d80d68984c"}], name: "addBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBlockData(uint256,bytes)" ]( "6926200", "0xf9020ba081b704ccec4ed58c46683cfbd2707d15a00da0575e596f22594d2a1ef22fe3e4a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347942a5994b501e6a560e727b6c2de5d856396aadd38a011d28870f29d146c9995840a51ad9932b934130c6a34fe61df54c4cb0aad9d45a03c3616bd24e90a15b0fafec60acf6fed6edf35a668f6bf587abac99e3c58c139a0b6e8d73c544419725c796d677e7f324d5cd073f595cb56b24f698b9cee7612a6b9010000000000000000000000000000000002000000000000002000100000000000000000000000000000000000000000800000000000000000000000000000000008000000000000000000000008000000008000002000000000000000000000000000000000000000000000004000000000400000000800000000000110000000000000020000000000800000000000000000000000008000000000000000000900000100000000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000004020000000000000100020000000000000000000000000000000000000000000000000000000800040870832140bc786548369af78837a20ec83037104845c1cc36e8a70616e64615f706f6f6ca0fa158e62dabd2e67c319abae80eeb3718cec2c2814633fd61cfbb1031d8f14fe8818ab85d80d68984c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545392035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6926200"}, {name: "option", type: "address", value: "0x2a5994b501e6a560e727b6c2de5d856396aadd38"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "456698177730628196" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addBlockData( \"6926300\", \"0xf90215a0fa94956df2980a6... )", async function( ) {
		const txOriginal = {blockNumber: "6926502", timeStamp: "1545393559", hash: "0x9504d57ef32e96b7c148b9f53902bfa856cbb47c7bf3a6e2982fe58c949aab15", nonce: "1", blockHash: "0x8e1dde5c9a3e00f1183fba1cba6e57aa3d99e1dd4c21828139e4834baf7b0ce9", transactionIndex: "148", from: "0xc1630fc6c9faf31853c9b67526a3f6432f144fc8", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "190000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0x1483fc8c000000000000000000000000000000000000000000000000000000000069afdc00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000218f90215a0fa94956df2980a6c56b91f0b6c79948341c920eac1d8fe47f2b0bb906f8a67c6a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0cd9d5e14e81829703feb227ec50afe9903dd07b6a07fa61f97c92da9307411e8a020bf231064cc07d8ffe6f63f7dd7910bc588c852e0253720538af5c2c5130f16a0c7c409808da596f35d146faa1dab4f6b6d9c19582635370918f07481376893b4b901001a07ea90920351105081b917484008241040d08c0018405a2280c162002910cd4aa2151128912e0189800653a3681440a6a104022ae8020501c0b0404465300856004020808060334040511a8c4a64854a088e14a9cc8341821085cc02c80a23000180fa07e0c814c0310204c00c4c030b63158c169845ac100140160440d62200009015c15200f8604404c4cda0a49a39b02d0d6040083848d34b180c61ab0a460044282010415616a2045c81688023184021904044858c5043088072652d0fd461623a89006900089b021661282541dc0a4867d92b493c00c88486e252e381b05125899212d0968868104a0018f1074a26092e30c8809542c80a0025134b268708385fba22be618369afdc837a121d8379d681845c1cc8ef94737061726b706f6f6c2d6574682d636e2d687a32a01ddf87451c0a44110df5b1bb1cd8455bff0b23441084287fb7585ab33b64a85388f41ac100094d7e080000000000000000", contractAddress: "", cumulativeGasUsed: "5070487", gasUsed: "102860", confirmations: "749407"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926300"}, {type: "bytes", name: "blockData", value: "0xf90215a0fa94956df2980a6c56b91f0b6c79948341c920eac1d8fe47f2b0bb906f8a67c6a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0cd9d5e14e81829703feb227ec50afe9903dd07b6a07fa61f97c92da9307411e8a020bf231064cc07d8ffe6f63f7dd7910bc588c852e0253720538af5c2c5130f16a0c7c409808da596f35d146faa1dab4f6b6d9c19582635370918f07481376893b4b901001a07ea90920351105081b917484008241040d08c0018405a2280c162002910cd4aa2151128912e0189800653a3681440a6a104022ae8020501c0b0404465300856004020808060334040511a8c4a64854a088e14a9cc8341821085cc02c80a23000180fa07e0c814c0310204c00c4c030b63158c169845ac100140160440d62200009015c15200f8604404c4cda0a49a39b02d0d6040083848d34b180c61ab0a460044282010415616a2045c81688023184021904044858c5043088072652d0fd461623a89006900089b021661282541dc0a4867d92b493c00c88486e252e381b05125899212d0968868104a0018f1074a26092e30c8809542c80a0025134b268708385fba22be618369afdc837a121d8379d681845c1cc8ef94737061726b706f6f6c2d6574682d636e2d687a32a01ddf87451c0a44110df5b1bb1cd8455bff0b23441084287fb7585ab33b64a85388f41ac100094d7e08"}], name: "addBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBlockData(uint256,bytes)" ]( "6926300", "0xf90215a0fa94956df2980a6c56b91f0b6c79948341c920eac1d8fe47f2b0bb906f8a67c6a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0cd9d5e14e81829703feb227ec50afe9903dd07b6a07fa61f97c92da9307411e8a020bf231064cc07d8ffe6f63f7dd7910bc588c852e0253720538af5c2c5130f16a0c7c409808da596f35d146faa1dab4f6b6d9c19582635370918f07481376893b4b901001a07ea90920351105081b917484008241040d08c0018405a2280c162002910cd4aa2151128912e0189800653a3681440a6a104022ae8020501c0b0404465300856004020808060334040511a8c4a64854a088e14a9cc8341821085cc02c80a23000180fa07e0c814c0310204c00c4c030b63158c169845ac100140160440d62200009015c15200f8604404c4cda0a49a39b02d0d6040083848d34b180c61ab0a460044282010415616a2045c81688023184021904044858c5043088072652d0fd461623a89006900089b021661282541dc0a4867d92b493c00c88486e252e381b05125899212d0968868104a0018f1074a26092e30c8809542c80a0025134b268708385fba22be618369afdc837a121d8379d681845c1cc8ef94737061726b706f6f6c2d6574682d636e2d687a32a01ddf87451c0a44110df5b1bb1cd8455bff0b23441084287fb7585ab33b64a85388f41ac100094d7e08", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545393559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6926300"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "456698177730628196" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6926600\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6926502", timeStamp: "1545393559", hash: "0x0e2bf1f1b47fdcd7bc6af186fa4c348cfb4c437d43f0727c39177066cab26392", nonce: "2", blockHash: "0x8e1dde5c9a3e00f1183fba1cba6e57aa3d99e1dd4c21828139e4834baf7b0ce9", transactionIndex: "160", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798838", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069b1080000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "7906079", gasUsed: "798838", confirmations: "749407"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926600"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6926600", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545393559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "contractAddress", type: "address", value: "0x92a9499fda935a8b052cd9cb7dac203328690281"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6926600\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6926507", timeStamp: "1545393652", hash: "0x1e4990e496a4233b24cfd7a6699ee152310c389538cad157ecac5285b2897fe3", nonce: "3", blockHash: "0xcdc0550d11c85607d80cc16b920478658e859bc7ecf79bbacca6ad16b621ee5e", transactionIndex: "75", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069b108000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "2699401", gasUsed: "89486", confirmations: "749402"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926600"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6926600", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545393652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6926600\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6926537", timeStamp: "1545394139", hash: "0x7dfadf8fedcf6e1dc86391dfbdc7449db6de0d33c5859516ef17e2cbac254457", nonce: "4", blockHash: "0xf4c9ff11fdf1bba8d5de46af7eda64b77582cbcac1ba9404b5ddd742007181f0", transactionIndex: "107", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069b10800000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "4830307", gasUsed: "89486", confirmations: "749372"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926600"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6926600", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545394139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: claimRewardWithBlockData( \"6926600\", \"0xf9020da036d93621a3cafab... )", async function( ) {
		const txOriginal = {blockNumber: "6926704", timeStamp: "1545396318", hash: "0x16c6035990449b93ff2282a6f9786b893bf529dac1bdf45d56e35d4c7d0b1bb9", nonce: "5", blockHash: "0x879b3b37f855a05dcaae2f8bcbbdd711f889c05b43d93b66fd12ef24d343128b", transactionIndex: "28", from: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "160409", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x0eb15f0f000000000000000000000000000000000000000000000000000000000069b10800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000210f9020da036d93621a3cafabc3fb7b6bdb9e2d9a8f6f0c7e8ba2f98a9a41806d8cb9f643ea01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a05650c3446ed05c9f93198bac64adc691561fbb6abc62999615aa828c21ce22d2a045b58f09756290952760dd542a845f1d1be217eb459299b2a7a2d1d9443854e4a0126b1a959aef457edf8c19f3f4f490137bcc20ec687388c4734c424576a75950b901000000402000040000000000000000000000000000000200000000000000210000000002000010002000000000000000000000000000000000000000000020000000000004040040000000000810000000080000000000004000000000000000000040000000000008000000000200000000000000000000000000001000000000040000000000000000020000000000040200000000200000000000080000002000000000000000000000000000000000000000000000000000000000000000000000400200000000010000000000000001000000000100000000000000000008000000000000000000000000000000002000000000000000010000000000000087082491038ac0b58369b108837a121d830b3ef0845c1cdb208c6e616e6f706f6f6c2e6f7267a0e657564314a188582c4524dcfcc6df2dfaa5b5ef190c224fdec0763a43c38b0488210a5deab67e029500000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "979809", gasUsed: "106409", confirmations: "749205"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926600"}, {type: "bytes", name: "blockData", value: "0xf9020da036d93621a3cafabc3fb7b6bdb9e2d9a8f6f0c7e8ba2f98a9a41806d8cb9f643ea01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a05650c3446ed05c9f93198bac64adc691561fbb6abc62999615aa828c21ce22d2a045b58f09756290952760dd542a845f1d1be217eb459299b2a7a2d1d9443854e4a0126b1a959aef457edf8c19f3f4f490137bcc20ec687388c4734c424576a75950b901000000402000040000000000000000000000000000000200000000000000210000000002000010002000000000000000000000000000000000000000000020000000000004040040000000000810000000080000000000004000000000000000000040000000000008000000000200000000000000000000000000001000000000040000000000000000020000000000040200000000200000000000080000002000000000000000000000000000000000000000000000000000000000000000000000400200000000010000000000000001000000000100000000000000000008000000000000000000000000000000002000000000000000010000000000000087082491038ac0b58369b108837a121d830b3ef0845c1cdb208c6e616e6f706f6f6c2e6f7267a0e657564314a188582c4524dcfcc6df2dfaa5b5ef190c224fdec0763a43c38b0488210a5deab67e0295"}], name: "claimRewardWithBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimRewardWithBlockData(uint256,bytes)" ]( "6926600", "0xf9020da036d93621a3cafabc3fb7b6bdb9e2d9a8f6f0c7e8ba2f98a9a41806d8cb9f643ea01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a05650c3446ed05c9f93198bac64adc691561fbb6abc62999615aa828c21ce22d2a045b58f09756290952760dd542a845f1d1be217eb459299b2a7a2d1d9443854e4a0126b1a959aef457edf8c19f3f4f490137bcc20ec687388c4734c424576a75950b901000000402000040000000000000000000000000000000200000000000000210000000002000010002000000000000000000000000000000000000000000020000000000004040040000000000810000000080000000000004000000000000000000040000000000008000000000200000000000000000000000000001000000000040000000000000000020000000000040200000000200000000000080000002000000000000000000000000000000000000000000000000000000000000000000000400200000000010000000000000001000000000100000000000000000008000000000000000000000000000000002000000000000000010000000000000087082491038ac0b58369b108837a121d830b3ef0845c1cdb208c6e616e6f706f6f6c2e6f7267a0e657564314a188582c4524dcfcc6df2dfaa5b5ef190c224fdec0763a43c38b0488210a5deab67e0295", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545396318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardClaimed", events: [{name: "blockNumber", type: "uint256", value: "6926600"}, {name: "user", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}, {name: "winner", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "reward", type: "uint256", value: "2900000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "506962672261204210" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6926800\", addressList[6], addressList... )", async function( ) {
		const txOriginal = {blockNumber: "6926737", timeStamp: "1545396820", hash: "0x3754850885f57cb889369c31522e0a8efa1ad2a2dacfa16590ea595caad49f76", nonce: "9", blockHash: "0x3971e077394099d24e4fba0b265dad67d2fcb5329c92b89b0ed99058997a21a1", transactionIndex: "125", from: "0x9e21b76a3aad0c284f3f77ac2da96c69b43ec47f", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "822413", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069b1d0000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec80000000000000000000000006fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", contractAddress: "", cumulativeGasUsed: "7253379", gasUsed: "822413", confirmations: "749172"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926800"}, {type: "address", name: "option", value: addressList[6]}, {type: "address", name: "referrer", value: addressList[5]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6926800", addressList[6], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545396820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6926800"}, {name: "contractAddress", type: "address", value: "0xd5e1f48919d947355f880601dc38473529d5bad4"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6926800"}, {name: "user", type: "address", value: "0x9e21b76a3aad0c284f3f77ac2da96c69b43ec47f"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x9e21b76a3aad0c284f3f77ac2da96c69b43ec47f"}, {name: "referrer", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "61481955000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addBlockData( \"6926800\", \"0xf90210a09c06cfec7391caf... )", async function( ) {
		const txOriginal = {blockNumber: "6927175", timeStamp: "1545403487", hash: "0x8bf38c7ef340676d4937390ec412b5e7877c024221b7f74618f6544547e01ef2", nonce: "2", blockHash: "0x41bad7030e776acf6e8c5dcc8792b1a760edd58ae97f17ae18ec582b22eadfe9", transactionIndex: "31", from: "0xc1630fc6c9faf31853c9b67526a3f6432f144fc8", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "190000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x1483fc8c000000000000000000000000000000000000000000000000000000000069b1d000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000213f90210a09c06cfec7391cafce001c98b75bb2b2cb5cee4c99c2bf1b29746b55a15836724a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794829bd824b016326a401d083b33d092293333a830a013daaf0ac3a4859782c0781dc0003008cc3c9547b3989bf13cf250cd5aa95388a07374e3e3db386790e31251ca7873ff00984b26323982093bb34b850a9458ec3ba03814b3446768cbfad2ff81f4205da31ffc7a456f7714584b10cc5bba2627b7aeb901002c940100f6c00a39c0c1841200a2905c1129020d1024009a38828480a2ca208a1ada013011600a418aa6406e9e840e6322c6a6088b0800cb00105900402a8089811801004c002e03db488a5e10e868003b24a11cb849ce2a80c30508053655594104c1c0aa0170844095100480562f00824910217081051000ae01908541e0281250a08160031010c0cb54e0c908970800e209c101980822808502221030600a020041274102791200041a004468c1088401708c6611c03016040090bc026186010440471295904012d804c4c71250c700d0e3357128654c0876230f7003602107d06243c8148c10208902017d828a0558205068228e88115640082008b4019087083b55220bffb48369b1d0837a30a08379fc32845c1ce5e28fe4b883e5bda9e7a59ee4bb99e9b1bca06689ac369ae9aee09207a11647a04352142c67e2626d5b288c343f8258b766f08887e9694401af658b00000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7566713", gasUsed: "58111", confirmations: "748734"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6926800"}, {type: "bytes", name: "blockData", value: "0xf90210a09c06cfec7391cafce001c98b75bb2b2cb5cee4c99c2bf1b29746b55a15836724a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794829bd824b016326a401d083b33d092293333a830a013daaf0ac3a4859782c0781dc0003008cc3c9547b3989bf13cf250cd5aa95388a07374e3e3db386790e31251ca7873ff00984b26323982093bb34b850a9458ec3ba03814b3446768cbfad2ff81f4205da31ffc7a456f7714584b10cc5bba2627b7aeb901002c940100f6c00a39c0c1841200a2905c1129020d1024009a38828480a2ca208a1ada013011600a418aa6406e9e840e6322c6a6088b0800cb00105900402a8089811801004c002e03db488a5e10e868003b24a11cb849ce2a80c30508053655594104c1c0aa0170844095100480562f00824910217081051000ae01908541e0281250a08160031010c0cb54e0c908970800e209c101980822808502221030600a020041274102791200041a004468c1088401708c6611c03016040090bc026186010440471295904012d804c4c71250c700d0e3357128654c0876230f7003602107d06243c8148c10208902017d828a0558205068228e88115640082008b4019087083b55220bffb48369b1d0837a30a08379fc32845c1ce5e28fe4b883e5bda9e7a59ee4bb99e9b1bca06689ac369ae9aee09207a11647a04352142c67e2626d5b288c343f8258b766f08887e9694401af658b"}], name: "addBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBlockData(uint256,bytes)" ]( "6926800", "0xf90210a09c06cfec7391cafce001c98b75bb2b2cb5cee4c99c2bf1b29746b55a15836724a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794829bd824b016326a401d083b33d092293333a830a013daaf0ac3a4859782c0781dc0003008cc3c9547b3989bf13cf250cd5aa95388a07374e3e3db386790e31251ca7873ff00984b26323982093bb34b850a9458ec3ba03814b3446768cbfad2ff81f4205da31ffc7a456f7714584b10cc5bba2627b7aeb901002c940100f6c00a39c0c1841200a2905c1129020d1024009a38828480a2ca208a1ada013011600a418aa6406e9e840e6322c6a6088b0800cb00105900402a8089811801004c002e03db488a5e10e868003b24a11cb849ce2a80c30508053655594104c1c0aa0170844095100480562f00824910217081051000ae01908541e0281250a08160031010c0cb54e0c908970800e209c101980822808502221030600a020041274102791200041a004468c1088401708c6611c03016040090bc026186010440471295904012d804c4c71250c700d0e3357128654c0876230f7003602107d06243c8148c10208902017d828a0558205068228e88115640082008b4019087083b55220bffb48369b1d0837a30a08379fc32845c1ce5e28fe4b883e5bda9e7a59ee4bb99e9b1bca06689ac369ae9aee09207a11647a04352142c67e2626d5b288c343f8258b766f08887e9694401af658b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545403487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "456698177730628196" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6942746", timeStamp: "1545631919", hash: "0x8db7522a8936ae2e38c8098c0de7d84bac05237ac2ad0c024f1b9e105a23190b", nonce: "11", blockHash: "0x415ebc74aaa498f1916ccfa2ffb62d34a0e439996f338e5dd17abfcc6f779ad3", transactionIndex: "22", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "10000000000000000", gas: "798838", gasPrice: "5841000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "1891640", gasUsed: "798838", confirmations: "733163"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545631919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "contractAddress", type: "address", value: "0xa2fce5e462a928bd700402c95e71d85c4b40cdde"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "10000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6942763", timeStamp: "1545632208", hash: "0x0d1b69292e9c2d8c103b64bc716228c866eb324c46c76894ab66017f0f2f8fbb", nonce: "12", blockHash: "0xd7dbd3168e2276eeb9cc884b0d1fd4d837b64339304625e4e7d5510b1789ae3f", transactionIndex: "118", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "5841000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b400000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "5296895", gasUsed: "89486", confirmations: "733146"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545632208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6942815", timeStamp: "1545632931", hash: "0x2eba041c032d606b32feeb3f255c0fe569aff4808642ea4f892c85b060c80b1e", nonce: "13", blockHash: "0x3833e9fad63bd960e93aa4b6d6bb6e31c6ffe6fc0205d4a9be8fb88283580253", transactionIndex: "47", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "111111111099999889", gas: "89486", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b40000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "6146989", gasUsed: "89486", confirmations: "733094"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "111111111099999889" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545632931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "111111111099999889"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6942829", timeStamp: "1545633133", hash: "0xe0e10857ed901ac96b333ddde1cd2619fdbda32779394d99de65a3748efe0350", nonce: "14", blockHash: "0xa70bf943bc7ed3483645dfa0e96fd04ce0079864fcb80d1c0c6c75ff6724f749", transactionIndex: "96", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000829bd824b016326a401d083b33d092293333a830", contractAddress: "", cumulativeGasUsed: "6808168", gasUsed: "89486", confirmations: "733080"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[13]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545633133 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x829bd824b016326a401d083b33d092293333a830"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6942846", timeStamp: "1545633437", hash: "0x51fa45130490b754d39e0015ba22b136947c00f6a3db366721ebbab953cb25a0", nonce: "32", blockHash: "0x50b3f67132c1f7d45dc966c230e11aa90f70c33b5dd72fef68720fc20c7d8f71", transactionIndex: "52", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "74486", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b400000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "5655942", gasUsed: "74486", confirmations: "733063"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545633437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6942853", timeStamp: "1545633553", hash: "0xedaf430d88166c01620488439563f555375b51f7480f8e50e4bbdee692fd84e3", nonce: "33", blockHash: "0x977286582ce42f738f5f0cf9cce4957fdd09e23236af755cd686316826c71f48", transactionIndex: "149", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "74486", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "5596688", gasUsed: "74486", confirmations: "733056"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545633553 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6942866", timeStamp: "1545633874", hash: "0xd8ed57266939f99b520f57919b2d6ceab0a25cb5486cc42b9f529cc37031f6f3", nonce: "34", blockHash: "0x59bce5ec676e3759e8e6d2ed9d49087fb713982b969d79312e1be26b6a49171c", transactionIndex: "66", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "74486", gasPrice: "4500000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000829bd824b016326a401d083b33d092293333a830", contractAddress: "", cumulativeGasUsed: "4213608", gasUsed: "74486", confirmations: "733043"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[13]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545633874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0x829bd824b016326a401d083b33d092293333a830"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6942872", timeStamp: "1545633988", hash: "0x3ce58297471e7746c21b06f4b73d7c3bd4bbf735568610833a1a7ac098be4385", nonce: "2", blockHash: "0x768fe5b66907b2b723eaf279b6a3b415e75c7dd200fce0d2254f14775911dc41", transactionIndex: "120", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89422", gasPrice: "4500000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000b2930b35844a230f00e51431acae96fe543a0347", contractAddress: "", cumulativeGasUsed: "5607539", gasUsed: "89422", confirmations: "733037"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[16]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545633988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6942900\", addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6942872", timeStamp: "1545633988", hash: "0x9acddbe6e124b298d3809cf86e7a4355313da1229c6f68b3e48dfd928109eb96", nonce: "15", blockHash: "0x768fe5b66907b2b723eaf279b6a3b415e75c7dd200fce0d2254f14775911dc41", transactionIndex: "124", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89422", gasPrice: "4500000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f0b4000000000000000000000000b2930b35844a230f00e51431acae96fe543a0347", contractAddress: "", cumulativeGasUsed: "5778022", gasUsed: "74422", confirmations: "733037"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "address", name: "option", value: addressList[16]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6942900", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545633988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: claimRewardWithBlockData( \"6942900\", \"0xf9020da03b20dd21b8e9120... )", async function( ) {
		const txOriginal = {blockNumber: "6942916", timeStamp: "1545634714", hash: "0xf4255ecc6563d8957c25b83c643d22e8c420cebc8f2ec9ce048a0fb350405bab", nonce: "16", blockHash: "0x4c1db1eb2380bafd1b7f9b82fccadab3f428f692ea6870ea70be0973ccf549be", transactionIndex: "147", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "158685", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0eb15f0f000000000000000000000000000000000000000000000000000000000069f0b400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000210f9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6486729", gasUsed: "143685", confirmations: "732993"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "bytes", name: "blockData", value: "0xf9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da"}], name: "claimRewardWithBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimRewardWithBlockData(uint256,bytes)" ]( "6942900", "0xf9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545634714 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardClaimed", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "winner", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "reward", type: "uint256", value: "60902777772499947"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6942923", timeStamp: "1545634851", hash: "0xf0d8d9c61be1a9c422dd40e2a2b1750bd784e079cf413dce30595b7626521f70", nonce: "17", blockHash: "0x27ef83fdec71ff2e25ca8a464da0fdc60326a85bdaef41c9e8c8ac3ef37f7922", transactionIndex: "117", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798838", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f11800000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "7186298", gasUsed: "798838", confirmations: "732986"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943000"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545634851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "contractAddress", type: "address", value: "0x45dae9c6e66d14139df93441f03ba261504beb18"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943000\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6942946", timeStamp: "1545635254", hash: "0x7abe81d447399298b0c28f2ee515d374189048de725337481bfbe09b999fe8b2", nonce: "0", blockHash: "0x72b2066c9e48d254a182f95ef7935cb4d68f7d1266f518ec20b56ccbe8adf870", transactionIndex: "136", from: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f118000000000000000000000000829bd824b016326a401d083b33d092293333a830", contractAddress: "", cumulativeGasUsed: "6154223", gasUsed: "89486", confirmations: "732963"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943000"}, {type: "address", name: "option", value: addressList[13]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943000", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545635254 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "user", type: "address", value: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6"}, {name: "option", type: "address", value: "0x829bd824b016326a401d083b33d092293333a830"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "76260802266375000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6942960", timeStamp: "1545635502", hash: "0x1cdc616a37632f5ff65f8efa7d2cb70bd6a8dbb884bbe89b7bb55ef246c420b8", nonce: "4", blockHash: "0xa359d13ce133d9d1ec0a98eccb7997a07cf7e21139a519a94b12f9db2006ded4", transactionIndex: "121", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f118000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "4412891", gasUsed: "89486", confirmations: "732949"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943000"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545635502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943000\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6942968", timeStamp: "1545635625", hash: "0x4b8085fbafbd3919f89b1c586b9121c6082d65df95204b113e4d66c8e33f231d", nonce: "5", blockHash: "0xb89bbdc20abc3981fc14234bf0119e41c0b3cacfc06f7d21102ff9e8064a0e30", transactionIndex: "80", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f1180000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "4737884", gasUsed: "89486", confirmations: "732941"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943000"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943000", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545635625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: claimRewardWithBlockData( \"6942900\", \"0xf9020da03b20dd21b8e9120... )", async function( ) {
		const txOriginal = {blockNumber: "6942970", timeStamp: "1545635652", hash: "0x382a9869ccaea5780bbbac64aa1819f05acd4cf3c45c90b74f07436666a49e65", nonce: "35", blockHash: "0xa7486f9ca3f2cac056baa4d0bb917a246bbc64558fff8281212c54ee5a516155", transactionIndex: "130", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "100021", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0eb15f0f000000000000000000000000000000000000000000000000000000000069f0b400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000210f9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7148467", gasUsed: "50011", confirmations: "732939"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6942900"}, {type: "bytes", name: "blockData", value: "0xf9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da"}], name: "claimRewardWithBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimRewardWithBlockData(uint256,bytes)" ]( "6942900", "0xf9020da03b20dd21b8e9120cb69a0f857a45fcdff9b18e68e3c5b0be06d416fabf0453dca01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d493479452bc44d5378309ee2abf1539bf71de1b7d7be3b5a0539f52cda1ad274080b5b60fb6d79e96fa81a0a51c1a84574552b959ea02f407a0cbe21513c0c43f0827922e4451158396dde952c2cc9526c871f5a5d88d79d4eda00f8106d2a7266c672495c2a022101a97363e77ab03fa51650e38c746ac3df4ebb9010000000080000000400020000800000000006080000081000080000020000000400000000008004000000000008000400044000000800000800200108000600002400040000300000000000008000000800000000000000000000001000680000000008082202000009020008000002000000000000410000000000110004040000000000000000000800010080400008000800100008000020008000408010000020100080000000800800004000000000000000000000000100110800000000000000202030000004000000040000000800040000100080400480000000020200010000000020000800000000000040000080000000080000000020000004000870844150f2914228369f0b4837a121d830a70d8845c20829b8c6e616e6f706f6f6c2e6f7267a032cbf6f76a7000aafa16e844ab752f1d13a8af480fc52452b5c21d0597fa3b95886f9464d021c0e8da", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545635652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardClaimed", events: [{name: "blockNumber", type: "uint256", value: "6942900"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "winner", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "reward", type: "uint256", value: "60902777772499948"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943100\", addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6943007", timeStamp: "1545636226", hash: "0xaf99d19a3cd76c4a4448c4004830c58b64514363360ddce309df6d7ae84b8715", nonce: "19", blockHash: "0xc1ca11ae8b83784c4077962bdd7215b213a483ea2bc7605fb6c9e8a13f745ba3", transactionIndex: "77", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798774", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f17c000000000000000000000000b2930b35844a230f00e51431acae96fe543a0347", contractAddress: "", cumulativeGasUsed: "3807183", gasUsed: "798774", confirmations: "732902"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "address", name: "option", value: addressList[16]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943100", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545636226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "contractAddress", type: "address", value: "0x15a4d6154c9f5f062c370ff913e16f6a9bf5d160"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943100\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943007", timeStamp: "1545636226", hash: "0x102f984065496aa14f82e18c0786fa3f64d48816454e968df0e95b4e69c80334", nonce: "1", blockHash: "0xc1ca11ae8b83784c4077962bdd7215b213a483ea2bc7605fb6c9e8a13f745ba3", transactionIndex: "78", from: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6", to: "0xae33185575973ee122793b5703273e502caee424", value: "2000000000000000", gas: "798838", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f17c000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "3896669", gasUsed: "89486", confirmations: "732902"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943100", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545636226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "2000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "76260802266375000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943100\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6943051", timeStamp: "1545636935", hash: "0x3d72745c9ca7cb39614ec7eff2b5123308b17eea7074f1f6d8243d2ba32f4598", nonce: "6", blockHash: "0x599d12ee70a479ded71c843f2c4ae79503e40e62e0a2f3fa3a31a1302ee6ffba", transactionIndex: "119", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f17c0000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "6035627", gasUsed: "89486", confirmations: "732858"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943100", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545636935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943100\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6943059", timeStamp: "1545637064", hash: "0xb5c9ddbe45e9f02a7b1dfa3eb26f2102ddcb6bab6e229b73b1039848db163f46", nonce: "7", blockHash: "0x45ed6aa32bfcfd681b12a6bfb93d67a2a31f7ede1c818b8aa2f60ad1bc82cd18", transactionIndex: "173", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f17c00000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "7769774", gasUsed: "89486", confirmations: "732850"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943100", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545637064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943100\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6943074", timeStamp: "1545637329", hash: "0x47157879cd90ec86f754893d2f05f44b38618257338cd0ea1c8b88076570a9e8", nonce: "8", blockHash: "0x1564fba5e5b45e79afcc479dc7d81b10d9ba4fa121bb31fd4c601b8f3c041025", transactionIndex: "171", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f17c000000000000000000000000829bd824b016326a401d083b33d092293333a830", contractAddress: "", cumulativeGasUsed: "6877311", gasUsed: "89486", confirmations: "732835"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "address", name: "option", value: addressList[13]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943100", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545637329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0x829bd824b016326a401d083b33d092293333a830"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943200\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943120", timeStamp: "1545637978", hash: "0xfa489262b2fc8e9fe6ae78efe621e2423138aa29948904e561c976179146a2b1", nonce: "2", blockHash: "0x3747883aec18d0c1726d4951e6ac95a295c45cf9fb86c56879fb76acb04ccae1", transactionIndex: "155", from: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6", to: "0xae33185575973ee122793b5703273e502caee424", value: "2000000000000000", gas: "798838", gasPrice: "6615000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f1e0000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "7845905", gasUsed: "798838", confirmations: "732789"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943200"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943200", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545637978 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6943200"}, {name: "contractAddress", type: "address", value: "0x1621868bb61d92bee31dc42d7b2b4ae22636cf74"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943200"}, {name: "user", type: "address", value: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "2000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "76260802266375000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: claimRewardWithBlockData( \"6943100\", \"0xf90215a0dc8b996c840bfd1... )", async function( ) {
		const txOriginal = {blockNumber: "6943131", timeStamp: "1545638148", hash: "0x08a0d47d364d96809a2c0d02b081fc95cdf762db1a17e719c82e8feb61a63423", nonce: "9", blockHash: "0x12a9572ba94c86a484a4eb7bae5d61e373de96e901a5e4f7309b0e93be370b56", transactionIndex: "98", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "172569", gasPrice: "6615000000", isError: "0", txreceipt_status: "1", input: "0x0eb15f0f000000000000000000000000000000000000000000000000000000000069f17c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000218f90215a0dc8b996c840bfd1d5ab767f64552ff9cf303f4a28f91443156f84a0c27684175a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0eed36e50a2d08b49c96ed1b354016e05a3cf92bc6a69da8511cc9a0d453b8e2aa071d3cb0c712a10bc13df1356a8fcaafa8faac98c4872082bdd6659edb758b12ea00fa8e6bd90e72ebca935d0d4db99a59c3d2b95bab4ca5b867f77f53953988002b90100594401c2480ac0200075916350038080444000030202402043028120544080600633512410912005060000032307084414411402a22080100521880023002ca20608240045074021508008180060401ae2500c08c800400010180840849061c040009408069140d0004420b0110009804002381100410000400c2059d20908a800408011e000900010081020202440480441d1005140422602210246000804001844530018040690a2c6320000608818401000020200900002092094020e950001208006005182518c8a2e30124090a090802021920440000800192004432900105e21006202000040004284c920a04110811282c0310809424840205b000881870828b631da9e0b8369f17c837a121d8379d267845c208f0394737061726b706f6f6c2d6574682d636e2d687a33a090fdf9dc19eaeeea56eb51077907126a03b53ba0a962d73de6e635c4498dc6cc8860c79d0025189c870000000000000000", contractAddress: "", cumulativeGasUsed: "4284773", gasUsed: "118569", confirmations: "732778"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943100"}, {type: "bytes", name: "blockData", value: "0xf90215a0dc8b996c840bfd1d5ab767f64552ff9cf303f4a28f91443156f84a0c27684175a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0eed36e50a2d08b49c96ed1b354016e05a3cf92bc6a69da8511cc9a0d453b8e2aa071d3cb0c712a10bc13df1356a8fcaafa8faac98c4872082bdd6659edb758b12ea00fa8e6bd90e72ebca935d0d4db99a59c3d2b95bab4ca5b867f77f53953988002b90100594401c2480ac0200075916350038080444000030202402043028120544080600633512410912005060000032307084414411402a22080100521880023002ca20608240045074021508008180060401ae2500c08c800400010180840849061c040009408069140d0004420b0110009804002381100410000400c2059d20908a800408011e000900010081020202440480441d1005140422602210246000804001844530018040690a2c6320000608818401000020200900002092094020e950001208006005182518c8a2e30124090a090802021920440000800192004432900105e21006202000040004284c920a04110811282c0310809424840205b000881870828b631da9e0b8369f17c837a121d8379d267845c208f0394737061726b706f6f6c2d6574682d636e2d687a33a090fdf9dc19eaeeea56eb51077907126a03b53ba0a962d73de6e635c4498dc6cc8860c79d0025189c87"}], name: "claimRewardWithBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimRewardWithBlockData(uint256,bytes)" ]( "6943100", "0xf90215a0dc8b996c840bfd1d5ab767f64552ff9cf303f4a28f91443156f84a0c27684175a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0eed36e50a2d08b49c96ed1b354016e05a3cf92bc6a69da8511cc9a0d453b8e2aa071d3cb0c712a10bc13df1356a8fcaafa8faac98c4872082bdd6659edb758b12ea00fa8e6bd90e72ebca935d0d4db99a59c3d2b95bab4ca5b867f77f53953988002b90100594401c2480ac0200075916350038080444000030202402043028120544080600633512410912005060000032307084414411402a22080100521880023002ca20608240045074021508008180060401ae2500c08c800400010180840849061c040009408069140d0004420b0110009804002381100410000400c2059d20908a800408011e000900010081020202440480441d1005140422602210246000804001844530018040690a2c6320000608818401000020200900002092094020e950001208006005182518c8a2e30124090a090802021920440000800192004432900105e21006202000040004284c920a04110811282c0310809424840205b000881870828b631da9e0b8369f17c837a121d8379d267845c208f0394737061726b706f6f6c2d6574682d636e2d687a33a090fdf9dc19eaeeea56eb51077907126a03b53ba0a962d73de6e635c4498dc6cc8860c79d0025189c87", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545638148 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardClaimed", events: [{name: "blockNumber", type: "uint256", value: "6943100"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "winner", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "reward", type: "uint256", value: "5750000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943149", timeStamp: "1545638428", hash: "0xc65fea0bbf630406584863238622c94667069ac5bf65ce8e9da70ba18a14054c", nonce: "3", blockHash: "0xe98f8660656a738e686abcb9a8b2aa45a97e2e71c7de13dacbc917dce1973d7f", transactionIndex: "58", from: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798838", gasPrice: "7607250000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "7200917", gasUsed: "798838", confirmations: "732760"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545638428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "contractAddress", type: "address", value: "0x0e987337209fc71fd227af9f010dab2dd02b7a7c"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x7f30f0a148fa77b0688c8029faab97b509ba55e6"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "76260802266375000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943200\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6943149", timeStamp: "1545638428", hash: "0xabfb261042f70aac52973d5e50b96a506db6e8060a6db9c073729a66d50952d5", nonce: "20", blockHash: "0xe98f8660656a738e686abcb9a8b2aa45a97e2e71c7de13dacbc917dce1973d7f", transactionIndex: "67", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "7607250000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f1e00000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "7688976", gasUsed: "89486", confirmations: "732760"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943200"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943200", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545638428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943200"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6943200\", addressList[6], addressList... )", async function( ) {
		const txOriginal = {blockNumber: "6943152", timeStamp: "1545638448", hash: "0xad0c8d26919e749ab491075952b5585cf8de27be95b959b8e39ddcb4c6579e14", nonce: "0", blockHash: "0x1b686625f09ee30f90301cc98635c61db76059e1349cc17ad9f7c3393eb7c274", transactionIndex: "92", from: "0x5cf8530f33b197c74933120bff512a3fedbce407", to: "0xae33185575973ee122793b5703273e502caee424", value: "100000000000000000", gas: "98061", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069f1e0000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec800000000000000000000000037e6cf2f6f27c2f0f695aec27acc03a6b2e23339", contractAddress: "", cumulativeGasUsed: "3134180", gasUsed: "98061", confirmations: "732757"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943200"}, {type: "address", name: "option", value: addressList[6]}, {type: "address", name: "referrer", value: addressList[19]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6943200", addressList[6], addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545638448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943200"}, {name: "user", type: "address", value: "0x5cf8530f33b197c74933120bff512a3fedbce407"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "100000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x5cf8530f33b197c74933120bff512a3fedbce407"}, {name: "referrer", type: "address", value: "0x37e6cf2f6f27c2f0f695aec27acc03a6b2e23339"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "2054508000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addBlockData( \"6943000\", \"0xf90206a0c9c95ce3694df7c... )", async function( ) {
		const txOriginal = {blockNumber: "6943203", timeStamp: "1545639197", hash: "0xa1e39cf38ef830e006603b0c61616042276a72bac697132eb00b6479ad579d1b", nonce: "3", blockHash: "0xde98b24ea2b56c344a3ce63e08e80db38f4c0cbfb47b0161e766d0bdfad54109", transactionIndex: "84", from: "0xc1630fc6c9faf31853c9b67526a3f6432f144fc8", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "190000", gasPrice: "7956716500", isError: "0", txreceipt_status: "1", input: "0x1483fc8c000000000000000000000000000000000000000000000000000000000069f11800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000209f90206a0c9c95ce3694df7ce0448c9f12ce4e4226a57810450ae82ffb9418dc71c3b2a61a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794b2930b35844a230f00e51431acae96fe543a0347a09aea67512476abbb29353a4ea08925ea99408b123af755b2c319e1ec2edec2faa0f44d61332a2dcceccc5bf100c60ed8796706421791877f154b0d4de35e7a6b07a0aa48d75e484cc78aa607074e57e74d2946994084d8dffeb8995fd575de9c02cfb901000c0804030a83e03108649d151a0cc4801085040904002884241061b4b26454e016e14084459128e04f1804160b80444007411607fa40a0503352804b492c098d0618000801a2812180c7122a72406000f601054e8b50a0348b0b1856e044f710044180200202455c3d433006080b28087012228820d0d04c8631413560e0c0d0040540a46c08826102000444038c02824c499d61c07120ae0005c0d024010044002c81e247252e0204e05f0a91308b4028006cc0891441a8203f0880114a1102084049068200aa41e6930852128467e905c108020802c900000700c881c5630aa870e0b000042002010000a400159881103102a05890624e9a00312c3a81115187082a86212ab00b8369f118837a11f883794a04845c2089178573696e6733a05254017fdb7c98feaf12d2ecb46425ef47d898754814776b1e4f3fcaa7306e3688dfa86ae00e2dadd90000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5035191", gasUsed: "101580", confirmations: "732706"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943000"}, {type: "bytes", name: "blockData", value: "0xf90206a0c9c95ce3694df7ce0448c9f12ce4e4226a57810450ae82ffb9418dc71c3b2a61a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794b2930b35844a230f00e51431acae96fe543a0347a09aea67512476abbb29353a4ea08925ea99408b123af755b2c319e1ec2edec2faa0f44d61332a2dcceccc5bf100c60ed8796706421791877f154b0d4de35e7a6b07a0aa48d75e484cc78aa607074e57e74d2946994084d8dffeb8995fd575de9c02cfb901000c0804030a83e03108649d151a0cc4801085040904002884241061b4b26454e016e14084459128e04f1804160b80444007411607fa40a0503352804b492c098d0618000801a2812180c7122a72406000f601054e8b50a0348b0b1856e044f710044180200202455c3d433006080b28087012228820d0d04c8631413560e0c0d0040540a46c08826102000444038c02824c499d61c07120ae0005c0d024010044002c81e247252e0204e05f0a91308b4028006cc0891441a8203f0880114a1102084049068200aa41e6930852128467e905c108020802c900000700c881c5630aa870e0b000042002010000a400159881103102a05890624e9a00312c3a81115187082a86212ab00b8369f118837a11f883794a04845c2089178573696e6733a05254017fdb7c98feaf12d2ecb46425ef47d898754814776b1e4f3fcaa7306e3688dfa86ae00e2dadd9"}], name: "addBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBlockData(uint256,bytes)" ]( "6943000", "0xf90206a0c9c95ce3694df7ce0448c9f12ce4e4226a57810450ae82ffb9418dc71c3b2a61a01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d4934794b2930b35844a230f00e51431acae96fe543a0347a09aea67512476abbb29353a4ea08925ea99408b123af755b2c319e1ec2edec2faa0f44d61332a2dcceccc5bf100c60ed8796706421791877f154b0d4de35e7a6b07a0aa48d75e484cc78aa607074e57e74d2946994084d8dffeb8995fd575de9c02cfb901000c0804030a83e03108649d151a0cc4801085040904002884241061b4b26454e016e14084459128e04f1804160b80444007411607fa40a0503352804b492c098d0618000801a2812180c7122a72406000f601054e8b50a0348b0b1856e044f710044180200202455c3d433006080b28087012228820d0d04c8631413560e0c0d0040540a46c08826102000444038c02824c499d61c07120ae0005c0d024010044002c81e247252e0204e05f0a91308b4028006cc0891441a8203f0880114a1102084049068200aa41e6930852128467e905c108020802c900000700c881c5630aa870e0b000042002010000a400159881103102a05890624e9a00312c3a81115187082a86212ab00b8369f118837a11f883794a04845c2089178573696e6733a05254017fdb7c98feaf12d2ecb46425ef47d898754814776b1e4f3fcaa7306e3688dfa86ae00e2dadd9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545639197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6943000"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "456698177730628196" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6943203", timeStamp: "1545639197", hash: "0x27b19c401a00097c12033db988a1886b715718c8d86c7b9243ab1c5701486727", nonce: "21", blockHash: "0xde98b24ea2b56c344a3ce63e08e80db38f4c0cbfb47b0161e766d0bdfad54109", transactionIndex: "131", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6156250000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c00000000000000000000000052bc44d5378309ee2abf1539bf71de1b7d7be3b5", contractAddress: "", cumulativeGasUsed: "7555983", gasUsed: "89486", confirmations: "732706"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[10]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545639197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0x52bc44d5378309ee2abf1539bf71de1b7d7be3b5"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6943236", timeStamp: "1545639703", hash: "0x2c981e79191d9bd735e497ea3449ecd7d194c94591fe89c8c7ff93b99d98bd86", nonce: "37", blockHash: "0xd66a793e0a13cea22e50242e38b97d399c4bf3a923bdd1d2160dde43ae1e1c55", transactionIndex: "143", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c0000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c", contractAddress: "", cumulativeGasUsed: "5995402", gasUsed: "89486", confirmations: "732673"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[9]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545639703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943244", timeStamp: "1545639900", hash: "0x5e3c2dbe19c32832998ef0d3d794551b835fad90136ee16999dd48b6face9801", nonce: "1", blockHash: "0x3e2f0774bc1d0ed0ad557ffc234e1873487d1d1a9021974c9121834fff1b6dfd", transactionIndex: "71", from: "0x5cf8530f33b197c74933120bff512a3fedbce407", to: "0xae33185575973ee122793b5703273e502caee424", value: "10000000000000000", gas: "74486", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "3574647", gasUsed: "74486", confirmations: "732665"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545639900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x5cf8530f33b197c74933120bff512a3fedbce407"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "10000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "2054508000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943276", timeStamp: "1545640482", hash: "0x037af07fd60d91850b9ab52c5bcc98a755404a9fdb533443da451a340af08625", nonce: "38", blockHash: "0xc78ac52c1980406920df8f360bcc5eea7b97e08a9851e384450ddf0dc712e341", transactionIndex: "103", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "74486", gasPrice: "6900000256", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "3439124", gasUsed: "74486", confirmations: "732633"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545640482 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6943285", timeStamp: "1545640558", hash: "0x4edc7c439a259ec3441c830ae3e4ba3443734410a8dc44164eea5cb507861291", nonce: "39", blockHash: "0x49db62e34f6259519ae18c26d31ab0364b94fd85274392a6d8cf6d7a810c51ed", transactionIndex: "81", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89486", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c000000000000000000000000829bd824b016326a401d083b33d092293333a830", contractAddress: "", cumulativeGasUsed: "3984315", gasUsed: "89486", confirmations: "732624"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[13]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545640558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0x829bd824b016326a401d083b33d092293333a830"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6943500\", addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6943327", timeStamp: "1545641176", hash: "0x7233d7633f9337fd75a0d29b8f2007523173ede057082951835557c25186ce5a", nonce: "22", blockHash: "0xfea9f04c465c51daf6051411714bfbe4fe0736751389b3ae9b7d608fdcedf2b4", transactionIndex: "183", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "89422", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f30c000000000000000000000000b2930b35844a230f00e51431acae96fe543a0347", contractAddress: "", cumulativeGasUsed: "7513107", gasUsed: "89422", confirmations: "732582"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[16]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6943500", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545641176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6943500\", addressList[20], addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6943452", timeStamp: "1545642805", hash: "0xe7f2e3e9db47c24065209202a74b2014087ee4c82fac804038b5a4114706c03a", nonce: "10", blockHash: "0x2323f12183070d96d7c4b321e589ff577228c056931a4e12fdf885db987c112a", transactionIndex: "31", from: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "113061", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069f30c0000000000000000000000002a65aca4d5fc5b5c859090a6c34d1641353982260000000000000000000000006fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", contractAddress: "", cumulativeGasUsed: "2381867", gasUsed: "113061", confirmations: "732457"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "address", name: "option", value: addressList[20]}, {type: "address", name: "referrer", value: addressList[5]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6943500", addressList[20], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545642805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "option", type: "address", value: "0x2a65aca4d5fc5b5c859090a6c34d164135398226"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x00000668cd2b9d2ae367e4232e28656fe2e7613d"}, {name: "referrer", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "13571794114994747" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6944000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943456", timeStamp: "1545642835", hash: "0xdf02a8a375523eeffe42a4bfc3eeac1c58ac7b864965edb0f7892c29aa0fbb69", nonce: "23", blockHash: "0xe94174454205d86079710f523bd29e9a2a88a872156d828589d8d4a7f2f96eaf", transactionIndex: "103", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "798774", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f500000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "5586020", gasUsed: "798774", confirmations: "732453"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6944000"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6944000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545642835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6944000"}, {name: "contractAddress", type: "address", value: "0x3cfe51198945a35b875021093a776c72a782ca10"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6944000"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: claimRewardWithBlockData( \"6943500\", \"0xf90211a0c2e2b93ae7c4b8a... )", async function( ) {
		const txOriginal = {blockNumber: "6943523", timeStamp: "1545643892", hash: "0x3cda569c427966c4f03cf4e1cf604facfdea6d1f693c44dce0ad8bd307cd17bb", nonce: "40", blockHash: "0xe27f5c4ae30555c1f395e5f37ce00ea393150690d712bb29448e8e3418f3a632", transactionIndex: "58", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "0", gas: "174041", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0eb15f0f000000000000000000000000000000000000000000000000000000000069f30c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000214f90211a0c2e2b93ae7c4b8ad5da06b27d58d71ee7585666411de16d7bc19b4a2c4dfa2daa01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0709a1cd12a77042bd65d65180d07b03e7aa9a9bd146142aecf93f378e00a9c8fa0824f2a6135b74a3783f7025a1913ec4d4bd5919290d87a61c1c3d88e7571eefaa0e55f98fd9500bfa525673e2e4fa19f43fdb24bfb2b918730910c708362ac78d3b901000038200655820820905981178c2230220036886530422448849c81282148416243c442103206c852828e0280b3150061066512a1082182600161c1a0625928104014c4515468810b845c110ec41848509720c60443800114c24ac80682406915403a900a2b081d5f1348604510413d6016426020001c4d92011008713002b96810f21285046302386056342c41a0880a40008ac170a128a60403d09420a101098c0d01f56243104200780b0c836081218c01013005008ab1804b2899a0c63d20603a920671200c026c103060a68866031c18643099295d0020140188f140b2503a6429b19c00e059209000912008a1077520009440ca40cfc0cc5a6842096010870837ed9e03ecc38369f30c837a121d8379f17f845c20a61f90737061726b706f6f6c2d6574682d7477a02608b045ebfe95ea612f5dfc7343e0dc3de3abb798dc2a942b07a408e6c609ab88f34df2303f7b0f44000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2748462", gasUsed: "120041", confirmations: "732386"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6943500"}, {type: "bytes", name: "blockData", value: "0xf90211a0c2e2b93ae7c4b8ad5da06b27d58d71ee7585666411de16d7bc19b4a2c4dfa2daa01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0709a1cd12a77042bd65d65180d07b03e7aa9a9bd146142aecf93f378e00a9c8fa0824f2a6135b74a3783f7025a1913ec4d4bd5919290d87a61c1c3d88e7571eefaa0e55f98fd9500bfa525673e2e4fa19f43fdb24bfb2b918730910c708362ac78d3b901000038200655820820905981178c2230220036886530422448849c81282148416243c442103206c852828e0280b3150061066512a1082182600161c1a0625928104014c4515468810b845c110ec41848509720c60443800114c24ac80682406915403a900a2b081d5f1348604510413d6016426020001c4d92011008713002b96810f21285046302386056342c41a0880a40008ac170a128a60403d09420a101098c0d01f56243104200780b0c836081218c01013005008ab1804b2899a0c63d20603a920671200c026c103060a68866031c18643099295d0020140188f140b2503a6429b19c00e059209000912008a1077520009440ca40cfc0cc5a6842096010870837ed9e03ecc38369f30c837a121d8379f17f845c20a61f90737061726b706f6f6c2d6574682d7477a02608b045ebfe95ea612f5dfc7343e0dc3de3abb798dc2a942b07a408e6c609ab88f34df2303f7b0f44"}], name: "claimRewardWithBlockData", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimRewardWithBlockData(uint256,bytes)" ]( "6943500", "0xf90211a0c2e2b93ae7c4b8ad5da06b27d58d71ee7585666411de16d7bc19b4a2c4dfa2daa01dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347945a0b54d5dc17e0aadc383d2db43b0a0d3e029c4ca0709a1cd12a77042bd65d65180d07b03e7aa9a9bd146142aecf93f378e00a9c8fa0824f2a6135b74a3783f7025a1913ec4d4bd5919290d87a61c1c3d88e7571eefaa0e55f98fd9500bfa525673e2e4fa19f43fdb24bfb2b918730910c708362ac78d3b901000038200655820820905981178c2230220036886530422448849c81282148416243c442103206c852828e0280b3150061066512a1082182600161c1a0625928104014c4515468810b845c110ec41848509720c60443800114c24ac80682406915403a900a2b081d5f1348604510413d6016426020001c4d92011008713002b96810f21285046302386056342c41a0880a40008ac170a128a60403d09420a101098c0d01f56243104200780b0c836081218c01013005008ab1804b2899a0c63d20603a920671200c026c103060a68866031c18643099295d0020140188f140b2503a6429b19c00e059209000912008a1077520009440ca40cfc0cc5a6842096010870837ed9e03ecc38369f30c837a121d8379f17f845c20a61f90737061726b706f6f6c2d6574682d7477a02608b045ebfe95ea612f5dfc7343e0dc3de3abb798dc2a942b07a408e6c609ab88f34df2303f7b0f44", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545643892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "option", type: "address"}], name: "RoundFinalized", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundFinalized", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "reward", type: "uint256"}], name: "RewardClaimed", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardClaimed", events: [{name: "blockNumber", type: "uint256", value: "6943500"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "winner", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "reward", type: "uint256", value: "16200000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6944000\", addressList[9], addressList... )", async function( ) {
		const txOriginal = {blockNumber: "6943587", timeStamp: "1545644682", hash: "0x44b980372d149d33c2bc4fe7686a04add9b440f97aa22ae2f0f2c5d94e7b6460", nonce: "41", blockHash: "0x33b510febcaa0c41adeaa1220e97cc4dac8226d98af0e249e6ee766d0928b644", transactionIndex: "168", from: "0x67bff8171ab078a5ac961973873862b31d67bf1b", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "112997", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069f5000000000000000000000000005a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c0000000000000000000000006fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", contractAddress: "", cumulativeGasUsed: "7937390", gasUsed: "112997", confirmations: "732322"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6944000"}, {type: "address", name: "option", value: addressList[9]}, {type: "address", name: "referrer", value: addressList[5]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6944000", addressList[9], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545644682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6944000"}, {name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "option", type: "address", value: "0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}, {name: "referrer", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "10203764091746195" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6944000\", addressList[16], addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6943665", timeStamp: "1545645732", hash: "0xe7e4b0c2754d2ba6a27212dc8c33933630c812283b7d35fa5781235adb929eea", nonce: "0", blockHash: "0x5ee77fd267393eb9a7be84ed62c4e199317dcd7b3429b0decc7c82b347d4b82e", transactionIndex: "118", from: "0x37e6cf2f6f27c2f0f695aec27acc03a6b2e23339", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "112933", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069f500000000000000000000000000b2930b35844a230f00e51431acae96fe543a03470000000000000000000000006fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81", contractAddress: "", cumulativeGasUsed: "5755527", gasUsed: "112933", confirmations: "732244"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6944000"}, {type: "address", name: "option", value: addressList[16]}, {type: "address", name: "referrer", value: addressList[5]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6944000", addressList[16], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545645732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6944000"}, {name: "user", type: "address", value: "0x37e6cf2f6f27c2f0f695aec27acc03a6b2e23339"}, {name: "option", type: "address", value: "0xb2930b35844a230f00e51431acae96fe543a0347"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x37e6cf2f6f27c2f0f695aec27acc03a6b2e23339"}, {name: "referrer", type: "address", value: "0x6fe155f3daa9120d9e4f7f5d6e67a03d5e9c3c81"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "75106290357291667" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addBet( \"6944500\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6943692", timeStamp: "1545646053", hash: "0xce14b4b251486c50b8bda194e4fae3f4620f70c16ae35d92d82bb638472076bf", nonce: "25", blockHash: "0xcdaee56be7de10f59b47a15a29c20a9cc76ddb142c52bfec7388298c61f9bdfd", transactionIndex: "137", from: "0x8ecc411b42f9105ecf567c8ddb22346969459a29", to: "0xae33185575973ee122793b5703273e502caee424", value: "100000000000000000", gas: "798838", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xb7acdca6000000000000000000000000000000000000000000000000000000000069f6f4000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec8", contractAddress: "", cumulativeGasUsed: "7802964", gasUsed: "798838", confirmations: "732217"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6944500"}, {type: "address", name: "option", value: addressList[6]}], name: "addBet", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBet(uint256,address)" ]( "6944500", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545646053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: false, name: "contractAddress", type: "address"}], name: "RoundCreated", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoundCreated", events: [{name: "blockNumber", type: "uint256", value: "6944500"}, {name: "contractAddress", type: "address", value: "0x39148d5defe2483eb6c2d4aec07c9a38036688ff"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6944500"}, {name: "user", type: "address", value: "0x8ecc411b42f9105ecf567c8ddb22346969459a29"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "100000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11423296807998056800" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addBetWithReferrer( \"6944000\", addressList[6], addressList... )", async function( ) {
		const txOriginal = {blockNumber: "6943701", timeStamp: "1545646232", hash: "0xd581edf046f4d8e1f2774e4d3d7e8ed18cd5a0b197942ad0c9a8b24e43393c1e", nonce: "0", blockHash: "0x240da452f8e957b9f175fac4765e64268a444ecbf4d70068fb61468dc370cd48", transactionIndex: "160", from: "0x1111111e3a7486f3880b8f0c0d25f5aa2ed3084a", to: "0xae33185575973ee122793b5703273e502caee424", value: "1000000000000000", gas: "97997", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0cf56f3f000000000000000000000000000000000000000000000000000000000069f500000000000000000000000000ea674fdde714fd979de3edf0f56aa9716b898ec800000000000000000000000067bff8171ab078a5ac961973873862b31d67bf1b", contractAddress: "", cumulativeGasUsed: "7509794", gasUsed: "97997", confirmations: "732208"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "blockNumber", value: "6944000"}, {type: "address", name: "option", value: addressList[6]}, {type: "address", name: "referrer", value: addressList[14]}], name: "addBetWithReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBetWithReferrer(uint256,address,address)" ]( "6944000", addressList[6], addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545646232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "blockNumber", type: "uint256"}, {indexed: true, name: "user", type: "address"}, {indexed: true, name: "option", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RoundBetAdded", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RoundBetAdded", events: [{name: "blockNumber", type: "uint256", value: "6944000"}, {name: "user", type: "address", value: "0x1111111e3a7486f3880b8f0c0d25f5aa2ed3084a"}, {name: "option", type: "address", value: "0xea674fdde714fd979de3edf0f56aa9716b898ec8"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "referrer", type: "address"}], name: "NewReferral", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewReferral", events: [{name: "user", type: "address", value: "0x1111111e3a7486f3880b8f0c0d25f5aa2ed3084a"}, {name: "referrer", type: "address", value: "0x67bff8171ab078a5ac961973873862b31d67bf1b"}], address: "0xae33185575973ee122793b5703273e502caee424"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "1214355166666667" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
