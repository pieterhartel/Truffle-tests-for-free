const CryptantCrabPresale = artifacts.require( "./CryptantCrabPresale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CryptantCrabPresale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x9b00fC5dc3Bc5f6E6d016C19512d6d96767E319e", "0xb7784F0B98d049BB73435044C5879cc78365f168", "0x837dDB7A9e71070848A545Acb266997327a59413", "0xECd6b4A2f82b0c9FB283A4a8a1ef5ADf555f794b", "0xc58e24f5B05365Aa21DED72111af939446D13B2e", "0xd9f7F769C3A529B8342d0bC6E30AF91c7b23a08B", "0xb00350845a2619b1255d82DECC26Cd81A3e0153e", "0x85Fc55f18eEDFEbC30A84535CE9D1077703Eb2eA", "0xD9c1498d4528E9Ba7a8571cDc9F7441DA86a0159", "0x032C966df54dF9f30c71f8012C3EDf468A2D9762", "0xF3ac7F0D4b41E83aF7C337Df180D79b2F9c7963F", "0x7B23f68c6c71A4390A01d79e15d7ac9Bc5001C0A", "0x9091D127B540BD6E24Fb308d65192821786CC8A5", "0x1203DF9A2aAf21401Def5bB1092Ea4982976766D", "0x2E0cE5513f4b3A48A8a4E30ff69e24714F5Cd5fA", "0x9e315E9701908501f6dC68A2af6e28a20C75d970", "0x7ED8aadAbc4C9501bbEd9CD23C2C3015a8b965c9", "0x9528DB1EB04D3fFA04fEcbf68b8b20163bb24F56", "0x75298D6Fd0757DaDcfE18a106023efa195F741e6", "0x5bc6F1Bb6766d792A8B9E264a4a1ce6c369615EB", "0x299A68906bE876695E69f004f3Dc7bf213b4c140", "0x75E1e4312E09f6D30343dCe547d58899B3Ac32d7", "0x3163Fa406A301c2eB69A8235365E4B513ffac157"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "currentTokenId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PRESALE_LIMIT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "presaleEndTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "presalePriceUpdatePeriod", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PRESALE_MAX_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PRICE_INCREMENT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "genesisCrab", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentPresalePeriod", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_sender", type: "address"}], name: "getCryptantFragments", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "giveawayTokenId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "withdrawer", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cryptantCrabStorage", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cryptantCrabToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentPresalePrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "refundReceiver", type: "address"}, {indexed: false, name: "reqAmt", type: "uint256"}, {indexed: false, name: "paid", type: "uint256"}, {indexed: false, name: "refundAmt", type: "uint256"}], name: "Refund", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PresalePurchased(address,uint256,uint256,uint256)", "CrabHatched(address,uint256,uint256,uint256,uint256,uint256)", "CryptantFragmentsAdded(address,uint256,uint256)", "CryptantFragmentsRemoved(address,uint256,uint256)", "Refund(address,uint256,uint256,uint256)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x260ecffe36a912f3688d7fa915793137bbaf0980df289ffad7ae877d7ca0a23b", "0x119326b1fd8ed92ff4f7d9da36e3caa7d39681c38d437053fe7e3965cf74aaf8", "0xed28291c8ece55af2a3498316da394241d9026fd7256843843d9f4fa0a56f1e0", "0x493b0dbd8211d00bb91bce263c489749e7a13b57015e0eb6cb883fe58e74b20a", "0xb7048c2ad36aadee977bb16b4543a18866044d27a2ca753e1c7dbcfa7d7a6962", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6574319 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6578940 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_genesisCrabAddress", value: 4}, {type: "address", name: "_cryptantCrabTokenAddress", value: 5}, {type: "address", name: "_cryptantCrabStorageAddress", value: 6}], name: "CryptantCrabPresale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "currentTokenId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentTokenId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PRESALE_LIMIT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PRESALE_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleEndTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleEndTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presalePriceUpdatePeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presalePriceUpdatePeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PRESALE_MAX_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PRESALE_MAX_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PRICE_INCREMENT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PRICE_INCREMENT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "genesisCrab", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "genesisCrab()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentPresalePeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentPresalePeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getCryptantFragments", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCryptantFragments(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "giveawayTokenId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "giveawayTokenId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "withdrawer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cryptantCrabStorage", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cryptantCrabStorage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cryptantCrabToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cryptantCrabToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentPresalePrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentPresalePrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CryptantCrabPresale", function( accounts ) {

	it( "TEST: CryptantCrabPresale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6574319", timeStamp: "1540378462", hash: "0x03dd6da6a78a5bbbc110d5d95b1f544b0527ddd717ab6e22f03925fe63b4b6d7", nonce: "6", blockHash: "0x5551a798602754f091f76bd143cc43ef7918144ce646c675eb9f96ed8d835d2e", transactionIndex: "0", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: 0, value: "0", gas: "3000000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0x7c46a633000000000000000000000000837ddb7a9e71070848a545acb266997327a59413000000000000000000000000ecd6b4a2f82b0c9fb283a4a8a1ef5adf555f794b000000000000000000000000c58e24f5b05365aa21ded72111af939446d13b2e", contractAddress: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", cumulativeGasUsed: "1735690", gasUsed: "1735690", confirmations: "1163237"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_genesisCrabAddress", value: addressList[4]}, {type: "address", name: "_cryptantCrabTokenAddress", value: addressList[5]}, {type: "address", name: "_cryptantCrabStorageAddress", value: addressList[6]}], name: "CryptantCrabPresale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CryptantCrabPresale.new( addressList[4], addressList[5], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540378462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CryptantCrabPresale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"1\", \"120000000000000000\", \"1011011... )", async function( ) {
		const txOriginal = {blockNumber: "6574573", timeStamp: "1540381774", hash: "0x4a9cd8b5b2dbada133295e6361a69382f44d5066115ff9a589ebcf3201a40b89", nonce: "29", blockHash: "0x228995f9ddcd73b303639dee34a5ba899cf5cc03fdd338223067f036d5032094", transactionIndex: "152", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000001aa535d3d0c0000000000000000000000000000000000000000000000000000000000178a18602d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7182793", gasUsed: "271924", confirmations: "1162983"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "1"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "101101101101"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "1", "120000000000000000", "101101101101", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540381774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "1"}, {name: "gene", type: "uint256", value: "101101101101"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"2\", \"120000000000000000\", \"2012012... )", async function( ) {
		const txOriginal = {blockNumber: "6574578", timeStamp: "1540381919", hash: "0x21cca07e6769a51ce723c9d36feff58760ce7d73b143fa70bdbd3f40249bca51", nonce: "30", blockHash: "0x8a774117754c23cbbf8f5ca075c6058a50ad9cd787b31d211fa45fde2e94594b", transactionIndex: "71", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000002ed886b031000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6191877", gasUsed: "258392", confirmations: "1162978"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "2"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "201201201201"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "2", "120000000000000000", "201201201201", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540381919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "2"}, {name: "gene", type: "uint256", value: "201201201201"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"3\", \"120000000000000000\", \"3013013... )", async function( ) {
		const txOriginal = {blockNumber: "6574582", timeStamp: "1540382041", hash: "0x52228f71cb6172d3441f504e2e66cd8e76665df84373f60735ab0f9c4263138a", nonce: "31", blockHash: "0xdc05fc2ab43c87de62ec5eb3b5905978992aecfb63f7b17b8d337282ea029ad0", transactionIndex: "44", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000004626f50035000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3276544", gasUsed: "256860", confirmations: "1162974"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "3"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "301301301301"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "3", "120000000000000000", "301301301301", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540382041 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "3"}, {name: "gene", type: "uint256", value: "301301301301"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "141"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"4\", \"120000000000000000\", \"4014014... )", async function( ) {
		const txOriginal = {blockNumber: "6574587", timeStamp: "1540382116", hash: "0xee0414adff248c5ccb7a25010a69d924d0be40f182dafac35e40a023d39fb6f4", nonce: "32", blockHash: "0x32c92d03ed2475157c115b1ab009dd9848e7182a7f002733f7c19a0a64209892", transactionIndex: "54", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000005d75635039000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2756629", gasUsed: "255456", confirmations: "1162969"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "4"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "401401401401"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "4", "120000000000000000", "401401401401", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540382116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "4"}, {name: "gene", type: "uint256", value: "401401401401"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"5\", \"120000000000000000\", \"5015015... )", async function( ) {
		const txOriginal = {blockNumber: "6574593", timeStamp: "1540382234", hash: "0x236f96872fb49843618ec1864336f42d1f050c0079a21c8020921ff6bd7e4a2d", nonce: "33", blockHash: "0xfabfd49e50aa6eb0bc03ab7961ea839a1068eab03ad39a227ab6c05b9bf7f108", transactionIndex: "103", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000000000074c3d1a03d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3833016", gasUsed: "259860", confirmations: "1162963"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "5"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "501501501501"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "5", "120000000000000000", "501501501501", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540382234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5"}, {name: "gene", type: "uint256", value: "501501501501"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"6\", \"120000000000000000\", \"1021021... )", async function( ) {
		const txOriginal = {blockNumber: "6574600", timeStamp: "1540382328", hash: "0xcf0516c903255ae774156efbeae6780bbeb2ef40b6ed819f27168fa1ff8cc1a7", nonce: "34", blockHash: "0x7cda21ce64b956739811f2b6a7814437815eee86e0b4db5ce7156f62e9f3b58d", transactionIndex: "160", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000000000017c5c27056000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6602763", gasUsed: "259860", confirmations: "1162956"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "6"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "102102102102"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "6", "120000000000000000", "102102102102", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540382328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "6"}, {name: "gene", type: "uint256", value: "102102102102"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"7\", \"120000000000000000\", \"2022022... )", async function( ) {
		const txOriginal = {blockNumber: "6574605", timeStamp: "1540382412", hash: "0x0a026cb3ddce459f5154e733642ed5c65ef007fc097d7b111781f57e0ac8bf88", nonce: "35", blockHash: "0x491ce0e5f0a89ec667a32dad0123f1bdb5bcfc067a8862b9b268b3c414d5a514", transactionIndex: "88", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000002f1430c05a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3439713", gasUsed: "255456", confirmations: "1162951"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "7"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "202202202202"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "7", "120000000000000000", "202202202202", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540382412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "7"}, {name: "gene", type: "uint256", value: "202202202202"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"8\", \"120000000000000000\", \"3023023... )", async function( ) {
		const txOriginal = {blockNumber: "6574615", timeStamp: "1540382579", hash: "0xce0f5d8da5e536b1f3261957d43b4b9cc06ef5cdcff609f86c38263a4ed648c1", nonce: "36", blockHash: "0x704ed49e141e18731c1ea357d131bec5a4b66e0476fa6fa8d072796220159d13", transactionIndex: "76", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000000000046629f105e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3663353", gasUsed: "256924", confirmations: "1162941"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "8"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "302302302302"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "8", "120000000000000000", "302302302302", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540382579 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "8"}, {name: "gene", type: "uint256", value: "302302302302"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"9\", \"120000000000000000\", \"4024024... )", async function( ) {
		const txOriginal = {blockNumber: "6574617", timeStamp: "1540382593", hash: "0x5973b18630853fc2b15a18494fac6a825652b020723c648af567e3fc8a11a2d3", nonce: "37", blockHash: "0xf30b7e55fc72a3a561b27c9f2306ad1c128b4790c908370d4dd1e87e2a97028c", transactionIndex: "42", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000005db10d6062000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2321790", gasUsed: "256924", confirmations: "1162939"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "9"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "402402402402"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "9", "120000000000000000", "402402402402", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540382593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "9"}, {name: "gene", type: "uint256", value: "402402402402"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: createCrab( \"10\", \"120000000000000000\", \"502502... )", async function( ) {
		const txOriginal = {blockNumber: "6574619", timeStamp: "1540382612", hash: "0x30f0294c027a2e5c246f84a8e82b4fa23e116c5807fd272493f7a0cd80b90130", nonce: "38", blockHash: "0x044b0ccc0de14d43ed9134cd9b72d907a7164d5831f6b7f84d892a626a67d03f", transactionIndex: "14", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x64c3dae6000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000000000074ff7bb066000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "722130", gasUsed: "258392", confirmations: "1162937"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_customTokenId", value: "10"}, {type: "uint256", name: "_crabPrice", value: "120000000000000000"}, {type: "uint256", name: "_customGene", value: "502502502502"}, {type: "uint256", name: "_customSkin", value: "0"}, {type: "uint256", name: "_customHeart", value: "0"}, {type: "bool", name: "_hasLegendary", value: false}], name: "createCrab", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createCrab(uint256,uint256,uint256,uint256,uint256,bool)" ]( "10", "120000000000000000", "502502502502", "0", "0", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540382612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "10"}, {name: "gene", type: "uint256", value: "502502502502"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575069", timeStamp: "1540388984", hash: "0x1cbbb337f6c8989d60827891cbba3a10f046f22ef2beaa8375de2f9b58e2888c", nonce: "0", blockHash: "0x6a908b097baefbc0d9bc8bb480201f9ba3b738cbdeea52e8bdf49d0728b1defd", transactionIndex: "57", from: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4337799", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "6408647", gasUsed: "2854590", confirmations: "1162487"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540388984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "11"}, {name: "gene", type: "uint256", value: "106207503509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "12"}, {name: "gene", type: "uint256", value: "209403503203"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "13"}, {name: "gene", type: "uint256", value: "310407106306"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "14"}, {name: "gene", type: "uint256", value: "401107408201"}, {name: "specialSkin", type: "uint256", value: "4"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "134"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "15"}, {name: "gene", type: "uint256", value: "509103503405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "16"}, {name: "gene", type: "uint256", value: "110509504306"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "17"}, {name: "gene", type: "uint256", value: "208101405205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "18"}, {name: "gene", type: "uint256", value: "306506104107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "19"}, {name: "gene", type: "uint256", value: "410109503503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "20"}, {name: "gene", type: "uint256", value: "508110106507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "421"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "563137039000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575074", timeStamp: "1540389051", hash: "0xfc6b06ea643110b150575a7ddb8d24aed18b1b210efc5a4712dc69a625781b82", nonce: "1", blockHash: "0x689a2b7301edab37eb11f9d87c079e435cbdf857f7f1734e1de66cfcf4612665", transactionIndex: "38", from: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4334916", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4514485", gasUsed: "2813164", confirmations: "1162482"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540389051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "21"}, {name: "gene", type: "uint256", value: "109403107504"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "213"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "22"}, {name: "gene", type: "uint256", value: "206504207210"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "23"}, {name: "gene", type: "uint256", value: "308206109403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "24"}, {name: "gene", type: "uint256", value: "401507507307"}, {name: "specialSkin", type: "uint256", value: "4"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "25"}, {name: "gene", type: "uint256", value: "508509103109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "313"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "26"}, {name: "gene", type: "uint256", value: "106510406205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "214"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "27"}, {name: "gene", type: "uint256", value: "206410505209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "28"}, {name: "gene", type: "uint256", value: "306209509508"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "29"}, {name: "gene", type: "uint256", value: "410108303509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "332"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "tokenId", type: "uint256", value: "30"}, {name: "gene", type: "uint256", value: "503403108204"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xd9f7f769c3a529b8342d0bc6e30af91c7b23a08b"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "60000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "563137039000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575075", timeStamp: "1540389058", hash: "0xac415d0396c715dfef0a9dfb5ffd54ea084803692267dcd450cc27f989a0d906", nonce: "0", blockHash: "0xff57a0424ddeabb516984621c9e9a7e90e9575dd18330d48f0dea76d96276522", transactionIndex: "33", from: "0xb00350845a2619b1255d82decc26cd81a3e0153e", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4241206", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4850184", gasUsed: "2821279", confirmations: "1162481"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540389058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "31"}, {name: "gene", type: "uint256", value: "105310207110"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "133"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "32"}, {name: "gene", type: "uint256", value: "206207503107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "33"}, {name: "gene", type: "uint256", value: "304307509106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "431"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "34"}, {name: "gene", type: "uint256", value: "403310204303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "35"}, {name: "gene", type: "uint256", value: "509108302106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "321"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "36"}, {name: "gene", type: "uint256", value: "107409505509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "213"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "37"}, {name: "gene", type: "uint256", value: "205407207406"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "214"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "38"}, {name: "gene", type: "uint256", value: "302106305207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "39"}, {name: "gene", type: "uint256", value: "407504203206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "40"}, {name: "gene", type: "uint256", value: "509107509305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1312019013000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setWithdrawer( addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "6575382", timeStamp: "1540393270", hash: "0xba3ad4d2cabbc748db7f8b4812e15ab7148bb3c002a65f93445252c33ff355c5", nonce: "261", blockHash: "0xbd106735fa03bd16f8f7effec26a1116894ba2213984bf0a2ab8edfaa787492b", transactionIndex: "43", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d174c24000000000000000000000000b7784f0b98d049bb73435044c5879cc78365f168", contractAddress: "", cumulativeGasUsed: "2742635", gasUsed: "43587", confirmations: "1162174"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newWithdrawer", value: addressList[3]}], name: "setWithdrawer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setWithdrawer(address)" ]( addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540393270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( \"3600000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6575392", timeStamp: "1540393372", hash: "0xb055067ff4bd7dfd09ad5d58777e560c108496b846b7ad547fa7178113f3f92e", nonce: "262", blockHash: "0x61364795750eb543e1de1404e47a7f230254788f659b8570beac1a08fcc18b79", transactionIndex: "16", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2e1a7d4d00000000000000000000000000000000000000000000000031f5c4ed27680000", contractAddress: "", cumulativeGasUsed: "708459", gasUsed: "30661", confirmations: "1162164"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "3600000000000000000"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(uint256)" ]( "3600000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540393372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575781", timeStamp: "1540398947", hash: "0xeaa85df5258ce8829c4317cbd10e92dda22b3e6a095c85d9417ef1dbd23580f7", nonce: "0", blockHash: "0xaf97956f600576bc72ec9d43e04ac2a7286b74ebc940dcdb967949abd0af2996", transactionIndex: "10", from: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4304169", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3184627", gasUsed: "2840779", confirmations: "1161775"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540398947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "41"}, {name: "gene", type: "uint256", value: "107310406105"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "42"}, {name: "gene", type: "uint256", value: "208305107403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "43"}, {name: "gene", type: "uint256", value: "308507207108"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "44"}, {name: "gene", type: "uint256", value: "401206209201"}, {name: "specialSkin", type: "uint256", value: "4"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "114"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "45"}, {name: "gene", type: "uint256", value: "506207508209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "46"}, {name: "gene", type: "uint256", value: "103109507309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "47"}, {name: "gene", type: "uint256", value: "203504505506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "48"}, {name: "gene", type: "uint256", value: "306509206507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "114"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "49"}, {name: "gene", type: "uint256", value: "403107506110"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "321"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "50"}, {name: "gene", type: "uint256", value: "507506203404"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "336502070000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575795", timeStamp: "1540399135", hash: "0x441a532a6227fc7ba4a26683fc4bbb18a1353e79133e00fa0a399dd19632c3b2", nonce: "0", blockHash: "0x2852c5f63a2d1e58f4b77b7bdf137c35a03b7674e0b5426ed3cd795c05b9accf", transactionIndex: "74", from: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4353213", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "6198444", gasUsed: "2836502", confirmations: "1161761"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540399135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "51"}, {name: "gene", type: "uint256", value: "110110104203"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "52"}, {name: "gene", type: "uint256", value: "209407504108"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "341"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "53"}, {name: "gene", type: "uint256", value: "306403106407"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "54"}, {name: "gene", type: "uint256", value: "402209510103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "55"}, {name: "gene", type: "uint256", value: "502310403303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "56"}, {name: "gene", type: "uint256", value: "107310110410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "57"}, {name: "gene", type: "uint256", value: "210508406310"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "58"}, {name: "gene", type: "uint256", value: "307401203506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "321"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "59"}, {name: "gene", type: "uint256", value: "408404208506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "312"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "60"}, {name: "gene", type: "uint256", value: "509305304103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1419841849000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575798", timeStamp: "1540399192", hash: "0xe2a8b6e4ec66d3cb9d9e5417bbc807fe002f7b51c2aafd02e6bd5fca8605df8c", nonce: "1", blockHash: "0x68eb92f7c01ae163f6c0167b6d8f30d08be2248b00cebf38a3d5c0f91e1c5aec", transactionIndex: "26", from: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4210938", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4453325", gasUsed: "2802888", confirmations: "1161758"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540399192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "61"}, {name: "gene", type: "uint256", value: "104509105210"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "62"}, {name: "gene", type: "uint256", value: "204103305205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "63"}, {name: "gene", type: "uint256", value: "308408409405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "321"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "64"}, {name: "gene", type: "uint256", value: "404510405310"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "65"}, {name: "gene", type: "uint256", value: "508405204208"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "224"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "66"}, {name: "gene", type: "uint256", value: "108305303110"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "67"}, {name: "gene", type: "uint256", value: "210507104303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "68"}, {name: "gene", type: "uint256", value: "301106503505"}, {name: "specialSkin", type: "uint256", value: "3"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "214"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "69"}, {name: "gene", type: "uint256", value: "403305109209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "tokenId", type: "uint256", value: "70"}, {name: "gene", type: "uint256", value: "503206407508"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xd9c1498d4528e9ba7a8571cdc9f7441da86a0159"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "60000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1419841849000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575824", timeStamp: "1540399655", hash: "0x0ce2efddfad8f41711f4de908db6be7690f8b6804bf26aa4462cf4c404cfe5f3", nonce: "0", blockHash: "0xbd2eb8006078087eec6996cb39ae8f1aaea882ba7dd82133d4e8274724fe4c11", transactionIndex: "99", from: "0x032c966df54df9f30c71f8012c3edf468a2d9762", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4261024", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "6154802", gasUsed: "2827239", confirmations: "1161732"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540399655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "71"}, {name: "gene", type: "uint256", value: "104208410410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "214"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "72"}, {name: "gene", type: "uint256", value: "206304303408"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "73"}, {name: "gene", type: "uint256", value: "301109208508"}, {name: "specialSkin", type: "uint256", value: "3"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "74"}, {name: "gene", type: "uint256", value: "409308504104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "75"}, {name: "gene", type: "uint256", value: "507206401205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "76"}, {name: "gene", type: "uint256", value: "106210103110"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "77"}, {name: "gene", type: "uint256", value: "206309109303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "78"}, {name: "gene", type: "uint256", value: "305205408310"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "79"}, {name: "gene", type: "uint256", value: "405403103308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "213"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "80"}, {name: "gene", type: "uint256", value: "509504210409"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "242"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "444908218023196695" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575853", timeStamp: "1540399954", hash: "0x6f738c7e359fe14640b3259ea4f258e8b22efdcb49bc733e21c855d8ad5ccf99", nonce: "1", blockHash: "0x952b2a58ef733f746bf791dfda5baaf2b3603f0ca9ae69d34ec2371481af8092", transactionIndex: "28", from: "0xb00350845a2619b1255d82decc26cd81a3e0153e", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4319847", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4974483", gasUsed: "2791287", confirmations: "1161703"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540399954 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "81"}, {name: "gene", type: "uint256", value: "109204409301"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "82"}, {name: "gene", type: "uint256", value: "207203408403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "83"}, {name: "gene", type: "uint256", value: "303509305209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "314"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "84"}, {name: "gene", type: "uint256", value: "404206303308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "85"}, {name: "gene", type: "uint256", value: "507108107304"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "224"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "86"}, {name: "gene", type: "uint256", value: "103104509104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "87"}, {name: "gene", type: "uint256", value: "209208404508"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "521"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "88"}, {name: "gene", type: "uint256", value: "309309407106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "89"}, {name: "gene", type: "uint256", value: "402207503406"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "tokenId", type: "uint256", value: "90"}, {name: "gene", type: "uint256", value: "503106303410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xb00350845a2619b1255d82decc26cd81a3e0153e"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "60000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1312019013000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6575860", timeStamp: "1540400037", hash: "0xd8bb38fd00e1c2c1b6c69ef354de24523ec924891de5a11a9c86b3e5ffd2fa39", nonce: "1", blockHash: "0x12a916084dad5be3633efe2376b0ea2de14dcd6e64da4524ed0b0446ea93395c", transactionIndex: "52", from: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "549768", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4042669", gasUsed: "369448", confirmations: "1161696"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540400037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "91"}, {name: "gene", type: "uint256", value: "101309209310"}, {name: "specialSkin", type: "uint256", value: "1"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "33000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "336502070000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6575884", timeStamp: "1540400335", hash: "0x9db120d50ad9bf999c19b121342b0f724ebbaf901040f395d892815874cb2757", nonce: "264", blockHash: "0xf46e1c8da6af5f9e84e66b0ec02f2464c3f8da49b73d4fc7e60a5aa1acc79ff9", transactionIndex: "26", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec243555000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3548271", gasUsed: "2664500", confirmations: "1161672"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540400335 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5001"}, {name: "gene", type: "uint256", value: "203304409106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "142"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5002"}, {name: "gene", type: "uint256", value: "207310210410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5003"}, {name: "gene", type: "uint256", value: "210503210203"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5004"}, {name: "gene", type: "uint256", value: "204208106307"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5005"}, {name: "gene", type: "uint256", value: "207106104509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "224"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5006"}, {name: "gene", type: "uint256", value: "205507207404"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "161"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5007"}, {name: "gene", type: "uint256", value: "206209206503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "141"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5008"}, {name: "gene", type: "uint256", value: "204104407503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5009"}, {name: "gene", type: "uint256", value: "208405106206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5010"}, {name: "gene", type: "uint256", value: "204103407109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6575985", timeStamp: "1540401556", hash: "0x39dc5f39920e2fe3a9fcfeca0833702c7f73471381910537ac34b2970bb6730f", nonce: "2", blockHash: "0xab88e4e8201c489173a4a28e92e1a7247952c511c51055e3f661e0c26ca02d1e", transactionIndex: "26", from: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "720000000000000000", gas: "2565847", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3230851", gasUsed: "1698501", confirmations: "1161571"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "720000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "6"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540401556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "6"}, {name: "cryptant", type: "uint256", value: "18000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "92"}, {name: "gene", type: "uint256", value: "207507405507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "242"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "93"}, {name: "gene", type: "uint256", value: "305205105103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "94"}, {name: "gene", type: "uint256", value: "406508310510"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "95"}, {name: "gene", type: "uint256", value: "508508507206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "96"}, {name: "gene", type: "uint256", value: "104202410509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "tokenId", type: "uint256", value: "97"}, {name: "gene", type: "uint256", value: "205103308309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x85fc55f18eedfebc30a84535ce9d1077703eb2ea"}, {name: "amount", type: "uint256", value: "18000"}, {name: "newBalance", type: "uint256", value: "51000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "336502070000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6576076", timeStamp: "1540402750", hash: "0xf56a148c00554598bc2ad3a172ce186b9be1ecbb37e82286360235f32a163771", nonce: "1", blockHash: "0x72325464e12427092f3ec2af7315cf0582106b9c5f6766201226a7a76f05a00b", transactionIndex: "139", from: "0x032c966df54df9f30c71f8012c3edf468a2d9762", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "240000000000000000", gas: "880183", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6775908", gasUsed: "592661", confirmations: "1161480"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "240000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "2"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540402750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "amount", type: "uint256", value: "2"}, {name: "cryptant", type: "uint256", value: "6000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "98"}, {name: "gene", type: "uint256", value: "305509104303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "tokenId", type: "uint256", value: "99"}, {name: "gene", type: "uint256", value: "410407206104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "215"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x032c966df54df9f30c71f8012c3edf468a2d9762"}, {name: "amount", type: "uint256", value: "6000"}, {name: "newBalance", type: "uint256", value: "36000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "444908218023196695" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6576098", timeStamp: "1540403014", hash: "0x3a393d762a9396e094cd30f8a91634a92e7735bedc8fec6657dbe421325329c8", nonce: "265", blockHash: "0xd6a5c0794fd45e84d98c7d37e61948a4b0d81c8d85d13542a9e69e20bc67e147", transactionIndex: "31", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec243555000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4066597", gasUsed: "2665968", confirmations: "1161458"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540403014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5011"}, {name: "gene", type: "uint256", value: "504209409406"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5012"}, {name: "gene", type: "uint256", value: "507505206107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "142"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5013"}, {name: "gene", type: "uint256", value: "505205106103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "241"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5014"}, {name: "gene", type: "uint256", value: "510203406510"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5015"}, {name: "gene", type: "uint256", value: "509505303109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5016"}, {name: "gene", type: "uint256", value: "506410505210"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5017"}, {name: "gene", type: "uint256", value: "505310309403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "332"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5018"}, {name: "gene", type: "uint256", value: "507104203504"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5019"}, {name: "gene", type: "uint256", value: "509107408407"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5020"}, {name: "gene", type: "uint256", value: "510304108205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6576108", timeStamp: "1540403137", hash: "0x884bbe8979aeaf0659922c72bdbd251618a4d24af5da752a31ab9cec08176e86", nonce: "266", blockHash: "0xb4e2a71595472c202defe8c5d6cd522f2f027a103e48b05b0b1c4aae8f216a02", transactionIndex: "11", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xec2435550000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4330607", gasUsed: "4000000", confirmations: "1161448"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "20"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6576123", timeStamp: "1540403330", hash: "0x1e38551c0cc7689c77a03f2868294cfa3a2995f3dbcd3f75492dce69ee7c9fac", nonce: "267", blockHash: "0xc189882b460a859fe436393f221a35f7841ae2e57939db411a037e7a46f49c13", transactionIndex: "45", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec243555000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5226102", gasUsed: "2669126", confirmations: "1161433"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540403330 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5021"}, {name: "gene", type: "uint256", value: "508503203209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5022"}, {name: "gene", type: "uint256", value: "510309507405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5023"}, {name: "gene", type: "uint256", value: "503306508106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "115"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5024"}, {name: "gene", type: "uint256", value: "502305110109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5025"}, {name: "gene", type: "uint256", value: "510501106103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5026"}, {name: "gene", type: "uint256", value: "503104302206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5027"}, {name: "gene", type: "uint256", value: "503304408109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "611"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5028"}, {name: "gene", type: "uint256", value: "506405206107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5029"}, {name: "gene", type: "uint256", value: "504203409503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5030"}, {name: "gene", type: "uint256", value: "510104509509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "312"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6576149", timeStamp: "1540403722", hash: "0x02745462df2398058c0a26ac9d4264b829600fd22cc4d131d2869bd2a7f66b33", nonce: "268", blockHash: "0xbdc50afc848685a14bee15ebddaac258f0ecdf0c6bef4b2c27fec5d24e41df71", transactionIndex: "26", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec243555000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3968189", gasUsed: "2671914", confirmations: "1161407"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540403722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5031"}, {name: "gene", type: "uint256", value: "505108505407"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5032"}, {name: "gene", type: "uint256", value: "504208209503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5033"}, {name: "gene", type: "uint256", value: "505303310303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "431"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5034"}, {name: "gene", type: "uint256", value: "507503106409"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5035"}, {name: "gene", type: "uint256", value: "503508505106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5036"}, {name: "gene", type: "uint256", value: "509309404403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5037"}, {name: "gene", type: "uint256", value: "503209403202"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "241"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5038"}, {name: "gene", type: "uint256", value: "504204106204"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "413"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5039"}, {name: "gene", type: "uint256", value: "503108306207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5040"}, {name: "gene", type: "uint256", value: "510403206306"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6576158", timeStamp: "1540403856", hash: "0x4c63b8c73f86923d6bb2c614fe69266325c989e2de31250194e2ef4c63d7b808", nonce: "269", blockHash: "0xc67fb84cd99ed6a798a5d6cb5cd6a586f544baf700545f6da25d8e6badb4e22c", transactionIndex: "68", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec243555000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5447430", gasUsed: "2663032", confirmations: "1161398"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540403856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5041"}, {name: "gene", type: "uint256", value: "510105205503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5042"}, {name: "gene", type: "uint256", value: "507504407405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5043"}, {name: "gene", type: "uint256", value: "505207309505"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "131"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5044"}, {name: "gene", type: "uint256", value: "509304109507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5045"}, {name: "gene", type: "uint256", value: "504109405207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "314"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5046"}, {name: "gene", type: "uint256", value: "504108407204"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5047"}, {name: "gene", type: "uint256", value: "504103506308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5048"}, {name: "gene", type: "uint256", value: "510510510305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5049"}, {name: "gene", type: "uint256", value: "504204506303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5050"}, {name: "gene", type: "uint256", value: "510203208304"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6577651", timeStamp: "1540425221", hash: "0xa34a435623653461dda80e1605899bf84c281ca53aa9fc767622ce9fb6b5ca63", nonce: "0", blockHash: "0x56b21a26efec5478b6a0d2fb47ce95adde12d388e33769cac2a5d651d1c2e701", transactionIndex: "109", from: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "360000000000000000", gas: "1338994", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5553805", gasUsed: "889727", confirmations: "1159905"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "360000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "3"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540425221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f"}, {name: "amount", type: "uint256", value: "3"}, {name: "cryptant", type: "uint256", value: "9000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f"}, {name: "tokenId", type: "uint256", value: "100"}, {name: "gene", type: "uint256", value: "507204108304"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f"}, {name: "tokenId", type: "uint256", value: "101"}, {name: "gene", type: "uint256", value: "109110407210"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f"}, {name: "tokenId", type: "uint256", value: "102"}, {name: "gene", type: "uint256", value: "203409103407"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "114"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xf3ac7f0d4b41e83af7c337df180d79b2f9c7963f"}, {name: "amount", type: "uint256", value: "9000"}, {name: "newBalance", type: "uint256", value: "9000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "108665804000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6577658", timeStamp: "1540425279", hash: "0x39309d1fa14032ee9ed5134ae9438299d3d68d69e5ba3f07b6de4062f1b090fc", nonce: "0", blockHash: "0x0333ee7fb60946f7149841cb71d426ac81056c9a2a2950d172b67ba5973fe790", transactionIndex: "78", from: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4269964", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5981199", gasUsed: "2803343", confirmations: "1159898"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540425279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "103"}, {name: "gene", type: "uint256", value: "306109304104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "104"}, {name: "gene", type: "uint256", value: "406108205409"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "105"}, {name: "gene", type: "uint256", value: "504505204207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "106"}, {name: "gene", type: "uint256", value: "107409210104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "312"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "107"}, {name: "gene", type: "uint256", value: "204108209508"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "108"}, {name: "gene", type: "uint256", value: "307306101410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "331"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "109"}, {name: "gene", type: "uint256", value: "408509505305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "110"}, {name: "gene", type: "uint256", value: "504110303307"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "111"}, {name: "gene", type: "uint256", value: "102109108403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "141"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "tokenId", type: "uint256", value: "112"}, {name: "gene", type: "uint256", value: "205303208206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x7b23f68c6c71a4390a01d79e15d7ac9bc5001c0a"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "833983765540000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6577659", timeStamp: "1540425300", hash: "0xd795efcb64eaf303ba57c92312d8ebca4c02781380db885c61c63273fc943a37", nonce: "23", blockHash: "0x86c442c0a0ca4e9b456e95869bfe5ce3614c11663e35d73f4c37f7b817e2b70b", transactionIndex: "67", from: "0x9091d127b540bd6e24fb308d65192821786cc8a5", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "480000000000000000", gas: "1753309", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4477746", gasUsed: "1163001", confirmations: "1159897"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "480000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "4"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540425300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "amount", type: "uint256", value: "4"}, {name: "cryptant", type: "uint256", value: "12000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "tokenId", type: "uint256", value: "113"}, {name: "gene", type: "uint256", value: "306503305405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "tokenId", type: "uint256", value: "114"}, {name: "gene", type: "uint256", value: "408106406103"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "tokenId", type: "uint256", value: "115"}, {name: "gene", type: "uint256", value: "510204306303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "tokenId", type: "uint256", value: "116"}, {name: "gene", type: "uint256", value: "109507103109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x9091d127b540bd6e24fb308d65192821786cc8a5"}, {name: "amount", type: "uint256", value: "12000"}, {name: "newBalance", type: "uint256", value: "12000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "384920503494552899" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6577664", timeStamp: "1540425379", hash: "0x077bf3ccc717d668b4d7e97f16b29c4d0f14dd90674d37c12ec19175a81823e4", nonce: "13", blockHash: "0x51a43ee9b4a8646c68fc514ab96047e36cf8322123ad5166009fa48af45388dc", transactionIndex: "47", from: "0x1203df9a2aaf21401def5bb1092ea4982976766d", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4209084", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4530547", gasUsed: "2853991", confirmations: "1159892"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540425379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "117"}, {name: "gene", type: "uint256", value: "205107206505"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "118"}, {name: "gene", type: "uint256", value: "307107303507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "119"}, {name: "gene", type: "uint256", value: "405403108506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "120"}, {name: "gene", type: "uint256", value: "507410506409"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "121"}, {name: "gene", type: "uint256", value: "107505108204"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "421"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "122"}, {name: "gene", type: "uint256", value: "209409106504"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "313"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "123"}, {name: "gene", type: "uint256", value: "306505208408"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "224"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "124"}, {name: "gene", type: "uint256", value: "407108206106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "251"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "125"}, {name: "gene", type: "uint256", value: "508209108101"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "142"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "tokenId", type: "uint256", value: "126"}, {name: "gene", type: "uint256", value: "101308507309"}, {name: "specialSkin", type: "uint256", value: "1"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "341"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x1203df9a2aaf21401def5bb1092ea4982976766d"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "347252868525849289" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6577753", timeStamp: "1540426503", hash: "0x1242ce3da977f5f859fe34c2dbd2e76b7dcddd30794bdd00cbed9cfbaa6a75da", nonce: "2133", blockHash: "0xc802d390a5f581533d6e8c521643f8b558c7e8fa16f2e18dd141a478375c3a8a", transactionIndex: "45", from: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4353213", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5795378", gasUsed: "2873610", confirmations: "1159803"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540426503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "127"}, {name: "gene", type: "uint256", value: "202306410303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "128"}, {name: "gene", type: "uint256", value: "303108408305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "242"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "129"}, {name: "gene", type: "uint256", value: "410308204503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "130"}, {name: "gene", type: "uint256", value: "501504306409"}, {name: "specialSkin", type: "uint256", value: "5"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "143"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "131"}, {name: "gene", type: "uint256", value: "108206404507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "332"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "132"}, {name: "gene", type: "uint256", value: "210403508304"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "332"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "133"}, {name: "gene", type: "uint256", value: "308108307410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "134"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "134"}, {name: "gene", type: "uint256", value: "409508505405"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "213"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "135"}, {name: "gene", type: "uint256", value: "504308308505"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "136"}, {name: "gene", type: "uint256", value: "105402108209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "242"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "153289113876871365" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6577760", timeStamp: "1540426562", hash: "0x48298d0cf2e7390739ab7aa88d04821c9f2f3a5663f8214de6496b86cf79f38d", nonce: "1484", blockHash: "0x83d96710f034d5c66a1d8a4ce884f3a770cabb16c71ab52a48016cccb5b72e44", transactionIndex: "8", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "515791", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "978229", gasUsed: "348265", confirmations: "1159796"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540426562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "tokenId", type: "uint256", value: "137"}, {name: "gene", type: "uint256", value: "204408205107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "332"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "3000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "148550291472833407" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6577776", timeStamp: "1540426778", hash: "0x8d9395b4a0cdcf83f64fe1c33dba8402053f19f7e3e25922118b1ff6ee30a96a", nonce: "0", blockHash: "0x8980539c3fbc833726227ac750c37d34cf4a57b137aa41bd27b7f85854b38032", transactionIndex: "54", from: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1200000000000000000", gas: "4255938", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5940247", gasUsed: "2796928", confirmations: "1159780"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540426778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "138"}, {name: "gene", type: "uint256", value: "308107104208"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "139"}, {name: "gene", type: "uint256", value: "406106104507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "140"}, {name: "gene", type: "uint256", value: "506203309206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "141"}, {name: "gene", type: "uint256", value: "104105503503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "142"}, {name: "gene", type: "uint256", value: "207307403207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "143"}, {name: "gene", type: "uint256", value: "309509206203"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "144"}, {name: "gene", type: "uint256", value: "406505310305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "145"}, {name: "gene", type: "uint256", value: "502208104409"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "146"}, {name: "gene", type: "uint256", value: "108108405507"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "312"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "tokenId", type: "uint256", value: "147"}, {name: "gene", type: "uint256", value: "209303510303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "313"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x7ed8aadabc4c9501bbed9cd23c2c3015a8b965c9"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6577799", timeStamp: "1540427073", hash: "0xbbecb52938287c29ca9c38f2aa178aed08dff53c9c8d76b7abf306611061696e", nonce: "1485", blockHash: "0x0c8fac2707cd063b0a04a169670223869bda99b45d4346c9b72a24e286619345", transactionIndex: "30", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "513924", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1882335", gasUsed: "341148", confirmations: "1159757"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540427073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "tokenId", type: "uint256", value: "148"}, {name: "gene", type: "uint256", value: "307107301403"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "6000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "148550291472833407" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6577819", timeStamp: "1540427409", hash: "0x6aaed26968e64aa757f55ce341065be4bb16ad00a3c7f6d87a81005fb8b47a5d", nonce: "1486", blockHash: "0x23dda6b231b13a02e030a536f050b8b691ecae215826aee571588c94c211778b", transactionIndex: "34", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "475195", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1753079", gasUsed: "313861", confirmations: "1159737"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540427409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "tokenId", type: "uint256", value: "149"}, {name: "gene", type: "uint256", value: "408104410406"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "9000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "148550291472833407" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6577919", timeStamp: "1540428672", hash: "0x0d15c08851e246f318a2c3d198e4a496f98ac4200366092c170c11ff1464f9e8", nonce: "40", blockHash: "0xb289eb0f3ebb72fbc40c2e5c603ae4a150a430e3ad814efbee0f6993412b0e25", transactionIndex: "135", from: "0x9528db1eb04d3ffa04fecbf68b8b20163bb24f56", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "477405", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6283559", gasUsed: "315334", confirmations: "1159637"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540428672 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x9528db1eb04d3ffa04fecbf68b8b20163bb24f56"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x9528db1eb04d3ffa04fecbf68b8b20163bb24f56"}, {name: "tokenId", type: "uint256", value: "150"}, {name: "gene", type: "uint256", value: "505503407208"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "213"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x9528db1eb04d3ffa04fecbf68b8b20163bb24f56"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "4000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "289191232912844841" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6577934", timeStamp: "1540428929", hash: "0x76e82b2fa24cb2b83006468c4d0b4adc7698051872eac2e34f7cb1e6dbe49261", nonce: "479", blockHash: "0xcd1d2f3a73cf01b4141d41cebab1464f194977952f3d32aec2a70c9214c4ae86", transactionIndex: "84", from: "0x75298d6fd0757dadcfe18a106023efa195f741e6", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "120000000000000000", gas: "497695", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4761624", gasUsed: "330329", confirmations: "1159622"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540428929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x75298d6fd0757dadcfe18a106023efa195f741e6"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75298d6fd0757dadcfe18a106023efa195f741e6"}, {name: "tokenId", type: "uint256", value: "151"}, {name: "gene", type: "uint256", value: "103108305309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "411"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x75298d6fd0757dadcfe18a106023efa195f741e6"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "3000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "357470159603752389" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6578071", timeStamp: "1540431049", hash: "0x2ef45f49803176038d92e9e9a0c1965d8fae5a7cdced4f4585aa6803375e625d", nonce: "1368", blockHash: "0xd7d940dda290252cd3c05027cc6488d1a91838b67c3635295ccd5aa268bb9bcd", transactionIndex: "54", from: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1210000000000000000", gas: "4258662", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "6326475", gasUsed: "2834792", confirmations: "1159485"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1210000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540431049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "152"}, {name: "gene", type: "uint256", value: "203205308305"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "331"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "153"}, {name: "gene", type: "uint256", value: "306205308309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "154"}, {name: "gene", type: "uint256", value: "401408107506"}, {name: "specialSkin", type: "uint256", value: "4"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "155"}, {name: "gene", type: "uint256", value: "508405509506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "413"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "156"}, {name: "gene", type: "uint256", value: "106405207104"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "221"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "157"}, {name: "gene", type: "uint256", value: "206210308108"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "321"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "158"}, {name: "gene", type: "uint256", value: "310103405101"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "159"}, {name: "gene", type: "uint256", value: "405508308309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "160"}, {name: "gene", type: "uint256", value: "504207509404"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "tokenId", type: "uint256", value: "161"}, {name: "gene", type: "uint256", value: "104510206208"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "231"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x5bc6f1bb6766d792a8b9e264a4a1ce6c369615eb"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "8816684818610255080" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6578111", timeStamp: "1540431572", hash: "0xd411c7ef2124ef041137a159a483255705ed19830f75d2e69dfa2038123769fe", nonce: "2134", blockHash: "0x93419a51904ecf22526eb4418589be6948773fd53822958350d16ef1ca1fcc65", transactionIndex: "111", from: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "363000000000000000", gas: "1291785", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7383801", gasUsed: "867062", confirmations: "1159445"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "363000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "3"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540431572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "3"}, {name: "cryptant", type: "uint256", value: "9000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "162"}, {name: "gene", type: "uint256", value: "203110110107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "114"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "163"}, {name: "gene", type: "uint256", value: "303203408508"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "164"}, {name: "gene", type: "uint256", value: "403506404509"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "121000000000000000"}, {name: "growthValue", type: "uint256", value: "413"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "9000"}, {name: "newBalance", type: "uint256", value: "39000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "153289113876871365" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6578309", timeStamp: "1540434563", hash: "0xaf5f3d6b131d2c09d7128c4e84cd40f5c3189fdbca1bc15b4b546ed75e4ee741", nonce: "0", blockHash: "0x8f722f6034a7f0b46e9bc6f71cb72034bbb31e0eec8082c9ebbde57d0109ca8d", transactionIndex: "55", from: "0x299a68906be876695e69f004f3dc7bf213b4c140", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1220000000000000000", gas: "4270140", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5515957", gasUsed: "2854188", confirmations: "1159247"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "1220000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540434563 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "165"}, {name: "gene", type: "uint256", value: "506207209408"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "166"}, {name: "gene", type: "uint256", value: "107508304106"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "313"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "167"}, {name: "gene", type: "uint256", value: "201405206108"}, {name: "specialSkin", type: "uint256", value: "2"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "331"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "168"}, {name: "gene", type: "uint256", value: "305106106504"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "142"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "169"}, {name: "gene", type: "uint256", value: "403110508209"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "170"}, {name: "gene", type: "uint256", value: "502204103107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "171"}, {name: "gene", type: "uint256", value: "103503310503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "172"}, {name: "gene", type: "uint256", value: "203103310203"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "173"}, {name: "gene", type: "uint256", value: "307108206308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "421"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "tokenId", type: "uint256", value: "174"}, {name: "gene", type: "uint256", value: "403406509107"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "122000000000000000"}, {name: "growthValue", type: "uint256", value: "131"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x299a68906be876695e69f004f3dc7bf213b4c140"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "425023739000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: generateGiveawayCrabs( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6578738", timeStamp: "1540440608", hash: "0x1dd23279e2a936f697ffcd88f87e4ebb25ec8514fcaa3d4c43a888b43a94d53e", nonce: "316", blockHash: "0x11349da5e5ad4dc9325ba6cbd2ca7ef84486458b2151117d90944fc289071203", transactionIndex: "75", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xec2435550000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3043046", gasUsed: "285134", confirmations: "1158818"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "generateGiveawayCrabs", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "generateGiveawayCrabs(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540440608 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "5051"}, {name: "gene", type: "uint256", value: "510410507310"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "120000000000000000"}, {name: "growthValue", type: "uint256", value: "122"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6578756", timeStamp: "1540440909", hash: "0xe7424610109cc8506c8ad9f2dd264c1c244f8a35d9e9c79947da184aa3b81b44", nonce: "317", blockHash: "0x360e3e2dcfc349b26c310d66ca48a82eb853b0561d26c84a0436e2bde7ebcd8c", transactionIndex: "174", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "123000000000000000", gas: "1000000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6856826", gasUsed: "34688", confirmations: "1158800"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "123000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540440909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6578767", timeStamp: "1540441066", hash: "0x20c796755c79d734f3af0e5d06a1a30e6416bffef0e7f465cdf41cc9d53d4afe", nonce: "318", blockHash: "0x8d6c62d5bc1bab0c6b2c4473fa74927c9fe10aaf05a14479dabe23d5087db244", transactionIndex: "103", from: "0xb7784f0b98d049bb73435044c5879cc78365f168", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "125000000000000000", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4223042", gasUsed: "348822", confirmations: "1158789"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "125000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "1"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540441066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "amount", type: "uint256", value: "1"}, {name: "cryptant", type: "uint256", value: "3000"}, {name: "refund", type: "uint256", value: "1000000000000000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "tokenId", type: "uint256", value: "175"}, {name: "gene", type: "uint256", value: "509203508206"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "212"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "amount", type: "uint256", value: "3000"}, {name: "newBalance", type: "uint256", value: "3000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "refundReceiver", type: "address"}, {indexed: false, name: "reqAmt", type: "uint256"}, {indexed: false, name: "paid", type: "uint256"}, {indexed: false, name: "refundAmt", type: "uint256"}], name: "Refund", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Refund", events: [{name: "refundReceiver", type: "address", value: "0xb7784f0b98d049bb73435044c5879cc78365f168"}, {name: "reqAmt", type: "uint256", value: "124000000000000000"}, {name: "paid", type: "uint256", value: "125000000000000000"}, {name: "refundAmt", type: "uint256", value: "1000000000000000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5097800077933637895" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6578853", timeStamp: "1540442162", hash: "0x698a11235e972605e63620afd41be85987d9649045b07e3a5333d3cca536a1ab", nonce: "0", blockHash: "0xd4f310191d971c6361a4539694fbc226fbeaea7b01938af71a10b398a2bd137f", transactionIndex: "44", from: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1240000000000000000", gas: "4234120", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5527139", gasUsed: "2843387", confirmations: "1158703"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "1240000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540442162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "176"}, {name: "gene", type: "uint256", value: "103308210309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "431"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "177"}, {name: "gene", type: "uint256", value: "204206404207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "178"}, {name: "gene", type: "uint256", value: "301507104208"}, {name: "specialSkin", type: "uint256", value: "3"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "124"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "179"}, {name: "gene", type: "uint256", value: "409210206309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "511"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "180"}, {name: "gene", type: "uint256", value: "507507510504"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "181"}, {name: "gene", type: "uint256", value: "104303407304"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "232"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "182"}, {name: "gene", type: "uint256", value: "207204303505"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "183"}, {name: "gene", type: "uint256", value: "310304504110"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "222"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "184"}, {name: "gene", type: "uint256", value: "408110108207"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "tokenId", type: "uint256", value: "185"}, {name: "gene", type: "uint256", value: "508201308309"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "132"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x75e1e4312e09f6d30343dce547d58899b3ac32d7"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "3582612254000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6578902", timeStamp: "1540442866", hash: "0xfb44d2ca0e3837de84943bf147961ac696a270d2db21f1005e8fbc42a1e890bf", nonce: "2150", blockHash: "0x63468d2af162cb752cfbf7b2c64db604b970045f8405d8cc3c6c4e5d9f0ac153", transactionIndex: "111", from: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "496000000000000000", gas: "1698984", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a10000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4746388", gasUsed: "1135592", confirmations: "1158654"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "496000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "4"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540442866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "4"}, {name: "cryptant", type: "uint256", value: "12000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "186"}, {name: "gene", type: "uint256", value: "108406204204"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "322"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "187"}, {name: "gene", type: "uint256", value: "204403510506"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "223"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "188"}, {name: "gene", type: "uint256", value: "308110406308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "123"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "tokenId", type: "uint256", value: "189"}, {name: "gene", type: "uint256", value: "408110310303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "311"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x2e0ce5513f4b3a48a8a4e30ff69e24714f5cd5fa"}, {name: "amount", type: "uint256", value: "12000"}, {name: "newBalance", type: "uint256", value: "51000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "153289113876871365" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6578940", timeStamp: "1540443440", hash: "0x73e189b144ccdf6d41052edb642c9483a42484026d84f1a715338589e8843f61", nonce: "1", blockHash: "0xbdd65f945037dc389d7907c31a6c49e3cbf1ed88e356ac88eda39df094ba3537", transactionIndex: "28", from: "0x3163fa406a301c2eb69a8235365e4b513ffac157", to: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e", value: "1240000000000000000", gas: "4217892", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xefef39a1000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4648718", gasUsed: "2831555", confirmations: "1158616"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "1240000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amount", value: "10"}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540443440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "cryptant", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "PresalePurchased", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PresalePurchased", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "amount", type: "uint256", value: "10"}, {name: "cryptant", type: "uint256", value: "30000"}, {name: "refund", type: "uint256", value: "0"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "gene", type: "uint256"}, {indexed: false, name: "specialSkin", type: "uint256"}, {indexed: false, name: "crabPrice", type: "uint256"}, {indexed: false, name: "growthValue", type: "uint256"}], name: "CrabHatched", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "190"}, {name: "gene", type: "uint256", value: "505208205308"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "224"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "191"}, {name: "gene", type: "uint256", value: "106310108404"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "192"}, {name: "gene", type: "uint256", value: "208106203410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "233"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "193"}, {name: "gene", type: "uint256", value: "303205210410"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "313"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "194"}, {name: "gene", type: "uint256", value: "402503404205"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "422"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "195"}, {name: "gene", type: "uint256", value: "509506206303"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "196"}, {name: "gene", type: "uint256", value: "104208405406"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "133"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "197"}, {name: "gene", type: "uint256", value: "208410201109"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "113"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "198"}, {name: "gene", type: "uint256", value: "305108303503"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "323"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}, {name: "CrabHatched", events: [{name: "owner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "tokenId", type: "uint256", value: "199"}, {name: "gene", type: "uint256", value: "403304305210"}, {name: "specialSkin", type: "uint256", value: "0"}, {name: "crabPrice", type: "uint256", value: "124000000000000000"}, {name: "growthValue", type: "uint256", value: "142"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "cryptantOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "newBalance", type: "uint256"}], name: "CryptantFragmentsAdded", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CryptantFragmentsAdded", events: [{name: "cryptantOwner", type: "address", value: "0x3163fa406a301c2eb69a8235365e4b513ffac157"}, {name: "amount", type: "uint256", value: "30000"}, {name: "newBalance", type: "uint256", value: "30000"}], address: "0x9b00fc5dc3bc5f6e6d016c19512d6d96767e319e"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "2294359237000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "999999999999794" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
