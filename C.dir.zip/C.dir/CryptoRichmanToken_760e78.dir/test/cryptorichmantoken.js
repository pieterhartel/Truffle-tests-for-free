const CryptoRichmanToken = artifacts.require( "./CryptoRichmanToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CryptoRichmanToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5b366F606Dab2A1E221Da2588F62BFe454760e78", "0x26D5B6451048cb11a62abe605E85CB0966F0e322", "0xFE0e71341Ca81E3E0713a25d6A2b1247A46696C1", "0xebA6Ab2D4e7F3361C060400363772C2330Bd2cbb", "0x7B2e64CD7b6F924Ed3b7F17498450c6400596409", "0x68daeF1E1397337Df951180B43B712342b14828F", "0x3a831b9084b1c2f7443632d59208A4123258BC6B", "0xE87c831DBF2d7E3bB400ADB29840a2e578cF09D8", "0xd0D110A2711AcC53Bf49ad3eCF6a4CE87aE657e3", "0x6E71248522f4891c0e6f88Ed1A9fDBa08e7AE923", "0x49B3db0fD5b98924d42dfad18A11C08f7d7A3e5F", "0x02f6Cc9146c81954621086f2570ed536c2829995", "0xfD5dCF65e72cec3ed611314fA5CaC3A259570b58", "0x95AB4Cf6bB283c0A6964109864AE7B5C9fd5F4b0", "0x5FEBE26A5c92a0B647F821890E81fd92faD0BEAE", "0xE0E16F675F0f964fa9A6D0155EB5B242c68648A8", "0xaF207BafF884f3cE95c2BfCBB60B6e2d023e8041", "0x9eDA37DC9F6E57fe57bC5e996aa596Cec1F15b5A", "0x3520a15D0De2C9071Cce17B0Aa52bdd7Ce88C863", "0x09C3b22d5bCa15701fBfEe4Af43CEDFA08BE6B14", "0xA09295a2C73Fc991D2AFBb1E928bBaA594a3a4cA", "0xcA80A9374ce92a33B3251EF074CC03e1075dd017", "0xD9be46365e14071277Db563248c1D050191b1f54", "0x4740F1136283feE975028DbcEc0ed8154f48f3ab", "0xA0b16233C92efD4f8A458A5624E44110bA76a2bf", "0x05e66EB895d9BEDaF6c5fc9d44C2f4AC80Bb3fdd", "0x95D4BB8e5a1fFcbB5D00c70f3100Ee90048dC6Ea", "0x737BE443d4bbAAfedfC29b68D98D7da4a93DC512", "0x49681aDF3579Ac627CC8980a767E9a4aF13D50d7", "0xB878Ad746D979F937Be7C44D17E8fB917a39EDD8", "0xaFD5B3B59B26F506F3245533cbE477d04cbd9022", "0x7CDa428A58a2c4BBbb2E53F2b79B6cFB3AB8e66e", "0x4ee0Cacf3Dc35a9e75a84979Dd2623e912df2eC4", "0x477D6A3dE23732e785EF7f16c1Bfa318a2265DAc", "0x67f7D2e1c464227af1fcd37799c0d26c36870077", "0x7bf6155e92950D0843d4722DfE37d854B2d839bF", "0xdb87696910aC4005514dAFdECC2312e2AAf4FA87", "0x23a7f49DcD170407E84eBA82E0733452dB537d9B", "0x05cFB777df05B06Bb3e479AA8210C8C956c4458c", "0x399D60b1B015BD4E462E0A6f2be8d53a429206BF", "0x8ffC084C141207F505DB46e8E068e04860f2524a", "0x30CF88F1b9e8fE889fb5CCa136e6185Fc0464475"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ethereumToSpend", type: "uint256"}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokensToSell", type: "uint256"}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_includeReferralBonus", type: "bool"}], name: "myDividends", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onTokenPurchase(address,uint256,uint256,address,uint256,uint256)", "onTokenSell(address,uint256,uint256,uint256,uint256)", "onReinvestment(address,uint256,uint256)", "onWithdraw(address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8032875b28d82ddbd303a9e4e5529d047a14ecb6290f80012a81b7e6227ff1ab", "0x8d3a0130073dbd54ab6ac632c05946df540553d3b514c9f8165b4ab7f2b1805e", "0xbe339fc14b041c2b0e0f3dd2cd325d0c3668b78378001e53160eab3615326458", "0xccad973dcd043c7d680389db4378bd6b9775db7124092e9e0422c9e46d7985dc", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6618180 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6619909 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "CryptoRichmanToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dividendsOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ethereumToSpend", value: random.range( maxRandom )}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateTokensReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokensToSell", value: random.range( maxRandom )}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateEthereumReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakingRequirement()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bool", name: "_includeReferralBonus", value: ( random.range( 2 ) === 0 )}], name: "myDividends", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myDividends(bool)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEthereumBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CryptoRichmanToken", function( accounts ) {

	it( "TEST: CryptoRichmanToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6618180", timeStamp: "1540998141", hash: "0xb9804047d62754c9ad710d4f34e9813ed53d7033bf30728a9ad37d20ab70c56e", nonce: "0", blockHash: "0x46e5074de22f2d605a5fd32efbc95dea1baaeda05aa05c3aed765ad2572dea85", transactionIndex: "11", from: "0xfe0e71341ca81e3e0713a25d6a2b1247a46696c1", to: 0, value: "0", gas: "2028198", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x838be54a", contractAddress: "0x5b366f606dab2a1e221da2588f62bfe454760e78", cumulativeGasUsed: "4721282", gasUsed: "2028198", confirmations: "1108040"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "CryptoRichmanToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CryptoRichmanToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540998141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CryptoRichmanToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1746218000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618270", timeStamp: "1540999455", hash: "0x8ebe186f12071899f11ab02ee4d2015e28ae7e43e627b0b4267e78201c1ec36c", nonce: "0", blockHash: "0x4d5c9e045ae1272a4fbbef28dadabb1bf18b7aab0c9e15443b1e13bd07361f7a", transactionIndex: "25", from: "0xeba6ab2d4e7f3361c060400363772c2330bd2cbb", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "71000000000000000000", gas: "198241", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1141512", gasUsed: "132161", confirmations: "1107950"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "71000000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540999455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xeba6ab2d4e7f3361c060400363772c2330bd2cbb"}, {name: "incomingEthereum", type: "uint256", value: "71000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "113038662530788041163477"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1540999455"}, {name: "price", type: "uint256", value: "1243506000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "9326702341856004" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618277", timeStamp: "1540999571", hash: "0xdbfeb0e67b97e939769c73d2fd1dbb18a8d7c006f320ae367e2c85050cbbd55f", nonce: "3", blockHash: "0x3cf84e6becc6cefeb2a713d80c87fefb5c36c48863b47d8491dabcc7d7965ae4", transactionIndex: "71", from: "0x68daef1e1397337df951180b43b712342b14828f", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "38000000000000000000", gas: "192313", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5247423", gasUsed: "108209", confirmations: "1107943"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "38000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540999571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x68daef1e1397337df951180b43b712342b14828f"}, {name: "incomingEthereum", type: "uint256", value: "38000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "27022748185317763322936"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1540999571"}, {name: "price", type: "uint256", value: "1540759000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1083360660033417" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618278", timeStamp: "1540999580", hash: "0xc094db3cac569997c510871a1143d0bf58e774efc4588f3054fc71f717b9f517", nonce: "5", blockHash: "0xa6ac92bcff26b7ce506ce59594015e65d6719ecf5436719a51cc23462b61f2f7", transactionIndex: "42", from: "0x3a831b9084b1c2f7443632d59208a4123258bc6b", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "46000000000000000000", gas: "192313", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1892319", gasUsed: "108209", confirmations: "1107942"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "46000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540999580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x3a831b9084b1c2f7443632d59208a4123258bc6b"}, {name: "incomingEthereum", type: "uint256", value: "46000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "26961520468137022953567"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1540999580"}, {name: "price", type: "uint256", value: "1837330000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1526829126207362" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618281", timeStamp: "1540999676", hash: "0x48963bff8411f1ab7110dfedaa32fca33e8f74cbbeafabf813d903eb495b3d85", nonce: "6", blockHash: "0x6f04f2cda9aa9af73de7d72fc6d07453da4f4005d0ff9da2f99ca14a3bc91e80", transactionIndex: "86", from: "0xe87c831dbf2d7e3bb400adb29840a2e578cf09d8", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "59000000000000000000", gas: "199765", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "6027783", gasUsed: "108209", confirmations: "1107939"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "59000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540999676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xe87c831dbf2d7e3bb400adb29840a2e578cf09d8"}, {name: "incomingEthereum", type: "uint256", value: "59000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "29232195876068118672118"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1540999676"}, {name: "price", type: "uint256", value: "2158893000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1351480981015261" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618291", timeStamp: "1540999773", hash: "0xc5e3a2c101933f7f3b58a17f03000730b791e2246e057cf1407b3fc4129eda0c", nonce: "11", blockHash: "0xf659bb4806ad8457b76c944f11863b62d4cb1e4552ab9ecc91d2d2768687fc43", transactionIndex: "35", from: "0xd0d110a2711acc53bf49ad3ecf6a4ce87ae657e3", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "62000000000000000000", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "3281324", gasUsed: "108330", confirmations: "1107929"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "62000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540999773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xd0d110a2711acc53bf49ad3ecf6a4ce87ae657e3"}, {name: "incomingEthereum", type: "uint256", value: "62000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "26624980616095365951079"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1540999773"}, {name: "price", type: "uint256", value: "2451768000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "31377877466251887" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618312", timeStamp: "1541000114", hash: "0xb0c9c329eeadaa647fae38bb8aa3a8b2d895d9885011e40fe0b528031608a78c", nonce: "22", blockHash: "0x6d7c0dacd3030de15b87d4d51822c1b917a43d08c2b1e794ca617f1ea56a2328", transactionIndex: "32", from: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "968076578066809077", gas: "50000", gasPrice: "16000000000", isError: "1", txreceipt_status: "0", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "7109641", gasUsed: "50000", confirmations: "1107908"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "968076578066809077" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618325", timeStamp: "1541000289", hash: "0x3f60e19465a330b1ec4615a3c7d172796dfcad5a1dadd305133e89d21061cb8a", nonce: "23", blockHash: "0x4870e6003a5d252a12242f0349c21528b52b9a9d8978467ee25f1037bfd375ff", transactionIndex: "36", from: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "967276578066809077", gas: "162495", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "2529506", gasUsed: "108330", confirmations: "1107895"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "967276578066809077" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541000289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923"}, {name: "incomingEthereum", type: "uint256", value: "967276578066809077"}, {name: "tokensMinted", type: "uint256", value: "390231547744871673057"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541000289"}, {name: "price", type: "uint256", value: "2456058000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618341", timeStamp: "1541000520", hash: "0x02fb16b6cb146135c9ef23c60e25c9dfab6f228aee918b46ff7e1e3c79090738", nonce: "13", blockHash: "0xe0586551bf70638fe94567dde51117b904193a5181e1b885128a237eb6a05673", transactionIndex: "211", from: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "500000000000000000", gas: "200000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "6476196", gasUsed: "108330", confirmations: "1107879"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541000520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "201449483680724994004"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541000520"}, {name: "price", type: "uint256", value: "2458269000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8396166757665645" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6618356", timeStamp: "1541000683", hash: "0x4661680eb295e3c0f2023bec114232099a0f81bd8eadd51ba8ef1a51c7164678", nonce: "38", blockHash: "0xe40fe1cb5e2e0cc10663129d09604def36114d2f082fc9a10561380c5c5a0d05", transactionIndex: "31", from: "0x02f6cc9146c81954621086f2570ed536c2829995", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "5040238665717397407", gas: "185106", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000006e71248522f4891c0e6f88ed1a9fdba08e7ae923", contractAddress: "", cumulativeGasUsed: "1100226", gasUsed: "123404", confirmations: "1107864"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5040238665717397407" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[11]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541000683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x02f6cc9146c81954621086f2570ed536c2829995"}, {name: "incomingEthereum", type: "uint256", value: "5040238665717397407"}, {name: "tokensMinted", type: "uint256", value: "2020656609023041705003"}, {name: "referredBy", type: "address", value: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923"}, {name: "timestamp", type: "uint256", value: "1541000683"}, {name: "price", type: "uint256", value: "2480500000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618374", timeStamp: "1541000964", hash: "0x95f27c5bc63937142d3b67e0358539b1a2bb4bc2a7276d84bd204ac36c642888", nonce: "0", blockHash: "0x5c0ace1386e38c86587dc611953a2ddde6ffb87b8b7b4c6baf261b7d4df039b8", transactionIndex: "102", from: "0xfd5dcf65e72cec3ed611314fa5cac3a259570b58", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "370000000000000000", gas: "200000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5067115", gasUsed: "108330", confirmations: "1107846"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "370000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541000964 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xfd5dcf65e72cec3ed611314fa5cac3a259570b58"}, {name: "incomingEthereum", type: "uint256", value: "370000000000000000"}, {name: "tokensMinted", type: "uint256", value: "147621919742958732275"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541000964"}, {name: "price", type: "uint256", value: "2482128000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6618376", timeStamp: "1541000985", hash: "0x98fc337a900320f43693bfb9749e75e588ef9bfb2fcc9dff08c14c3fe0171a06", nonce: "8", blockHash: "0xec88255f87d9f5bb7b2a66124a7ae443942a41479553441cb652116f53224d3c", transactionIndex: "23", from: "0x95ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1129883647453778216", gas: "185106", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000002f6cc9146c81954621086f2570ed536c2829995", contractAddress: "", cumulativeGasUsed: "5499055", gasUsed: "123404", confirmations: "1107844"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1129883647453778216" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[13]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541000985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x95ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0"}, {name: "incomingEthereum", type: "uint256", value: "1129883647453778216"}, {name: "tokensMinted", type: "uint256", value: "450202335162746100629"}, {name: "referredBy", type: "address", value: "0x02f6cc9146c81954621086f2570ed536c2829995"}, {name: "timestamp", type: "uint256", value: "1541000985"}, {name: "price", type: "uint256", value: "2487078000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618382", timeStamp: "1541001073", hash: "0xd8e7a6779ba20bfbec414ebd522d901e62a94f9fba0bce7d8a73952d51078872", nonce: "24", blockHash: "0x6eadecbf43afb6f167f0ebab47ef109963bb55bcf90c14090007f2274dceda12", transactionIndex: "15", from: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "0", gas: "136632", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "539603", gasUsed: "76088", confirmations: "1107838"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541001073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923"}, {name: "incomingEthereum", type: "uint256", value: "201887072582459905"}, {name: "tokensMinted", type: "uint256", value: "80347576322305809526"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1541001073"}, {name: "price", type: "uint256", value: "2487958000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x6e71248522f4891c0e6f88ed1a9fdba08e7ae923"}, {name: "ethereumReinvested", type: "uint256", value: "201887072582459905"}, {name: "tokensMinted", type: "uint256", value: "80347576322305809526"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618389", timeStamp: "1541001155", hash: "0xcfb0e6270223e8ab30e4a21e113e7bf51731d78ab7c9dd3f703f556624a9e89c", nonce: "0", blockHash: "0xc1378ebd2c216f945fec2ffd0fe804f8bf849549e0f8f09f987a0a6e0dfc5ac9", transactionIndex: "92", from: "0x5febe26a5c92a0b647f821890e81fd92fad0beae", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1400000000000000000", gas: "162495", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5591076", gasUsed: "108330", confirmations: "1107831"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "1400000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541001155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5febe26a5c92a0b647f821890e81fd92fad0beae"}, {name: "incomingEthereum", type: "uint256", value: "1400000000000000000"}, {name: "tokensMinted", type: "uint256", value: "556392564684663287877"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541001155"}, {name: "price", type: "uint256", value: "2494085000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "123365313645000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6618391", timeStamp: "1541001178", hash: "0x0518b6f627a7dc379c10342df6a613980960dd43c97d65cdbf2c8578d0afed30", nonce: "3", blockHash: "0x1ddab8d6425bf37dfb2afe5569098f485e1a350246b4d6daa55b2cddd3e80a6b", transactionIndex: "47", from: "0xe0e16f675f0f964fa9a6d0155eb5b242c68648a8", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "404843343540207408", gas: "185106", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000095ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0", contractAddress: "", cumulativeGasUsed: "2923926", gasUsed: "123404", confirmations: "1107829"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "404843343540207408" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541001178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xe0e16f675f0f964fa9a6d0155eb5b242c68648a8"}, {name: "incomingEthereum", type: "uint256", value: "404843343540207408"}, {name: "tokensMinted", type: "uint256", value: "160639846069624870776"}, {name: "referredBy", type: "address", value: "0x95ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0"}, {name: "timestamp", type: "uint256", value: "1541001178"}, {name: "price", type: "uint256", value: "2495845000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "29124951000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6618427", timeStamp: "1541001770", hash: "0x32d21cdb616af82003ce4a3a9f7b33ec45470d9464ccb0cf20260826cc8bd0a2", nonce: "8", blockHash: "0xd6569ebf9ecd44028b5d1ab30dca84a1bf20ed9645b801b4c66506afdcb19e1f", transactionIndex: "29", from: "0xaf207baff884f3ce95c2bfcbb60b6e2d023e8041", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "2079268506534752489", gas: "140000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000095ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0", contractAddress: "", cumulativeGasUsed: "1075410", gasUsed: "108404", confirmations: "1107793"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "2079268506534752489" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[15]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541001770 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xaf207baff884f3ce95c2bfcbb60b6e2d023e8041"}, {name: "incomingEthereum", type: "uint256", value: "2079268506534752489"}, {name: "tokensMinted", type: "uint256", value: "823257927720016176418"}, {name: "referredBy", type: "address", value: "0x95ab4cf6bb283c0a6964109864ae7b5c9fd5f4b0"}, {name: "timestamp", type: "uint256", value: "1541001770"}, {name: "price", type: "uint256", value: "2504898000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618431", timeStamp: "1541001805", hash: "0xa918b40b24c855fbaedf13a8f83691a1028baf47b6def5108e95b78abc364913", nonce: "31", blockHash: "0x995043c0f7d0dc41fc2bff6cc207288ac6a42e4d59942f5b7d7169f189610fee", transactionIndex: "169", from: "0x9eda37dc9f6e57fe57bc5e996aa596cec1f15b5a", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "2600000000000000000", gas: "162495", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5785413", gasUsed: "108330", confirmations: "1107789"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "2600000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541001805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9eda37dc9f6e57fe57bc5e996aa596cec1f15b5a"}, {name: "incomingEthereum", type: "uint256", value: "2600000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1025265610395709188054"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541001805"}, {name: "price", type: "uint256", value: "2516184000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6618487", timeStamp: "1541002514", hash: "0x9f7b86c75a0485428b131dab2c91c24911921bf8b96b6a9d83e2b367d24faa72", nonce: "0", blockHash: "0x97550d2a668cf193059e572d9c65c539f1504d301c260137e70bb2f0791c6256", transactionIndex: "55", from: "0x3520a15d0de2c9071cce17b0aa52bdd7ce88c863", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "480000000000000000", gas: "185106", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000049b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", contractAddress: "", cumulativeGasUsed: "6970231", gasUsed: "123404", confirmations: "1107733"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "480000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541002514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x3520a15d0de2c9071cce17b0aa52bdd7ce88c863"}, {name: "incomingEthereum", type: "uint256", value: "480000000000000000"}, {name: "tokensMinted", type: "uint256", value: "188777722054066788961"}, {name: "referredBy", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "timestamp", type: "uint256", value: "1541002514"}, {name: "price", type: "uint256", value: "2518252000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618545", timeStamp: "1541003295", hash: "0x6c421e708c1f553aec2f515c8df2adb87263b5b839cdd399241862b894e27de0", nonce: "14", blockHash: "0x53e83be3e9cde5885fddd2ddd8beb65823a760fa5324e0a910b1d28d93c3fa9d", transactionIndex: "132", from: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "0", gas: "136632", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "6266516", gasUsed: "76088", confirmations: "1107675"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541003295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "incomingEthereum", type: "uint256", value: "19452510323522968"}, {name: "tokensMinted", type: "uint256", value: "7647135937566479955"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1541003295"}, {name: "price", type: "uint256", value: "2518340000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "ethereumReinvested", type: "uint256", value: "19452510323522968"}, {name: "tokensMinted", type: "uint256", value: "7647135937566479955"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8396166757665645" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618597", timeStamp: "1541004061", hash: "0xa20be93b8ab57227b64e9f40638356bb213d974a190fbbf03f3c10dd0b8ac19f", nonce: "63", blockHash: "0x4c284aa71764e16305904a02ee89b1390ff4c45c1d068c1da5b94b3041588089", transactionIndex: "31", from: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1000000000000000000", gas: "162495", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1553922", gasUsed: "108330", confirmations: "1107623"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541004061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "392774716519675657235"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541004061"}, {name: "price", type: "uint256", value: "2522663000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618636", timeStamp: "1541004668", hash: "0x345f66fb7600a81c27598d294040bcb6f5b299f4566781c96dc2909cdf2017ca", nonce: "300", blockHash: "0xd34d27ed1320c172d2c00a4b4e57c148018bde2f83888c5943fa7560b4b65559", transactionIndex: "37", from: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "10000000000000000000", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5747511", gasUsed: "108330", confirmations: "1107584"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541004668 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca"}, {name: "incomingEthereum", type: "uint256", value: "10000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "3891369273706761529691"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541004668"}, {name: "price", type: "uint256", value: "2565464000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "35035429406606000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6618794", timeStamp: "1541006846", hash: "0x34474b47fbcf0eb3d23a4aaad6ccc824741c09f44fb0c58bc4b49ac83d6bb117", nonce: "98", blockHash: "0x74a29210a4fdab766bfca5dc2371f949c3847a61032916fadd24678bbb1ef648", transactionIndex: "119", from: "0xca80a9374ce92a33b3251ef074cc03e1075dd017", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "120000000000000000", gas: "51000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "5964529", gasUsed: "51000", confirmations: "1107426"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "2170990575322097625" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618794", timeStamp: "1541006846", hash: "0xe074dc54ae44d70613621188291bd902f5674a36c363de8032f8a0c3ed2944c2", nonce: "16", blockHash: "0x74a29210a4fdab766bfca5dc2371f949c3847a61032916fadd24678bbb1ef648", transactionIndex: "142", from: "0xd9be46365e14071277db563248c1d050191b1f54", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1000000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "6900371", gasUsed: "108330", confirmations: "1107426"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541006846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xd9be46365e14071277db563248c1d050191b1f54"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "385571853480003160483"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541006846"}, {name: "price", type: "uint256", value: "2569710000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "985269958911125405" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6618799", timeStamp: "1541006941", hash: "0xecf7c9d5baacfe3d16e72dbf94c8609c6e040d299544c38cf2253a9906a4c065", nonce: "99", blockHash: "0x079c9154dd33b8704abb826b16decf68a3800f3de0b327ea7851a016fce11025", transactionIndex: "174", from: "0xca80a9374ce92a33b3251ef074cc03e1075dd017", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "120000000000000000", gas: "210000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "7510576", gasUsed: "123404", confirmations: "1107421"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541006941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xca80a9374ce92a33b3251ef074cc03e1075dd017"}, {name: "incomingEthereum", type: "uint256", value: "120000000000000000"}, {name: "tokensMinted", type: "uint256", value: "46225866304075685777"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541006941"}, {name: "price", type: "uint256", value: "2570216000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "2170990575322097625" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6618826", timeStamp: "1541007277", hash: "0xcde0f31da3c1ac45cfe92115d4292b7d09d68dfcf218dcabb0daa1b5e3d01c05", nonce: "100", blockHash: "0x752a0751b796ceb8042a643c950509b1f115acda1403bb96a7b42a59f0e8c24a", transactionIndex: "7", from: "0xca80a9374ce92a33b3251ef074cc03e1075dd017", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "90000000000000000", gas: "177606", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "312712", gasUsed: "78404", confirmations: "1107394"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541007277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xca80a9374ce92a33b3251ef074cc03e1075dd017"}, {name: "incomingEthereum", type: "uint256", value: "90000000000000000"}, {name: "tokensMinted", type: "uint256", value: "34663399146436512375"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541007277"}, {name: "price", type: "uint256", value: "2570601000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "2170990575322097625" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6618840", timeStamp: "1541007472", hash: "0xd8c652881ac22e73fba5c445388d16fec4b21e786c746bdfb1cee887df8aefbf", nonce: "34", blockHash: "0xe8310f8299d23e6a6a00ac9cef6cf1e46dff5ea4010e6740992b1b090d1da931", transactionIndex: "72", from: "0x4740f1136283fee975028dbcec0ed8154f48f3ab", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "300000000000000000", gas: "200000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000049b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", contractAddress: "", cumulativeGasUsed: "3464196", gasUsed: "123404", confirmations: "1107380"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541007472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x4740f1136283fee975028dbcec0ed8154f48f3ab"}, {name: "incomingEthereum", type: "uint256", value: "300000000000000000"}, {name: "tokensMinted", type: "uint256", value: "115507548568742949880"}, {name: "referredBy", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "timestamp", type: "uint256", value: "1541007472"}, {name: "price", type: "uint256", value: "2571866000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "6452361771028529603" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6618853", timeStamp: "1541007665", hash: "0xe81ed3c7a1e69470f5429ded83cf889039d4316eca54da4f9e70907e62054cd6", nonce: "101", blockHash: "0xfb07f88dbaa59470438d13e27eadeca151dee9942c075a32b6f4ef2a88aa0c55", transactionIndex: "216", from: "0xca80a9374ce92a33b3251ef074cc03e1075dd017", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "90000000000000000", gas: "127606", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "7914958", gasUsed: "78404", confirmations: "1107367"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541007665 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xca80a9374ce92a33b3251ef074cc03e1075dd017"}, {name: "incomingEthereum", type: "uint256", value: "90000000000000000"}, {name: "tokensMinted", type: "uint256", value: "34641138794734828076"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541007665"}, {name: "price", type: "uint256", value: "2572251000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "2170990575322097625" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6618862", timeStamp: "1541007796", hash: "0x990318fac42fa1ccaa163e092da08db50b5b5b03cc5a8fa18adfd0a923c3e646", nonce: "94", blockHash: "0xaee5e65d433fc5dfc801e959279db82e2b8ffaee32536f2d53f1decb8c2a289d", transactionIndex: "31", from: "0xa0b16233c92efd4f8a458a5624e44110ba76a2bf", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "100000000000000000", gas: "162495", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "2152128", gasUsed: "108330", confirmations: "1107358"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541007796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xa0b16233c92efd4f8a458a5624e44110ba76a2bf"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "38484136573532987347"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541007796"}, {name: "price", type: "uint256", value: "2572669000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "508729025951450469" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618880", timeStamp: "1541008108", hash: "0xe9c56ae2b65a6d78f2637c4dffd7c01d104bf2631fedee74c2536ac0a075d275", nonce: "39", blockHash: "0xc13661d06c07ce765ead8127ab36e4508b7255a461fe7eb4dd14e749bb570453", transactionIndex: "7", from: "0x02f6cc9146c81954621086f2570ed536c2829995", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "0", gas: "136632", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "512576", gasUsed: "76088", confirmations: "1107340"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541008108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x02f6cc9146c81954621086f2570ed536c2829995"}, {name: "incomingEthereum", type: "uint256", value: "49844280039050249"}, {name: "tokensMinted", type: "uint256", value: "19179776208675778507"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1541008108"}, {name: "price", type: "uint256", value: "2572889000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x02f6cc9146c81954621086f2570ed536c2829995"}, {name: "ethereumReinvested", type: "uint256", value: "49844280039050249"}, {name: "tokensMinted", type: "uint256", value: "19179776208675778507"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619113", timeStamp: "1541011137", hash: "0xfb4d57276b14cdd19686a11d9ac9a8be54b5dba1dac6232f2f9878a26c8865f2", nonce: "5", blockHash: "0x204b3c8ddac15228394368a39e453922ba6eef584c8481d1f5c7bbd2492ae277", transactionIndex: "99", from: "0x05e66eb895d9bedaf6c5fc9d44c2f4ac80bb3fdd", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "57308957030343194", gas: "162495", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "7321233", gasUsed: "108330", confirmations: "1107107"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "57308957030343194" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541011137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x05e66eb895d9bedaf6c5fc9d44c2f4ac80bb3fdd"}, {name: "incomingEthereum", type: "uint256", value: "57308957030343194"}, {name: "tokensMinted", type: "uint256", value: "22050195090142509403"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541011137"}, {name: "price", type: "uint256", value: "2573131000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "1121878882753630" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619158", timeStamp: "1541011688", hash: "0x9403f7b7e4ffd0fe2876145586e615c377d10522cb008352509612ca84cb9a3d", nonce: "6", blockHash: "0xa8b46c9091d5a88472bf071b1d8a070fdb6e15407339db14416d85ddcc1cda37", transactionIndex: "54", from: "0x05e66eb895d9bedaf6c5fc9d44c2f4ac80bb3fdd", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "31000000000000000", gas: "117495", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "7584038", gasUsed: "78330", confirmations: "1107062"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "31000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541011688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x05e66eb895d9bedaf6c5fc9d44c2f4ac80bb3fdd"}, {name: "incomingEthereum", type: "uint256", value: "31000000000000000"}, {name: "tokensMinted", type: "uint256", value: "11926694217748317765"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541011688"}, {name: "price", type: "uint256", value: "2573252000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "1121878882753630" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619176", timeStamp: "1541011980", hash: "0x6676579b1ce7aa5d2a192fe7bae4bf952c3b19fb052ed1a9c9bc6def3840b012", nonce: "166", blockHash: "0x9b4b519c939268b2ed97a914e85256e9a545d9bd56520f10b7d699fece9f4c37", transactionIndex: "38", from: "0x95d4bb8e5a1ffcbb5d00c70f3100ee90048dc6ea", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "260000000000000000", gas: "250000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "2829885", gasUsed: "108330", confirmations: "1107044"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "260000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541011980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x95d4bb8e5a1ffcbb5d00c70f3100ee90048dc6ea"}, {name: "incomingEthereum", type: "uint256", value: "260000000000000000"}, {name: "tokensMinted", type: "uint256", value: "100006412479636278547"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541011980"}, {name: "price", type: "uint256", value: "2574352000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "155380191409243096" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6619205", timeStamp: "1541012370", hash: "0x2cf633367b1e4c2d1c411d01a9c96f729eb264c6a6fcda66dc1fa8bfb2fa2660", nonce: "93", blockHash: "0x1a51cca2023b11854aa00642d6855bdcfd53287b41da0823103700f58bca1a8e", transactionIndex: "58", from: "0x737be443d4bbaafedfc29b68d98d7da4a93dc512", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "300000000000000000", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000a09295a2c73fc991d2afbb1e928bbaa594a3a4ca", contractAddress: "", cumulativeGasUsed: "2655877", gasUsed: "123404", confirmations: "1107015"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[22]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541012370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x737be443d4bbaafedfc29b68d98d7da4a93dc512"}, {name: "incomingEthereum", type: "uint256", value: "300000000000000000"}, {name: "tokensMinted", type: "uint256", value: "115338938978503679374"}, {name: "referredBy", type: "address", value: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca"}, {name: "timestamp", type: "uint256", value: "1541012370"}, {name: "price", type: "uint256", value: "2575628000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "669935699054830645" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619207", timeStamp: "1541012386", hash: "0x040b89900fe4fc0a2bf1c0c98aaa465976521867ba5589085a0970ebad23c7e7", nonce: "44", blockHash: "0x818045e2e636ab9f5147b540b26307a390ce55cf17dbe86389ff147586d5a93d", transactionIndex: "21", from: "0x49681adf3579ac627cc8980a767e9a4af13d50d7", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1040429467048825273", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "1122131", gasUsed: "108330", confirmations: "1107013"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "1040429467048825273" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541012386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x49681adf3579ac627cc8980a767e9a4af13d50d7"}, {name: "incomingEthereum", type: "uint256", value: "1040429467048825273"}, {name: "tokensMinted", type: "uint256", value: "399567328607923808254"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541012386"}, {name: "price", type: "uint256", value: "2580017000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "3139716388723916" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6619241", timeStamp: "1541012752", hash: "0x071ded52d37955f47d7be554d2ccac2ef46df1e5c47489db708288db215be397", nonce: "89", blockHash: "0x2c8b19815785cc8145cdf74baa1f53b52078c583fb1e3fd7cd5f41313d849eb3", transactionIndex: "20", from: "0xb878ad746d979f937be7c44d17e8fb917a39edd8", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "200000000000000000", gas: "162675", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "1031264", gasUsed: "108404", confirmations: "1106979"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541012752 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb878ad746d979f937be7c44d17e8fb917a39edd8"}, {name: "incomingEthereum", type: "uint256", value: "200000000000000000"}, {name: "tokensMinted", type: "uint256", value: "76730179114251829588"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541012752"}, {name: "price", type: "uint256", value: "2580864000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "34867846958195351" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6619250", timeStamp: "1541012890", hash: "0x5a6153e79c91b28293fd27cbafa5cac91508421bb174bf190b89c698109fc1b2", nonce: "102", blockHash: "0xb024e74626c87deb803323f3eb82ce745b8fe1bd58691206328398b0e53a58ce", transactionIndex: "8", from: "0xafd5b3b59b26f506f3245533cbe477d04cbd9022", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1000000000000000000", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000a09295a2c73fc991d2afbb1e928bbaa594a3a4ca", contractAddress: "", cumulativeGasUsed: "390588", gasUsed: "108404", confirmations: "1106970"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[22]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541012890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xafd5b3b59b26f506f3245533cbe477d04cbd9022"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "383275112545769947829"}, {name: "referredBy", type: "address", value: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca"}, {name: "timestamp", type: "uint256", value: "1541012890"}, {name: "price", type: "uint256", value: "2585077000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "73208091454647797" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6619329", timeStamp: "1541013929", hash: "0x9f564df3810a6963c9f366c11db41769a62bb648f7a95c09bcb2416838627a3b", nonce: "683", blockHash: "0xba834e0e2f65c38d3952daad215c9c14cf2c51858aba108ac11d057a3d155f81", transactionIndex: "61", from: "0x7cda428a58a2c4bbbb2e53f2b79b6cfb3ab8e66e", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "200000000000000000", gas: "162606", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000049b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", contractAddress: "", cumulativeGasUsed: "4170544", gasUsed: "108404", confirmations: "1106891"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[12]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541013929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7cda428a58a2c4bbbb2e53f2b79b6cfb3ab8e66e"}, {name: "incomingEthereum", type: "uint256", value: "200000000000000000"}, {name: "tokensMinted", type: "uint256", value: "76580037449084988018"}, {name: "referredBy", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "timestamp", type: "uint256", value: "1541013929"}, {name: "price", type: "uint256", value: "2585924000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "34670270841398512" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6619411", timeStamp: "1541015073", hash: "0xb972502389d11b6cc87bba4726cf46b0c349c3aad921caaa7deb2ce8e9f78664", nonce: "10", blockHash: "0xae6f2aa8218f290955cf3f25578ec83e7d5037bf9711f0724818df76e79dd4a4", transactionIndex: "87", from: "0x4ee0cacf3dc35a9e75a84979dd2623e912df2ec4", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1000000000000000000", gas: "162606", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "6431066", gasUsed: "108404", confirmations: "1106809"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541015073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x4ee0cacf3dc35a9e75a84979dd2623e912df2ec4"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "382526603224428069499"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541015073"}, {name: "price", type: "uint256", value: "2590137000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "116339080139532" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6619411", timeStamp: "1541015073", hash: "0x2503bf39fc73d607a2eecd9e1068b85a23b8a74f38b6c922bd02e3da09ce708f", nonce: "15", blockHash: "0xae6f2aa8218f290955cf3f25578ec83e7d5037bf9711f0724818df76e79dd4a4", transactionIndex: "102", from: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "0", gas: "136632", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "7586158", gasUsed: "76088", confirmations: "1106809"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541015073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "incomingEthereum", type: "uint256", value: "20302035171739293"}, {name: "tokensMinted", type: "uint256", value: "7759632589878368871"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1541015073"}, {name: "price", type: "uint256", value: "2590214000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x49b3db0fd5b98924d42dfad18a11c08f7d7a3e5f"}, {name: "ethereumReinvested", type: "uint256", value: "20302035171739293"}, {name: "tokensMinted", type: "uint256", value: "7759632589878368871"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8396166757665645" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6619553", timeStamp: "1541016918", hash: "0x472abb1232b60defb812e9514bf57ea82e15238c4b3c0cfe6227f3f00d648f1a", nonce: "12", blockHash: "0x96c024e72fdbfcd20728e1725c56afb783737df790c80ec199de9afd439b2390", transactionIndex: "93", from: "0x477d6a3de23732e785ef7f16c1bfa318a2265dac", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "20000000000000000", gas: "162606", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000009c3b22d5bca15701fbfee4af43cedfa08be6b14", contractAddress: "", cumulativeGasUsed: "7867614", gasUsed: "108404", confirmations: "1106667"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[21]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541016918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x477d6a3de23732e785ef7f16c1bfa318a2265dac"}, {name: "incomingEthereum", type: "uint256", value: "20000000000000000"}, {name: "tokensMinted", type: "uint256", value: "7643941833875760109"}, {name: "referredBy", type: "address", value: "0x09c3b22d5bca15701fbfee4af43cedfa08be6b14"}, {name: "timestamp", type: "uint256", value: "1541016918"}, {name: "price", type: "uint256", value: "2590302000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619594", timeStamp: "1541017555", hash: "0x5ba976a77951d29fe1f7c8c0300ea622f1666274d75ef5a57724cb30d3a3a87d", nonce: "2", blockHash: "0x32261bce787f64c7d0dac503b53de51607b06d97b8a8f10693606de4b5643478", transactionIndex: "91", from: "0x67f7d2e1c464227af1fcd37799c0d26c36870077", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "254000000000000000", gas: "162495", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "4245824", gasUsed: "108330", confirmations: "1106626"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "254000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541017555 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x67f7d2e1c464227af1fcd37799c0d26c36870077"}, {name: "incomingEthereum", type: "uint256", value: "254000000000000000"}, {name: "tokensMinted", type: "uint256", value: "97056484448333065050"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541017555"}, {name: "price", type: "uint256", value: "2591369000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "3856310000001776" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619642", timeStamp: "1541018111", hash: "0x5d781b0a7234d24d9ccea54fbd382fe2f7af4b7fd85d7043cce15bfbdae101c4", nonce: "127", blockHash: "0x51461c75fcb1b54da0b1d926814494a43c0ae2ff3adf1f219829f2e7c8efb14b", transactionIndex: "62", from: "0x7bf6155e92950d0843d4722dfe37d854b2d839bf", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "500000000000000000", gas: "150000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "3716514", gasUsed: "108330", confirmations: "1106578"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541018111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7bf6155e92950d0843d4722dfe37d854b2d839bf"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "190939337059396119297"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541018111"}, {name: "price", type: "uint256", value: "2593470000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "1042640770841422043" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6619661", timeStamp: "1541018412", hash: "0x6a838def0529b5a64750d03540ba93c287ed0c268c878f8c2355da8aabb97db3", nonce: "50", blockHash: "0xf47bff2f9f7bce39d4114ae24b738216e891b5088fe07596a48076e39e6e2486", transactionIndex: "106", from: "0xdb87696910ac4005514dafdecc2312e2aaf4fa87", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "400000000000000000", gas: "162606", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000a09295a2c73fc991d2afbb1e928bbaa594a3a4ca", contractAddress: "", cumulativeGasUsed: "6444713", gasUsed: "108404", confirmations: "1106559"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[22]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541018412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xdb87696910ac4005514dafdecc2312e2aaf4fa87"}, {name: "incomingEthereum", type: "uint256", value: "400000000000000000"}, {name: "tokensMinted", type: "uint256", value: "152640207062337412953"}, {name: "referredBy", type: "address", value: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca"}, {name: "timestamp", type: "uint256", value: "1541018412"}, {name: "price", type: "uint256", value: "2595153000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "9048517328431811" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6619701", timeStamp: "1541019013", hash: "0x85f7d7c86617ca0656fcca1d8f9da030062c9e0c6dfc42e906f1f9d9c423cf2e", nonce: "74", blockHash: "0x2319a8b9e6366735c714f43fe1627827e698aa5f332fb4b6b5f32a6635b09ef0", transactionIndex: "77", from: "0x23a7f49dcd170407e84eba82e0733452db537d9b", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "0", gas: "200000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6969447", gasUsed: "37480", confirmations: "1106519"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541019013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "7192490154079544" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619777", timeStamp: "1541020153", hash: "0xfa22dd7b233c304189d6ebb914908664bc2085736253c1855ac5159456b96084", nonce: "447", blockHash: "0x14c91ff5a7a1d0c080b61a4dfdcad2884353cb1f05d3d546720494762e619747", transactionIndex: "93", from: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "140000000000000000", gas: "150000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "3008682", gasUsed: "108330", confirmations: "1106443"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "140000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541020153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c"}, {name: "incomingEthereum", type: "uint256", value: "140000000000000000"}, {name: "tokensMinted", type: "uint256", value: "53400746629757142754"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541020153"}, {name: "price", type: "uint256", value: "2595736000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "96891230424468778" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6619796", timeStamp: "1541020479", hash: "0x2c11f0006a29c86e6884790a8fd06de6629bec4da1c6c73156339cfe6363ee0e", nonce: "110", blockHash: "0x2ee7a71197104b04943fe71f8c616c787575b77dbd22d6714d4cbf4d75eb6ef7", transactionIndex: "13", from: "0x399d60b1b015bd4e462e0a6f2be8d53a429206bf", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "50000000000000000", gas: "162606", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000a09295a2c73fc991d2afbb1e928bbaa594a3a4ca", contractAddress: "", cumulativeGasUsed: "586420", gasUsed: "108404", confirmations: "1106424"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[22]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541020479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x399d60b1b015bd4e462e0a6f2be8d53a429206bf"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "19068766863043429317"}, {name: "referredBy", type: "address", value: "0xa09295a2c73fc991d2afbb1e928bbaa594a3a4ca"}, {name: "timestamp", type: "uint256", value: "1541020479"}, {name: "price", type: "uint256", value: "2595945000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "10571725926382730" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619878", timeStamp: "1541021689", hash: "0x549ec4626a4839ad81acdb7970f453b2def3247f6869e80d8fdd7e2c3a876751", nonce: "128", blockHash: "0x71efd894730c41ad5aa8b2e28faf26bd3cd58212dd6073b8ff88e8f2f0d58c4d", transactionIndex: "5", from: "0x7bf6155e92950d0843d4722dfe37d854b2d839bf", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1300000000000000000", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "340782", gasUsed: "78330", confirmations: "1106342"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "1300000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541021689 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7bf6155e92950d0843d4722dfe37d854b2d839bf"}, {name: "incomingEthereum", type: "uint256", value: "1300000000000000000"}, {name: "tokensMinted", type: "uint256", value: "495248261373404053809"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541021689"}, {name: "price", type: "uint256", value: "2601390000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "1042640770841422043" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619883", timeStamp: "1541021787", hash: "0x0086cb07a005d39e5d43878f782c1b5229e3524b7a821db95f3d89fc44894581", nonce: "46", blockHash: "0xffd058e83b1c4382cf748925c80204fed7d9750c9991bf4b24e32ed1e50e88ea", transactionIndex: "76", from: "0x8ffc084c141207f505db46e8e068e04860f2524a", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "1500000000000000000", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "5445523", gasUsed: "108330", confirmations: "1106337"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541021787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x8ffc084c141207f505db46e8e068e04860f2524a"}, {name: "incomingEthereum", type: "uint256", value: "1500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "570154678431202196489"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541021787"}, {name: "price", type: "uint256", value: "2607660000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "99872937608152185" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6619906", timeStamp: "1541022059", hash: "0x5d9fb92fec1484b4332b84ee1e9c6a28dd1d4c337550a3ed287e671b62070562", nonce: "57", blockHash: "0xebd27db313a0fcf0046cd7f1ba2eb63ea6e879989cd7ac903b17ec43949bc658", transactionIndex: "92", from: "0x30cf88f1b9e8fe889fb5cca136e6185fc0464475", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "50000000000000000", gas: "162495", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000007b2e64cd7b6f924ed3b7f17498450c6400596409", contractAddress: "", cumulativeGasUsed: "4365437", gasUsed: "108330", confirmations: "1106314"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[6]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541022059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x30cf88f1b9e8fe889fb5cca136e6185fc0464475"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "18981541590253690516"}, {name: "referredBy", type: "address", value: "0x7b2e64cd7b6f924ed3b7f17498450c6400596409"}, {name: "timestamp", type: "uint256", value: "1541022059"}, {name: "price", type: "uint256", value: "2607869000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "302587569231229863" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6619909", timeStamp: "1541022128", hash: "0xb8ba0b94281463b8fa295c9893b61043b38c41e241bf6bcdcd130511d44cc889", nonce: "75", blockHash: "0x90c2a2f025b68bf0cd12680232a17985fc3757850a99205f13071d0cf9d8c781", transactionIndex: "113", from: "0x23a7f49dcd170407e84eba82e0733452db537d9b", to: "0x5b366f606dab2a1e221da2588f62bfe454760e78", value: "700000000000000000", gas: "200000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6836260", gasUsed: "105594", confirmations: "1106311"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "700000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541022128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x23a7f49dcd170407e84eba82e0733452db537d9b"}, {name: "incomingEthereum", type: "uint256", value: "700000000000000000"}, {name: "tokensMinted", type: "uint256", value: "265582189916296594156"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1541022128"}, {name: "price", type: "uint256", value: "2610795000000000"}], address: "0x5b366f606dab2a1e221da2588f62bfe454760e78"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "7192490154079544" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1664327518164829" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
